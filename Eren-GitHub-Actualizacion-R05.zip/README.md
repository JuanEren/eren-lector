# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 31.0.0 · revisión CI R05 · terreno R03 y borde v29 restaurado

La revisión R05 no cambia el juego. Corrige el extractor de locuciones para que la evaluación de `app.js` en Node disponga de un objeto `window` aislado, añade una regresión ejecutable sin credenciales y habilita el sistema de base permanente más actualizaciones GitHub menores de 20 MB. La versión Android y el registro jugable permanecen `31.0.0` / `GB01-v17` porque la ejecución anterior no produjo ninguna APK.

El premio de lectura incorpora dos escenas de validación en horizontal:

- Se integra el lote autorizado `UI-20260825-R02` / `UI_EDUCATIVA_R02_CANDIDATE` completo: 16 PNG RGBA, paneles, cuatro estados de botón, iconos e interfaz de puzle. El texto continúa siendo nativo y localizable; el hueco del puzle se deriva de la máscara alfa de la pieza activa. Estado: `INTEGRATED_TECHNICAL_QA_PASS`, pendiente de revisión 9-slice, legibilidad y escala táctil en dispositivo; `GAME_READY=false`.

- `GB_M1_01_UMBRAL`: tramo corto con caja inferior obligatoria, pilar vertical `U0`, salto, paso agachado, puzle cooperativo de Scar y Eren, ruta opcional con estrella, agua, daño, retorno y meta.
- `LAB_MOV_01`: seis estaciones para medir velocidad, salto vertical, hueco horizontal, colliders, seguimiento de Scar y daño/retorno.
- Física fija a 60 Hz, posiciones en módulos, aceleración/frenada, salto variable, *coyote time* y búfer de salto.
- La geometría funcional aprobada de G0–G3, U0–U3, caja, techo, puerta y peligros permanece intacta. `TERRAIN-MOUNT-20260825-R03` aporta nueve PNG precompuestos a 100 PPU: uno por cada sólido `G0`, `G1`, `G2`, `G3`, `U0`, `U1`, `U2`, `U3` y `TECHO_BAJO`.
- Cada sólido de terreno genera una única llamada de dibujo con su tamaño nativo. El runtime ya no rellena las plataformas repitiendo piezas `1×1` ni `0,5×0,5`; no estira, recorta o recompone los derivados autorizados.
- Eren vuelve a la referencia dorada v29 `ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN`: permanece apoyado mientras una de sus dos sondas inferiores, situadas a `±0,08` del ancho del collider, toca el suelo. Cuando ambas salen, cae conservando X y velocidad horizontal, sin empuje ni snap. La regla corporal de solape `2/3` queda retirada y no se aplica a Scar.
- Eren E1 y Scar S1 aportan temporalmente 10 PNG de reposo, caminar/andar y correr por personaje. El lote sigue `SUPERSEDED_CANDIDATE`; para evitar el deslizamiento perceptible, Eren mantiene temporalmente `reposo-00`, mientras Scar conserva su reposo animado de cola. Eren E2 y Scar S2 mantienen provisionalmente sus 6 PNG de salto. La siguiente integración espera `CANDIDATE_PLAYTEST_R02`; nada se promociona a `GAME_READY`.
- Los PNG se dibujan a 100 px por módulo, pivote inferior central y escala `(1,1)`, sin root motion. El renderer añade exclusivamente al dibujo `+6 px` para Eren y `+2 px` para Scar en el eje vertical de pantalla; colliders, pivotes y física permanecen intactos. Esta corrección de contacto no sustituye el lote de animación R02 pendiente.
- La entrada distingue una caja marrón rompible de `1 × 1` y un pilar gris permanente `U0_VERTICAL`. El PNG fuente de la caja mide `100×100`, su silueta ocupa `100×90`, toca la fila inferior y se dibuja sin aumento de escala en runtime.
- Los huecos G0→G1 y G1→G2 miden 1,5 módulos: caminar sin saltar falla y cada cruce admite un salto normal desde apoyo completo. `TECHO_BAJO` empieza 1,5 módulos después del aterrizaje de G1 para no convertirlo en una salida al límite. U1 conserva 1,5 módulos libres en el borde de salida; la ruta alta sigue siendo opcional y el canal U1→U2 mantiene 2 módulos.
- La placa es una superficie compartida, pero su sensor es exclusivo de Scar. Una pisada válida la deja enclavada. La palanca puede activarse antes o después; al cumplirse ambas condiciones, la compuerta queda abierta y Scar retoma automáticamente el seguimiento.
- La compuerta cerrada sella desde G2 hasta el techo del mundo, por lo que no ofrece una coronación utilizable desde G2, U1, U2 ni U3. Además, una salvaguarda de progresión devuelve a Eren al lado seguro ante cualquier cruce accidental y R2 no puede activarse hasta resolver el puzle.
- El agua mide `4` módulos y exige `CORRER + SALTAR`; los pinchos muestran dos puntas en `1` módulo, pero su collider interior deja margen para superarlos andando.
- Scar tiene movimiento, salto, descenso y recuperación propios; no copia la coordenada vertical de Eren. Anticipa los huecos ordinarios, mantiene un único salto activo y conserva su navegación separada de las sondas de Eren. En el tramo final espera antes de los pinchos hasta que Eren habilita el cruce y ejecuta un salto reservado; la aproximación genérica no puede dirigirla al peligro.
- La meta es una zona física de `2 × 0,5` al final de G3. La misión solo termina si Eren y Scar están simultáneamente dentro de ella y ambos apoyados en G3; reencontrarse en cualquier otro punto de la plataforma no completa el nivel.
- La orden de placa comprueba posición horizontal, altura y apoyo correctos. Eren sobre la placa no activa su sensor; la palanca se arma de forma independiente y la compuerta espera a que Scar haya pisado la placa una vez. Scar adopta automáticamente su postura baja al atravesar el túnel en ambos sentidos.
- Controles táctiles simultáneos, teclado y mando Android. La botonera táctil forma un rombo: Scar azul arriba, Correr verde a la izquierda, Acción roja a la derecha y Saltar amarillo abajo. `A` salta, `X/B` actúa, `R1/R2` corre y `Y/L1` ordena a Scar.
- Acceso directo desde la primera pantalla: durante el playtest no hace falta completar un cuento ni gastar una pieza.
- Ajuste vivo de andar, correr, impulso, gravedad, desnivel y hueco.
- Registro local `GB01-v17` con trazabilidad explícita de UI R02 y terreno R03, eventos `caida_borde_sondas_pie`, ruta segura de Scar, reanudación tras el puzle y presencia individual en la meta; conserva hasta diez intentos y permite copiar el JSON completo o un resumen compacto.

Reglas permanentes incorporadas al contrato: ningún hueco funcional puede aparentar salto si caminar ya lo supera, y ningún puzle obligatorio puede omitirse saltando, trepando o usando una plataforma alternativa. Ambas reglas se verifican con el controlador real y con pruebas desde todos los apoyos alcanzables.

La lectura y los menús siguen en vertical. El juego cambia a horizontal al entrar y restaura vertical al salir. El progreso de lectura no se modifica ni se consume durante el playtest. La ampliación reciente de cuentos se mantiene deliberadamente en su build específica y todavía no se ha fusionado con este paquete; el punto de integración futuro queda registrado en [`docs/PLAN_INTEGRACION_CUENTOS_GRAYBOX.md`](docs/PLAN_INTEGRACION_CUENTOS_GRAYBOX.md).

En la primera pantalla, pulsa **Probar juego**. Dentro del panel lateral, **Compartir registro** abre el menú de Android y **Ver registro** permite copiar el registro completo o **Copiar resumen** para enviar solo las métricas y anomalías relevantes. La velocidad inicial de Eren al correr permanece fijada en **6,0 módulos/s**.

La integración UI y sus pruebas están documentadas en [`docs/INTEGRACION_UI_EDUCATIVA_R02.md`](docs/INTEGRACION_UI_EDUCATIVA_R02.md). El montaje de terreno está documentado en [`docs/TERRAIN-MOUNT-20260825-R03/`](docs/TERRAIN-MOUNT-20260825-R03/). La corrección CI está documentada en [`docs/INTEGRACION_CI_R05.md`](docs/INTEGRACION_CI_R05.md). El contrato de animación permanece en [`docs/CONTRATO_ARTE_CANDIDATE_PLAYTEST_R02.md`](docs/CONTRATO_ARTE_CANDIDATE_PLAYTEST_R02.md). El registro identifica la build como `GB01-v17` / `31.0.0-graybox-terrain-r03-footprobe-candidate`. Estado máximo: `CANDIDATE_PLAYTEST`; `GAME_READY=false`; terreno R03 y UI R02 integrados como candidatos, con arte de locomoción `CANDIDATE_PLAYTEST_R02=PENDING` (`ART_R02_PENDING`).

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
