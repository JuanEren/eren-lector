# Integración CI R05 · Azure y actualización incremental

Fecha: 25/08/2026  
Lote: `CI-AZURE-20260825-R05`  
Base: `Eren-Leo-y-entiendo-Android.zip` v31 R04  
SHA-256 base: `155ba166ebc9e4e1d4b5f2d7f1aba3ca2fa511d4e9211cb38489d7c0242f60e9`

## Alcance

R05 corrige exclusivamente la canalización de compilación. No modifica física, mecánica de borde, colliders, geometría, sprites, terreno, UI, cuentos, preguntas ni frases.

## Fallo corregido

GitHub Actions #41 se detuvo en `scripts/generate-azure-audio.mjs` con `ReferenceError: window is not defined`. El script evaluaba la cabecera de `app.js` mediante `node:vm`; la UI R02 había añadido `window.__uiR02=UI_R02_PACK` antes de los catálogos.

La extracción se ha separado en `scripts/extract-audio-catalogue.mjs`. Su sandbox declara un objeto `window` sin prototipo y aplica un límite de ejecución. `tests/azure-catalogue-smoke.mjs` ejecuta la misma extracción sin claves Azure ni red y exige los 12 cuentos, cinco grupos de ampliaciones, cinco grupos de preguntas avanzadas, diez celebraciones, diecisiete frases y la identidad UI R02.

## Sistema incremental

La base v31 permanece en GitHub con el nombre estable `Eren-Leo-y-entiendo-Android.zip`. Cada revisión posterior se añade como `Eren-GitHub-Actualizacion-RNN.zip` en la raíz del repositorio.

El workflow exterior:

1. verifica el SHA-256 de la base;
2. descomprime la base en un directorio temporal;
3. ordena y aplica todas las actualizaciones RNN;
4. rechaza rutas absolutas o con `..`;
5. procesa la lista explícita de eliminaciones de cada revisión;
6. verifica los SHA-256 de los archivos resultantes;
7. ejecuta la regresión Node, el smoke completo, Azure si hay secretos y Gradle;
8. publica `app-debug.apk` como `Eren-Leo-y-entiendo-APK`.

R05 no borra ningún archivo. El paquete incremental debe permanecer por debajo de 20 MB; el ZIP maestro completo continúa en Drive y Biblioteca.

## Estado

- `AZURE_CATALOGUE_NODE_R05`: PASS local.
- `GRAYBOX_SMOKE_R04_REGRESSION`: PASS local.
- APK: pendiente de GitHub Actions.
- Estado máximo: `CANDIDATE_PLAYTEST`.
- `GAME_READY=false` hasta playtest Android.
