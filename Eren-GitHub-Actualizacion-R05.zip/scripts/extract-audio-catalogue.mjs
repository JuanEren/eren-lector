import fs from 'node:fs/promises';
import vm from 'node:vm';

const REQUIRED_ARRAYS = ['stories', 'levelAdditions', 'advancedQuestions', 'celebrations', 'gamePhrases'];

export async function extractAudioCatalogue(appFile) {
  const source = await fs.readFile(appFile, 'utf8');
  const runtimeMarker = source.indexOf('let story=');
  if (runtimeMarker < 0) throw new Error('No se encontró el límite del catálogo de lectura en app.js.');

  const dataSection = source.slice(0, runtimeMarker);
  const browserWindow = Object.create(null);
  const sandbox = { window: browserWindow };
  vm.createContext(sandbox);

  const expression = `${dataSection}\nJSON.stringify({stories,levelAdditions,advancedQuestions,celebrations,gamePhrases,uiPack:window.__uiR02||null})`;
  const encoded = vm.runInContext(expression, sandbox, { timeout: 2000, filename: 'app-catalogue.vm.js' });
  const catalogue = JSON.parse(encoded);

  for (const field of REQUIRED_ARRAYS) {
    if (!Array.isArray(catalogue[field])) throw new Error(`El catálogo de audio no contiene el array ${field}.`);
  }
  if (!catalogue.stories.length || !catalogue.celebrations.length || !catalogue.gamePhrases.length) throw new Error('El catálogo de audio está vacío o incompleto.');
  return catalogue;
}
