import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractAudioCatalogue } from '../scripts/extract-audio-catalogue.mjs';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const appFile = path.join(projectRoot, 'app/src/main/assets/www/app.js');
const catalogue = await extractAudioCatalogue(appFile);

const summary = {
  stories: catalogue.stories.length,
  levelAdditions: catalogue.levelAdditions.length,
  advancedQuestions: catalogue.advancedQuestions.length,
  celebrations: catalogue.celebrations.length,
  gamePhrases: catalogue.gamePhrases.length,
  uiPackage: catalogue.uiPack?.packageId ?? null,
};

if (summary.stories !== 12) throw new Error(`Se esperaban 12 cuentos y se extrajeron ${summary.stories}.`);
if (summary.levelAdditions !== 5 || summary.advancedQuestions !== 5) throw new Error('Las ampliaciones o preguntas avanzadas no coinciden con la base v31.');
if (summary.celebrations !== 10 || summary.gamePhrases !== 17) throw new Error('Las celebraciones o frases del juego no coinciden con la base v31.');
if (summary.uiPackage !== 'UI_EDUCATIVA_R02_CANDIDATE') throw new Error('La evaluación Node no conservó el paquete UI R02.');

console.log(JSON.stringify({ test: 'AZURE_CATALOGUE_NODE_R05', status: 'PASS', ...summary }, null, 2));
