# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 32.0.0 · actualización incremental R07

R07 corrige el playtest Android de `GB01-v17` sin ampliar todavía el nivel. La nueva candidata se identifica como `32.0.0-graybox-r07-mario-native-ui-drawer-candidate` / `GB01-v18`; permanece `CANDIDATE_PLAYTEST` y `GAME_READY=false`.

Cambios principales:

- Se restaura como ley `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`: Eren conserva el suelo mientras exista cualquier solape horizontal real. No hay sondas, umbral `2/3`, caída forzada, soporte ignorado, empuje, *snap* ni corrección de X.
- Se corrige la penetración `U1 → TECHO_BAJO`. Al salir completamente de U1, Eren cae de forma natural y el collider anterior nunca se vuelve intangible; por tanto no puede quedar de pie dentro de U1.
- `TERRAIN-MOUNT-20260825-R03` queda `PLAYTEST_REJECTED` para uso runtime. Sus nueve PNG precompuestos se conservan solo como evidencia histórica.
- El runtime usa `TERRAIN-NATIVE-MOUNT-20260826-R04`: piezas autorizadas de relleno `1×1`, superficies `4×1`, `2×1` y `1×1`, plataforma orgánica `1,5×0,5` y columna `1×4,5`. U1 se monta con dos tapas y un centro repetible sin estirar el bitmap.
- Los restos de caja y los dos estados de placa se alinean con la superficie mediante sus márgenes alfa inferiores medidos. La placa incorpora además una base visual modular `1,5×0,5`; su silueta fuente continúa marcada `PENDING_ART_COVERAGE` porque solo ocupa 0,74/0,85 módulos del lienzo contractual.
- El panel derecho queda cerrado por defecto. El botón **☰ Registro** de la esquina superior derecha abre un cajón superpuesto; el lienzo jugable ocupa todo el ancho y la botonera queda más cerca del borde derecho.
- Se mantienen la geometría G0–G3/U0–U3, física de salto (`15,9 / 36 / 44 / -16`), ruta segura de Scar, puzle enclavado y meta conjunta.
- La prueba automatizada cubre 120 casos de borde, 240 fotogramas en el borde de U1, caída segura a `TECHO_BAJO`, cero reentradas, 20 rutas finales de Scar y cero muertes en pinchos.

En la primera pantalla pulsa **Probar juego**. Para compartir el JSON, abre **☰ Registro** y pulsa **Compartir registro**. La base grande de GitHub no se sustituye: esta revisión se distribuye como `Eren-GitHub-Actualizacion-R07.zip`, que el workflow incremental aplica después de R05.

La decisión completa está en [`docs/DECISION_PLAYTEST_R07.md`](docs/DECISION_PLAYTEST_R07.md). El montaje R03 rechazado se conserva en [`docs/TERRAIN-MOUNT-20260825-R03/`](docs/TERRAIN-MOUNT-20260825-R03/), y la integración UI autorizada permanece documentada en [`docs/INTEGRACION_UI_EDUCATIVA_R02.md`](docs/INTEGRACION_UI_EDUCATIVA_R02.md).

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
