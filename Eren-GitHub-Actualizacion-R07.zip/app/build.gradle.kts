plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 33
        versionName = "32.0.0-graybox-r07-mario-native-ui-drawer-candidate"
    }
}
