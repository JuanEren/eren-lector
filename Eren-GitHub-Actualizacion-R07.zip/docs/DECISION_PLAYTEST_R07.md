# Decisión de playtest R07 · GB01-v18

Fecha: 26/08/2026  
Decisión: `GB-PLAYTEST-20260826-R07`  
Base observada: `31.0.0-graybox-terrain-r03-footprobe-candidate` / `GB01-v17`  
Candidata resultante: `32.0.0-graybox-r07-mario-native-ui-drawer-candidate` / `GB01-v18`  
Estado máximo: `CANDIDATE_PLAYTEST` · `GAME_READY=false`

## Evidencia recibida

El registro Android contiene intentos con 16 y 21 eventos `caida_borde_sondas_pie`. En la zona de U1 se repiten eventos con Eren inmóvil o casi inmóvil y alternan los soportes `U1` y `TECHO_BAJO`. Las capturas muestran el collider de Eren ocupando simultáneamente el volumen vertical de U1 después de caer sobre TECHO_BAJO.

## Causa física

La build v31 ejecutaba esta secuencia:

1. las dos sondas inferiores perdían apoyo antes de desaparecer el solape real;
2. `detachFromSupport` marcaba U1 como soporte ignorado;
3. el motor omitía todas las colisiones con U1 mientras Eren caía;
4. Eren aterrizaba en TECHO_BAJO con su cuerpo dentro de U1;
5. al moverse podía alternar soporte, penetrar o salir del sólido.

No era un defecto del salto ni del ZIP. Era una contradicción entre pérdida de apoyo y resolución de sólidos.

## Ley mecánica

Se restaura `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`:

- cualquier solape horizontal real mayor que cero conserva apoyo;
- la caída empieza únicamente al desaparecer el solape;
- nunca se ignora el soporte anterior;
- no existe umbral `2/3`, sonda de pie, empuje, snap o corrección de X;
- `ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN` queda superseded;
- salto y gravedad permanecen `15,9 / 36 / 44 / -16`.

## Causa visual

El problema no requiere Gemini. Es un error de integración y montaje:

- R03 convirtió cada sólido completo en un PNG opaco precompuesto;
- las plataformas orgánicas transparentes recibieron rellenos marrones que no pertenecen a su silueta;
- U1, U2, U3 y TECHO_BAJO dejaron de comportarse como piezas modulares reutilizables;
- los márgenes alfa inferiores de restos y placas no se compensaban;
- la placa fuente solo ocupa 0,74 módulos libre y 0,85 módulos pulsada dentro de un lienzo contractual de 1,5 módulos.

R03 queda `PLAYTEST_REJECTED` en runtime, aunque sus archivos se conservan como evidencia. El nuevo montaje `TERRAIN-NATIVE-MOUNT-20260826-R04` usa las piezas originales autorizadas y prioriza 4×1, 2×1 y 1×1. U1 utiliza tapa izquierda, centro repetible y tapa derecha de la plataforma 1,5×0,5 sin estirar el bitmap.

Los restos y las placas se alinean por el último píxel alfa visible. La placa recibe una base modular visual de 1,5×0,5, pero su cobertura artística continúa `PENDING_ART_COVERAGE`; esta limitación queda visible en el registro y no se oculta ni se declara resuelta.

## UI

El panel de diagnóstico está cerrado por defecto. `☰ Registro` lo abre como cajón superpuesto desde la esquina superior derecha. El canvas ocupa todo el ancho y los controles táctiles se acercan a los márgenes seguros.

## QA ejecutado

- Catálogo Azure en Node: PASS.
- 100 casos de apoyo parcial: 10 repeticiones por lado en 67 %, 42 %, 41,8 %, 24 % y 1 %; todos estables durante 180 frames.
- 20 salidas con 0 %: caída natural, sin soporte ignorado ni corrección de X.
- U1: 240 frames estable al 41 %; caída a TECHO_BAJO sin penetrar U1 y sin recontactos.
- Scar: 20/20 rutas finales; cero recuperaciones por pinchos.
- Panel plegable: cerrado, apertura y cierre verificados.
- Terrain runtime: cero cargas o draw calls de `terrain-mount-r03`.

## Alcance pendiente

- Playtest real de `GB01-v18` en Android.
- Confirmar visualmente el montaje nativo en el dispositivo objetivo.
- Arte debe entregar una placa que cubra realmente su contrato 1,5×0,5 si se desea una silueta mayor.
- `CANDIDATE_PLAYTEST_R02` de locomoción sigue pendiente.
- No se integraron paralaje, visual development, social, enemigos ni ampliación del nivel.

