# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 33.0.0 · actualización incremental R08

R08 corrige el rechazo visual de `GB01-v18` sin ampliar el nivel ni cambiar sus colliders. La nueva candidata se identifica como `33.0.0-graybox-r08-contact-terrain-candidate` / `GB01-v19`; permanece `CANDIDATE_PLAYTEST` y `GAME_READY=false`.

Cambios principales:

- La ley mecánica `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN` se conserva: cualquier solape real mantiene el apoyo y la caída solo empieza al llegar a cero. No vuelven las sondas, el umbral `2/3`, el soporte ignorado, el empuje, el *snap* ni la corrección física de X.
- El caso mostrado con `apoyo 3 %` recibe `VISUAL_FOOT_ANCHOR_R08`: el sprite se desplaza suavemente hacia la parte de plataforma que aún sostiene al collider. Es una corrección exclusiva del renderer; el cuerpo físico y su posición X no cambian, y el ajuste vuelve a cero al saltar o caer.
- `TERRAIN-NATIVE-MOUNT-20260826-R04` queda `PLAYTEST_REJECTED_VISUAL`. El runtime ya no compone suelos con bloques, centros repetidos ni tapas que generaban juntas.
- El runtime usa `TERRAIN-CONTACT-MOUNT-20260826-R05`: una fuente continua opaca de `950×200 px` a 100 PPU y un único recorte exacto por sólido. G0–G3, U1–U3, TECHO_BAJO y la base de placa coinciden con el collider desde su primera fila visible.
- Los offsets globales de Eren `+6 px` y Scar `+2 px` quedan eliminados. Las compensaciones inferiores solo se aplican a los fotogramas concretos que tienen transparencia bajo los pies.
- La placa utiliza sus límites visibles reales y escala uniforme para cubrir los `1,5` módulos contratados; deja de verse como una pieza diminuta sobre otra plataforma.
- El panel derecho continúa oculto por defecto; **☰ Registro** abre el cajón superpuesto y el juego mantiene todo el ancho.
- Se mantienen la geometría G0–G3/U0–U3, física de salto (`15,9 / 36 / 44 / -16`), colisión U1 → TECHO_BAJO, ruta segura de Scar, puzle enclavado y meta conjunta.
- La prueba automatizada cubre 120 casos de borde, el anclaje visual al 3 % en ambos lados sin mutación física, U1 sin penetración, 20 rutas finales de Scar y cero muertes en pinchos.

En la primera pantalla pulsa **Probar juego**. Para compartir el JSON, abre **☰ Registro** y pulsa **Compartir registro**. La base grande de GitHub no se sustituye: esta revisión se distribuye como `Eren-GitHub-Actualizacion-R08.zip`, que el workflow incremental aplica después de R07.

La decisión completa está en [`docs/DECISION_PLAYTEST_R08.md`](docs/DECISION_PLAYTEST_R08.md). Los montajes R03 y R04 se conservan solo para trazabilidad, y la integración UI autorizada permanece documentada en [`docs/INTEGRACION_UI_EDUCATIVA_R02.md`](docs/INTEGRACION_UI_EDUCATIVA_R02.md).

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
