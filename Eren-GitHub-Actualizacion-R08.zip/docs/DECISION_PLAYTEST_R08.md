# Decisión de playtest R08 · GB01-v19

Fecha: 26/08/2026  
Decisión: `GB-PLAYTEST-20260826-R08`  
Base observada: `32.0.0-graybox-r07-mario-native-ui-drawer-candidate` / `GB01-v18`  
Candidata resultante: `33.0.0-graybox-r08-contact-terrain-candidate` / `GB01-v19`  
Estado máximo: `CANDIDATE_PLAYTEST` · `GAME_READY=false`

## Evidencia recibida

Las capturas Android muestran tres defectos inequívocos:

1. Eren aparece prácticamente en el aire sobre U1 aunque el diagnóstico indica `apoyo 3 %`.
2. G0–G3 presentan cortes verticales y repetición visible de bloques; U1–U3 y TECHO_BAJO se leen como tiras de hierba aisladas.
3. La placa de Scar queda pequeña y colocada sobre otra pieza visual, sin cubrir los `1,5` módulos del contrato.

El registro `GB01-v18` confirma que ya no existen `caida_borde_sondas_pie` ni recontactos. Por tanto, la penetración física de R03 estaba corregida, pero el montaje visual R04 y la representación del contacto parcial seguían rechazados.

## Diagnóstico

No era un fallo de descarga, del ZIP ni de Gemini. Había dos causas de integración:

- `TERRAIN-NATIVE-MOUNT-20260826-R04` componía superficies de tamaños distintos, centros repetidos y recortes. Aunque cada operación era modular, el conjunto producía juntas, cambios de textura y una lectura pobre en cámara real.
- `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN` conserva correctamente el suelo con cualquier solape real. Con un 3 % de solape, el collider sigue apoyado pero el sprite permanecía centrado en el cuerpo físico; la imagen hacía visible el vacío que la postura no compensaba.

R04 queda `PLAYTEST_REJECTED_VISUAL`. La física permisiva no se revierte porque el registro demuestra estabilidad y porque volver a forzar la caída reabriría el defecto U1 → TECHO_BAJO.

## Solución de terreno

Se integra `TERRAIN-CONTACT-MOUNT-20260826-R05`:

- maestro continuo opaco `terrain-continuous-950x200-r08.png`;
- `950×200 px`, 100 PPU, primera fila visible `y=0`;
- SHA-256 `c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066`;
- un `drawImage` con recorte exacto por sólido;
- cero tapas, centros repetidos, bandas marrones, damero o PNG precompuesto por nivel;
- geometría, colliders y pivotes sin cambios.

El maestro parte de un candidato producido con ImageGen integrado. La primera salida y la revisión de extracción conservaron un damero RGB horneado fuera de la franja y fueron rechazadas como archivos runtime. Solo se normalizó la región completamente opaca del terreno a `950×200`; el archivo integrado no contiene ese fondo ni transparencia falsa. No se usó Gemini.

Resumen sanitizado del prompt de producción: crear una franja continua de suelo lateral 2D para bosque, con hierba/musgo en la primera fila y cuerpo de tierra y piedra oscuro, sin objetos, texto, bordes laterales, costuras ni perspectiva. Revisión: aislar únicamente la franja de terreno y mantener su textura, sin modificar el contenido opaco.

## Solución de contacto

Se añade `VISUAL_FOOT_ANCHOR_R08`:

- comienza por debajo del 42 % de apoyo;
- desplaza el dibujo como máximo `0,42` módulos hacia la superficie restante;
- transición de `4 módulos/s`;
- no modifica `entity.x`, collider, velocidad, cámara, salto ni resolución de sólidos;
- vuelve suavemente a cero al saltar, caer, agacharse o recuperar al personaje.

Los offsets globales `Eren +6 px` y `Scar +2 px` se eliminan. Solo se compensan los fotogramas de locomoción cuyo PNG tiene transparencia inferior medida.

## Placa y objetos

La placa usa sus límites alfa visibles (`74×21 px` libre y `85×18 px` pulsada), escala uniforme y contacto inferior. Ambos estados cubren visualmente `1,5` módulos sin deformación independiente de ejes. La base comparte el terreno continuo; ya no se monta una plataforma orgánica adicional bajo una placa diminuta.

## UI conservada

El panel de registro continúa cerrado por defecto. `☰ Registro` abre el cajón superpuesto y el canvas conserva todo el ancho. No se reabre la interfaz R07.

## QA ejecutado

- Catálogo Azure en Node: PASS.
- Graybox completo en Node: PASS.
- 120 casos de apoyo parcial y salida natural: PASS.
- Anclaje visual al 3 % en ambos lados: PASS; `0` mutaciones de X física.
- U1 estable y caída a TECHO_BAJO: PASS; `0` penetraciones.
- Terreno: `9` sólidos visuales, `9` recortes continuos, `0` draw calls R03/R04.
- Placa visible: cobertura `1,5` módulos y escala uniforme: PASS.
- Scar: 20/20 rutas finales; `0` recuperaciones por pinchos.
- Evidencia determinista renderizada con los mismos PNG, recortes y métricas del runtime: PASS.

## Pendiente

- Compilar APK mediante GitHub Actions.
- Playtest real de `GB01-v19` en el Samsung SM-S928B.
- Confirmar en dispositivo el terreno, la placa y el anclaje del 3 % antes de promover nada a `GAME_READY`.
- `CANDIDATE_PLAYTEST_R02` de locomoción sigue pendiente.

