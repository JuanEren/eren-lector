import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const canvasPackage = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? `${process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES}/@napi-rs/canvas`
  : '@napi-rs/canvas';
const { createCanvas, loadImage } = require(canvasPackage);

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = path.join(project, 'app/src/main/assets/www');
const output = path.join(project, 'docs/evidencias-r08');
await mkdir(output, { recursive: true });

const asset = relative => path.join(www, relative);
const [terrain, column, eren, scar, plateFree, box, gate, star, water] = await Promise.all([
  loadImage(asset('assets/playtest/terrain-r08/terrain-continuous-950x200-r08.png')),
  loadImage(asset('assets/playtest/mundo1-functional/terrain/columna-ruina-1x4_5.png')),
  loadImage(asset('assets/playtest/e1-s1-candidate/eren/eren-reposo-00.png')),
  loadImage(asset('assets/playtest/e1-s1-candidate/scar/scar-reposo-00-candidate.png')),
  loadImage(asset('assets/playtest/mundo1-functional/objects/placa-presion-libre-1_5x0_5.png')),
  loadImage(asset('assets/playtest/mundo1-functional/objects/caja-rompible-intacta-1x1.png')),
  loadImage(asset('assets/playtest/mundo1-functional/objects/interruptor-muro-1_5x2.png')),
  loadImage(asset('assets/playtest/mundo1-functional/objects/estrella-1x1.png')),
  loadImage(asset('assets/playtest/mundo1-functional/hazards/agua-4x1_5.png')),
]);

const sourceX = { G0: 0, G1: 180, G2: 430, G3: 90, U1: 540, U2: 720, U3: 780, TECHO_BAJO: 350, PLACA_BASE: 610 };
const solids = [
  { id: 'G0', x: 0, y: 0, w: 9.5, h: 2 }, { id: 'G1', x: 11, y: 0, w: 7, h: 2 },
  { id: 'G2', x: 19.5, y: 0, w: 5, h: 2 }, { id: 'G3', x: 28.5, y: 0, w: 8, h: 2 },
  { id: 'TECHO_BAJO', x: 12.5, y: 3, w: 1.5, h: .5 }, { id: 'U1', x: 14, y: 4, w: 2.5, h: .5 },
  { id: 'U2', x: 18.5, y: 6, w: 1.5, h: .5 }, { id: 'U3', x: 21, y: 4.5, w: 1.5, h: .5 },
];

const palette = {
  bg: '#0b1118', bg2: '#172431', panel: '#15212c', panelLine: '#3c5266',
  grid: '#7590a42c', major: '#8ea9bd4f', text: '#f4f8fb', muted: '#aabac8',
  cyan: '#22ddef', gold: '#ffd34f', magenta: '#ff55d5', green: '#68e394', red: '#ff725f',
};

function background(ctx, width, height, title, subtitle) {
  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, palette.bg2); gradient.addColorStop(1, palette.bg);
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = palette.text; ctx.font = '800 31px sans-serif'; ctx.fillText(title, 48, 48);
  ctx.fillStyle = palette.muted; ctx.font = '500 16px sans-serif'; ctx.fillText(subtitle, 48, 77);
}

function mapper(view) {
  return { x: value => view.left + (value - view.minX) * view.scale, y: value => view.bottom - (value - view.minY) * view.scale };
}

function grid(ctx, view) {
  const map = mapper(view);
  ctx.save(); ctx.beginPath(); ctx.rect(view.left, view.top, (view.maxX - view.minX) * view.scale, (view.maxY - view.minY) * view.scale); ctx.clip();
  for (let x = Math.ceil(view.minX * 2) / 2; x <= view.maxX; x += .5) {
    const major = Math.abs(x - Math.round(x)) < 1e-9; ctx.strokeStyle = major ? palette.major : palette.grid; ctx.lineWidth = major ? 1.1 : .7;
    ctx.beginPath(); ctx.moveTo(map.x(x), view.top); ctx.lineTo(map.x(x), view.bottom); ctx.stroke();
  }
  for (let y = Math.ceil(view.minY * 2) / 2; y <= view.maxY; y += .5) {
    const major = Math.abs(y - Math.round(y)) < 1e-9; ctx.strokeStyle = major ? palette.major : palette.grid; ctx.lineWidth = major ? 1.1 : .7;
    ctx.beginPath(); ctx.moveTo(view.left, map.y(y)); ctx.lineTo(map.x(view.maxX), map.y(y)); ctx.stroke();
  }
  ctx.restore();
}

function drawCollider(ctx, view, body, label = body.id) {
  const map = mapper(view), left = map.x(body.x), top = map.y(body.y + body.h);
  ctx.save(); ctx.setLineDash([7, 4]); ctx.strokeStyle = palette.cyan; ctx.lineWidth = 1.7; ctx.strokeRect(left, top, body.w * view.scale, body.h * view.scale); ctx.setLineDash([]);
  ctx.strokeStyle = palette.magenta; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(left, top); ctx.lineTo(left + body.w * view.scale, top); ctx.stroke();
  if (label) { ctx.fillStyle = palette.text; ctx.font = '700 11px monospace'; ctx.fillText(label, left + 4, top + 14); }
  ctx.restore();
}

function drawTerrain(ctx, view, solid, debug = false) {
  const map = mapper(view), sourceW = Math.round(solid.w * 100), sourceH = Math.round(solid.h * 100);
  ctx.save(); ctx.imageSmoothingEnabled = true;
  ctx.drawImage(terrain, Math.min(sourceX[solid.id] ?? 0, 950 - sourceW), 0, sourceW, sourceH, map.x(solid.x), map.y(solid.y + solid.h), solid.w * view.scale, solid.h * view.scale);
  ctx.restore(); if (debug) drawCollider(ctx, view, solid);
}

function drawCharacter(ctx, view, image, character, physicalX, y, visualOffsetX = 0, debug = false) {
  const map = mapper(view), visual = character === 'eren' ? { w: 3, h: 2 } : { w: 2, h: 1.5 };
  const body = character === 'eren' ? { w: 1, h: 1.5 } : { w: 1.5, h: 1 };
  const renderX = physicalX + visualOffsetX;
  ctx.save(); ctx.imageSmoothingEnabled = true;
  ctx.drawImage(image, map.x(renderX - visual.w / 2), map.y(y + visual.h), visual.w * view.scale, visual.h * view.scale);
  ctx.restore();
  if (debug) {
    drawCollider(ctx, view, { id: character.toUpperCase(), x: physicalX - body.w / 2, y, w: body.w, h: body.h });
    ctx.fillStyle = palette.gold; ctx.beginPath(); ctx.arc(map.x(renderX), map.y(y), 5, 0, Math.PI * 2); ctx.fill();
  }
}

function drawPlate(ctx, view, x, y) {
  const map = mapper(view), sx = 39, sy = 13, sw = 74, sh = 21, w = 1.5, h = w * sh / sw;
  drawTerrain(ctx, view, { id: 'PLACA_BASE', x, y: y - .5, w, h: .5 });
  ctx.drawImage(plateFree, sx, sy, sw, sh, map.x(x), map.y(y + h), w * view.scale, h * view.scale);
}

function panel(ctx, x, y, width, title, lines) {
  const height = 53 + lines.length * 27;
  ctx.fillStyle = palette.panel; ctx.strokeStyle = palette.panelLine; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(x, y, width, height, 14); ctx.fill(); ctx.stroke();
  ctx.fillStyle = palette.text; ctx.font = '800 18px sans-serif'; ctx.fillText(title, x + 18, y + 31);
  ctx.font = '600 14px sans-serif'; lines.forEach((line, index) => { ctx.fillStyle = line.startsWith('PASS') ? palette.green : palette.muted; ctx.fillText(line, x + 18, y + 61 + index * 27); });
}

async function overview() {
  const canvas = createCanvas(1600, 900), ctx = canvas.getContext('2d');
  background(ctx, 1600, 900, 'R08 · Terreno continuo y contacto visual', 'Mismos sólidos y colliders · una fuente opaca a 100 PPU · sin mosaico modular R04');
  const view = { minX: 0, maxX: 24.5, minY: 0, maxY: 8, scale: 52, left: 55, top: 115, bottom: 531 };
  grid(ctx, view); solids.filter(item => item.x < 24.5).forEach(item => drawTerrain(ctx, view, item));
  const map = mapper(view); ctx.drawImage(column, map.x(6.5), map.y(7.5), view.scale, 4.5 * view.scale);
  ctx.drawImage(box, map.x(6.5), map.y(3), view.scale, view.scale);
  drawPlate(ctx, view, 15, 2); ctx.drawImage(gate, map.x(21.5), map.y(4), 1.5 * view.scale, 2 * view.scale);
  ctx.drawImage(star, map.x(18.75), map.y(7.25), view.scale, view.scale);
  drawCharacter(ctx, view, eren, 'eren', 16.97, 4.5, -.42); drawCharacter(ctx, view, scar, 'scar', 15.75, 2);
  panel(ctx, 55, 590, 470, 'Terreno', ['PASS · 9 sólidos = 9 recortes continuos', 'PASS · 0 costuras verticales runtime', 'PASS · primera fila visible = collider', 'PASS · SHA-256 fijado en pruebas']);
  panel(ctx, 565, 590, 470, 'Contacto', ['PASS · offset global Eren/Scar = 0 px', 'PASS · ajuste por fotograma de apoyo', 'PASS · anclaje visual bajo 42 %', 'PASS · física y collider intactos']);
  panel(ctx, 1075, 590, 470, 'Regresión', ['PASS · U1 → techo sin penetración', 'PASS · 120 casos de borde', 'PASS · Scar final 20/20', 'CANDIDATE · GAME_READY=false']);
  await writeFile(path.join(output, '01_R08_TERRENO_CONTINUO_OVERVIEW.png'), canvas.toBuffer('image/png'));
}

async function edgeContact() {
  const canvas = createCanvas(1600, 900), ctx = canvas.getContext('2d');
  background(ctx, 1600, 900, 'R08 · Caso real: Eren con 3 % de apoyo en U1', 'El collider conserva el contacto permisivo; solo el dibujo coloca los pies sobre el borde restante');
  const view = { minX: 12, maxX: 19, minY: 2.5, maxY: 8, scale: 145, left: 55, top: 105, bottom: 802 };
  grid(ctx, view); for (const item of solids.filter(solid => ['TECHO_BAJO', 'U1', 'U2'].includes(solid.id))) drawTerrain(ctx, view, item, true);
  const physicalX = 16.97, visualOffsetX = -.42;
  drawCharacter(ctx, view, eren, 'eren', physicalX, 4.5, visualOffsetX, true);
  const map = mapper(view);
  ctx.strokeStyle = palette.gold; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(map.x(physicalX), map.y(7.2)); ctx.lineTo(map.x(physicalX + visualOffsetX), map.y(7.2)); ctx.stroke();
  ctx.fillStyle = palette.gold; ctx.beginPath(); ctx.moveTo(map.x(physicalX + visualOffsetX), map.y(7.2)); ctx.lineTo(map.x(physicalX + visualOffsetX) + 13, map.y(7.2) - 7); ctx.lineTo(map.x(physicalX + visualOffsetX) + 13, map.y(7.2) + 7); ctx.fill();
  panel(ctx, 1095, 135, 445, 'Resultado automatizado', ['PASS · apoyo físico: 3 %', 'PASS · desplazamiento visual: −0,42 m', 'PASS · desplazamiento físico: 0,00 m', 'PASS · vuelve a 0 al saltar/caer', 'PASS · U1 sigue siendo sólido']);
  panel(ctx, 1095, 350, 445, 'Lectura', ['Cian · collider físico original', 'Magenta · superficie física', 'Punto amarillo · pivote visual', 'Flecha · corrección solo renderer']);
  await writeFile(path.join(output, '02_R08_ANCLAJE_VISUAL_APOYO_3_POR_CIENTO.png'), canvas.toBuffer('image/png'));
}

async function plateAndSurface() {
  const canvas = createCanvas(1600, 850), ctx = canvas.getContext('2d');
  background(ctx, 1600, 850, 'R08 · Placa y superficie sin montaje pobre', 'La placa usa su silueta visible completa; la base comparte la misma fuente continua que G1');
  const view = { minX: 11.5, maxX: 18.5, minY: 0, maxY: 5.5, scale: 145, left: 55, top: 105, bottom: 802 };
  grid(ctx, view); drawTerrain(ctx, view, solids.find(item => item.id === 'G1'), true); drawTerrain(ctx, view, solids.find(item => item.id === 'TECHO_BAJO'), true); drawTerrain(ctx, view, solids.find(item => item.id === 'U1'), true);
  drawPlate(ctx, view, 15, 2); drawCharacter(ctx, view, scar, 'scar', 15.75, 2, 0, true);
  panel(ctx, 1095, 135, 445, 'Cobertura R08', ['PASS · placa visible = 1,5 módulos', 'PASS · escala uniforme, sin deformación', 'PASS · alineación inferior al contacto', 'PASS · base sin capa marrón añadida', 'PASS · 0 juntas entre bloques de G1']);
  await writeFile(path.join(output, '03_R08_PLACA_Y_SUPERFICIE_CONTINUA.png'), canvas.toBuffer('image/png'));
}

await overview(); await edgeContact(); await plateAndSurface();
console.log(JSON.stringify({ output, screenshots: 3, build: '33.0.0-graybox-r08-contact-terrain-candidate' }));
