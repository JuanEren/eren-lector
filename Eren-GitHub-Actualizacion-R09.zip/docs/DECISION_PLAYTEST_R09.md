# Decisión de playtest R09 · GB01-v20

Fecha: 26/08/2026  
Decisión: `GB-PLAYTEST-20260826-R09`  
Base observada: `33.0.0-graybox-r08-contact-terrain-candidate` / `GB01-v19`  
Candidata resultante: `34.0.0-graybox-r09-ground-contact-plane-candidate` / `GB01-v20`  
Estado máximo: `CANDIDATE_PLAYTEST` · `GAME_READY=false`

## Evidencia recibida

Las capturas Android y las dos referencias retocadas confirman que R08 mejoró sustancialmente el terreno, pero personajes y mecanismos todavía terminaban exactamente sobre la primera fila del PNG. La silueta de la hierba hace que esa línea matemática se perciba por encima del suelo: Eren, Scar y la placa parecen flotar unos píxeles.

El registro `GB01-v19` no muestra recontactos ni caídas por sondas y conserva la física permisiva. Por tanto, el defecto pendiente es de representación del contacto, no de geometría ni colisión.

## Diagnóstico medido

Los PNG de locomoción no comparten el mismo margen transparente inferior. Se midieron estos máximos relevantes:

- Eren caminar: `5 / 3 / 4 / 3 px`; correr: `4 / 6 / 17 / 3 px`.
- Scar caminar: `2 / 0 / 0 / 0 px`; correr: `2 / 13 / 2 / 2 px`.

R08 compensaba los márgenes por fotograma, pero dejaba la última fila visible exactamente en el borde superior físico. Faltaba un plano visual común que situase el dibujo dentro de la franja orgánica sin mover el cuerpo físico.

## Decisión

Se integra `SHARED_VISUAL_CONTACT_PLANE_R09`:

- encaje visual común: `6 px` de fuente a 100 PPU (`0,06` módulos);
- actores: solo reposo, caminar y correr mientras están apoyados;
- salto y caída: `0 px` de encaje;
- objetos apoyados: placa libre/pulsada, caja intacta, restos y palanca;
- compensación previa obligatoria del margen alfa propio de cada fotograma;
- terreno: cobertura completa e idéntica a R08.

Este patrón separa la forma física de la colocación visual, igual que los pivotes de sprite y los anclajes de tilemap disponibles en motores 2D. Referencias técnicas: [Unity Sprite Editor](https://docs.unity3d.com/kr/6000.0/Manual/com.unity.2d.sprite.html), [Unity Tilemap Tile Anchor](https://docs.unity3d.com/kr/2018.3/Manual/class-Tilemap.html) y [Godot Sprite2D offset](https://docs.godotengine.org/en/4.6/classes/class_sprite2d.html).

## Invariantes preservados

- `geometryChanged=false`
- `collidersChanged=false`
- `physicsChanged=false`
- `terrainPixelsChanged=false`
- `pivotsChanged=false`
- `transformScale=[1,1]`
- Eren: `takeoffVy=15,9`, `gravityUp=36`, `gravityDown=44`, terminal `-16`
- apoyo de borde: `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`
- corrección horizontal parcial: `VISUAL_FOOT_ANCHOR_R08`
- UI: cajón de registro cerrado por defecto y viewport completo

`TERRAIN-CONTACT-MOUNT-20260826-R06` reutiliza exactamente `terrain-continuous-950x200-r08.png`, SHA-256 `c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066`. No se añade otro PNG, banda, tapa ni capa de relleno.

## QA ejecutado

- Catálogo Azure en Node: PASS.
- Graybox completo en Node: PASS.
- Todos los fotogramas terrestres de Eren y Scar: mismo contacto visible: PASS.
- Actores en aire: encaje `0 px`: PASS.
- Placa, caja, restos y palanca: plano compartido: PASS.
- Terreno: `9` sólidos, `9` recortes continuos, fuente y SHA R08 preservados: PASS.
- 120 casos de borde: PASS.
- U1 → TECHO_BAJO: `0` penetraciones: PASS.
- Scar: 20/20 rutas finales, `0` muertes por pinchos: PASS.
- Tres montajes de evidencia con los PNG reales del runtime: PASS.

## Pendiente

- Compilar APK mediante GitHub Actions.
- Playtest real de `GB01-v20` en el Samsung SM-S928B.
- Confirmar visualmente en movimiento reposo, caminar, correr, placa y caja rota.
- `CANDIDATE_PLAYTEST_R02` de locomoción continúa pendiente y queda fuera de R09.

