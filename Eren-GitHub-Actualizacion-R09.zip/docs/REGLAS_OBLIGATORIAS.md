# Reglas obligatorias de producción de niveles, assets, sprites y animaciones

Estado: **LEY DE PROYECTO · PUERTA CERO · OBLIGATORIA**  
Revisión: **26/08/2026 · R05 · coordinación Arte ↔ Game/Level Design**

Estas reglas se aplican a toda producción nueva y, tras la primera prueba jugable, a la revisión progresiva de todo el material histórico. Solo una autorización expresa del usuario puede cambiar una regla, reabrir un aprobado o conceder una excepción documentada.

## 0. Ley de entorno, autoridad y coordinación

- No se trabaja en producción fuera de **ChatGPT Work** o **Codex**. El chat normal solo sirve para consulta.
- Google Drive (`EREN_MASTER_LIBRARY`) es la fuente maestra visible de documentación y assets; la Biblioteca de ChatGPT es el espejo versionado; GitHub conserva código, escenas, pruebas y builds reproducibles.
- La conversación de **Game Design y Level Design** gobierna métricas del jugador, mecánicas, recorridos, ritmo, graybox, geometría, cámara, colliders funcionales y criterios de aceptación jugable.
- Esta conversación de **Assets, Sprites y Animación** gobierna maestros visuales, fichas de producción, generación o dibujo, capas, recortes, pivotes, secuencias, QA artístico/técnico y promoción a `GAME_READY`.
- Arte no puede cambiar por iniciativa propia geometría, saltos, colisiones, rutas o mecánicas. Game/Level Design no puede declarar un asset visual `GAME_READY` sin superar las puertas de arte y QA.
- Toda solicitud entre ambas áreas se entrega mediante un contrato mínimo: `asset_id`, función jugable, estado requerido, tamaño modular, coordenada o contexto, pivote/suelo, collider o trigger, capas, estados/animaciones, escala de cámara y criterio de aceptación.
- Si falta un dato bloqueante, el asset no se improvisa: queda `BLOQUEADO_POR_BRIEF` hasta recibirlo o documentar la decisión del usuario.
- Gemini, Nano Banana, Canva y cualquier otra IA externa solo pueden actuar como **talleres de producción de candidatos**. Sus salidas entran aisladas en `11_IMPORTACIONES_GEMINI`, con brief, referencias, prompt, fuente bruta, manifiesto y estado `CANDIDATE`; nunca pasan directamente a `08_BORRADORES` o `10_GAME_READY`.
- La producción externa obedece las mismas reglas, no puede cambiar game/level design ni declarar aprobación. Work/Codex conserva la autoridad de QA, persistencia y promoción. Las marcas invisibles de procedencia impuestas por el proveedor se documentan y no se intentan retirar; queda prohibida cualquier marca visible que contamine el asset.

## 1. Flujo obligatorio y puertas

0. Definir métricas de Eren, Scar, salto, cámara y colisiones en el laboratorio jugable.
1. Diseñar la necesidad y el recorrido sobre graybox modular.
2. Comprobar la mecánica sin depender del arte final.
3. Si falla, volver al diseño. Si funciona, bloquear esa geometría o registrar el cambio autorizado.
4. Emitir la ficha de producción del asset mínimo necesario.
5. Aprobar maestro visual, maestro mecánico y, si se anima, referencia de movimiento.
6. Producir un maestro o una secuencia representativa; nunca una familia completa sin validar primero este hito.
7. Extraer mediante coordenadas fijas o una transformada global común; queda prohibido autoencuadrar o reescalar cada fotograma.
8. Superar QA técnico, QA visual y prueba en cámara/escena real.
9. Recibir aprobación visual expresa del usuario cuando corresponda.
10. Persistir fuente, ficha, prompt, PNG, métricas, controles y decisión; solo entonces promover a `10_GAME_READY`.
11. Integrar sobre la geometría validada y repetir la prueba jugable.
12. Añadir después cubrejuntas, decoración, paralaje, iluminación, VFX y audio, sin cambiar geometría ni colisiones.

Ningún problema mecánico se corrige ocultándolo con arte. Ningún problema de arte se corrige alterando silenciosamente la mecánica.

## 2. Producción mínima antes del primer jugable

- Se produce únicamente el conjunto que pida el segmento gris: personajes mínimos, geometría funcional o placeholders, una estrella, un peligro, daño/retorno y los controles definidos.
- El macroplano 150 × 50 es una referencia aprobada de estructura, pero no se considera geometría jugable final hasta superar métricas, graybox y playtest.
- Los 553 assets existentes se conservan; no se rediseñan en masa antes de la prueba.
- Los 28 assets del Bloque 1 V4 permanecen aprobados. Eren E1 continúa como candidato hasta cerrar sus evidencias y la prueba en cámara real. Scar no avanza sin el contrato funcional del graybox y el cierre o excepción documentada de E1.
- Un asset no requerido por la prueba se mantiene en backlog.

## 3. Revisión obligatoria después del primer playtest

Tras observar la prueba jugable se registran primero métricas, fallos y cambios de geometría. Solo después se audita el arte, en este orden:

1. conjunto mínimo de Eren y Scar usado en la prueba;
2. assets funcionales que realmente aparecen en el Nivel 1;
3. las 66 secuencias/258 fotogramas de mundo ya inventariadas;
4. el resto del catálogo de 553 imágenes.

Cada elemento se clasifica como `APROBADO`, `CORREGIR`, `REHACER`, `ESTATICO`, `NO_USADO` o `RECHAZADO_HISTORICO`. La revisión no autoriza regeneraciones masivas: se corrige la causa concreta y solo los fotogramas o capas que fallen. Lo rechazado se conserva para trazabilidad y nunca se integra.

## 4. Reglas de geometría y colisión

- Cuadrícula base de 1 × 1 módulo; única subdivisión permitida: 0,5 módulo.
- Posición, tamaño funcional, pivotes, apoyos, colliders, plataformas, huecos, peligros y zonas de interacción usan múltiplos exactos de 0,5.
- Quedan prohibidos valores intermedios como 0,6; 0,75; 1,2; 1,3; 1,8 o 2,7 módulos.
- La regla afecta expresamente a X/Y, anchura, altura, puntos de apoyo, escalones, puertas, cajas, mecanismos y triggers.
- El mínimo funcional es 0,5 × 0,5 módulos.
- Remates visuales pueden salir de la celda, pero anclaje, soporte y collider permanecen en la retícula.
- No se escala libremente un asset funcional para hacerlo encajar.
- Arte visible y colisión deben coincidir; el collider puede ser más simple que la silueta, pero nunca contradecir su lectura.
- Eren, Scar y objetos conservan escala, pivote y línea de suelo constantes.
- Plataformas, recompensas, aproximaciones, salidas y rutas deben estar dentro de las métricas jugables confirmadas.
- Ninguna estrella queda fuera del alcance real; ningún interruptor, puerta, cofre, acertijo, caja o mecanismo se coloca junto a un borde sin aproximación y salida seguras.
- El paso agachado debe ser físicamente imposible de superar saltando y la ruta inferior debe disponer de una salida alcanzable.

## 5. Reglas de arte, perspectiva y legibilidad

- Estilo aprobado: ilustración 2D pintada de lectura lateral; no pixel art obligatorio.
- Todo asset funcional comparte perspectiva lateral y apoyo inequívoco. La profundidad se construye con capas, paralaje y decoración, no inclinando la base funcional.
- Suelos, plataformas, columnas, escalones, cajas, puertas, cofres, mecanismos, interruptores y peligros no pueden utilizar perspectiva isométrica, cenital, angular o falsa profundidad que desplace su base respecto de la colisión.
- Un asset incompatible con la perspectiva común solo puede ser decorativo y carecer de collider o interacción necesaria.
- La decoración no oculta peligros, plataformas, estrellas, mecanismos ni rutas.
- Orden de capas: fondo lejano → paralaje medio → geometría funcional → personajes/objetos → decoración frontal controlada → interfaz.
- Cubrejuntas y primer plano no alteran la lectura de la colisión y respetan zonas de exclusión alrededor de elementos jugables.
- Un asset aprobado es inmutable: no se regenera, sustituye o reinterpreta sin autorización o fallo técnico demostrado.

## 6. Leyes de sprites y animación

- Lienzo, orientación, escala, pivote, suelo y volumen se bloquean antes de animar.
- Todo clip de locomoción se produce `in place`; el motor gobierna el desplazamiento real.
- Se planifican claves, extremos, breakdowns, contactos, arcos, timing, spacing, holds y hoja de exposición antes de completar intermedios.
- Más fotogramas no equivalen a mejor animación; cada frame debe tener una función.
- En antorchas, puertas, cofres, mecanismos y objetos equivalentes, la base inmóvil permanece idéntica píxel a píxel; solo se anima la capa móvil.
- Quedan prohibidos el autoencuadre, la normalización por frame, el cambio involuntario de escala y el desplazamiento del objeto completo.
- Squash/stretch conserva volumen y solo afecta a las partes autorizadas.
- El collider funcional no pulsa, encoge ni cambia con la silueta salvo estado mecánico expresamente definido.
- Toda secuencia se revisa con onion-skin, reproducción en bucle, fondos de contraste y cámara real del juego.

## 7. Leyes de recorte y transparencia

- PNG RGBA con alfa real para siluetas, personajes, objetos y piezas transparentes; nunca fondo negro, blanco, damero horneado ni matte residual. Un maestro de terreno que cubra por contrato todo su rectángulo puede ser PNG RGB opaco si ancho, alto, primera fila visible, cobertura y SHA-256 quedan fijados y validados.
- Se inspeccionan perímetro y cavidades internas entre hojas, flores, patas, barrotes y piezas separadas.
- Control obligatorio sobre negro, blanco, gris y magenta/damero, a 100 %, 400 % y 800 %.
- No se altera RGB opaco al corregir alfa sin autorización.
- El usuario no revisa cientos de archivos para buscar defectos técnicos: el asistente entrega paneles, excepciones y candidatos ya auditados.

## 8. Ley de comunicación y feedback

- Toda tarea multietapa informa al inicio, al cerrar cada puerta, al cambiar el plan y antes de persistir o promover.
- Si pasan más de 60 segundos sin resultado visible, se comunica el estado y el siguiente hito.
- Formato mínimo: `ESTADO · HECHO · QA · SIGUIENTE`.
- No se ocultan bloqueos ni se declara avance sin evidencia verificable.

## 9. Rendimiento, persistencia y aprobación

- Animaciones cortas y reutilizables; VFX, luces, fauna y clima con límites y calidad adaptable.
- Se prueba rendimiento en el dispositivo móvil objetivo antes del cierre.
- Todo lote conserva ficha, prompt, entradas, fuente, PNG, hashes, QA, reproducción, decisión y versión.
- Todo lote externo conserva además proveedor, superficie/modelo declarado, salida bruta inalterada y limitaciones no verificadas. Un dato que el proveedor no pueda medir se registra `PENDING_WORK`; nunca se inventa.
- `08_BORRADORES` contiene candidatos; `09_RECHAZADOS`, históricos; `10_GAME_READY`, únicamente aprobados.
- Generado no significa terminado. Terminado significa: identificable, validado, probado, aprobado, persistido y disponible para integración.

## 10. Ley de entrega, conservación y acciones del usuario

- Toda respuesta que entregue uno o más archivos terminará con un bloque claro llamado `QUÉ TIENES QUE HACER`.
- Para cada archivo se indicará obligatoriamente: para qué sirve, si es `OBLIGATORIO`, `OPCIONAL` o `SOLO EVIDENCIA`, la acción exacta del usuario, el destino previsto y si sustituye a otro archivo anterior.
- Se identificará un único archivo principal cuando exista. Su nombre se entregará ya definitivo y apto para sustituir la versión anterior, sin obligar al usuario a renombrarlo.
- Los archivos auxiliares —ejecutables de prueba, evidencias, informes o checksums— no se presentarán sin explicar expresamente si el usuario debe descargarlos, subirlos, conservarlos o no hacer nada con ellos.
- Toda entrega terminará también con un bloque `GUARDADO`, que confirmará qué código, assets, reglas, manifiestos, informes, pruebas y decisiones importantes han quedado almacenados de forma persistente y qué elemento, si alguno, continúa pendiente.
- Ningún contenido importante puede quedar únicamente en el chat, en una carpeta temporal o en archivos auxiliares. Debe incorporarse al proyecto fuente principal y a la documentación maestra o espejo persistente disponible antes de declarar la tarea terminada.
- Si por cualquier motivo un archivo importante no puede guardarse, se informará antes del cierre y se dará al usuario una única acción concreta para evitar su pérdida.
- El usuario no tendrá que deducir qué archivo usar ni comprobar por su cuenta si la entrega quedó conservada.

### 10.1. Protocolo obligatorio de Drive, inventario y avisos entre conversaciones

- La carpeta común del Proyecto Eren en Drive es la fuente de verdad compartida entre Arte, Game Design y cualquier otra conversación de producción. La Biblioteca conserva el espejo versionado y GitHub conserva código, pruebas y builds reproducibles.
- Antes de iniciar **cada iteración**, el asistente debe leer de nuevo el protocolo, el registro vigente y la carpeta `00_INSTRUCCIONES_Y_REGISTRO`; debe comprobar si existe un aviso posterior a la última entrega y aplicar el que corresponda antes de tocar un lote.
- Todo aviso nuevo se guarda en esa carpeta con nombre `AVISO_AAAAMMDD_<LOTE>_VNN.md`. Debe indicar alcance, versión, propietario, consumidor, archivos maestros, enlaces, estado autorizado y acción requerida. Una instrucción importante no puede quedar solo en una conversación.
- Todo lote importante se registra en el inventario maestro con: `lote_id`, revisión, tipo, estado, propietario, consumidor, enlace maestro, SHA-256, build que lo integra, dependencia o sustitución y siguiente acción.
- Antes de modificar o integrar un lote se vuelve a leer el registro remoto, se comprueba que no exista una reserva concurrente y se marca `EN_CURSO`. Nunca se sobrescribe una revisión reservada por otra conversación.
- Solo pueden integrarse estados expresamente autorizados. `BORRADOR`, `CANDIDATE_SOURCE`, `REJECTED`, `SUPERSEDED` o cualquier candidato sin autorización permanecen fuera de la build.
- Al terminar se suben a Drive o GitHub, según corresponda, el proyecto fuente, la build o ejecutable disponible, las evidencias, los manifiestos, el informe y los checksums. Después se actualizan registro, inventario y aviso de cierre con enlaces reales.
- Cada cierre debe declarar uno de estos estados de persistencia: `DRIVE_VERIFICADO`, `GITHUB_VERIFICADO`, `BIBLIOTECA_VERIFICADA` o `BLOQUEADO_NO_PERSISTIDO`. `SOLO_LOCAL` no permite dar la tarea por terminada.
- El asistente debe verificar mediante relectura que cada archivo subido existe, conserva su nombre definitivo y abre desde su enlace maestro. No se inventan enlaces ni se confunde una carpeta temporal con almacenamiento persistente.
- El usuario no mantiene manualmente este sistema. La respuesta final debe decir `NO TIENES QUE HACER NADA` cuando todo esté guardado, o proporcionar una única acción concreta si falta una subida externa inevitable —por ejemplo, ejecutar GitHub Actions para obtener una APK—.
- Si existe un archivo principal destinado a sustituir el anterior, conservará exactamente el nombre estable acordado. Para este proyecto Android, el ZIP fuente principal se llama `Eren-Leo-y-entiendo-Android.zip`.

## 11. Estado operativo vigente

- Bloque 1 V4: **CERRADO · GAME_READY**.
- Bandera de meta y pedestal con gema: **APROBADOS · NO REABRIR**.
- Plano 150 × 50: **MACROPLANO APROBADO · JUGABILIDAD PENDIENTE DE GRAYBOX/PLAYTEST**.
- Animaciones de mundo: **AUDITADAS; 0 SECUENCIAS ANIMADAS GAME_READY**.
- Eren E1: **CANDIDATO TÉCNICO; PENDIENTE DE MAESTROS, BLOCKING Y PRUEBA EN CÁMARA REAL**.
- Próximo hito compartido: segmento gris jugable; después, auditoría progresiva del arte histórico conforme a esta ley.

### 11.1. Ley mecánica y visual vigente del graybox

- La referencia mecánica dorada de Eren es `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`: conserva suelo con cualquier solape horizontal real mayor que cero y cae de forma natural únicamente cuando el solape desaparece.
- Quedan `SUPERSEDED_FOR_EDGE_MECHANICS` tanto el umbral corporal `2/3` como `ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN`. Ninguno puede reintroducirse sin autorización expresa del usuario y una nueva decisión versionada.
- Al abandonar un borde nunca se vuelve intangible el soporte anterior, no se cambia `ignoredSupportId`, no se empuja, no se hace *snap*, no se recoloca X y no se generan ciclos de caída/recontacto. La regresión obligatoria incluye `U1 → TECHO_BAJO` y prohíbe que Eren quede dentro de cualquiera de los dos sólidos.
- Los valores congelados de Eren son `takeoffVy=15,9`, `gravityUp=36`, `gravityDown=44` y velocidad terminal `-16`. El montaje visual no puede alterarlos.
- Scar conserva controlador, navegación, saltos reservados y ruta segura propios; no hereda la regla de apoyo de Eren.
- `TERRAIN-MOUNT-20260825-R03` queda `PLAYTEST_REJECTED` y `TERRAIN-NATIVE-MOUNT-20260826-R04` queda `PLAYTEST_REJECTED_VISUAL` para runtime. Ninguno puede volver a cargarse. R04 demostró que elegir piezas grandes y repetir centros sigue produciendo juntas, capas y escalas visuales pobres en cámara real.
- La referencia candidata es `TERRAIN-CONTACT-MOUNT-20260826-R05`: una fuente continua opaca `950×200 px` a 100 PPU, primera fila visible `y=0`, un único recorte por sólido y cero composición interna en runtime. Cada recorte conserva la medida exacta del collider; queda prohibido añadir bandas marrones, tapas duplicadas o rellenos externos para ocultar cortes.
- Antes de integrar otro terreno se exige una puerta visual con, como mínimo, G0 de `9,5×2`, U1 de `2,5×0,5`, una plataforma de `1,5×0,5`, placa y contacto de personaje en cámara equivalente al dispositivo. Si se ven juntas, halos, damero, escala pobre o una capa que no pertenece a la silueta, el lote se rechaza antes de compilar.
- Caja, restos, placas y mecanismos se alinean por el contacto visible medido en alfa. Cuando el lienzo contractual contiene demasiado vacío, se recortan sus límites visibles y se escala de forma uniforme; nunca se deforma X/Y de forma independiente ni se oculta el defecto con otra banda.
- Los antiguos offsets divergentes `Eren +6 px` y `Scar +2 px` quedan `SUPERSEDED_VISUAL`: no pueden recuperarse como desplazamientos de entidad ni aplicarse en el aire. Cada fotograma terrestre debe compensar primero su transparencia inferior medida sobre alfa.
- `SHARED_VISUAL_CONTACT_PLANE_R09` añade después un único encaje de renderer de `+6 px` de fuente (`0,06` módulos a 100 PPU) a Eren y Scar apoyados y a placa, caja, restos y palanca. Todos deben terminar en el mismo plano visual dentro de la hierba. En salto o caída, el encaje de actores es obligatoriamente `0 px`.
- El encaje visual común nunca autoriza a mover o reducir terreno, collider, geometría, pivote físico, posición de entidad, cámara, velocidad, salto o gravedad. El maestro opaco R08 debe seguir rellenando cada sólido completo desde su primera fila.
- `VISUAL_FOOT_ANCHOR_R08` puede desplazar únicamente el dibujo de Eren hacia el apoyo restante por debajo del 42 %; no cambia entidad, collider, X física, cámara, velocidad ni resolución de colisiones, y vuelve a cero en el aire.
- La build `34.0.0-graybox-r09-ground-contact-plane-candidate` / `GB01-v20` es `CANDIDATE_PLAYTEST`; `GAME_READY=false` hasta superar prueba en dispositivo.
