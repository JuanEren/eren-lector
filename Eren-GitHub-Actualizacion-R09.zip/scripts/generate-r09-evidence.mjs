import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require=createRequire(import.meta.url);
const canvasPackage=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?`${process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES}/@napi-rs/canvas`:'@napi-rs/canvas';
const {createCanvas,loadImage}=require(canvasPackage);
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const www=path.join(project,'app/src/main/assets/www');
const output=path.join(project,'docs/evidencias-r09');
await mkdir(output,{recursive:true});
const asset=relative=>path.join(www,relative);

const [terrain,erenIdle,scarIdle,plateFree,box,lever,...runFrames]=await Promise.all([
 loadImage(asset('assets/playtest/terrain-r08/terrain-continuous-950x200-r08.png')),
 loadImage(asset('assets/playtest/e1-s1-candidate/eren/eren-reposo-00.png')),
 loadImage(asset('assets/playtest/e1-s1-candidate/scar/scar-reposo-00-candidate.png')),
 loadImage(asset('assets/playtest/mundo1-functional/objects/placa-presion-libre-1_5x0_5.png')),
 loadImage(asset('assets/playtest/mundo1-functional/objects/caja-rompible-intacta-1x1.png')),
 loadImage(asset('assets/playtest/mundo1-functional/objects/interruptor-muro-1_5x2.png')),
 ...[0,1,2,3].map(index=>loadImage(asset(`assets/playtest/e1-s1-candidate/eren/eren-correr-0${index}.png`))),
 ...[0,1,2,3].map(index=>loadImage(asset(`assets/playtest/e1-s1-candidate/scar/scar-correr-0${index}-candidate.png`))),
]);

const erenRun=runFrames.slice(0,4),scarRun=runFrames.slice(4,8);
const erenRunGaps=[4,6,17,3],scarRunGaps=[2,13,2,2];
const CONTACT_INSET_PX=6;
const sourceX={G0:0,G1:180,G2:430,G3:90,U1:540,U2:720,U3:780,TECHO_BAJO:350,PLACA_BASE:610};
const colors={bg:'#0b1118',bg2:'#172431',panel:'#14212c',line:'#40576a',grid:'#7590a42c',major:'#8ea9bd4f',text:'#f4f8fb',muted:'#aabac8',cyan:'#22ddef',gold:'#ffd34f',green:'#68e394',red:'#ff725f'};

function background(ctx,w,h,title,subtitle){
 const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,colors.bg2);g.addColorStop(1,colors.bg);ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
 ctx.fillStyle=colors.text;ctx.font='800 31px sans-serif';ctx.fillText(title,48,48);ctx.fillStyle=colors.muted;ctx.font='500 16px sans-serif';ctx.fillText(subtitle,48,77);
}
function mapper(view){return{x:value=>view.left+(value-view.minX)*view.scale,y:value=>view.bottom-(value-view.minY)*view.scale};}
function grid(ctx,view){
 const map=mapper(view);ctx.save();ctx.beginPath();ctx.rect(view.left,view.top,(view.maxX-view.minX)*view.scale,(view.maxY-view.minY)*view.scale);ctx.clip();
 for(let x=Math.ceil(view.minX*2)/2;x<=view.maxX;x+=.5){const major=Math.abs(x-Math.round(x))<1e-9;ctx.strokeStyle=major?colors.major:colors.grid;ctx.lineWidth=major?1.1:.7;ctx.beginPath();ctx.moveTo(map.x(x),view.top);ctx.lineTo(map.x(x),view.bottom);ctx.stroke();}
 for(let y=Math.ceil(view.minY*2)/2;y<=view.maxY;y+=.5){const major=Math.abs(y-Math.round(y))<1e-9;ctx.strokeStyle=major?colors.major:colors.grid;ctx.lineWidth=major?1.1:.7;ctx.beginPath();ctx.moveTo(view.left,map.y(y));ctx.lineTo(map.x(view.maxX),map.y(y));ctx.stroke();}
 ctx.restore();
}
function terrainSolid(ctx,view,id,x,y,w,h){
 const map=mapper(view),sw=Math.round(w*100),sh=Math.round(h*100),sx=Math.min(sourceX[id]??0,950-sw);ctx.drawImage(terrain,sx,0,sw,sh,map.x(x),map.y(y+h),w*view.scale,h*view.scale);
}
function physicalLine(ctx,view,x,y,w,label){
 const map=mapper(view);ctx.save();ctx.strokeStyle=colors.cyan;ctx.lineWidth=2;ctx.setLineDash([8,5]);ctx.beginPath();ctx.moveTo(map.x(x),map.y(y));ctx.lineTo(map.x(x+w),map.y(y));ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=colors.cyan;ctx.font='700 12px monospace';ctx.fillText(label,map.x(x),map.y(y)-8);ctx.restore();
}
function actor(ctx,view,image,kind,x,y,bottomGapPx=0,contactInsetPx=CONTACT_INSET_PX){
 const map=mapper(view),visual=kind==='eren'?{w:3,h:2}:{w:2,h:1.5};
 const top=map.y(y+visual.h)+(bottomGapPx+contactInsetPx)/100*view.scale;
 ctx.drawImage(image,map.x(x-visual.w/2),top,visual.w*view.scale,visual.h*view.scale);
}
function plate(ctx,view,x,y,contactInsetPx=CONTACT_INSET_PX){
 const map=mapper(view),sx=39,sy=13,sw=74,sh=21,w=1.5,h=w*sh/sw;
 ctx.drawImage(plateFree,sx,sy,sw,sh,map.x(x),map.y(y+h)+contactInsetPx/100*view.scale,w*view.scale,h*view.scale);
}
function prop(ctx,view,image,x,y,w,h,contactInsetPx=CONTACT_INSET_PX){const map=mapper(view);ctx.drawImage(image,map.x(x),map.y(y+h)+contactInsetPx/100*view.scale,w*view.scale,h*view.scale);}
function panel(ctx,x,y,w,title,lines){
 const h=54+lines.length*27;ctx.fillStyle=colors.panel;ctx.strokeStyle=colors.line;ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(x,y,w,h,14);ctx.fill();ctx.stroke();ctx.fillStyle=colors.text;ctx.font='800 18px sans-serif';ctx.fillText(title,x+18,y+31);ctx.font='600 14px sans-serif';lines.forEach((line,index)=>{ctx.fillStyle=line.startsWith('PASS')?colors.green:colors.muted;ctx.fillText(line,x+18,y+61+index*27);});
}

async function beforeAfter(){
 const canvas=createCanvas(1600,900),ctx=canvas.getContext('2d');background(ctx,1600,900,'R09 · Plano visual de contacto común','R08 y R09 comparten exactamente la misma línea física; solo cambia dónde termina el dibujo apoyado');
 const left={minX:0,maxX:7,minY:0,maxY:4.8,scale:90,left:55,top:120,bottom:552};
 const right={...left,left:850};grid(ctx,left);grid(ctx,right);
 for(const [view,inset,title] of [[left,0,'R08 · contacto demasiado alto'],[right,6,'R09 · encaje visual +6 px']]){
  const map=mapper(view);terrainSolid(ctx,view,'G1',.25,0,6.5,2);physicalLine(ctx,view,.25,2,6.5,'collider y=2,00 · sin cambios');
  actor(ctx,view,erenIdle,'eren',2,2,0,inset);actor(ctx,view,scarIdle,'scar',4.15,2,0,inset);plate(ctx,view,5.15,2,inset);
  ctx.fillStyle=inset?colors.green:colors.gold;ctx.font='800 18px sans-serif';ctx.fillText(title,view.left,map.y(4.55));
  ctx.strokeStyle=inset?colors.green:colors.gold;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(map.x(.6),map.y(2));ctx.lineTo(map.x(.6),map.y(2-inset/100));ctx.stroke();
 }
 panel(ctx,55,625,460,'Decisión R09',['PASS · terreno rellena el sólido completo','PASS · línea física idéntica','PASS · imagen baja 6 px solo al apoyar','PASS · placa usa el mismo plano']);
 panel(ctx,565,625,460,'Alcance',['Eren · reposo, caminar y correr','Scar · reposo, andar y correr','Placa, caja, restos y palanca','Aire · offset vertical 0 px']);
 panel(ctx,1075,625,470,'Bloqueos',['PASS · geometryChanged=false','PASS · collidersChanged=false','PASS · physicsChanged=false','CANDIDATE · GAME_READY=false']);
 await writeFile(path.join(output,'01_R09_PLANO_CONTACTO_ANTES_DESPUES.png'),canvas.toBuffer('image/png'));
}

async function frameNormalization(){
 const canvas=createCanvas(1600,980),ctx=canvas.getContext('2d');background(ctx,1600,980,'R09 · Todos los fotogramas terrestres normalizados','El espacio transparente inferior se mide por PNG; después todos terminan 6 px dentro de la franja visual');
 const view={minX:0,maxX:16,minY:0,maxY:7.5,scale:88,left:70,top:115,bottom:775};grid(ctx,view);const map=mapper(view);
 terrainSolid(ctx,view,'G1',.25,0,15.5,2);physicalLine(ctx,view,.25,2,15.5,'plano físico común');
 for(let index=0;index<4;index++){
  const x=2+index*3.6;actor(ctx,view,erenRun[index],'eren',x,2,erenRunGaps[index]);ctx.fillStyle=colors.text;ctx.font='700 13px sans-serif';ctx.fillText(`Eren correr ${index} · alfa +${erenRunGaps[index]} px`,map.x(x-1.35),map.y(4.35));
  actor(ctx,view,scarRun[index],'scar',x,5.2,scarRunGaps[index]);physicalLine(ctx,view,x-1,5.2,2,`Scar ${index}`);ctx.fillStyle=colors.text;ctx.fillText(`alfa +${scarRunGaps[index]} px`,map.x(x-.75),map.y(6.95));
 }
 panel(ctx,70,820,700,'Resultado',['PASS · Eren carrera 4/4 en el mismo contacto','PASS · Scar carrera 4/4 en el mismo contacto','PASS · caminar también normalizado 4/4 + 4/4']);
 panel(ctx,830,820,700,'Lectura',['Cian · línea física que no se mueve','Alfa · compensación propia de cada PNG','+6 px · encaje visual común en hierba']);
 await writeFile(path.join(output,'02_R09_LOCOMOCION_TERRESTRE_NORMALIZADA.png'),canvas.toBuffer('image/png'));
}

async function unchangedGeometry(){
 const canvas=createCanvas(1600,900),ctx=canvas.getContext('2d');background(ctx,1600,900,'R09 · Terreno y geometría preservados','Nueve sólidos continuos, una fuente opaca R08 y un plano de contacto exclusivamente de renderer');
 const view={minX:0,maxX:24.5,minY:0,maxY:8,scale:52,left:55,top:115,bottom:531};grid(ctx,view);
 const solids=[['G0',0,0,9.5,2],['G1',11,0,7,2],['G2',19.5,0,5,2],['TECHO_BAJO',12.5,3,1.5,.5],['U1',14,4,2.5,.5],['U2',18.5,6,1.5,.5],['U3',21,4.5,1.5,.5]];
 for(const [id,x,y,w,h] of solids){terrainSolid(ctx,view,id,x,y,w,h);physicalLine(ctx,view,x,y+h,w,id);}
 prop(ctx,view,box,6.5,2,1,1);plate(ctx,view,15,2);prop(ctx,view,lever,21.5,2,1.5,2);actor(ctx,view,erenIdle,'eren',16.1,4.5);actor(ctx,view,scarIdle,'scar',15.75,2);
 panel(ctx,55,590,470,'Terreno',['PASS · 9 sólidos = 9 recortes','PASS · PNG opaco rellena todo el hueco','PASS · SHA-256 R08 preservado','PASS · sin bandas o capas añadidas']);
 panel(ctx,565,590,470,'Contacto',['PASS · personajes +6 px apoyados','PASS · utilería +6 px apoyada','PASS · aire 0 px','PASS · alfa por fotograma medido']);
 panel(ctx,1075,590,470,'Regresión',['PASS · borde 120 casos','PASS · U1/techo sin penetración','PASS · Scar final 20/20','CANDIDATE · GAME_READY=false']);
 await writeFile(path.join(output,'03_R09_TERRENO_Y_FISICA_PRESERVADOS.png'),canvas.toBuffer('image/png'));
}

await beforeAfter();await frameNormalization();await unchangedGeometry();
console.log(JSON.stringify({output,screenshots:3,contactInsetPx:6,build:'34.0.0-graybox-r09-ground-contact-plane-candidate'}));
