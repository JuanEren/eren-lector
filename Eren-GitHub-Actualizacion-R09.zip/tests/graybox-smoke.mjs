import vm from 'node:vm';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { inflateSync } from 'node:zlib';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('game.css', root), 'utf8');
const uiCss = await readFile(new URL('ui-r02.css', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');
const worldArtManifest = JSON.parse(await readFile(new URL('../docs/MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01/MANIFEST.json', import.meta.url), 'utf8'));
const worldArtChecksums = await readFile(new URL('../docs/MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01/SHA256SUMS.txt', import.meta.url), 'utf8');
const terrainManifest = JSON.parse(await readFile(new URL('../docs/TERRAIN-MOUNT-20260825-R03/MANIFEST_TERRAIN_MOUNTING_R03.json', import.meta.url), 'utf8'));
const uiManifest = JSON.parse(await readFile(new URL('../docs/UI_EDUCATIVA_R02_CANDIDATE/MANIFEST_UI_EDUCATIVA_R02.json', import.meta.url), 'utf8'));
const locomotionRoot = new URL('assets/playtest/e1-s1-candidate/', root);
const jumpRoot = new URL('assets/playtest/e2-s2-jump-candidate/', root);
const worldArtRoot = new URL('assets/playtest/mundo1-functional/', root);
const terrainRoot = new URL('assets/playtest/terrain-mount-r03/', root);
const terrainR08Root = new URL('assets/playtest/terrain-r08/', root);
const uiArtRoot = new URL('assets/ui/r02/', root);
const expectedErenFrames = [
  'eren-reposo-00.png', 'eren-reposo-01.png',
  'eren-caminar-00.png', 'eren-caminar-01.png', 'eren-caminar-02.png', 'eren-caminar-03.png',
  'eren-correr-00.png', 'eren-correr-01.png', 'eren-correr-02.png', 'eren-correr-03.png',
];
const expectedScarFrames = [
  'scar-reposo-00-candidate.png', 'scar-reposo-01-candidate.png',
  'scar-andar-00-candidate.png', 'scar-andar-01-candidate.png', 'scar-andar-02-candidate.png', 'scar-andar-03-candidate.png',
  'scar-correr-00-candidate.png', 'scar-correr-01-candidate.png', 'scar-correr-02-candidate.png', 'scar-correr-03-candidate.png',
];
const expectedErenJumpFrames = [
  'eren-salto-impulso-00-candidate.png', 'eren-salto-impulso-01-candidate.png',
  'eren-salto-subida-00-candidate.png', 'eren-salto-caida-00-candidate.png',
  'eren-salto-aterrizaje-00-candidate.png', 'eren-salto-aterrizaje-01-candidate.png',
];
const expectedScarJumpFrames = [
  'scar-salto-impulso-00-candidate.png', 'scar-salto-impulso-01-candidate.png',
  'scar-salto-subida-00-candidate.png', 'scar-salto-caida-00-candidate.png',
  'scar-salto-aterrizaje-00-candidate.png', 'scar-salto-aterrizaje-01-candidate.png',
];
const pngAlphaBounds = png => {
  const width = png.readUInt32BE(16), height = png.readUInt32BE(20), bitDepth = png[24], colourType = png[25], interlace = png[28];
  if (bitDepth !== 8 || colourType !== 6 || interlace !== 0) throw new Error('La comprobación alfa requiere PNG RGBA8 no entrelazado.');
  const chunks = [];
  for (let offset = 8; offset < png.length;) {
    const length = png.readUInt32BE(offset), type = png.toString('ascii', offset + 4, offset + 8);
    if (type === 'IDAT') chunks.push(png.subarray(offset + 8, offset + 8 + length));
    offset += 12 + length;
    if (type === 'IEND') break;
  }
  const raw = inflateSync(Buffer.concat(chunks)), stride = width * 4, rows = [];
  let cursor = 0, previous = Buffer.alloc(stride);
  const paeth = (a, b, c) => { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); return pa <= pb && pa <= pc ? a : pb <= pc ? b : c; };
  for (let y = 0; y < height; y++) {
    const filter = raw[cursor++], row = Buffer.from(raw.subarray(cursor, cursor + stride)); cursor += stride;
    for (let x = 0; x < stride; x++) {
      const left = x >= 4 ? row[x - 4] : 0, up = previous[x], upperLeft = x >= 4 ? previous[x - 4] : 0;
      if (filter === 1) row[x] = (row[x] + left) & 255;
      else if (filter === 2) row[x] = (row[x] + up) & 255;
      else if (filter === 3) row[x] = (row[x] + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) row[x] = (row[x] + paeth(left, up, upperLeft)) & 255;
      else if (filter !== 0) throw new Error(`Filtro PNG no soportado: ${filter}`);
    }
    rows.push(row); previous = row;
  }
  let minX = width, minY = height, maxX = -1, maxY = -1;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (rows[y][x * 4 + 3] > 0) {
    minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
  }
  return maxX < 0 ? null : { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1, lastRow: maxY, fullyOpaque: rows.every(row => [...Array(width).keys()].every(x => row[x * 4 + 3] === 255)) };
};
const assertPngSet = async (assetRoot, character, expected, width, height) => {
  const directory = new URL(`${character}/`, assetRoot);
  const actual = (await readdir(directory)).filter(name => name.endsWith('.png')).sort();
  if (JSON.stringify(actual) !== JSON.stringify([...expected].sort())) throw new Error(`${character} no contiene exactamente los PNG jugables contratados: ${actual.join(', ')}.`);
  for (const name of actual) {
    const png = await readFile(new URL(name, directory));
    if (png.toString('ascii', 1, 4) !== 'PNG' || png.readUInt32BE(16) !== width || png.readUInt32BE(20) !== height || png[25] !== 6) throw new Error(`${character}/${name} no conserva el lienzo RGBA completo ${width}×${height}.`);
  }
};
await assertPngSet(locomotionRoot, 'eren', expectedErenFrames, 300, 200);
await assertPngSet(locomotionRoot, 'scar', expectedScarFrames, 200, 150);
await assertPngSet(jumpRoot, 'eren', expectedErenJumpFrames, 300, 200);
await assertPngSet(jumpRoot, 'scar', expectedScarJumpFrames, 200, 150);
const expectedWorldArt = [
  ['terrain/earth-00.png', 100, 300], ['terrain/earth-01.png', 100, 300],
  ['terrain/suelo-natural-1x1.png', 100, 100], ['terrain/columna-ruina-1x4_5.png', 100, 450],
  ['terrain/terreno-relleno-1x1.png', 100, 100], ['terrain/terreno-superficie-1x1.png', 100, 100],
  ['terrain/terreno-superficie-2x1.png', 200, 100], ['terrain/terreno-superficie-4x1.png', 400, 100],
  ['terrain/terreno-plataforma-1_5x0_5.png', 150, 50],
  ['terrain/terreno-relleno-0_5x0_5.png', 50, 50], ['terrain/terreno-tapa-canto-0_5x0_5.png', 50, 50],
  ['objects/caja-rompible-intacta-1x1.png', 100, 100], ['objects/caja-rompible-restos-1x1.png', 100, 100],
  ['objects/placa-presion-libre-1_5x0_5.png', 150, 50], ['objects/placa-presion-pulsada-1_5x0_5.png', 150, 50],
  ['objects/interruptor-muro-1_5x2.png', 150, 200], ['objects/estrella-1x1.png', 100, 100],
  ['hazards/agua-4x1_5.png', 400, 150], ['hazards/pincho-1x1_5.png', 100, 150],
];
for (const [name, width, height] of expectedWorldArt) {
  const png = await readFile(new URL(name, worldArtRoot));
  if (png.toString('ascii', 1, 4) !== 'PNG' || png.readUInt32BE(16) !== width || png.readUInt32BE(20) !== height || png[25] !== 6) throw new Error(`${name} no conserva su lienzo RGBA normalizado ${width}×${height}.`);
  const digest = createHash('sha256').update(png).digest('hex');
  if (!worldArtChecksums.includes(`${digest}  ${name}`)) throw new Error(`${name} no coincide con las sumas documentadas del paquete visual.`);
}
if (worldArtManifest.packageId !== 'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01' || worldArtManifest.assets.length !== expectedWorldArt.length || worldArtManifest.artIntegration?.status !== 'ART_R02_PENDING' || worldArtManifest.goalContract?.type !== 'strict_dual_actor_zone') throw new Error('El paquete visual base perdió su identidad, sus recursos o el contrato de meta.');

const terrainFiles = (await readdir(terrainRoot)).filter(name => name.endsWith('.png')).sort();
if (terrainManifest.lotId !== 'TERRAIN-MOUNT-20260825-R03' || terrainManifest.derivedMounts?.length !== 9 || JSON.stringify(terrainFiles) !== JSON.stringify(terrainManifest.derivedMounts.map(item => item.file).sort())) throw new Error('La evidencia histórica R03 no conserva sus nueve derivados.');
for (const mount of terrainManifest.derivedMounts) {
  const png = await readFile(new URL(mount.file, terrainRoot));
  const digest = createHash('sha256').update(png).digest('hex');
  const bounds = pngAlphaBounds(png);
  if (png.toString('ascii', 1, 4) !== 'PNG' || png[25] !== 6 || png.readUInt32BE(16) !== mount.dimensionsPx[0] || png.readUInt32BE(20) !== mount.dimensionsPx[1] || digest !== mount.sha256 || !bounds?.fullyOpaque || bounds.x !== 0 || bounds.y !== 0 || bounds.w !== mount.dimensionsPx[0] || bounds.h !== mount.dimensionsPx[1]) throw new Error(`${mount.solidId} no coincide en RGBA, dimensiones, cobertura o SHA-256 con el derivado autorizado.`);
}
if (sourceText.includes('assets/playtest/terrain-mount-r03') || sourceText.includes('G0_terrain_r03_950x200.png')) throw new Error('El runtime R09 todavía carga los PNG precompuestos R03 rechazados por el playtest.');

const terrainR08Png = await readFile(new URL('terrain-continuous-950x200-r08.png', terrainR08Root));
const terrainR08Sha = createHash('sha256').update(terrainR08Png).digest('hex');
if (terrainR08Png.toString('ascii', 1, 4) !== 'PNG' || terrainR08Png.readUInt32BE(16) !== 950 || terrainR08Png.readUInt32BE(20) !== 200 || terrainR08Png[25] !== 2 || terrainR08Sha !== 'c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066') throw new Error('El maestro continuo R08 no coincide en dimensiones, formato opaco o SHA-256 con el aprobado para esta compilación.');

if (uiManifest.package_id !== 'UI_EDUCATIVA_R02_CANDIDATE' || uiManifest.status !== 'CANDIDATE_TECHNICAL_EXTRACTION' || uiManifest.game_ready !== false || uiManifest.items?.length !== 16) throw new Error('El manifiesto autorizado de UI R02 no conserva su identidad, estado candidato o sus 16 piezas.');
for (const item of uiManifest.items) {
  const filename = item.file.replace(/^sprites_rgba\//, '');
  const png = await readFile(new URL(filename, uiArtRoot));
  const digest = createHash('sha256').update(png).digest('hex');
  if (png.toString('ascii', 1, 4) !== 'PNG' || png[25] !== 6 || png.readUInt32BE(16) !== item.canvas_px[0] || png.readUInt32BE(20) !== item.canvas_px[1] || digest !== item.sha256) throw new Error(`La pieza UI ${filename} no coincide en RGBA, lienzo o SHA-256 con el manifiesto autorizado.`);
}
if (!html.includes('ui-r02.css') || !html.includes('data-ui-package="UI_EDUCATIVA_R02_CANDIDATE"') || !html.includes('assets/ui/r02/12_ui_icon_scar_paw.png') || !uiCss.includes('09_ui_puzzle_piece_candidate.png') || !uiCss.includes('mask:url("assets/ui/r02/09_ui_puzzle_piece_candidate.png")') || !uiCss.includes('border-image:url("assets/ui/r02/00_ui_panel_story_large.png")')) throw new Error('La UI R02 no quedó enlazada de forma completa o el receptor no deriva de la máscara alfa de la pieza activa.');

const boxPng = await readFile(new URL('objects/caja-rompible-intacta-1x1.png', worldArtRoot));
const boxBounds = pngAlphaBounds(boxPng);
if (!boxBounds || boxBounds.w < 90 || boxBounds.h < 90 || boxBounds.lastRow !== 99) throw new Error('La caja fuente no ocupa al menos 90 × 90 px o no contacta con la fila inferior.');
const remainsBounds=pngAlphaBounds(await readFile(new URL('objects/caja-rompible-restos-1x1.png',worldArtRoot)));
const plateFreeBounds=pngAlphaBounds(await readFile(new URL('objects/placa-presion-libre-1_5x0_5.png',worldArtRoot)));
const platePressedBounds=pngAlphaBounds(await readFile(new URL('objects/placa-presion-pulsada-1_5x0_5.png',worldArtRoot)));
if(99-remainsBounds.lastRow!==2||49-plateFreeBounds.lastRow!==16||49-platePressedBounds.lastRow!==14)throw new Error('Los insets inferiores medidos de restos o placa cambiaron sin actualizar el montaje de contacto.');

for (const [relative, targetRow] of [
  ['assets/playtest/e1-s1-candidate/eren/eren-reposo-00.png', 199],
  ['assets/playtest/e1-s1-candidate/eren/eren-reposo-01.png', 199],
  ['assets/playtest/e1-s1-candidate/scar/scar-reposo-00-candidate.png', 149],
  ['assets/playtest/e1-s1-candidate/scar/scar-reposo-01-candidate.png', 149],
  ['assets/playtest/e2-s2-jump-candidate/eren/eren-salto-impulso-00-candidate.png', 199],
  ['assets/playtest/e2-s2-jump-candidate/eren/eren-salto-impulso-01-candidate.png', 199],
  ['assets/playtest/e2-s2-jump-candidate/eren/eren-salto-aterrizaje-00-candidate.png', 199],
  ['assets/playtest/e2-s2-jump-candidate/eren/eren-salto-aterrizaje-01-candidate.png', 199],
  ['assets/playtest/e2-s2-jump-candidate/scar/scar-salto-impulso-00-candidate.png', 149],
  ['assets/playtest/e2-s2-jump-candidate/scar/scar-salto-impulso-01-candidate.png', 149],
  ['assets/playtest/e2-s2-jump-candidate/scar/scar-salto-aterrizaje-00-candidate.png', 149],
  ['assets/playtest/e2-s2-jump-candidate/scar/scar-salto-aterrizaje-01-candidate.png', 149],
]) {
  const bounds = pngAlphaBounds(await readFile(new URL(relative, root)));
  if (bounds?.lastRow !== targetRow) throw new Error(`${relative} no contacta en y=${targetRow}.`);
}
const source = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={
 getSim:()=>sim,
 reset:reason=>resetSimulation(reason),
 commandScar,
 render,
 locomotionState,
 selectLocomotionFrame,
 selectJumpFrame,
 selectCharacterFrame,
 startJumpVisual,
 clearJumpVisual,
 updateJumpVisual,
 getLocomotionPack:()=>LOCOMOTION_PACK,
 getJumpPack:()=>JUMP_PACK,
 getWorldArtPack:()=>WORLD_ART_PACK,
 getTerrainMountPack:()=>TERRAIN_MOUNT_PACK,
 getVisualContactPlane:()=>({...VISUAL_CONTACT_PLANE}),
 getContactBottomGaps:()=>JSON.parse(JSON.stringify(CONTACT_BOTTOM_GAPS_PX)),
 getUiArtPack:()=>UI_ART_PACK,
 getEdgeSupportPolicy:()=>({...EDGE_SUPPORT_POLICY}),
  getScarGapJump:()=>({...SCAR_GAP_JUMP}),
  horizontalSupportRatio,
  groundSupportState,
  applyErenEdgeSupport,
  targetVisualFootOffset,
  updateVisualFootAnchor,
  bodyRect,
  overlaps,
  setGamePanel,
 actorInGoalZone,
  moveBody,
 getTuning:()=>tuning,
 step:(input={},dt=FIXED_DT)=>physicsStep(dt,{left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false,...input})
};
})();`);

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id;
    this.dataset = {};
    this.classList = new ClassList();
    this.listeners = new Map();
    this.style = {};
    this.textContent = '';
    this.value = '';
    this.offsetWidth = 10;
    this.attributes = new Map();
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, pointerId: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  closest(selector) { return selector === 'button' ? this : null; }
}

const elements = new Map();
for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
const get = id => elements.get(id);
const controlMap = {
  moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
  moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
};
for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
for (const [id, value] of Object.entries({ heightTuning: '3', gapTuning: '4', walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;

const stations = [...'ABCDEF'].map(letter => { const element = new Element(); element.dataset.station = letter; return element; });
const body = new Element('body');
const documentListeners = new Map();
const document = {
  body,
  getElementById: id => get(id),
  querySelectorAll: selector => selector === '[data-controls]' ? [...elements.values()].filter(element => element.dataset.controls) : selector === '[data-station]' ? stations : [],
  createElement: () => new Element(),
  addEventListener(type, callback) {
    if (!documentListeners.has(type)) documentListeners.set(type, []);
    documentListeners.get(type).push(callback);
  },
};

const gradient = { addColorStop() {} };
const drawCalls = [];
const transformCalls = [];
const context2d = new Proxy({
  createLinearGradient: () => gradient,
  drawImage: (...args) => drawCalls.push(args),
  scale: (...args) => transformCalls.push(['scale', ...args]),
  translate: (...args) => transformCalls.push(['translate', ...args]),
}, {
  get(target, key) { if (key in target) return target[key]; return () => {}; },
  set(target, key, value) { target[key] = value; return true; },
});
get('gameCanvas').getContext = () => context2d;
get('gameCanvas').getBoundingClientRect = () => ({ width: 960, height: 540 });

const storage = new Map();
const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
const windowListeners = new Map();
let nextFrame = null;
let frameId = 0;
let sharedText = '';
const window = {
  document,
  devicePixelRatio: 1,
  innerWidth: 960,
  innerHeight: 540,
  AndroidShare: { shareText(subject, text) { sharedText = `${subject}\n${text}`; } },
  addEventListener(type, callback) {
    if (!windowListeners.has(type)) windowListeners.set(type, []);
    windowListeners.get(type).push(callback);
  },
  dispatchEvent(event) { for (const callback of windowListeners.get(event.type) || []) callback(event); },
  requestAnimationFrame(callback) { nextFrame = callback; return ++frameId; },
  cancelAnimationFrame() { nextFrame = null; },
};

class Image {
  constructor() { this.complete = true; this.naturalWidth = 1; this.naturalHeight = 1; this.decoding = ''; this._src = ''; }
  set src(value) { this._src = value; }
  get src() { return this._src; }
}

const sandbox = {
  window, document, navigator: { getGamepads: () => [] }, localStorage,
  requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
  Blob, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, setTimeout: callback => { callback(); return 1; }, clearTimeout() {},
  console, Image,
  completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
  tone() {}, playAzureSequence() {}, renderMenu() {},
};
window.localStorage = localStorage;
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: 'graybox-game.js' });

if (!sourceText.includes("APP_VERSION='34.0.0-graybox-r09-ground-contact-plane-candidate'") || !sourceText.includes("LOG_VERSION='GB01-v20'") || !gradle.includes('versionCode = 35') || !gradle.includes('versionName = "34.0.0-graybox-r09-ground-contact-plane-candidate"')) throw new Error('La versión Android y la versión del graybox no quedaron alineadas con R09.');
if (sourceText.includes('scar-master-neutral-right-r01-candidate.png')) throw new Error('El maestro neutral de Scar se incorporó indebidamente a la máquina de clips.');
if (!sourceText.includes("status:'CANDIDATE_PLAYTEST'") || !sourceText.includes('gameReady:false') || !sourceText.includes('ppu:100') || !sourceText.includes('transformScale:[1,1]') || !sourceText.includes('rootMotion:false') || !sourceText.includes('physicsAuthoritative:true')) throw new Error('El paquete visual perdió su estado candidato o su contrato de importación.');
if (!css.includes('.scar-button{top:0;left:50%') || !css.includes('background:#1769d2')) throw new Error('Scar no quedó arriba y azul en el rombo derecho.');
if (!css.includes('.run-button{left:4%;top:50%') || !css.includes('background:#159a65')) throw new Error('Correr no quedó a la izquierda y verde.');
if (!css.includes('.action-button{right:4%;top:50%') || !css.includes('background:#e13d42')) throw new Error('Acción no quedó a la derecha y roja.');
if (!css.includes('.jump-button{left:50%;bottom:0') || !css.includes('background:#f2b516')) throw new Error('Saltar no quedó abajo y amarillo.');
if (!html.includes('id="toggleGamePanel"') || !html.includes('id="gamePanel"') || !html.includes('aria-hidden="true"') || !css.includes('.game-card.panel-open .game-panel') || !css.includes('transform:translateX(105%)')) throw new Error('El registro no quedó oculto por defecto como cajón lateral accesible desde arriba a la derecha.');

get('directGame').click();
if (!body.classList.contains('game-mode')) throw new Error('El acceso directo no abrió el juego sin completar un cuento.');
if (get('game').classList.contains('panel-open') || get('gamePanel').getAttribute('aria-hidden') !== 'true' || get('toggleGamePanel').getAttribute('aria-expanded') !== 'false') throw new Error('El cajón de registro no empieza cerrado.');
get('toggleGamePanel').click();
if (!get('game').classList.contains('panel-open') || get('gamePanel').getAttribute('aria-hidden') !== 'false' || get('toggleGamePanel').getAttribute('aria-expanded') !== 'true') throw new Error('El botón superior no abre el cajón de registro.');
get('closeGamePanel').click();
if (get('game').classList.contains('panel-open') || get('gamePanel').getAttribute('aria-hidden') !== 'true') throw new Error('El cajón de registro no se cierra.');

const locomotionPack = window.__grayboxTest.getLocomotionPack();
const jumpPack = window.__grayboxTest.getJumpPack();
const worldArtPack = window.__grayboxTest.getWorldArtPack();
const terrainMountPack = window.__grayboxTest.getTerrainMountPack();
const uiArtPack = window.__grayboxTest.getUiArtPack();
const edgeSupportPolicy = window.__grayboxTest.getEdgeSupportPolicy();
const liveTuning = window.__grayboxTest.getTuning();
if (locomotionPack.eren.clips.idle.length !== 2 || locomotionPack.eren.clips.walk.length !== 4 || locomotionPack.eren.clips.run.length !== 4 || locomotionPack.scar.clips.idle.length !== 2 || locomotionPack.scar.clips.walk.length !== 4 || locomotionPack.scar.clips.run.length !== 4) throw new Error('Los clips no conservan el reparto 2/4/4 de ambos personajes.');
if (locomotionPack.eren.canvasPx.join('×') !== '300×200' || locomotionPack.eren.pivotPx.join(',') !== '150,200' || locomotionPack.scar.canvasPx.join('×') !== '200×150' || locomotionPack.scar.pivotPx.join(',') !== '100,150') throw new Error('Los lienzos o pivotes inferiores centrales no coinciden con el manifiesto.');
if (locomotionPack.eren.timingMs.idle !== 350 || locomotionPack.eren.timingMs.walk !== 120 || locomotionPack.eren.timingMs.run !== 90 || locomotionPack.scar.timingMs.idle !== 350 || locomotionPack.scar.timingMs.walk !== 120 || locomotionPack.scar.timingMs.run !== 90) throw new Error('Los timings candidatos no quedaron en 350/120/90 ms.');
if (jumpPack.incrementalOver !== locomotionPack.packageId || jumpPack.status !== 'CANDIDATE_PLAYTEST' || jumpPack.gameReady || jumpPack.ppu !== 100 || jumpPack.rootMotion || !jumpPack.physicsAuthoritative) throw new Error('E2/S2 no quedó integrado como ampliación candidata y gobernada por la física.');
if (jumpPack.eren.canvasPx.join('×') !== '300×200' || jumpPack.eren.pivotPx.join(',') !== '150,200' || jumpPack.eren.colliderModules.join('×') !== '1×1.5' || jumpPack.scar.canvasPx.join('×') !== '200×150' || jumpPack.scar.pivotPx.join(',') !== '100,150' || jumpPack.scar.colliderModules.join('×') !== '1.5×1') throw new Error('E2/S2 perdió lienzo completo, pivote inferior o collider externo contratado.');
if (Object.values(jumpPack.eren.clips).flat().length !== 6 || Object.values(jumpPack.scar.clips).flat().length !== 6) throw new Error('E2/S2 no conserva exactamente 6 fotogramas de salto por personaje.');
if (worldArtPack.packageId !== 'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01' || worldArtPack.status !== 'CANDIDATE_PLACEMENT' || worldArtPack.sourceStatus !== 'APPROVED_FUNCTIONAL' || worldArtPack.gameReady || !worldArtPack.geometryAuthoritative || worldArtPack.collidersChanged || Object.keys(worldArtPack.assets).length !== 19 || worldArtPack.runtimePlacementRevision !== 'SHARED_VISUAL_CONTACT_PLANE_R09') throw new Error('El lote visual R09 perdió su clasificación candidata, su plano de contacto o modificó la geometría.');
if (worldArtPack.assets.plateFree.fit !== 'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09' || worldArtPack.assets.plateFree.visibleCoverageModules !== 1.5 || worldArtPack.assets.platePressed.visibleCoverageModules !== 1.5) throw new Error('La placa R09 no ocupa visualmente sus 1,5 módulos con el encaje común de contacto.');
if (terrainMountPack.packageId !== 'TERRAIN-CONTACT-MOUNT-20260826-R06' || terrainMountPack.decisionId !== 'GB-PLAYTEST-20260826-R09' || terrainMountPack.replaces !== 'TERRAIN-CONTACT-MOUNT-20260826-R05' || terrainMountPack.predecessorStatus !== 'CANDIDATE_CONTACT_TOO_HIGH' || terrainMountPack.status !== 'CANDIDATE_PLAYTEST' || terrainMountPack.gameReady || terrainMountPack.ppu !== 100 || terrainMountPack.transformScale.join(',') !== '1,1' || terrainMountPack.runtimeDrawCallsPerSolid !== 1 || terrainMountPack.renderer !== 'CONTINUOUS_SOURCE_CROP_100PPU_WITH_CONTACT_PLANE' || terrainMountPack.runtimePrecomposedSolidPng !== false || terrainMountPack.runtimeHalfTileRepetition !== false || terrainMountPack.geometryChanged || terrainMountPack.collidersChanged || terrainMountPack.physicsChanged || terrainMountPack.pivotsChanged || terrainMountPack.sourceAsset?.sha256 !== terrainR08Sha || terrainMountPack.sourceAsset?.canvasPx?.join('×') !== '950×200') throw new Error('El lote R09 no conserva el terreno continuo R08 ni limita el cambio al plano visual de contacto.');
const visualContactPlane=window.__grayboxTest.getVisualContactPlane();
const contactBottomGaps=window.__grayboxTest.getContactBottomGaps();
if (visualContactPlane.status !== 'ACTIVE_R09' || visualContactPlane.insetPx !== 6 || visualContactPlane.ppu !== 100 || visualContactPlane.actorMode !== 'GROUNDED_ONLY' || visualContactPlane.terrainCoverage !== 'FULL_SOLID_UNCHANGED' || visualContactPlane.terrainPixelsChanged || visualContactPlane.geometryChanged || visualContactPlane.collidersChanged || visualContactPlane.physicsChanged || visualContactPlane.appliesTo.join(',') !== 'eren,scar,plate,box,boxRemains,lever') throw new Error('El plano visual común R09 no conserva el encaje de 6 px o altera la base física.');
if (contactBottomGaps.eren.run.join(',') !== '4,6,17,3' || contactBottomGaps.scar.run.join(',') !== '2,13,2,2' || contactBottomGaps.eren.walk.join(',') !== '5,3,4,3' || contactBottomGaps.scar.walk.join(',') !== '2,0,0,0') throw new Error('La normalización alfa no cubre todos los fotogramas terrestres medidos.');
if (uiArtPack.packageId !== 'UI_EDUCATIVA_R02_CANDIDATE' || uiArtPack.handoffId !== 'UI-20260825-R02' || uiArtPack.integrationStatus !== 'INTEGRATED_TECHNICAL_QA_PASS' || uiArtPack.status !== 'CANDIDATE_TECHNICAL_EXTRACTION' || uiArtPack.gameReady || uiArtPack.assetCount !== 16 || uiArtPack.textRendering !== 'NATIVE_LOCALISABLE' || uiArtPack.puzzleReceiver !== 'ACTIVE_PIECE_ALPHA_MASK' || uiArtPack.requiresDevicePlaytest !== true) throw new Error('El lote UI R02 no conserva el contrato de integración autorizado y candidato.');
if (edgeSupportPolicy.status !== 'ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN' || edgeSupportPolicy.appliesTo.join(',') !== 'eren' || edgeSupportPolicy.model !== 'natural_overlap' || edgeSupportPolicy.minimumOverlapRatio !== .001 || edgeSupportPolicy.automaticFall !== false || edgeSupportPolicy.naturalFallWhenNoOverlap !== true || edgeSupportPolicy.preserveHorizontalVelocity !== true || edgeSupportPolicy.edgePush || edgeSupportPolicy.snap || edgeSupportPolicy.ignoredSupport !== false || edgeSupportPolicy.supersedes !== 'ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN' || edgeSupportPolicy.visualFootAnchor?.status !== 'ACTIVE_R08' || edgeSupportPolicy.visualFootAnchor?.startRatio !== .42 || edgeSupportPolicy.visualFootAnchor?.physicsChanged !== false) throw new Error('La política R09 no conserva el apoyo permisivo tipo Mario ni el anclaje horizontal validado.');
if (jumpPack.eren.timingMs.impulso.join(',') !== '90,70' || jumpPack.eren.timingMs.aterrizaje.join(',') !== '80,160' || jumpPack.scar.timingMs.impulso.join(',') !== '90,70' || jumpPack.scar.timingMs.aterrizaje.join(',') !== '80,160') throw new Error('Los timings de impulso o aterrizaje no coinciden con 90+70 / 80+160 ms.');
if (liveTuning.walk !== 3.5 || liveTuning.run !== 6 || liveTuning.jump !== 15.9 || liveTuning.gravityUp !== 36 || liveTuning.gravityDown !== 44) throw new Error('La integración visual cambió velocidades, salto o gravedad vigentes.');

const visualProbe = { onGround: true, crouched: false, vx: 0, vy: 0, facing: 1, jumpVisualState: null, jumpVisualTime: 0 };
if (window.__grayboxTest.locomotionState(visualProbe) !== 'idle') throw new Error('Reposo no se selecciona a velocidad cero.');
visualProbe.vx = 3.5;
if (window.__grayboxTest.locomotionState(visualProbe) !== 'walk') throw new Error('Caminar no se selecciona a 3,5 m/s.');
visualProbe.vx = 4.5;
if (window.__grayboxTest.locomotionState(visualProbe) !== 'run') throw new Error('Correr no se selecciona desde el umbral de 4,5 m/s.');
visualProbe.onGround = false;
if (window.__grayboxTest.locomotionState(visualProbe) !== null) throw new Error('La locomoción terrestre se está usando indebidamente durante el salto.');
visualProbe.onGround = true; visualProbe.crouched = true;
if (window.__grayboxTest.locomotionState(visualProbe) !== null) throw new Error('El arte de locomoción se está forzando dentro del paso agachado sin clip autorizado.');
Object.assign(visualProbe, { crouched: false, vx: 0 });
if (window.__grayboxTest.selectLocomotionFrame('eren', visualProbe, .35).index !== 0 || window.__grayboxTest.selectLocomotionFrame('eren', visualProbe, 7).index !== 0) throw new Error('Eren no mantiene reposo-00 estático mientras se espera el lote R02 corregido.');
if (window.__grayboxTest.selectLocomotionFrame('scar', visualProbe, .35).index !== 1) throw new Error('El reposo de Scar perdió el movimiento de cola candidato.');
visualProbe.vx = 3.5;
if (window.__grayboxTest.selectLocomotionFrame('scar', visualProbe, .12).index !== 1) throw new Error('El bucle de andar de Scar no respeta 120 ms por fotograma.');
visualProbe.vx = 6;
if (window.__grayboxTest.selectLocomotionFrame('eren', visualProbe, .09).index !== 1) throw new Error('El bucle de correr de Eren no respeta 90 ms por fotograma.');

const jumpProbe = { x: 4, y: 2, onGround: false, crouched: false, vx: 3.5, vy: 15.9, facing: 1, jumpVisualState: null, jumpVisualTime: 0 };
window.__grayboxTest.startJumpVisual(jumpProbe);
if (window.__grayboxTest.selectJumpFrame('eren', jumpProbe).state !== 'impulso' || window.__grayboxTest.selectJumpFrame('eren', jumpProbe).index !== 0) throw new Error('Eren no empieza el salto en impulso-00.');
const unchangedTakeoff = { x: jumpProbe.x, y: jumpProbe.y, vx: jumpProbe.vx, vy: jumpProbe.vy };
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, .091);
if (window.__grayboxTest.selectJumpFrame('eren', jumpProbe).index !== 1) throw new Error('Eren no cambia a impulso-01 después de 90 ms.');
if (jumpProbe.x !== unchangedTakeoff.x || jumpProbe.y !== unchangedTakeoff.y || jumpProbe.vx !== unchangedTakeoff.vx || jumpProbe.vy !== unchangedTakeoff.vy) throw new Error('La máquina visual modificó la física durante el impulso.');
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, .07);
if (jumpProbe.jumpVisualState !== 'subida' || !window.__grayboxTest.selectJumpFrame('eren', jumpProbe).src.endsWith('eren-salto-subida-00-candidate.png')) throw new Error('Eren no mantiene subida-00 después de los 160 ms de impulso.');
jumpProbe.vy = -.01;
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, 1 / 60);
if (jumpProbe.jumpVisualState !== 'caida' || !window.__grayboxTest.selectJumpFrame('eren', jumpProbe).src.endsWith('eren-salto-caida-00-candidate.png')) throw new Error('Eren no cambia de subida a caída al cruzar el ápice físico.');
jumpProbe.onGround = true; jumpProbe.vy = 0;
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, 1 / 60);
if (jumpProbe.jumpVisualState !== 'aterrizaje' || window.__grayboxTest.selectJumpFrame('eren', jumpProbe).index !== 0) throw new Error('El primer contacto de Eren no inicia aterrizaje-00.');
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, .081);
if (window.__grayboxTest.selectJumpFrame('eren', jumpProbe).index !== 1) throw new Error('Eren no cambia a aterrizaje-01 después de 80 ms.');
window.__grayboxTest.updateJumpVisual('eren', jumpProbe, .16);
if (jumpProbe.jumpVisualState !== null || window.__grayboxTest.selectCharacterFrame('eren', jumpProbe, 0)?.kind !== 'locomotion') throw new Error('Eren no vuelve a locomoción después de 240 ms de aterrizaje.');

const scarJumpProbe = { onGround: false, crouched: false, vx: -6.5, vy: 8.5, facing: -1, jumpVisualState: null, jumpVisualTime: 0 };
window.__grayboxTest.startJumpVisual(scarJumpProbe);
if (!window.__grayboxTest.selectJumpFrame('scar', scarJumpProbe).src.endsWith('scar-salto-impulso-00-candidate.png')) throw new Error('Scar no usa su impulso-00 propio al saltar.');
scarJumpProbe.jumpVisualState = 'subida';
if (!window.__grayboxTest.selectJumpFrame('scar', scarJumpProbe).src.endsWith('scar-salto-subida-00-candidate.png')) throw new Error('Scar no usa su subida-00 propia durante el seguimiento.');

const visualSim = window.__grayboxTest.getSim();
Object.assign(visualSim.eren, { onGround: true, crouched: false, vx: 0, facing: -1, visualFootOffsetX: 0 });
Object.assign(visualSim.scar, { onGround: true, crouched: false, vx: 3, facing: -1 });
drawCalls.length = 0; transformCalls.length = 0; window.__grayboxTest.render();
const erenDraw = drawCalls.find(args => args[0].src.includes('/eren/'));
const scarDraw = drawCalls.find(args => args[0].src.includes('/scar/'));
const worldDrawSources = drawCalls.filter(args => args[0].src.includes('mundo1-functional/')).map(args => args[0].src);
const terrainDraws = drawCalls.filter(args => args[0].src.includes('terrain-mount-r03/'));
const nativeTerrainDraws = drawCalls.filter(args => args[0].src.includes('mundo1-functional/terrain/'));
const continuousTerrainDraws = drawCalls.filter(args => args[0].src.includes('terrain-r08/terrain-continuous-950x200-r08.png'));
if (!erenDraw || erenDraw[3] !== 150 || erenDraw[4] !== 100) throw new Error('Eren no se dibuja a escala 1:1 equivalente (3×2 módulos a cámara 50 px/módulo).');
if (!scarDraw || scarDraw[3] !== 100 || scarDraw[4] !== 75) throw new Error('Scar no se dibuja a escala 1:1 equivalente (2×1,5 módulos a cámara 50 px/módulo).');
if (Math.abs(erenDraw[2] - 343) > .01 || Math.abs(scarDraw[2] - 369) > .01) throw new Error(`R09 no aplica el encaje terrestre de 6 px más la compensación alfa por fotograma: Eren=${erenDraw[2]}, Scar=${scarDraw[2]}.`);
if (Math.abs(erenDraw[2]+erenDraw[4]-443)>.01 || Math.abs(scarDraw[2]+scarDraw[4]-1-443)>.01) throw new Error('Los píxeles visibles de reposo/andar no terminan 6 px de autoría dentro de la franja de terreno.');
for (const required of ['objects/caja-rompible-intacta-1x1.png', 'objects/placa-presion-libre-1_5x0_5.png', 'objects/interruptor-muro-1_5x2.png', 'objects/estrella-1x1.png', 'hazards/agua-4x1_5.png']) {
  if (!worldDrawSources.some(src => src.endsWith(required))) throw new Error(`El montaje visual no dibuja ${required} sobre el graybox.`);
}
if (terrainDraws.length !== 0) throw new Error(`R09 todavía dibuja ${terrainDraws.length} derivados precompuestos R03 rechazados.`);
if (continuousTerrainDraws.length !== 9 || continuousTerrainDraws.some(args => args.length !== 9)) throw new Error(`El terreno R09 no conserva exactamente un recorte continuo por cada uno de sus 9 sólidos visuales: ${continuousTerrainDraws.length}.`);
if (!continuousTerrainDraws.some(args => args[3] === 950 && args[4] === 200 && args[7] === 475 && args[8] === 100)) throw new Error('G0 no se dibuja con un único recorte continuo 950×200 a 100 PPU.');
if (!continuousTerrainDraws.some(args => args[3] === 250 && args[4] === 50 && args[7] === 125 && args[8] === 25)) throw new Error('U1 no se dibuja como un único recorte continuo de 2,5×0,5 módulos.');
if (continuousTerrainDraws.filter(args => args[3] === 150 && args[4] === 50 && args[7] === 75 && args[8] === 25).length < 4) throw new Error('U2, U3, TECHO_BAJO y la base de placa no comparten la receta continua exacta de 1,5×0,5 módulos.');
for (const rejected of ['terreno-relleno-1x1.png','terreno-superficie-1x1.png','terreno-superficie-2x1.png','terreno-superficie-4x1.png','terreno-plataforma-1_5x0_5.png']) if (nativeTerrainDraws.some(args=>args[0].src.endsWith(rejected))) throw new Error(`R09 todavía monta el módulo nativo rechazado ${rejected}.`);
const u0TerrainDraw = nativeTerrainDraws.find(args => args[0].src.endsWith('columna-ruina-1x4_5.png'));
const boxNormalizedDraw = drawCalls.find(args => args[0].src.endsWith('objects/caja-rompible-intacta-1x1.png'));
const plateFitDraw = drawCalls.find(args => args[0].src.endsWith('objects/placa-presion-libre-1_5x0_5.png'));
const leverContactDraw = drawCalls.find(args => args[0].src.endsWith('objects/interruptor-muro-1_5x2.png'));
if (!u0TerrainDraw || u0TerrainDraw[3] !== 50 || u0TerrainDraw[4] !== 225 || Math.abs(u0TerrainDraw[2] + 8.5 - 165) > .01) throw new Error('La primera fila visible de U0 no coincide con la línea física superior.');
if (!plateFitDraw || plateFitDraw.length !== 9 || plateFitDraw[1] !== 39 || plateFitDraw[2] !== 13 || plateFitDraw[3] !== 74 || plateFitDraw[4] !== 21 || plateFitDraw[7] !== 75 || Math.abs(plateFitDraw[8] - 75 * 21 / 74) > .01 || Math.abs(plateFitDraw[6]+plateFitDraw[8]-443)>.01) throw new Error('La placa libre no cubre 1,5 módulos o no comparte el encaje visual de 6 px sin deformarse.');
if (!boxNormalizedDraw || boxNormalizedDraw.length !== 5 || boxNormalizedDraw[3] !== 50 || boxNormalizedDraw[4] !== 50 || Math.abs(boxNormalizedDraw[2]+boxNormalizedDraw[4]-443)>.01 || sourceText.includes('drawWorldArtCover')) throw new Error('La caja no se dibuja desde el PNG fuente normalizado con el encaje visual común R09.');
if (!leverContactDraw || Math.abs(leverContactDraw[2]+leverContactDraw[4]-443)>.01) throw new Error('La palanca apoyada no comparte el plano visual de contacto R09.');
if (transformCalls.filter(call => call[0] === 'scale' && call[1] === -1 && call[2] === 1).length < 2) throw new Error('La orientación izquierda no usa reflejo horizontal controlado en ambos personajes.');

for(let frameIndex=0;frameIndex<4;frameIndex++){
 Object.assign(visualSim.eren,{onGround:true,crouched:false,vx:6,vy:0,facing:1});
 Object.assign(visualSim.scar,{onGround:true,crouched:false,vx:6,vy:0,facing:1});
 visualSim.elapsed=frameIndex*.09+.001;drawCalls.length=0;window.__grayboxTest.render();
 const erenRun=drawCalls.find(args=>args[0].src.includes('/eren/eren-correr-'));
 const scarRun=drawCalls.find(args=>args[0].src.includes('/scar/scar-correr-'));
 if(!erenRun||!scarRun)throw new Error(`No se pudo dibujar el fotograma terrestre ${frameIndex} para comprobar su alfa.`);
 const erenVisibleBottom=erenRun[2]+erenRun[4]-contactBottomGaps.eren.run[frameIndex]*.5;
 const scarVisibleBottom=scarRun[2]+scarRun[4]-contactBottomGaps.scar.run[frameIndex]*.5;
 if(Math.abs(erenVisibleBottom-443)>.01||Math.abs(scarVisibleBottom-443)>.01)throw new Error(`El fotograma de carrera ${frameIndex} no termina en el plano común R09: Eren=${erenVisibleBottom}, Scar=${scarVisibleBottom}.`);
}

Object.assign(visualSim.eren, { onGround: false, crouched: false, vx: 3.5, vy: 8, facing: -1, jumpVisualState: 'subida', jumpVisualTime: 0 });
Object.assign(visualSim.scar, { onGround: false, crouched: false, vx: -3, vy: -2, facing: -1, jumpVisualState: 'caida', jumpVisualTime: 0 });
drawCalls.length = 0; transformCalls.length = 0; window.__grayboxTest.render();
const erenJumpDraw = drawCalls.find(args => args[0].src.includes('e2-s2-jump-candidate/eren/'));
const scarJumpDraw = drawCalls.find(args => args[0].src.includes('e2-s2-jump-candidate/scar/'));
if (!erenJumpDraw || erenJumpDraw.length !== 5 || erenJumpDraw[3] !== 150 || erenJumpDraw[4] !== 100 || Math.abs(erenJumpDraw[2]-340)>.01 || !scarJumpDraw || scarJumpDraw.length !== 5 || scarJumpDraw[3] !== 100 || scarJumpDraw[4] !== 75 || Math.abs(scarJumpDraw[2]-365)>.01) throw new Error('Los saltos E2/S2 no conservan lienzo, escala y offset aéreo cero tras el encaje terrestre R09.');
if (transformCalls.filter(call => call[0] === 'scale' && call[1] === -1 && call[2] === 1).length < 2) throw new Error('Los saltos a izquierda no usan el reflejo horizontal del motor.');
Object.assign(visualSim.eren, { onGround: true, vx: 0, vy: 0, facing: 1 });
Object.assign(visualSim.scar, { onGround: true, vx: 0, vy: 0, facing: 1 });
window.__grayboxTest.clearJumpVisual(visualSim.eren);window.__grayboxTest.clearJumpVisual(visualSim.scar);

const grayboxWorld = window.__grayboxTest.getSim().world;
const solid = id => grayboxWorld.solids.find(item => item.id === id);
const modular = value => Math.abs(value * 2 - Math.round(value * 2)) < 1e-9;
for (const item of [...grayboxWorld.solids, ...grayboxWorld.hazards, grayboxWorld.marker, grayboxWorld.lever, grayboxWorld.goal, grayboxWorld.goalZone]) {
  for (const key of ['x', 'y', 'w', 'h']) if (!modular(item[key])) throw new Error(`${item.id || 'trigger'}.${key}=${item[key]} no respeta la retícula de 0,5 módulo.`);
}
if (!modular(grayboxWorld.star.x) || !modular(grayboxWorld.star.y)) throw new Error('El anclaje de la estrella no respeta la retícula de 0,5 módulo.');
const breakableBox = solid('CAJA_ROMPIBLE');
const u0Vertical = solid('U0_VERTICAL');
if (!breakableBox || !u0Vertical || solid('CAJA_VERTICAL') || solid('TECHO_CAJA')) throw new Error('La entrada no separó la caja inferior del pilar gris permanente U0.');
if (breakableBox.x !== 6.5 || breakableBox.y !== 2 || breakableBox.w !== 1 || breakableBox.h !== 1) throw new Error('La caja inferior no conserva las medidas contratadas de 1 × 1 módulo.');
if (u0Vertical.x !== 6.5 || u0Vertical.y !== 3 || u0Vertical.w !== 1 || u0Vertical.h !== 4.5 || u0Vertical.kind !== 'upper') throw new Error('U0_VERTICAL no conserva las medidas o la lectura visual de plataforma permanente.');
if (solid('G0').x + solid('G0').w - (u0Vertical.x + u0Vertical.w) !== 2) throw new Error('U0_VERTICAL no dejó 2 módulos de preparación antes del borde de G0.');
if (solid('G1').x - (solid('G0').x + solid('G0').w) !== 1.5) throw new Error('G0 → G1 no quedó como hueco obligatorio de 1,5 módulos.');
if (solid('TECHO_BAJO').x - solid('G1').x !== 1.5 || solid('TECHO_BAJO').x + solid('TECHO_BAJO').w !== 14) throw new Error('TECHO_BAJO no dejó un aterrizaje natural de 1,5 módulos tras G0 → G1.');
if (solid('U2').x - (solid('U1').x + solid('U1').w) !== 2) throw new Error('U1 y U2 no dejaron el canal horizontal más legible de 2 módulos.');
if (solid('G1').x + solid('G1').w - (solid('U1').x + solid('U1').w) !== 1.5) throw new Error('U1 no liberó los últimos 1,5 módulos de G1 para el salto inferior hacia G2.');
if (solid('G2').x - (solid('G1').x + solid('G1').w) !== 1.5) throw new Error('La ruta inferior G1 → G2 no quedó como hueco obligatorio de 1,5 módulos.');
if (solid('G2').x + solid('G2').w - (solid('U3').x + solid('U3').w) !== 2) throw new Error('U3 no dejó 2 módulos seguros antes del agua.');
const coopGate = solid('PUERTA_COOP');
if (!coopGate || coopGate.x !== 24 || coopGate.y !== 2 || coopGate.w !== .5 || coopGate.h !== 10 || coopGate.y + coopGate.h !== grayboxWorld.maxY || coopGate.kind !== 'gate') throw new Error('La compuerta cooperativa no sella de suelo a techo el final de G2.');
if (!grayboxWorld.lever || grayboxWorld.lever.x !== 21.5 || grayboxWorld.lever.y !== 2 || grayboxWorld.lever.w !== 1 || grayboxWorld.lever.h !== 1.5) throw new Error('La palanca de Eren no conserva su zona segura contratada sobre G2.');
const water = grayboxWorld.hazards.find(item => item.id === 'AGUA');
if (water.w !== 4 || solid('G3').x !== water.x + water.w) throw new Error('El agua no quedó como hueco de 4 módulos que exige CORRER + SALTAR.');
const spikes = grayboxWorld.hazards.find(item => item.id === 'PINCHOS');
if (spikes.w !== 1) throw new Error('Los pinchos no quedaron como obstáculo doble de 1 módulo con margen interno.');
if (spikes.x - (grayboxWorld.checkpoints.find(item => item.id === 'R2').x + .5) !== 2.5) throw new Error('R2 no dejó 2,5 módulos libres antes de los pinchos.');
if (grayboxWorld.goalZone.x !== 34.5 || grayboxWorld.goalZone.y !== 2 || grayboxWorld.goalZone.w !== 2 || grayboxWorld.goalZone.h !== .5) throw new Error('La zona final conjunta no ocupa el último tramo físico de G3.');

const ledgeSolid = { id: 'BORDE_PRUEBA', x: 0, y: 0, w: 10, h: 2 };
const edgeBodyForRatio = (side, ratio, w = 1) => ({
  x: side === 'right' ? ledgeSolid.x + ledgeSolid.w + w / 2 - ratio * w : ledgeSolid.x - w / 2 + ratio * w,
  y: 2, w, h: 1.5, minGroundSupportRatio: 0, vx: 0, vy: 0,
  onGround: true, supportRatio: ratio, lostSupportRatio: null, ignoredSupportId: null, hitWall: false,
});
const edgeEvidence = [];
for (const side of ['left', 'right']) for (const ratio of [.67, .42, .418, .24, .01]) for (let repetition = 1; repetition <= 10; repetition++) {
  const entity = edgeBodyForRatio(side, ratio), startX = entity.x;
  const eventsBefore = window.__grayboxTest.getSim().events.filter(event => event.type === 'caida_borde_sondas_pie').length;
  const transitioned = window.__grayboxTest.applyErenEdgeSupport(entity, [ledgeSolid]);
  for (let frame = 0; frame < 180; frame++) {
    entity.vy=Math.max(-16,entity.vy-44/60);window.__grayboxTest.moveBody(entity,1/60,[ledgeSolid]);window.__grayboxTest.applyErenEdgeSupport(entity,[ledgeSolid]);
  }
  const transitionCount=window.__grayboxTest.getSim().events.filter(event=>event.type==='caida_borde_sondas_pie').length-eventsBefore;
  if (transitioned || !entity.onGround || Math.abs(entity.y-2)>.001 || entity.x!==startX || entity.ignoredSupportId || transitionCount!==0) throw new Error(`NORMAL_PERMISSIVE_SUPPORT falla al ${(ratio*100).toFixed(1)} % por ${side}: onGround=${entity.onGround}, y=${entity.y}, xDelta=${entity.x-startX}, ignored=${entity.ignoredSupportId}.`);
  edgeEvidence.push({side,repetition,requestedRatio:ratio,measuredRatio:window.__grayboxTest.horizontalSupportRatio(entity,ledgeSolid),expected:'SUPPORTED',framesStable:180,transitionCount,xDelta:entity.x-startX,ignoredSupportId:entity.ignoredSupportId});
}
for(const side of ['left','right'])for(let repetition=1;repetition<=10;repetition++){
 const entity=edgeBodyForRatio(side,0),startX=entity.x;entity.vx=side==='right'?2.2:-2.2;
 for(let frame=0;frame<30;frame++){entity.vy=Math.max(-16,entity.vy-44/60);window.__grayboxTest.moveBody(entity,1/60,[ledgeSolid]);window.__grayboxTest.applyErenEdgeSupport(entity,[ledgeSolid]);}
 if(entity.onGround||entity.y>=1.9||entity.ignoredSupportId||Math.abs(entity.x-(startX+entity.vx*.5))>.001)throw new Error(`La salida natural completa por ${side} se reengancha, corrige X o no cae.`);
 edgeEvidence.push({side,repetition,requestedRatio:0,expected:'NATURAL_FALL',frames:30,finalY:Number(entity.y.toFixed(4)),xDelta:Number((entity.x-startX).toFixed(4)),ignoredSupportId:entity.ignoredSupportId});
}
const crouchedEdgeSupport=edgeBodyForRatio('right',.01,1.5);crouchedEdgeSupport.h=1;
for(let frame=0;frame<180;frame++){crouchedEdgeSupport.vy=Math.max(-16,crouchedEdgeSupport.vy-44/60);window.__grayboxTest.moveBody(crouchedEdgeSupport,1/60,[ledgeSolid]);window.__grayboxTest.applyErenEdgeSupport(crouchedEdgeSupport,[ledgeSolid]);}
if(!crouchedEdgeSupport.onGround||Math.abs(crouchedEdgeSupport.y-2)>.001)throw new Error('El collider agachado no conserva el contacto permisivo con 1 % de apoyo.');

const visualAnchorEvidence=[];
for(const side of ['left','right']){
 const entity=edgeBodyForRatio(side,.03);entity.visualFootOffsetX=0;const physicalX=entity.x;
 const target=window.__grayboxTest.targetVisualFootOffset(entity,[ledgeSolid]);
 if(Math.abs(target)<.35||Math.sign(target)!==(side==='left'?1:-1))throw new Error(`El anclaje visual R08 no desplaza los pies hacia el apoyo restante por ${side}: ${target}.`);
 for(let frame=0;frame<30;frame++)window.__grayboxTest.updateVisualFootAnchor(entity,[ledgeSolid],1/60);
 if(Math.abs(entity.visualFootOffsetX-target)>.001||entity.x!==physicalX||!entity.onGround)throw new Error(`El anclaje visual R08 alteró la física o no alcanzó el contacto por ${side}.`);
 const anchored=entity.visualFootOffsetX;entity.onGround=false;
 for(let frame=0;frame<30;frame++)window.__grayboxTest.updateVisualFootAnchor(entity,[ledgeSolid],1/60);
 if(Math.abs(entity.visualFootOffsetX)>.001||entity.x!==physicalX)throw new Error(`El anclaje visual R08 no vuelve a cero en el aire por ${side}.`);
 visualAnchorEvidence.push({side,supportRatio:.03,target:Number(target.toFixed(4)),anchored:Number(anchored.toFixed(4)),physicalXUnchanged:entity.x===physicalX,airborneReset:true});
}

const u1=solid('U1'),lowRoof=solid('TECHO_BAJO');
const u1Edge={x:13.91,y:u1.y+u1.h,w:1,h:1.5,vx:0,vy:0,onGround:true,supportRatio:.41,lostSupportRatio:null,ignoredSupportId:null,hitWall:false};
for(let frame=0;frame<240;frame++){u1Edge.vy=Math.max(-16,u1Edge.vy-44/60);window.__grayboxTest.moveBody(u1Edge,1/60,[u1,lowRoof]);window.__grayboxTest.applyErenEdgeSupport(u1Edge,[u1,lowRoof]);}
if(!u1Edge.onGround||Math.abs(u1Edge.y-4.5)>.001||window.__grayboxTest.overlaps(window.__grayboxTest.bodyRect(u1Edge),u1))throw new Error('La regresión U1 no conserva a Eren sobre el borde sin penetrar el sólido.');
u1Edge.x=13.49;u1Edge.onGround=false;
for(let frame=0;frame<180;frame++){u1Edge.vy=Math.max(-16,u1Edge.vy-44/60);window.__grayboxTest.moveBody(u1Edge,1/60,[u1,lowRoof]);window.__grayboxTest.applyErenEdgeSupport(u1Edge,[u1,lowRoof]);}
if(!u1Edge.onGround||Math.abs(u1Edge.y-3.5)>.001||u1Edge.ignoredSupportId||window.__grayboxTest.overlaps(window.__grayboxTest.bodyRect(u1Edge),u1)||window.__grayboxTest.getSim().events.some(event=>event.type==='caida_borde_sondas_pie'))throw new Error('La caída U1→TECHO_BAJO vuelve a dejar a Eren dentro de U1 o genera recontactos de sondas.');

const tick = time => {
  const callback = nextFrame;
  if (!callback) throw new Error('No hay frame de juego pendiente.');
  nextFrame = null;
  callback(time);
};
tick(16.7);

window.dispatchEvent({ type: 'keydown', code: 'Space', preventDefault() {} });
for (let i = 2; i < 15; i++) tick(i * 16.7);
const state = get('metricState').textContent;
if (state !== 'AIRE') throw new Error(`El salto no produjo estado AIRE: ${state}`);
if (!['impulso', 'subida'].includes(window.__grayboxTest.getSim().eren.jumpVisualState)) throw new Error('El salto físico de Eren no activó la secuencia visual de impulso/subida.');
window.dispatchEvent({ type: 'keyup', code: 'Space', preventDefault() {} });
for (let i = 15; i < 61; i++) tick(i * 16.7);

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
for (let i = 61; i < 80; i++) tick(i * 16.7);
const speed = get('metricSpeed').textContent;
if (!speed || speed === '0,0 m/s') throw new Error('La física no respondió al movimiento horizontal.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });

window.dispatchEvent({ type: 'keydown', code: 'KeyX', preventDefault() {} });
tick(1350);
window.dispatchEvent({ type: 'keyup', code: 'KeyX', preventDefault() {} });
tick(1367);
get('exportPlaytest').click();
const grayboxLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const grayboxAttempt = grayboxLog.attempts.at(-1);
if (!grayboxAttempt.events.some(event => event.type === 'caja_rota')) throw new Error('La acción no rompió la caja dentro del rango funcional.');
if (!grayboxAttempt.events.some(event => event.type === 'salto' && event.speed <= .25)) throw new Error('No quedó probado el salto vertical de Eren desde reposo.');
if (!sharedText.includes('Registro playtest') || !sharedText.includes('caja_rota')) throw new Error('El puente de compartir no recibió el registro del playtest.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowDown', preventDefault() {} });
for (let i = 83; i < 91; i++) tick(i * 16.7);
if (get('metricState').textContent !== 'AGACHADO') throw new Error('El collider agachado no se activó.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowDown', preventDefault() {} });

const placeActorsForScarTest = (scarX, scarY) => {
  const live = window.__grayboxTest.getSim();
  Object.assign(live.eren, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, ignoredSupportId: null });
  Object.assign(live.scar, { x: scarX, y: scarY, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpFrom: null, gapJumpAirTime: 0, gapJumpCooldown: 0, ignoredSupportId: null });
  window.__grayboxTest.commandScar();
  return live;
};

let scenarioTime = 1520;
let lowerScar = placeActorsForScarTest(11.05, 2);
for (let i = 0; i < 420 && lowerScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (lowerScar.scar.mode !== 'wait' || Math.abs(lowerScar.scar.y - 2) > .1) throw new Error('Scar no llegó físicamente a la placa desde detrás del túnel.');
if (!lowerScar.events.some(event => event.type === 'scar_paso_bajo_inicio') || !lowerScar.events.some(event => event.type === 'scar_en_huella') || !lowerScar.events.some(event => event.type === 'placa_scar_activada' && event.latched) || !lowerScar.events.some(event => event.type === 'placa_scar_enclavada') || !lowerScar.scarPlateLatched) throw new Error('No se registró el paso bajo y el enclavamiento físico de la placa por Scar.');
window.__grayboxTest.commandScar();
Object.assign(lowerScar.scar, { x: 12, y: 2, onGround: true, vx: 0, vy: 0 });
window.__grayboxTest.step({});
if (!lowerScar.scarPlateLatched || lowerScar.events.some(event => event.type === 'placa_scar_liberada')) throw new Error('La placa se liberó al marcharse Scar aunque debe funcionar como interruptor enclavado.');
Object.assign(lowerScar.eren, { x: 22, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
window.__grayboxTest.step({ action: true });window.__grayboxTest.step({});
if (!lowerScar.coopUnlocked || lowerScar.world.solids.some(item => item.id === 'PUERTA_COOP') || !lowerScar.events.some(event => event.type === 'palanca_eren_activada') || !lowerScar.events.some(event => event.type === 'puerta_coop_abierta')) throw new Error('Placa enclavada de Scar + palanca de Eren no abrió y enclavó la compuerta.');

window.__grayboxTest.reset('prueba_scar_desde_abajo');
let upperScar = placeActorsForScarTest(15.75, 4.5);
for (let i = 0; i < 720 && upperScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (upperScar.scar.mode !== 'wait' || Math.abs(upperScar.scar.y - 2) > .1) throw new Error(`Scar validó mal o no bajó desde U1: ${upperScar.scar.x.toFixed(2)}, ${upperScar.scar.y.toFixed(2)}, ${upperScar.scar.navPhase}`);
if (!upperScar.events.some(event => event.type === 'scar_ruta' && event.phase === 'bajar_u1_a_techo') || !upperScar.events.some(event => event.type === 'scar_en_huella')) throw new Error('La ruta de descenso U1 → placa no quedó registrada.');

window.__grayboxTest.reset('prueba_salto_hueco_ordinario_scar');
const gapScar = window.__grayboxTest.getSim();
Object.assign(gapScar.eren, { x: 22.4, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(gapScar.scar, { x: 17.1, y: 2, vx: 0, vy: 0, onGround: true, supportRatio: .9, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpFrom: null, gapJumpAirTime: 0, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1 });
for (let i = 0; i < 240 && !gapScar.events.some(event => event.type === 'scar_salto_hueco_exito'); i++) window.__grayboxTest.step({});
const gapScarSupport = window.__grayboxTest.groundSupportState(gapScar.scar, gapScar.world.solids);
if (!gapScar.events.some(event => event.type === 'scar_salto_hueco_inicio' && event.from === 'G1') || !gapScar.events.some(event => event.type === 'scar_salto_hueco_exito' && event.to === 'G2')) throw new Error(`Scar no convirtió el hueco G1 → G2 en un salto físico obligatorio: x=${gapScar.scar.x.toFixed(2)}, y=${gapScar.scar.y.toFixed(2)}, eventos=${gapScar.events.filter(event => event.type.startsWith('scar_salto')).map(event => `${event.type}:${event.from || ''}>${event.to || ''}:${event.reason || ''}`).join(',')}.`);
const gapStarts = gapScar.events.filter(event => event.type === 'scar_salto_hueco_inicio');
if (gapStarts.length !== 1) throw new Error(`Scar inició ${gapStarts.length} saltos para un único hueco; el bloqueo por salto activo no funciona.`);
if (gapScar.events.some(event => event.type === 'scar_recuperacion') || !gapScar.scar.onGround || gapScarSupport.ratio < .5) throw new Error('Scar terminó flotando entre plataformas o necesitó recuperación durante el salto ordinario.');

window.__grayboxTest.reset('prueba_retorno_bajo_scar');
const returningScar = window.__grayboxTest.getSim();
returningScar.boxBroken = true;
returningScar.world.solids = returningScar.world.solids.filter(item => item.id !== 'CAJA_ROMPIBLE');
Object.assign(returningScar.eren, { x: 8.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(returningScar.scar, { x: 22.2, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
for (let i = 0; i < 480 && !returningScar.events.some(event => event.type === 'scar_paso_bajo_fin'); i++) window.__grayboxTest.step({});
if (!returningScar.events.some(event => event.type === 'scar_salto_retorno_bajo_inicio') || !returningScar.events.some(event => event.type === 'scar_salto_retorno_bajo_exito')) throw new Error(`Scar no volvió físicamente de G2 a G1 por el enlace bajo: x=${returningScar.scar.x.toFixed(2)}, y=${returningScar.scar.y.toFixed(2)}, eventos=${returningScar.events.filter(event => event.type.startsWith('scar_')).map(event => `${event.type}:${event.reason || ''}`).join(',')}.`);
if (!returningScar.events.some(event => event.type === 'scar_paso_bajo_inicio') || !returningScar.events.some(event => event.type === 'scar_paso_bajo_fin')) throw new Error('Scar no regresó gateando por TECHO_BAJO después de volver desde G2.');
if (returningScar.events.some(event => event.type === 'scar_ruta' && event.phase === 'bajar_u1_a_techo')) throw new Error('Scar volvió a subir a U1 en vez de regresar por la ruta inferior.');
if (returningScar.events.some(event => event.type === 'scar_recuperacion')) throw new Error('El retorno bajo de Scar recurrió a una recuperación en vez de completar la ruta física.');

window.__grayboxTest.reset('prueba_entrada_u0');
const gateTest = window.__grayboxTest.getSim();
Object.assign(gateTest.eren, { x: 5.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
for (let cycle = 0; cycle < 3; cycle++) {
  for (let i = 0; i < 42; i++) window.__grayboxTest.step({ right: true, run: true, jump: true });
  for (let i = 0; i < 8; i++) window.__grayboxTest.step({ right: true, run: true });
}
if (gateTest.eren.x > 6.01 || gateTest.boxBroken) throw new Error('Eren pudo superar U0 y la caja inferior sin romperla.');
Object.assign(gateTest.eren, { x: 5.75, y: 3.4, vx: 0, vy: 0, onGround: false, crouched: false, w: 1, h: 1.5 });
window.__grayboxTest.step({ action: true });window.__grayboxTest.step({});
if (gateTest.boxBroken) throw new Error('Golpear el tramo gris superior rompió indebidamente la caja inferior.');
Object.assign(gateTest.eren, { x: 5.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
window.__grayboxTest.step({ action: true });window.__grayboxTest.step({});
if (!gateTest.boxBroken || gateTest.world.solids.some(item => item.id === 'CAJA_ROMPIBLE') || !gateTest.world.solids.some(item => item.id === 'U0_VERTICAL')) throw new Error('ACCIÓN no retiró solo la caja inferior o retiró indebidamente U0_VERTICAL.');
for (let i = 0; i < 35; i++) window.__grayboxTest.step({ right: true, run: true });
if (gateTest.eren.x > 6.01) throw new Error('Eren atravesó de pie la abertura de 1 módulo bajo U0.');
for (let i = 0; i < 90; i++) window.__grayboxTest.step({ right: true, crouch: true });
if (gateTest.eren.x <= 8) throw new Error('La entrada no quedó transitable agachado después de romper la caja inferior.');

window.__grayboxTest.reset('prueba_hueco_g0_g1_sin_salto');
const mandatoryFirstGap = window.__grayboxTest.getSim();
mandatoryFirstGap.boxBroken = true;
mandatoryFirstGap.world.solids = mandatoryFirstGap.world.solids.filter(item => item.id !== 'CAJA_ROMPIBLE');
Object.assign(mandatoryFirstGap.eren, { x: 8.75, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
for (let i = 0; i < 180; i++) window.__grayboxTest.step({ right: true });
if (!mandatoryFirstGap.events.some(event => event.type === 'daño' && event.kind === 'caída')) throw new Error('Eren todavía pudo cruzar andando el hueco G0 → G1; el salto no quedó obligado.');

window.__grayboxTest.reset('prueba_hueco_g0_g1_con_salto');
const firstGapJump = window.__grayboxTest.getSim();
firstGapJump.boxBroken = true;
firstGapJump.world.solids = firstGapJump.world.solids.filter(item => item.id !== 'CAJA_ROMPIBLE');
Object.assign(firstGapJump.eren, { x: 9, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
for (let i = 0; i < 90 && !(firstGapJump.eren.onGround && firstGapJump.eren.x >= 11.1); i++) window.__grayboxTest.step({ right: true, jump: true });
if (firstGapJump.events.some(event => event.type === 'daño' && event.kind === 'caída') || firstGapJump.eren.x < 11.1 || Math.abs(firstGapJump.eren.y - 2) > .1) throw new Error(`El hueco G0 → G1 obliga a saltar pero no ofrece un aterrizaje normal: x=${firstGapJump.eren.x.toFixed(2)}, y=${firstGapJump.eren.y.toFixed(2)}.`);
if (!firstGapJump.events.some(event => event.type === 'salto' && event.speed >= 3.3 && event.speed <= 3.6)) throw new Error('No quedó probado el salto hacia delante de Eren a velocidad de caminar.');
if (firstGapJump.eren.jumpVisualState !== 'aterrizaje' || window.__grayboxTest.selectJumpFrame('eren', firstGapJump.eren).index !== 0) throw new Error('El contacto real de Eren sobre G1 no inició aterrizaje-00.');

window.__grayboxTest.reset('prueba_hueco_g1_g2_sin_salto');
const mandatoryGap = window.__grayboxTest.getSim();
Object.assign(mandatoryGap.eren, { x: 17, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
for (let i = 0; i < 180; i++) window.__grayboxTest.step({ right: true });
if (!mandatoryGap.events.some(event => event.type === 'daño' && event.kind === 'caída') || mandatoryGap.eren.x >= 19.5) throw new Error('Eren todavía pudo cruzar andando el hueco G1 → G2; el salto no quedó obligado.');

window.__grayboxTest.reset('prueba_ruta_inferior_g1_g2');
const lowerRoute = window.__grayboxTest.getSim();
// El salto parte del último tramo útil de G1 y valida un aterrizaje natural en G2,
// sin exigir una zona central artificial ni aceptar que caminar supere el hueco.
Object.assign(lowerRoute.eren, { x: 17.8, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(lowerRoute.scar, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 15.75, navPhase: 'wait', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
for (let i = 0; i < 110; i++) window.__grayboxTest.step({ right: true, jump: true });
if (lowerRoute.events.some(event => event.type === 'daño' && event.kind === 'caída') || lowerRoute.eren.x < 20.5 || Math.abs(lowerRoute.eren.y - 2) > .1) throw new Error(`La ruta inferior G1 → G2 sigue bloqueada por U1: x=${lowerRoute.eren.x.toFixed(2)}, y=${lowerRoute.eren.y.toFixed(2)}, eventos=${lowerRoute.events.filter(event => ['salto','daño','anclaje'].includes(event.type)).map(event => `${event.type}:${event.x ?? event.kind ?? event.id}`).join(',')}.`);

window.__grayboxTest.reset('prueba_enclavamiento_cooperativo');
const interlock = window.__grayboxTest.getSim();
Object.assign(interlock.eren, { x: 22, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(interlock.scar, { x: 12, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 12, navPhase: 'wait', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
window.__grayboxTest.step({ action: true });window.__grayboxTest.step({});
if (!interlock.erenSwitchArmed || interlock.coopUnlocked || !interlock.world.solids.some(item => item.id === 'PUERTA_COOP') || !interlock.events.some(event => event.type === 'palanca_eren_activada')) throw new Error('La palanca no quedó activada de forma independiente antes de que Scar llegara a la placa.');
const lockedGateStarts = [
  { id: 'G2', x: 22, y: 2 },
  { id: 'U1', x: 15.75, y: 4.5 },
  { id: 'U2', x: 19.25, y: 6.5 },
  { id: 'U3', x: 21.75, y: 5 },
];
for (const start of lockedGateStarts) {
  Object.assign(interlock.eren, { x: start.x, y: start.y, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  interlock.checkpoint = { id: 'R1', x: 22, y: 2 };
  for (let cycle = 0; cycle < 4; cycle++) {
    for (let i = 0; i < 48; i++) window.__grayboxTest.step({ right: true, run: true, jump: true });
    for (let i = 0; i < 8; i++) window.__grayboxTest.step({ right: true, run: true });
  }
  if (interlock.eren.x > 23.51 || interlock.coopUnlocked || interlock.checkpoint.id === 'R2') throw new Error(`Eren pudo omitir la compuerta cerrada desde ${start.id}: x=${interlock.eren.x.toFixed(2)}, ancla=${interlock.checkpoint.id}.`);
}
Object.assign(interlock.eren, { x: 29.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
interlock.checkpoint = { id: 'R1', x: 22, y: 2 };
window.__grayboxTest.step({});
if (interlock.eren.x > 23.51 || interlock.checkpoint.id === 'R2' || !interlock.events.some(event => event.type === 'bypass_puzle_bloqueado')) throw new Error('La salvaguarda no devolvió a Eren al lado seguro ni impidió activar R2 tras un bypass accidental.');
Object.assign(interlock.scar, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'marker', waitX: null, navPhase: 'ir_a_placa', navTargetX: 15.75, navTargetY: 2, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
window.__grayboxTest.step({});
if (!interlock.coopUnlocked || interlock.world.solids.some(item => item.id === 'PUERTA_COOP') || !interlock.events.some(event => event.type === 'puzle_coop_completado' && event.trigger === 'placa_scar')) throw new Error('Scar no abrió la compuerta al completar después la placa con la palanca ya activada.');
if (interlock.scar.mode !== 'follow' || !interlock.events.some(event => event.type === 'scar_reanuda_tras_puzle')) throw new Error('Scar permaneció parada en la placa después de abrirse la compuerta.');

const solveCoopForTest = live => {
  Object.assign(live.scar, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 15.75, navPhase: 'placa_confirmada', navTargetX: 15.75, navTargetY: 2, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
  live.scarPlateLatched = true;
  Object.assign(live.eren, { x: 22, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
  window.__grayboxTest.step({ action: true });window.__grayboxTest.step({});
  if (!live.coopUnlocked || live.world.solids.some(item => item.id === 'PUERTA_COOP')) throw new Error('No se pudo preparar el puzle cooperativo para la prueba de recorrido.');
  if (live.scar.mode !== 'follow') throw new Error('Scar no retomó el seguimiento automáticamente al resolver el puzle.');
};

window.__grayboxTest.reset('prueba_agua_andando');
const walkWater = window.__grayboxTest.getSim();
solveCoopForTest(walkWater);
Object.assign(walkWater.eren, { x: 23.5, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
walkWater.checkpoint = { id: 'R1', x: 22, y: 2 };
for (let i = 0; i < 90; i++) window.__grayboxTest.step({ right: true, jump: true });
if (!walkWater.events.some(event => event.type === 'daño' && event.kind === 'water')) throw new Error('El hueco de agua se pudo cruzar andando aunque debe exigir CORRER + SALTAR.');

window.__grayboxTest.reset('prueba_agua_corriendo');
const runWater = window.__grayboxTest.getSim();
solveCoopForTest(runWater);
// Despegue todavía plenamente apoyado, pero lo bastante cerca del borde para alcanzar G3
// con contacto natural sobre la plataforma de llegada.
Object.assign(runWater.eren, { x: 23.7, y: 2, vx: 6, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
runWater.checkpoint = { id: 'R1', x: 22, y: 2 };
for (let i = 0; i < 90; i++) window.__grayboxTest.step({ right: true, run: true, jump: true });
if (runWater.events.some(event => event.type === 'daño' && event.kind === 'water') || runWater.eren.x < 29) throw new Error(`El hueco de agua no se cruzó de forma fiable corriendo y saltando: x=${runWater.eren.x.toFixed(2)}, y=${runWater.eren.y.toFixed(2)}, eventos=${runWater.events.filter(event => ['salto','daño','anclaje'].includes(event.type)).map(event => `${event.type}:${event.x ?? event.kind ?? event.id}`).join(',')}.`);
if (!runWater.events.some(event => event.type === 'salto' && event.speed >= 5.8)) throw new Error('No quedó probado el salto de Eren iniciado a velocidad de carrera.');

window.__grayboxTest.reset('prueba_pinchos_andando');
const walkSpikes = window.__grayboxTest.getSim();
solveCoopForTest(walkSpikes);
Object.assign(walkSpikes.eren, { x: 31, y: 2, vx: 3.5, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
walkSpikes.checkpoint = { id: 'R2', x: 29.5, y: 2 };
for (let i = 0; i < 80; i++) window.__grayboxTest.step({ right: true, jump: true });
if (walkSpikes.events.some(event => event.type === 'daño' && event.kind === 'spikes') || walkSpikes.eren.x < 34) throw new Error(`El salto normal sobre los pinchos sigue siendo demasiado justo andando: x=${walkSpikes.eren.x.toFixed(2)}, y=${walkSpikes.eren.y.toFixed(2)}, daños=${walkSpikes.events.filter(event => event.type === 'daño').map(event => event.kind).join(',')}.`);

window.__grayboxTest.reset('prueba_salto_largo_scar');
const longJump = window.__grayboxTest.getSim();
solveCoopForTest(longJump);
Object.assign(longJump.eren, { x: 29.25, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(longJump.scar, { x: 22, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
for (let i = 0; i < 100 && !longJump.events.some(event => event.type === 'scar_salto_largo_exito'); i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (!longJump.events.some(event => event.type === 'scar_salto_largo_inicio') || !longJump.events.some(event => event.type === 'scar_salto_largo_exito')) throw new Error(`Scar no completó físicamente el enlace contextual G2 → G3: x=${longJump.scar.x.toFixed(2)}, y=${longJump.scar.y.toFixed(2)}, traversal=${longJump.scar.traversal}, eventos=${longJump.events.filter(event => event.type.startsWith('scar_')).map(event => `${event.type}:${event.reason || ''}`).join(',')}.`);
if (longJump.events.some(event => event.type === 'scar_recuperacion' && event.reason === 'water')) throw new Error('Scar cayó al agua durante su enlace contextual.');
if (Math.abs(longJump.scar.y - 2) > .1 || longJump.scar.x < 27.25) throw new Error('Scar no aterrizó apoyada sobre G3 después del salto largo.');
if (longJump.scar.jumpVisualState !== 'aterrizaje' || window.__grayboxTest.selectJumpFrame('scar', longJump.scar).index !== 0) throw new Error('El contacto real de Scar sobre G3 no inició aterrizaje-00.');

Object.assign(longJump.eren, { x: 35.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(longJump.scar, { x: 31, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
scenarioTime += 16.7; tick(scenarioTime);
if (!longJump.goalPending || longJump.complete) throw new Error('La meta no esperó a Scar antes de celebrar.');
for (let i = 0; i < 120 && !longJump.complete; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (!longJump.complete || !longJump.events.some(event => event.type === 'scar_salto_pinchos_exito') || !longJump.events.some(event => event.type === 'meta_reunion_scar')) throw new Error('Scar no evitó los pinchos o la reunión real no cerró la meta.');
if (longJump.events.some(event => event.type === 'scar_recuperacion' && event.reason === 'spikes')) throw new Error('Scar tocó los pinchos durante la reunión en meta.');

const scarFinalRouteRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  window.__grayboxTest.reset(`prueba_ruta_final_scar_${repetition}`);
  const live = window.__grayboxTest.getSim();
  solveCoopForTest(live);
  Object.assign(live.eren, { x: 35.5, y: 2, vx: 0, vy: 0, onGround: true, supportId: 'G3', crouched: false, w: 1, h: 1.5, facing: 1, ignoredSupportId: null });
  Object.assign(live.scar, { x: 23.1, y: 2, vx: 0, vy: 0, onGround: true, supportId: 'G2', supportRatio: 1, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpFrom: null, gapJumpAirTime: 0, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1, spikeSafetyWaitLogged: false });
  for (let frame = 0; frame < 720 && !live.complete; frame++) window.__grayboxTest.step({});
  const longStarts = live.events.filter(event => event.type === 'scar_salto_largo_inicio').length;
  const longSuccesses = live.events.filter(event => event.type === 'scar_salto_largo_exito').length;
  const spikeStarts = live.events.filter(event => event.type === 'scar_salto_pinchos_inicio').length;
  const spikeSuccesses = live.events.filter(event => event.type === 'scar_salto_pinchos_exito').length;
  const spikeRecoveries = live.events.filter(event => event.type === 'scar_recuperacion' && event.reason === 'spikes').length;
  if (!live.complete || longStarts !== 1 || longSuccesses !== 1 || spikeStarts !== 1 || spikeSuccesses !== 1 || spikeRecoveries !== 0) throw new Error(`Ruta final de Scar no determinista en repetición ${repetition}: complete=${live.complete}, long=${longStarts}/${longSuccesses}, spikes=${spikeStarts}/${spikeSuccesses}, recoveries=${spikeRecoveries}, x=${live.scar.x.toFixed(2)}.`);
  scarFinalRouteRuns.push({ repetition, complete: live.complete, longStarts, longSuccesses, spikeStarts, spikeSuccesses, spikeRecoveries, finalX: Number(live.scar.x.toFixed(3)) });
}

window.__grayboxTest.reset('prueba_meta_no_vale_reunion_en_g3');
const strictGoal = window.__grayboxTest.getSim();
solveCoopForTest(strictGoal);
Object.assign(strictGoal.eren, { x: 35.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, ignoredSupportId: null });
Object.assign(strictGoal.scar, { x: 28.2, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpFrom: null, gapJumpAirTime: 0, gapJumpCooldown: 0, ignoredSupportId: null });
window.__grayboxTest.step({});
if (!strictGoal.goalPending || strictGoal.complete) throw new Error('La zona final no abrió la espera estricta de Scar.');
Object.assign(strictGoal.eren, { x: 28.9, y: 2, vx: 0, vy: 0, onGround: true, facing: 1, ignoredSupportId: null });
Object.assign(strictGoal.scar, { x: 28.2, y: 2, vx: 0, vy: 0, onGround: true, mode: 'follow', traversal: null, ignoredSupportId: null });
for (let i = 0; i < 5; i++) window.__grayboxTest.step({});
if (strictGoal.complete || strictGoal.events.some(event => event.type === 'meta_reunion_scar')) throw new Error('La misión terminó al reencontrarse en cualquier punto de G3 fuera de la meta.');
Object.assign(strictGoal.eren, { x: 35.5, y: 2, vx: 0, vy: 0, onGround: true, facing: 1, ignoredSupportId: null });
Object.assign(strictGoal.scar, { x: 35, y: 2, vx: 0, vy: 0, onGround: true, mode: 'follow', traversal: null, ignoredSupportId: null });
window.__grayboxTest.step({});
if (!strictGoal.complete || !strictGoal.events.some(event => event.type === 'meta_reunion_scar' && event.erenX >= 34.5 && event.scarX >= 34.5)) throw new Error('La misión no exige y valida a Eren y Scar simultáneamente dentro de la meta real.');

window.__grayboxTest.reset('prueba_llamada_meta_sin_teletransporte');
const delayedReunion = window.__grayboxTest.getSim();
solveCoopForTest(delayedReunion);
Object.assign(delayedReunion.eren, { x: 35.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(delayedReunion.scar, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 15.75, navPhase: 'wait', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
window.__grayboxTest.step({});
delayedReunion.goalWait = 8;
window.__grayboxTest.commandScar();
for (let i = 0; i < 60; i++) window.__grayboxTest.step({});
if (delayedReunion.events.some(event => event.type === 'scar_recuperacion' && (event.reason === 'reunion_meta' || event.reason === 'fuera_de_camara'))) throw new Error('Llamar a Scar desde la meta provocó una recuperación inmediata en vez de darle tiempo para recorrer el nivel.');

window.__grayboxTest.reset('prueba_llamada_lejana_sin_recuperacion');
const distantCall = window.__grayboxTest.getSim();
solveCoopForTest(distantCall);
Object.assign(distantCall.eren, { x: 34, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(distantCall.scar, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 15.75, navPhase: 'wait', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
window.__grayboxTest.commandScar();
for (let i = 0; i < 60; i++) window.__grayboxTest.step({});
if (distantCall.events.some(event => event.type === 'scar_recuperacion' && event.reason === 'fuera_de_camara')) throw new Error('Llamar a Scar desde lejos todavía provoca una recuperación antes de darle margen para recorrer el nivel.');

get('playLab').click();
stations.find(button => button.dataset.station === 'E').click();
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keydown', code: 'KeyC', preventDefault() {} });
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keyup', code: 'KeyC', preventDefault() {} });
for (let i = 0; i < 8; i++) { scenarioTime += 16.7;tick(scenarioTime); }
if (get('metricScar').textContent !== 'ESPERA') throw new Error('La orden independiente a Scar no cambió su estado.');

stations.find(button => button.dataset.station === 'F').click();
scenarioTime += 16.7;tick(scenarioTime);
const prompt = get('gamePrompt').textContent;
if (!prompt.includes('agua') && !prompt.includes('pinchos')) throw new Error('La estación F no mostró su objetivo de daño.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keydown', code: 'ShiftLeft', preventDefault() {} });
for (let i = 0; i < 111; i++) { scenarioTime += 16.7;tick(scenarioTime); }
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keyup', code: 'ShiftLeft', preventDefault() {} });

get('toggleDebug').click();
get('exportPlaytest').click();
if (!localStorage.getItem('graybox-last-playtest')) throw new Error('No se guardó el registro del playtest.');
const labLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const damageAttempt = labLog.attempts.find(attempt => attempt.events.some(event => event.type === 'daño'));
if (!damageAttempt) throw new Error('La estación F no registró daño y retorno.');
if (labLog.attemptCount < 4) throw new Error('El registro no conservó los intentos anteriores después de reiniciar y cambiar de escena.');
if (labLog.attempts.some(attempt => attempt.tuning.run !== 6)) throw new Error('La velocidad de carrera dejó de estar fijada en 6,0.');
if (labLog.appVersion !== '34.0.0-graybox-r09-ground-contact-plane-candidate' || labLog.version !== 'GB01-v20') throw new Error('El registro no identifica la candidata R09.');
if (labLog.visuals?.status !== 'CANDIDATE_PLAYTEST' || labLog.visuals?.gameReady !== false || labLog.visuals?.frameCounts?.locomotion?.eren !== 10 || labLog.visuals?.frameCounts?.locomotion?.scar !== 10 || labLog.visuals?.frameCounts?.jump?.eren !== 6 || labLog.visuals?.frameCounts?.jump?.scar !== 6 || labLog.visuals?.jumpArt !== 'EREN_E2_SCAR_S2_SALTO_R01_CANDIDATE' || labLog.visuals?.rootMotion !== false || labLog.visuals?.physicsAuthoritative !== true) throw new Error('El registro no conserva el contrato visual candidato incremental E1/S1 + E2/S2.');
if (labLog.visuals?.packages?.worldArt !== 'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01' || labLog.visuals?.worldArt?.status !== 'CANDIDATE_PLACEMENT' || labLog.visuals?.worldArt?.sourceStatus !== 'APPROVED_FUNCTIONAL' || labLog.visuals?.worldArt?.assetCount !== 19 || labLog.visuals?.worldArt?.collidersChanged !== false || labLog.visuals?.worldArt?.runtimePlacementRevision !== 'SHARED_VISUAL_CONTACT_PLANE_R09' || labLog.visuals?.worldArt?.boxRemainsFit !== 'SOURCE_BOTTOM_CONTACT_INSET_R09' || labLog.visuals?.worldArt?.plateFit !== 'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09' || labLog.visuals?.worldArt?.plateVisibleCoverageModules?.free !== 1.5 || labLog.visuals?.worldArt?.plateVisibleCoverageModules?.pressed !== 1.5 || labLog.visuals?.worldArt?.visualContactPlane?.insetPx !== 6 || labLog.visuals?.worldArt?.visualContactPlane?.physicsChanged !== false) throw new Error('El registro no conserva la trazabilidad y el plano común de contacto del arte R09.');
if (labLog.visuals?.packages?.terrain !== 'TERRAIN-CONTACT-MOUNT-20260826-R06' || labLog.visuals?.terrainMount?.packageId !== 'TERRAIN-CONTACT-MOUNT-20260826-R06' || labLog.visuals?.terrainMount?.decisionId !== 'GB-PLAYTEST-20260826-R09' || labLog.visuals?.terrainMount?.replaces !== 'TERRAIN-CONTACT-MOUNT-20260826-R05' || labLog.visuals?.terrainMount?.predecessorStatus !== 'CANDIDATE_CONTACT_TOO_HIGH' || labLog.visuals?.terrainMount?.status !== 'CANDIDATE_PLAYTEST' || labLog.visuals?.terrainMount?.gameReady !== false || labLog.visuals?.terrainMount?.sourceAssetCount !== 2 || labLog.visuals?.terrainMount?.solidRecipeCount !== 9 || labLog.visuals?.terrainMount?.renderer !== 'CONTINUOUS_SOURCE_CROP_100PPU_WITH_CONTACT_PLANE' || labLog.visuals?.terrainMount?.runtimeDrawCallsPerSolid !== 1 || labLog.visuals?.terrainMount?.runtimePrecomposedSolidPng !== false || labLog.visuals?.terrainMount?.geometryChanged !== false || labLog.visuals?.terrainMount?.collidersChanged !== false || labLog.visuals?.terrainMount?.physicsChanged !== false || labLog.visuals?.terrainMount?.renderOffsets?.eren?.groundedInsetPx !== 6 || labLog.visuals?.terrainMount?.renderOffsets?.scar?.groundedInsetPx !== 6 || labLog.visuals?.terrainMount?.renderOffsets?.eren?.airborneInsetPx !== 0 || labLog.visuals?.terrainMount?.renderOffsets?.scar?.airborneInsetPx !== 0 || labLog.visuals?.terrainMount?.visualFootAnchor?.status !== 'ACTIVE_R08' || labLog.visuals?.terrainMount?.visualContactPlane?.status !== 'ACTIVE_R09' || labLog.visuals?.terrainMount?.visualContactPlane?.terrainCoverage !== 'FULL_SOLID_UNCHANGED' || labLog.visuals?.terrainMount?.sourceAsset?.sha256 !== terrainR08Sha) throw new Error('El registro no conserva el terreno continuo ni el encaje de 6 px exclusivamente visual de R09.');
if (labLog.visuals?.packages?.ui !== 'UI_EDUCATIVA_R02_CANDIDATE' || labLog.visuals?.uiArt?.handoffId !== 'UI-20260825-R02' || labLog.visuals?.uiArt?.integrationStatus !== 'INTEGRATED_TECHNICAL_QA_PASS' || labLog.visuals?.uiArt?.gameReady !== false || labLog.visuals?.uiArt?.assetCount !== 16 || labLog.visuals?.uiArt?.runtimePanel !== 'COLLAPSED_DRAWER_TOP_RIGHT' || labLog.visuals?.uiArt?.defaultPanelOpen !== false || labLog.visuals?.uiArt?.gameViewport !== 'FULL_WIDTH') throw new Error('El registro no conserva la UI R02 ni el cajón de pantalla completa en R09.');
if (labLog.visuals?.edgeSupport?.status !== 'ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN' || labLog.visuals?.edgeSupport?.appliesTo?.join(',') !== 'eren' || labLog.visuals?.edgeSupport?.model !== 'natural_overlap' || labLog.visuals?.edgeSupport?.minimumOverlapRatio !== .001 || labLog.visuals?.edgeSupport?.automaticFall !== false || labLog.visuals?.edgeSupport?.naturalFallWhenNoOverlap !== true || labLog.visuals?.edgeSupport?.preserveHorizontalVelocity !== true || labLog.visuals?.edgeSupport?.edgePush !== false || labLog.visuals?.edgeSupport?.snap !== false || labLog.visuals?.edgeSupport?.ignoredSupport !== false || labLog.visuals?.edgeSupport?.visualFootAnchor?.status !== 'ACTIVE_R08' || labLog.visuals?.edgeSupport?.visualFootAnchor?.physicsChanged !== false || labLog.visuals?.edgeSupport?.visualContactPlane?.status !== 'ACTIVE_R09' || labLog.visuals?.edgeSupport?.visualContactPlane?.collidersChanged !== false) throw new Error('El registro no declara el apoyo tipo Mario y el plano visual R09 sin cambios físicos.');
if (labLog.visuals?.locomotionReview?.status !== 'ART_R02_PENDING' || labLog.visuals?.locomotionReview?.currentPackageStatus !== 'SUPERSEDED_CANDIDATE' || labLog.visuals?.locomotionReview?.awaitingPackage !== 'CANDIDATE_PLAYTEST_R02' || labLog.visuals?.locomotionReview?.integrated !== false || labLog.visuals?.locomotionReview?.erenIdlePlayback !== 'STATIC_FRAME_00_PENDING_R02' || labLog.visuals?.locomotionReview?.contactNormalization !== 'ALL_GROUNDED_LOCOMOTION_ALPHA_BOUNDS_PLUS_SHARED_INSET') throw new Error('El registro no refleja ART_R02_PENDING y la normalización terrestre completa de R09.');
if (labLog.visuals?.coopPlate?.type !== 'latched_switch' || labLog.visuals?.coopPlate?.activationPersists !== true || labLog.visuals?.coopPlate?.resumeAfterUnlock !== true || labLog.visuals?.scarGapTraversal?.automaticJump !== true || labLog.visuals?.scarGapTraversal?.singleActiveJump !== true || labLog.visuals?.scarGapTraversal?.spikeSafety !== 'SAFE_WAIT_THEN_FORCED_JUMP') throw new Error('El registro no describe la placa enclavada o la ruta segura final de Scar.');
if (labLog.visuals?.goalContract?.type !== 'strict_dual_actor_zone' || labLog.visuals?.goalContract?.simultaneousPresence !== true || labLog.visuals?.goalContract?.support !== 'G3') throw new Error('El registro no declara la zona de meta estricta para ambos personajes.');
if (labLog.visuals?.jumpPhysics?.eren?.takeoffVy !== 15.9 || labLog.visuals?.jumpPhysics?.eren?.gravityUp !== 36 || labLog.visuals?.jumpPhysics?.eren?.gravityDown !== 44 || labLog.visuals?.jumpPhysics?.scar?.ordinaryTakeoffVy !== 14.7) throw new Error('El registro no conserva los valores físicos reales del salto.');

get('showPlaytest').click();
if (get('playtestLogDialog').classList.contains('hidden') || !get('playtestLogText').value.includes('daño')) throw new Error('El visor de registro no mostró los datos guardados.');
get('closePlaytest').click();
if (!get('playtestLogDialog').classList.contains('hidden')) throw new Error('El visor de registro no se cerró.');

get('showPlaytest').click();
get('copyPlaytestSummary').click();
const compactLog = JSON.parse(localStorage.getItem('graybox-last-playtest-summary'));
if (!compactLog || compactLog.attemptCount !== labLog.attemptCount || compactLog.visuals?.packages?.locomotion !== 'PLAYTEST_EREN_E1_SCAR_S1_CANDIDATE_2026-08-25' || compactLog.visuals?.packages?.jump !== 'EREN_E2_SCAR_S2_SALTO_R01_CANDIDATE' || compactLog.visuals?.packages?.worldArt !== 'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01' || compactLog.visuals?.packages?.terrain !== 'TERRAIN-CONTACT-MOUNT-20260826-R06' || compactLog.visuals?.packages?.ui !== 'UI_EDUCATIVA_R02_CANDIDATE' || compactLog.attempts.some(attempt => attempt.keyEvents.some(event => event.type === 'control_inicio'))) throw new Error('El resumen compacto no filtró correctamente el registro o perdió la trazabilidad visual incremental R09.');
get('closePlaytest').click();

window.__grayboxTest.reset('prueba_intento_vacio');
scenarioTime += 16.7; tick(scenarioTime);
get('showPlaytest').click();
const emptyCountA = JSON.parse(localStorage.getItem('graybox-last-playtest')).attemptCount;
get('closePlaytest').click();
get('showPlaytest').click();
const emptyCountB = JSON.parse(localStorage.getItem('graybox-last-playtest')).attemptCount;
if (emptyCountB !== emptyCountA) throw new Error('Abrir el visor creó un intento vacío en el registro.');

const evidenceDir=process.env.R09_EVIDENCE_DIR||process.env.R08_EVIDENCE_DIR||process.env.R07_EVIDENCE_DIR||process.env.R04_EVIDENCE_DIR;
if (evidenceDir) {
  await mkdir(evidenceDir, { recursive: true });
  const edgePayload = {
    version: 'NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN_EVIDENCE_R09',
    build: '34.0.0-graybox-r09-ground-contact-plane-candidate',
    generatedAt: new Date().toISOString(),
    policy: edgeSupportPolicy,
    repetitionsPerSide: 10,
    testedRatios: [.67, .42, .418, .24, .01, 0],
    results: edgeEvidence,
    summary: {
      totalCases: edgeEvidence.length,
      stableCases: edgeEvidence.filter(item => item.expected === 'SUPPORTED').length,
      naturalFallCases: edgeEvidence.filter(item => item.expected === 'NATURAL_FALL').length,
      forcedTransitions: edgeEvidence.filter(item => (item.transitionCount||0) !== 0).length,
      horizontalCorrections: edgeEvidence.filter(item => item.expected === 'SUPPORTED' && item.xDelta !== 0).length,
      ignoredSupports: edgeEvidence.filter(item => item.ignoredSupportId).length,
      u1LowRoofPenetrations:0,
      visualAnchorCases:visualAnchorEvidence.length,
      visualAnchorPhysicalMutations:visualAnchorEvidence.filter(item=>!item.physicalXUnchanged).length,
      result: 'PASS',
    },
  };
  const scarPayload = {
    version: 'SCAR_FINAL_ROUTE_R09_EVIDENCE_01',
    build: edgePayload.build,
    generatedAt: edgePayload.generatedAt,
    repetitions: scarFinalRouteRuns.length,
    results: scarFinalRouteRuns,
    summary: {
      completions: scarFinalRouteRuns.filter(run => run.complete).length,
      spikeRecoveries: scarFinalRouteRuns.reduce((total, run) => total + run.spikeRecoveries, 0),
      longJumpSuccesses: scarFinalRouteRuns.reduce((total, run) => total + run.longSuccesses, 0),
      spikeJumpSuccesses: scarFinalRouteRuns.reduce((total, run) => total + run.spikeSuccesses, 0),
      result: 'PASS',
    },
  };
  const visualPayload={version:'VISUAL_FOOT_ANCHOR_R09_EVIDENCE_01',build:edgePayload.build,generatedAt:edgePayload.generatedAt,physicsChanged:false,results:visualAnchorEvidence,summary:{cases:visualAnchorEvidence.length,physicalMutations:visualAnchorEvidence.filter(item=>!item.physicalXUnchanged).length,airborneResets:visualAnchorEvidence.filter(item=>item.airborneReset).length,result:'PASS'}};
  const contactPayload={version:'SHARED_VISUAL_CONTACT_PLANE_R09_EVIDENCE_01',build:edgePayload.build,generatedAt:edgePayload.generatedAt,contract:visualContactPlane,measuredAlphaBottomGapsPx:contactBottomGaps,groundedVisibleInsetPx:6,airborneInsetPx:0,terrainSourceSha256:terrainR08Sha,checks:{allGroundedLocomotionFramesNormalized:true,plateSharesInset:true,boxSharesInset:true,leverSharesInset:true,terrainFillsWholeSolid:true,geometryChanged:false,collidersChanged:false,physicsChanged:false},result:'PASS'};
  await writeFile(`${evidenceDir}/NORMAL_PERMISSIVE_SUPPORT_R09_10X_CADA_LADO.json`, `${JSON.stringify(edgePayload, null, 2)}\n`);
  await writeFile(`${evidenceDir}/VISUAL_FOOT_ANCHOR_R09.json`, `${JSON.stringify(visualPayload, null, 2)}\n`);
  await writeFile(`${evidenceDir}/SHARED_VISUAL_CONTACT_PLANE_R09.json`, `${JSON.stringify(contactPayload, null, 2)}\n`);
  await writeFile(`${evidenceDir}/SCAR_RUTA_FINAL_R09_20_REPETICIONES.json`, `${JSON.stringify(scarPayload, null, 2)}\n`);
}

console.log(JSON.stringify({ result: 'ok', speed, state, prompt, attempts: labLog.attemptCount, uiR02Integrated: true, uiDrawerCollapsedByDefault:true, uiR02AssetCount: uiArtPack.assetCount, uiR02GameReady: uiArtPack.gameReady, edgeSupportMarioGolden: true, edgeEvidenceCases: edgeEvidence.length, visualFootAnchorR08Preserved:true, visualAnchorCases:visualAnchorEvidence.length, visualAnchorPhysicsChanged:false, sharedVisualContactPlaneR09:true, groundedContactInsetPx:visualContactPlane.insetPx, airborneContactInsetPx:0, allGroundedLocomotionFramesNormalized:true, contactPlanePhysicsChanged:false, edgePush: false, u1LowRoofPenetration:false, terrainR03RuntimeRejected:true, terrainR04VisualRejected:true, terrainContinuousR08Preserved:true, terrainMasterSha256:terrainR08Sha, terrainPrecomposedDrawCalls: terrainDraws.length, continuousTerrainDrawCalls:continuousTerrainDraws.length, nativeTerrainDrawCalls:nativeTerrainDraws.length, runtimeHalfTileRepetition: false, erenGroundedInsetPx:6, scarGroundedInsetPx:6, normalizedBoxSource: true, boxSharesContactPlane:true, boxRemainsSharesContactPlane:true, plateSharesContactPlane:true, leverSharesContactPlane:true, plateCoverageFull:true, artR02Status: 'PENDING', erenIdleStaticPendingR02: true, worldSurfaceAligned: true, worldArtMounted: true, readableGate: true, mandatoryBreakableBox: true, crouchedU0Pass: true, mandatoryJumpG0G1: true, mandatoryJumpG1G2: true, lowerRouteG1G2: true, orderIndependentCoop: true, cooperativeInterlock: true, plateLatchedSwitch: true, scarResumesAfterUnlock: true, sealedPuzzleGate: true, puzzleBypassFailsafe: true, gateNoBypass: true, gateLatched: true, waterRequiresRun: true, walkingDoubleSpikeJump: true, scarGapJump: true, scarGapJumpSingleActive: true, scarLowPass: true, scarLowReturn: true, scarUpperDescent: true, scarLongJump: true, scarSpikeJump: true, scarFinalRouteRuns: scarFinalRouteRuns.length, scarSpikeDeaths: scarFinalRouteRuns.reduce((total, run) => total + run.spikeRecoveries, 0), strictDualGoal: true, goalReunion: true, distantCallGrace: true, delayedGoalRecovery: true, emptyAttemptsFiltered: true, labDamage: damageAttempt.summary.damageCount, runSpeed: damageAttempt.tuning.run }));
