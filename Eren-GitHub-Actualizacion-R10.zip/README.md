# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 35.0.0 · actualización incremental R10

R10 aplica la calibración final solicitada tras el playtest de `GB01-v20`: Eren y Scar apoyados bajan `4 px` adicionales respecto de R09. La candidata se identifica como `35.0.0-graybox-r10-ground-contact-calibration-candidate` / `GB01-v21`; permanece `CANDIDATE_PLAYTEST` y `GAME_READY=false` hasta confirmación en el dispositivo.

Cambios principales:

- `CALIBRATED_VISUAL_CONTACT_PROFILE_R10` coloca Eren y Scar apoyados a `+10 px` de fuente (`0,10` módulos) dentro de la franja de hierba. La utilería conserva el encaje aprobado de R09 a `+6 px`; el PNG del terreno continúa rellenando el sólido completo.
- Los fotogramas de reposo, caminar y correr de Eren y Scar compensan primero su transparencia inferior medida por PNG. Así, incluso los fotogramas con `17 px` o `13 px` de margen terminan en el mismo plano visual.
- El encaje de `+10 px` se aplica a Eren y Scar solo cuando están en suelo; durante salto o caída vale `0 px`. Placa, caja, restos y palanca no cambian respecto de R09.
- La ley mecánica `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN` y el anclaje horizontal `VISUAL_FOOT_ANCHOR_R08` se conservan. No vuelven sondas, umbral `2/3`, empuje, *snap* ni corrección física de X.
- El runtime conserva sin modificar el maestro continuo R08 `950×200 px`, su SHA-256, los nueve recortes exactos y la cobertura visible de `1,5` módulos de la placa.
- El panel derecho continúa oculto por defecto; **☰ Registro** abre el cajón superpuesto y el juego mantiene todo el ancho.
- Se mantienen la geometría G0–G3/U0–U3, física de salto (`15,9 / 36 / 44 / -16`), colisión U1 → TECHO_BAJO, ruta segura de Scar, puzle enclavado y meta conjunta.
- La prueba automatizada cubre todos los fotogramas terrestres, el perfil diferenciado actores `10 px` / utilería `6 px`, 120 casos de borde, U1 sin penetración y 20 rutas finales de Scar sin muertes en pinchos.

En la primera pantalla pulsa **Probar juego**. Para compartir el JSON, abre **☰ Registro** y pulsa **Compartir registro**. La base grande de GitHub no se sustituye: esta revisión se distribuye como `Eren-GitHub-Actualizacion-R10.zip`, que el workflow incremental aplica después de R09.

La decisión completa está en [`docs/DECISION_PLAYTEST_R10.md`](docs/DECISION_PLAYTEST_R10.md). R03–R09 se conservan para trazabilidad, y la integración UI autorizada permanece documentada en [`docs/INTEGRACION_UI_EDUCATIVA_R02.md`](docs/INTEGRACION_UI_EDUCATIVA_R02.md).

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
