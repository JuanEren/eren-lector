# Decisión de playtest R10 · GB01-v21

Fecha: 26/08/2026  
Decisión: `GB-PLAYTEST-20260826-R10`  
Base observada: `34.0.0-graybox-r09-ground-contact-plane-candidate` / `GB01-v20`  
Candidata resultante: `35.0.0-graybox-r10-ground-contact-calibration-candidate` / `GB01-v21`  
Estado máximo: `CANDIDATE_PLAYTEST` · `GAME_READY=false`

## Evidencia y diagnóstico

Las capturas Android de R09 confirman que el montaje funcional ya es válido, pero la pata alejada de Scar y el pie posterior de Eren todavía se leen unos píxeles por encima de la hierba. El log conserva `edgeFootProbeFalls=0`, `edgeRecontactEvents=0` y la física permisiva ya aprobada. El pendiente es únicamente de representación.

R09 usaba un encaje común de `6 px` para actores y utilería. Las referencias retocadas muestran que los actores necesitan `4 px` adicionales, mientras placa, caja, restos y palanca ya están correctamente apoyados.

## Decisión

Se integra `CALIBRATED_VISUAL_CONTACT_PROFILE_R10`:

- Eren apoyado: `10 px` de fuente a 100 PPU;
- Scar apoyada: `10 px` de fuente a 100 PPU;
- actores en salto o caída: `0 px`;
- placa, caja, restos y palanca: conservan `6 px` de R09;
- terreno: cobertura completa e idéntica a R08/R09;
- compensación previa del margen alfa por fotograma: preservada.

El ajuste se ejecuta en renderer. No se mueve la entidad ni se cambia collider, pivote físico, geometría, cámara, salto, gravedad, velocidad o navegación.

## Invariantes preservados

- `geometryChanged=false`
- `collidersChanged=false`
- `physicsChanged=false`
- `terrainPixelsChanged=false`
- `pivotsChanged=false`
- `transformScale=[1,1]`
- Eren: `takeoffVy=15,9`, `gravityUp=36`, `gravityDown=44`, terminal `-16`
- apoyo: `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`
- anclaje horizontal parcial: `VISUAL_FOOT_ANCHOR_R08`
- utilería apoyada R09: `6 px`
- UI: cajón de registro cerrado y viewport completo

`TERRAIN-CONTACT-MOUNT-20260826-R07` reutiliza byte a byte `terrain-continuous-950x200-r08.png`, SHA-256 `c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066`.

## QA ejecutado

- Catálogo Azure en Node: PASS.
- Graybox completo en Node: PASS.
- Todos los fotogramas terrestres de Eren y Scar: contacto a `10 px`: PASS.
- Actores en aire: `0 px`: PASS.
- Utilería apoyada: `6 px` preservados: PASS.
- Terreno: `9` sólidos, `9` recortes continuos y SHA preservado: PASS.
- 120 casos de borde: PASS.
- U1 → TECHO_BAJO: `0` penetraciones: PASS.
- Scar: 20/20 rutas finales, `0` muertes por pinchos: PASS.
- Tres montajes de evidencia con PNG reales del runtime: PASS.

## Criterio de cierre

Si el playtest Android confirma reposo, caminar y correr sin separación visible, `GB01` queda `GRAYBOX_FUNCTIONAL_VALIDATED`. El refinamiento artístico del tileset continúa en un lote separado y no autoriza reabrir física o geometría.

Pendientes externos: compilar APK en GitHub Actions y confirmar visualmente `GB01-v21` en el Samsung SM-S928B.
