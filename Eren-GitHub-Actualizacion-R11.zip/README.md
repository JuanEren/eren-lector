# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 36.0.0 · actualización incremental R11

La prueba Android de R10 cierra `GB01` como **graybox funcional validado**: contacto de Eren y Scar, locomoción, salto, ruta de Scar, puzle, peligros y meta han sido aprobados. El refinamiento artístico del tileset sigue pendiente y `GAME_READY=false`, pero ya no bloquea la ampliación mecánica.

R11 corrige el único defecto de interfaz comunicado después de esa aprobación: el grupo de corazones cambiaba visualmente de posición al pasar de tres vidas a dos.

Cambios principales:

- `gameHearts` mantiene siempre una rejilla de tres casillas de `1,1 em` y una anchura total fija de `3,3 em`.
- Perder vida cambia únicamente el estado de la casilla (`♥` → `♡`); el bloque, su centro y la separación no se desplazan con `3`, `2`, `1` o `0` corazones.
- El HUD conserva una descripción accesible (`n de 3 corazones`).
- El registro pasa a `36.0.0-graybox-r11-hud-hearts-fixed-functional-validated` / `GB01-v22` y declara `FUNCTIONAL_VALIDATED_ART_PENDING`.
- Se preservan íntegramente el contacto R10 de actores a `+10 px`, la utilería a `+6 px`, el terreno continuo, la geometría, los colliders, la física, la cámara y todas las mecánicas aprobadas.
- `GB02` queda autorizado como siguiente fase independiente; R11 no incorpora todavía su geometría ni sus enemigos.

Esta revisión se distribuye como `Eren-GitHub-Actualizacion-R11.zip` y se aplica después de R10. La decisión completa está en [`docs/DECISION_PLAYTEST_R11.md`](docs/DECISION_PLAYTEST_R11.md).

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
