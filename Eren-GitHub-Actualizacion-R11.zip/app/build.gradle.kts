plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 37
        versionName = "36.0.0-graybox-r11-hud-hearts-fixed-functional-validated"
    }
}
