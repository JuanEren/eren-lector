# Cierre funcional GB01 y corrección HUD R11

Fecha: 26/08/2026  
Decisión: `GB-PLAYTEST-20260826-R11`  
Base aprobada en Android: `35.0.0-graybox-r10-ground-contact-calibration-candidate` / `GB01-v21`  
Revisión resultante: `36.0.0-graybox-r11-hud-hearts-fixed-functional-validated` / `GB01-v22`

## Resultado del playtest

La validación en dispositivo confirma que el contacto de pies y patas con el terreno es correcto y que las mecánicas de GB01 funcionan sin incidencias. Por tanto:

- `GB01_FUNCTIONAL_VALIDATED`;
- contacto R10: `APPROVED`;
- mecánicas: `APPROVED`;
- ampliación GB02: autorizada como siguiente fase;
- refinamiento del tileset: pendiente artístico separado;
- `GAME_READY=false` hasta cerrar arte, animación y QA final.

## Incidencia de interfaz

Con tres corazones el grupo se veía centrado, pero al sustituir uno por el corazón vacío el ancho visual de los glifos cambiaba y el conjunto parecía desplazarse.

R11 sustituye la cadena de longitud y métricas variables por `FIXED_THREE_SLOTS_R11`:

- tres casillas permanentes;
- `1,1 em` por casilla;
- `3,3 em` de anchura total;
- anclaje `CENTER_STABLE`;
- estados `♥` y `♡` dentro de la misma casilla;
- etiqueta accesible `n de 3 corazones`.

El número de vidas, el daño, la recuperación y los checkpoints no cambian.

## Invariantes preservados

- actores apoyados: contacto visual R10 a `+10 px`;
- actores en aire: `0 px`;
- utilería apoyada: `+6 px`;
- terreno continuo R08 y cobertura completa;
- geometría, colliders, física, pivotes, cámara y navegación sin cambios;
- valores de salto, gravedad y velocidades sin cambios;
- GB02 todavía no integrado en código.

## Criterio de aceptación R11

En la APK Android, al mostrar `3`, `2`, `1` y `0` corazones, la rejilla conserva el mismo ancho, centro y separación. Solo cambia el contenido de las casillas.
