# Eren: Leo y entiendo

Aplicación Android de lectura, comprensión y plataformas cooperativas con Eren y Scar.

## Versión 37.0.0 · actualización incremental R12

R12 integra por primera vez el tramo jugable `GB02` detrás del graybox `GB01` ya validado. La opción correcta del menú es **Nivel 1 · GB01+GB02**. El **Laboratorio técnico** queda identificado de forma inequívoca como herramienta de pruebas sin meta y deja a Scar esperando fuera de su estación específica `E`.

Esta revisión corrige los bloqueos observados en el registro de dispositivo:

- el recorrido que parecía una misión nueva era en realidad el laboratorio R11, cuyo mundo tenía `goal=null`; R12 lo separa visual y funcionalmente;
- Scar ya no se agacha por encontrarse dentro de una banda de coordenadas: solo cambia a collider bajo cuando su collider de pie detecta el techo físico `TUNEL_SCAR_TECHO_FISICO`;
- el pasadizo es realmente exclusivo de Scar; Eren queda bloqueado tanto de pie como agachado y debe usar su ruta alternativa por escalera;
- Scar activa una placa enclavada al final del pasadizo y despliega un puente que no vuelve a cerrarse;
- el salto final bajo `U6` usa un perfil contextual bajo y largo (`vx=8,2`, `vy=8,5`) para no golpear el techo ni caer sobre los pinchos; no cambia el salto ordinario, la gravedad ni ninguna física aprobada de GB01;
- se integra un enemigo terrestre provisional con aviso, hitbox, dos puntos de resistencia y resolución mediante dos pulsaciones válidas de Acción;
- la antigua meta de G3 pasa a ser el anclaje `R3`; la nueva meta estricta está en G6 y exige presencia simultánea de Eren y Scar.

## Evidencia automatizada

- paso exclusivo de Scar: `20/20`, una entrada agachada y una salida de pie por recorrido, `0` recuperaciones;
- placa y puente: `20/20` activaciones y aperturas enclavadas;
- salto final de Scar: `20/20` éxitos, `20/20` reuniones en meta, `0` recuperaciones por pinchos;
- ruta de Eren: el paso de Scar bloquea de pie y agachado; la escalera completa agarre y salida;
- enemigo: exactamente dos impactos válidos lo ahuyentan;
- regresión heredada: prueba integral del graybox, 120 casos de apoyo de borde y HUD fijo `3/2/1/0` aprobados.

Los JSON verificables están en `docs/evidencias-r12/`.

## Aplicación y prueba en Android

1. Aplica `Eren-GitHub-Actualizacion-R12.zip` después de R11.
2. Ejecuta el workflow **Compilar APK** o integra el overlay en el repositorio completo.
3. En el juego selecciona **Nivel 1 · GB01+GB02**, no **Laboratorio técnico**.
4. Tras cruzar la antigua meta, ahuyenta al enemigo con dos acciones.
5. Sube con Eren por la escalera y pulsa SCAR para ordenar a Scar atravesar el paso bajo.
6. Espera a que se abra el puente y reúne a ambos personajes en la meta de G6.

## Estado

- `GB01`: `FUNCTIONAL_VALIDATED_ART_PENDING`.
- `GB02`: `CANDIDATE_PLAYTEST`.
- `GAME_READY=false`.
- Pendiente: prueba física en dispositivo de R12, arte propio del enemigo y refinamiento/auditoría del tileset.

El diseño, el plano ampliado, el prompt para Gemini y las reglas modulares se incluyen en `docs/game-design-gb02-r02/` para que los archivos no dependan de enlaces anteriores.
