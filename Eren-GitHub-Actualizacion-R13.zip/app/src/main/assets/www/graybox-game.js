/* Graybox funcional 01 · Eren y Scar
 * Física a 60 Hz. Unidades del mundo en módulos (1 módulo = 100 px de autoría).
 * Integra arte funcional del Mundo 1 como montaje candidato sin cambiar la geometría autorizada.
 * R10 conserva la física permisiva validada y calibra exclusivamente su lectura:
 * actores apoyados a +10 px, utilería preservada a +6 px, normalización alfa de
 * toda la locomoción terrestre y terreno continuo sin mover colliders ni trayectorias.
 * R11 registra la validación funcional en Android y fija el HUD de vida en tres
 * casillas estables. R12 integra GB02 como tramo jugable separado del laboratorio:
 * paso físico exclusivo de Scar, escalera de Eren, puente enclavado, enemigo y meta dual.
 */
(()=>{
'use strict';

const byId=id=>document.getElementById(id);
const VIEW={w:19.2,h:10.8};
const FIXED_DT=1/60;
const TEST_MODE=true;
const APP_VERSION='38.0.0-graybox-r13-offline-audio-build-candidate';
const LOG_VERSION='GB02-v01';
const PLAYTEST_HISTORY_KEY='graybox-playtest-attempts-gb02-v01';
const MAX_PLAYTEST_ATTEMPTS=10;
const FUNCTIONAL_VALIDATION={
 status:'GB01_FUNCTIONAL_VALIDATED',validatedAt:'2026-08-26',devicePlaytest:'PASS',
 contactR10:'APPROVED',mechanics:'APPROVED',remainingWork:['TILESET_ART_REFINEMENT'],
 gameReady:false
};
const HUD_HEARTS_LAYOUT={
 status:'FIXED_THREE_SLOTS_R11',slots:3,containerWidthEm:3.3,slotWidthEm:1.1,
 anchor:'CENTER_STABLE',filledGlyph:'♥',emptyGlyph:'♡',logicChanged:false
};
const GB02_CONTRACT={
 decisionId:'GB02-PLAYTEST-20260826-R12',status:'CANDIDATE_PLAYTEST',gameReady:false,
 inheritedGb01:'FUNCTIONAL_VALIDATED_ART_PENDING',worldSize:[64.5,12],newSegment:[36.5,64.5],
 mechanics:['ENEMY_GROUND_01','EREN_LADDER_01','SCAR_EXCLUSIVE_CRAWL_01','SCAR_LATCHED_BRIDGE_01','STRICT_DUAL_GOAL_02'],
 frozen:{gb01Geometry:true,erenJumpPhysics:true,scarOrdinaryJumpPhysics:true,edgeSupport:true,visualContactR10:true},
 labRole:'TECHNICAL_SANDBOX_WITHOUT_GOAL'
};
const EDGE_SUPPORT_POLICY={
 status:'ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN',appliesTo:['eren'],diagnosticOnly:false,
 model:'natural_overlap',minimumOverlapRatio:.001,automaticFall:false,naturalFallWhenNoOverlap:true,
 preserveHorizontalVelocity:true,edgePush:false,snap:false,ignoredSupport:false,
 supersedes:'ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN',
 visualFootAnchor:{status:'ACTIVE_R08',startRatio:.42,maxOffsetModules:.42,physicsChanged:false}
};
const BOX_CENTER_X=7;
const COOP_GATE_X=24;
const SCAR_GAP_JUMP={minimumStableSupportRatio:.5,speedX:4.2,speedY:14.7,anticipationDistance:.48,retryCooldown:.4,minimumAirTime:.12};
const SCAR_LONG_JUMP={takeoffMinX:23.1,erenMinX:25,speedX:8.5,speedY:13.5};
const SCAR_SPIKE_JUMP={safeWaitX:31,takeoffMinX:30.95,erenMinX:33.4,speedX:5.5,speedY:14.7};
const SCAR_LOW_RETURN={takeoffMaxX:20.8,erenMaxX:18,speedX:-6.5,speedY:8.5};
const SCAR_GB02_SPIKE_JUMP={safeWaitX:59.5,takeoffMinX:59.5,erenMinX:62.5,speedX:8.2,speedY:8.5,landingMinX:62.5,profile:'LOW_LONG_CLEARANCE_UNDER_U6'};
const GB02_TUNNEL={entryX:45.5,exitX:51.5,approachX:44,plateX:50,plateW:1.5,standingHeight:1,crouchedHeight:.5};
const GB02_BRIDGE={x:51.5,y:1.5,w:4,h:.5,deploySeconds:.6};
const GB02_ENEMY={laneMinX:39,laneMaxX:43.5,w:1,h:1,hp:2,patrolSpeed:.85,warningRange:2.5,attackRange:1.15,attackWindup:.42,attackActive:.18,attackRecovery:.7};
const LOCOMOTION_THRESHOLDS={idleMaxSpeed:.25,runMinSpeed:4.5};
const CONTACT_BOTTOM_GAPS_PX={
 eren:{idle:[0,0],walk:[5,3,4,3],run:[4,6,17,3]},
 scar:{idle:[0,0],walk:[2,0,0,0],run:[2,13,2,2]}
};
const VISUAL_CONTACT_PLANE={
 status:'ACTIVE_R10',profile:'CALIBRATED_ACTORS_10PX_PROPS_6PX',insetPx:10,actorInsetPx:10,propInsetPx:6,ppu:100,actorMode:'GROUNDED_ONLY',propMode:'STATIC_SUPPORT_CONTACT_PRESERVED_R09',
 appliesTo:['eren','scar','plate','box','boxRemains','lever'],terrainCoverage:'FULL_SOLID_UNCHANGED',
 terrainPixelsChanged:false,geometryChanged:false,collidersChanged:false,physicsChanged:false
};
const UI_ART_PACK=window.__uiR02||{
 packageId:'UI_EDUCATIVA_R02_CANDIDATE',handoffId:'UI-20260825-R02',status:'CANDIDATE_TECHNICAL_EXTRACTION',integrationStatus:'INTEGRATED_TECHNICAL_QA_PASS',gameReady:false,assetCount:16,
 textRendering:'NATIVE_LOCALISABLE',nineSlice:'CANDIDATE_DEVICE_REVIEW',puzzleReceiver:'ACTIVE_PIECE_ALPHA_MASK',requiresDevicePlaytest:true
};
const LOCOMOTION_PACK={
 packageId:'PLAYTEST_EREN_E1_SCAR_S1_CANDIDATE_2026-08-25',status:'CANDIDATE_PLAYTEST',ppu:100,transformScale:[1,1],rootMotion:false,
 eren:{worldSize:{w:3,h:2},canvasPx:[300,200],pivotPx:[150,200],timingMs:{idle:350,walk:120,run:90},clips:{
  idle:['eren-reposo-00.png','eren-reposo-01.png'],
  walk:['eren-caminar-00.png','eren-caminar-01.png','eren-caminar-02.png','eren-caminar-03.png'],
  run:['eren-correr-00.png','eren-correr-01.png','eren-correr-02.png','eren-correr-03.png']
 }},
 scar:{worldSize:{w:2,h:1.5},canvasPx:[200,150],pivotPx:[100,150],timingMs:{idle:350,walk:120,run:90},clips:{
  idle:['scar-reposo-00-candidate.png','scar-reposo-01-candidate.png'],
  walk:['scar-andar-00-candidate.png','scar-andar-01-candidate.png','scar-andar-02-candidate.png','scar-andar-03-candidate.png'],
  run:['scar-correr-00-candidate.png','scar-correr-01-candidate.png','scar-correr-02-candidate.png','scar-correr-03-candidate.png']
 }}
};
const JUMP_PACK={
 packageId:'EREN_E2_SCAR_S2_SALTO_R01_CANDIDATE',incrementalOver:LOCOMOTION_PACK.packageId,status:'CANDIDATE_PLAYTEST',gameReady:false,ppu:100,transformScale:[1,1],rootMotion:false,physicsAuthoritative:true,
 eren:{worldSize:{w:3,h:2},canvasPx:[300,200],pivotPx:[150,200],colliderModules:[1,1.5],timingMs:{impulso:[90,70],subida:'physics_hold',caida:'physics_hold',aterrizaje:[80,160]},clips:{
  impulso:['eren-salto-impulso-00-candidate.png','eren-salto-impulso-01-candidate.png'],
  subida:['eren-salto-subida-00-candidate.png'],caida:['eren-salto-caida-00-candidate.png'],
  aterrizaje:['eren-salto-aterrizaje-00-candidate.png','eren-salto-aterrizaje-01-candidate.png']
 }},
 scar:{worldSize:{w:2,h:1.5},canvasPx:[200,150],pivotPx:[100,150],colliderModules:[1.5,1],timingMs:{impulso:[90,70],subida:'physics_hold',caida:'physics_hold',aterrizaje:[80,160]},clips:{
  impulso:['scar-salto-impulso-00-candidate.png','scar-salto-impulso-01-candidate.png'],
  subida:['scar-salto-subida-00-candidate.png'],caida:['scar-salto-caida-00-candidate.png'],
  aterrizaje:['scar-salto-aterrizaje-00-candidate.png','scar-salto-aterrizaje-01-candidate.png']
 }}
};
const LOCOMOTION_ASSET_ROOT='assets/playtest/e1-s1-candidate';
const locomotionFrames=Object.fromEntries(['eren','scar'].map(character=>[
 character,
 Object.fromEntries(Object.entries(LOCOMOTION_PACK[character].clips).map(([state,names])=>[
  state,
  names.map(name=>{const src=`${LOCOMOTION_ASSET_ROOT}/${character}/${name}`,image=new Image();image.decoding='async';image.src=src;return{src,image};})
 ]))
]));
const JUMP_ASSET_ROOT='assets/playtest/e2-s2-jump-candidate';
const jumpFrames=Object.fromEntries(['eren','scar'].map(character=>[
 character,
 Object.fromEntries(Object.entries(JUMP_PACK[character].clips).map(([state,names])=>[
  state,
  names.map(name=>{const src=`${JUMP_ASSET_ROOT}/${character}/${name}`,image=new Image();image.decoding='async';image.src=src;return{src,image};})
 ]))
]));
const WORLD_ART_PACK={
 packageId:'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01',runtimePlacementRevision:'CALIBRATED_ACTOR_CONTACT_PROFILE_R10',status:'CANDIDATE_PLACEMENT',gameReady:false,ppu:100,
 sourceStatus:'APPROVED_FUNCTIONAL',geometryAuthoritative:true,collidersChanged:false,
 assets:{
  earth0:{path:'terrain/earth-00.png',worldSize:{w:1,h:3},surfaceTopInsetPx:38},
  earth1:{path:'terrain/earth-01.png',worldSize:{w:1,h:3},surfaceTopInsetPx:27},
  natural1:{path:'terrain/suelo-natural-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:1},
  terrainFill1:{path:'terrain/terreno-relleno-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:3},
  terrainTop1:{path:'terrain/terreno-superficie-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:14},
  terrainTop2:{path:'terrain/terreno-superficie-2x1.png',worldSize:{w:2,h:1},surfaceTopInsetPx:3},
  terrainTop4:{path:'terrain/terreno-superficie-4x1.png',worldSize:{w:4,h:1},surfaceTopInsetPx:3},
  terrainPlatform15:{path:'terrain/terreno-plataforma-1_5x0_5.png',worldSize:{w:1.5,h:.5},canvasPx:[150,50],surfaceTopInsetPx:7},
  terrainFillHalf:{path:'terrain/terreno-relleno-0_5x0_5.png',worldSize:{w:.5,h:.5},surfaceTopInsetPx:0,nativeModule:true},
  terrainSurfaceHalf:{path:'terrain/terreno-tapa-canto-0_5x0_5.png',worldSize:{w:.5,h:.5},surfaceTopInsetPx:0,nativeModule:true},
  ruinColumn:{path:'terrain/columna-ruina-1x4_5.png',worldSize:{w:1,h:4.5},surfaceTopInsetPx:17},
  boxIntact:{path:'objects/caja-rompible-intacta-1x1.png',worldSize:{w:1,h:1},visibleBoundsPx:[0,10,100,90],fit:'NORMALIZED_SOURCE_CONTACT_INSET_R09'},
  boxRemains:{path:'objects/caja-rompible-restos-1x1.png',worldSize:{w:1,h:1},bottomTransparentPx:2,fit:'SOURCE_BOTTOM_CONTACT_INSET_R09'},
  plateFree:{path:'objects/placa-presion-libre-1_5x0_5.png',worldSize:{w:1.5,h:.5},visibleBoundsPx:[39,13,74,21],visibleCoverageModules:1.5,fit:'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09'},
  platePressed:{path:'objects/placa-presion-pulsada-1_5x0_5.png',worldSize:{w:1.5,h:.5},visibleBoundsPx:[31,18,85,18],visibleCoverageModules:1.5,fit:'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09'},
  lever:{path:'objects/interruptor-muro-1_5x2.png',worldSize:{w:1.5,h:2},placement:'PROVISIONAL_OVER_EXISTING_TRIGGER'},
  star:{path:'objects/estrella-1x1.png',worldSize:{w:1,h:1},pivot:'center'},
  water:{path:'hazards/agua-4x1_5.png',worldSize:{w:4,h:1.5}},
  spikeReference:{path:'hazards/pincho-1x1_5.png',worldSize:{w:1,h:1.5},placement:'NOT_RENDERED_COLLIDER_MISMATCH'}
 }
};
const WORLD_ART_ROOT='assets/playtest/mundo1-functional';
const worldArt=Object.fromEntries(Object.entries(WORLD_ART_PACK.assets).map(([id,definition])=>{
 const src=`${WORLD_ART_ROOT}/${definition.path}`,image=new Image();image.decoding='async';image.src=src;
 return[id,{...definition,src,image}];
}));
const TERRAIN_CONTINUOUS_ASSET={
 src:'assets/playtest/terrain-r08/terrain-continuous-950x200-r08.png',canvasPx:[950,200],ppu:100,
 sourceOffsetsPx:{G0:0,G1:180,G2:430,G3:90,U1:540,U2:720,U3:780,TECHO_BAJO:350,PLACA_BASE:610}
};
TERRAIN_CONTINUOUS_ASSET.image=new Image();
TERRAIN_CONTINUOUS_ASSET.image.decoding='async';
TERRAIN_CONTINUOUS_ASSET.image.src=TERRAIN_CONTINUOUS_ASSET.src;
const TERRAIN_MOUNT_PACK={
 packageId:'TERRAIN-CONTACT-MOUNT-20260826-R07',decisionId:'GB-PLAYTEST-20260826-R10',status:'CANDIDATE_PLAYTEST',gameReady:false,
 replaces:'TERRAIN-CONTACT-MOUNT-20260826-R06',predecessorStatus:'CANDIDATE_ACTOR_CONTACT_TOO_HIGH',
 ppu:100,transformScale:[1,1],integrationScope:'ACTOR_CONTACT_VISUAL_ONLY',runtimeDrawCallsPerSolid:1,runtimeHalfTileRepetition:false,
 renderer:'CONTINUOUS_SOURCE_CROP_100PPU_WITH_CALIBRATED_CONTACT_PROFILE',runtimePrecomposedSolidPng:false,
 geometryChanged:false,collidersChanged:false,physicsChanged:false,pivotsChanged:false,
 renderOffsets:{axis:'screen_y_positive_down',eren:{groundedInsetPx:10,airborneInsetPx:0},scar:{groundedInsetPx:10,airborneInsetPx:0},props:{groundedInsetPx:6},mode:'GROUNDED_ACTOR_CALIBRATION_PLUS_PER_FRAME_ALPHA_GAP'},
 visualFootAnchor:{status:'ACTIVE_R08',physicsChanged:false,startRatio:.42,maxOffsetModules:.42,transitionSpeedModulesPerSecond:4},
 visualContactPlane:VISUAL_CONTACT_PLANE,
 sourceAsset:{file:'terrain-continuous-950x200-r08.png',canvasPx:[950,200],ppu:100,opaque:true,firstVisibleRow:0,sha256:'c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066'},
 assets:{
  groundAndPlatforms:'terrain-continuous-950x200-r08.png',upperColumn:'ruinColumn'
 }
};
const EPS=.001;
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const approach=(value,target,amount)=>value<target?Math.min(value+amount,target):Math.max(value-amount,target);
const format=value=>Number(value).toFixed(1).replace('.',',');
const rect=(id,x,y,w,h,kind='ground')=>({id,x,y,w,h,kind});

const tuning={walk:3.5,run:6,jump:15.9,gravityUp:36,gravityDown:44,labHeight:3,labGap:4};
const controls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const nativeControls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const keyControls=new Set();
const pointerControls=new Map();
let scene='graybox';
let labStation='A';
let debug=false;
let sim=null;
let frameHandle=0;
let previousTime=0;
let accumulator=0;
let lastHudUpdate=0;
let logDialogWasPaused=false;
let attemptHistory=loadAttemptHistory();

function loadAttemptHistory(){
 try{const value=JSON.parse(localStorage.getItem(PLAYTEST_HISTORY_KEY)||'[]');return Array.isArray(value)?value.slice(-MAX_PLAYTEST_ATTEMPTS):[];}
 catch(error){return[];}
}

function storeAttemptHistory(){
 try{localStorage.setItem(PLAYTEST_HISTORY_KEY,JSON.stringify(attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS)));}
 catch(error){}
}

function body(x,y,w,h,minGroundSupportRatio=0){
 return{x,y,w,h,minGroundSupportRatio,vx:0,vy:0,onGround:true,supportRatio:1,lostSupportRatio:null,ignoredSupportId:null,facing:1,crouched:false,coyote:.12,jumpBuffer:0,invuln:0,recover:0,hitWall:false,jumpVisualState:null,jumpVisualTime:0,visualFootOffsetX:0};
}

function startJumpVisual(entity){
 entity.jumpVisualState='impulso';entity.jumpVisualTime=0;
}

function clearJumpVisual(entity){
 entity.jumpVisualState=null;entity.jumpVisualTime=0;
}

function jumpPhaseDurationMs(character,state){
 const timing=JUMP_PACK[character].timingMs[state];
 return Array.isArray(timing)?timing.reduce((total,value)=>total+value,0):Infinity;
}

function updateJumpVisual(character,entity,dt){
 const state=entity.jumpVisualState;
 if(state==='aterrizaje'){
  entity.jumpVisualTime+=dt;
  if(entity.jumpVisualTime*1000>=jumpPhaseDurationMs(character,'aterrizaje'))clearJumpVisual(entity);
  return;
 }
 if(entity.onGround){
  if(state==='impulso'||state==='subida'||state==='caida'){entity.jumpVisualState='aterrizaje';entity.jumpVisualTime=0;}
  return;
 }
 if(!state){entity.jumpVisualState=entity.vy>0?'subida':'caida';entity.jumpVisualTime=0;return;}
 if(state==='impulso'){
  entity.jumpVisualTime+=dt;
  if(entity.jumpVisualTime*1000>=jumpPhaseDurationMs(character,'impulso')){entity.jumpVisualState=entity.vy>0?'subida':'caida';entity.jumpVisualTime=0;}
  return;
 }
 const physicsState=entity.vy>0?'subida':'caida';
 if(state!==physicsState){entity.jumpVisualState=physicsState;entity.jumpVisualTime=0;}else entity.jumpVisualTime+=dt;
}

function buildGraybox(boxBroken=false,coopUnlocked=false,bridgeOpen=false){
 const solids=[
  rect('G0',0,0,9.5,2),rect('G1',11,0,7,2),rect('G2',19.5,0,5,2),rect('G3',28.5,0,8,2),
  rect('U0_VERTICAL',6.5,3,1,4.5,'upper'),rect('TECHO_BAJO',12.5,3,1.5,.5,'roof'),
  rect('U1',14,4,2.5,.5,'upper'),rect('U2',18.5,6,1.5,.5,'upper'),rect('U3',21,4.5,1.5,.5,'upper'),
  rect('G4',36.5,0,9,2),rect('U4',43,4.5,2.5,.5,'upper'),rect('G5',45.5,0,6,2),
  rect('TUNEL_SCAR_TECHO_FISICO',45.5,2.5,6,.5,'roof'),rect('TUNEL_TECHO_1',45.5,3,6,.5,'roof'),
  rect('G6',55.5,0,9,2),rect('U5',57,3.5,1.5,.5,'upper'),rect('U6',59,5,2,.5,'upper')
 ];
 if(!boxBroken)solids.push(rect('CAJA_ROMPIBLE',6.5,2,1,1,'box'));
 if(!coopUnlocked)solids.push(rect('PUERTA_COOP',COOP_GATE_X,2,.5,10,'gate'));
 if(bridgeOpen)solids.push(rect('PUENTE_1',GB02_BRIDGE.x,GB02_BRIDGE.y,GB02_BRIDGE.w,GB02_BRIDGE.h,'bridge'));
 return{
  minX:0,maxX:64.5,minY:0,maxY:12,solids,
  hazards:[rect('AGUA',24.5,-2,4,3.5,'water'),rect('PINCHOS',32.5,2,1,.5,'spikes'),rect('AGUA_2',51.5,-2,4,3.5,'water'),rect('PINCHOS_2',60.5,2,1.5,.5,'spikes')],
  star:{x:19.5,y:7,r:.34},star2:{x:60,y:6,r:.34},
  marker:{id:'PLACA_SCAR',x:15,y:2,w:1.5,h:.5},marker2:{id:'PLACA_SCAR_2',x:50,y:2,w:1.5,h:.5},
  lever:{id:'PALANCA_EREN',x:21.5,y:2,w:1,h:1.5},
  ladder:{id:'ESCALERA_E1_GRIP',x:42,y:2,w:2,h:3,artX:42.5,artY:1.5,artW:1,artH:3.5},
  actorFilters:[rect('PASO_SCAR_1',45.5,2,.5,2.5,'scar_only')],
  enemyLane:{id:'ENEMY_PATROL_01',x:GB02_ENEMY.laneMinX,y:2,w:GB02_ENEMY.laneMaxX-GB02_ENEMY.laneMinX,h:1},
  goal:{x:63.5,y:2,w:.5,h:2},goalZone:{x:62.5,y:2,w:2,h:.5},
  checkpoints:[{id:'R0',x:4.5,y:2},{id:'R1',x:22,y:2},{id:'R2',x:29.5,y:2},{id:'R3',x:35.5,y:2},{id:'R4',x:56.5,y:2}],labels:[]
 };
}

function buildLab(){
 const landingTop=2+tuning.labHeight;
 const landingX=39+tuning.labGap;
 const solids=[
  rect('A_SUELO',0,0,16,2),
  rect('B_SALIDA',16,0,7,2),rect('B_LLEGADA',25,landingTop-2,7,2,'upper'),
  rect('C_SALIDA',32,0,7,2),rect('C_LLEGADA',landingX,0,Math.max(4,48-landingX),2),
  rect('D_SUELO',48,0,16,2),rect('D_CAJA',50,2,1,1,'box'),rect('D_TECHO_15',52.5,3.5,3,.5,'roof'),rect('D_TECHO_10',57.5,3,3,.5,'roof'),
  rect('E0',64,0,6,2),rect('E1',70.8,2,4,2,'upper'),rect('E2',75.5,1,3,2,'upper'),rect('E3',79,0,1,2),
  rect('F0',80,0,6,2),rect('F1',89.5,0,6.5,2)
 ];
 return{
  minX:0,maxX:96,minY:0,maxY:12,solids,
  hazards:[rect('B_FOSO',23,-2,2,3.5,'water'),rect('C_FOSO',39,-2,tuning.labGap,3.5,'water'),rect('F_AGUA',86,-2,3.5,3.5,'water'),rect('F_PINCHOS',92,2,1.5,.5,'spikes')],
  star:null,star2:null,marker:{x:72,y:4,w:1.5,h:.5},marker2:null,ladder:null,actorFilters:[],enemyLane:null,goal:null,goalZone:null,checkpoints:[],
  labels:[
   {x:8,text:'A · VELOCIDAD'},{x:24,text:'B · SALTO VERTICAL'},{x:40,text:'C · HUECO'},
   {x:56,text:'D · COLLIDERS'},{x:72,text:'E · SCAR'},{x:88,text:'F · DAÑO Y RETORNO'}
  ]
 };
}

const stationSpawns={A:{x:2,y:2},B:{x:18,y:2},C:{x:34,y:2},D:{x:49,y:2},E:{x:65.5,y:2},F:{x:82,y:2}};
const stationScarSpawns={A:{x:3.5,y:2},B:{x:19.5,y:2},C:{x:35.5,y:2},D:{x:51.8,y:2},E:{x:67,y:2},F:{x:83.5,y:2}};

function createSimulation(){
 const spawn=scene==='graybox'?{x:4.5,y:2}:stationSpawns[labStation];
 const eren=body(spawn.x,spawn.y,1,1.5);
 eren.hearts=3;eren.climbing=false;eren.ladderCleared=false;
 const scarSpawn=scene==='graybox'?{x:spawn.x-1.7,y:spawn.y}:stationScarSpawns[labStation];
 const scar=body(scarSpawn.x,scarSpawn.y,1.5,1);
 scar.mode='follow';scar.recoverTimer=0;scar.recoveryGrace=0;scar.stuck=0;scar.navStuck=0;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.navMission=null;scar.traversal=null;scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=0;scar.spikeSafetyWaitLogged=false;
 if(scene==='lab'&&labStation!=='E'){scar.mode='wait';scar.navPhase='wait';scar.waitX=scar.x;}
 const world=scene==='graybox'?buildGraybox(false,false):buildLab();
 const cameraX=clamp(spawn.x-VIEW.w*.36,world.minX,Math.max(world.minX,world.maxX-VIEW.w));
 const now=new Date().toISOString();
 return{
  runId:`run-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,startedAt:now,archived:false,
  running:true,paused:false,scene,station:labStation,world,eren,scar,camera:{x:cameraX,y:0},
  boxBroken:false,erenSwitchArmed:false,scarPlateLatched:false,coopUnlocked:false,starCollected:false,star2Collected:false,
  bridgeState:'closed',bridgeTimer:0,enemy:scene==='graybox'?{x:41,y:2,w:GB02_ENEMY.w,h:GB02_ENEMY.h,hp:GB02_ENEMY.hp,maxHp:GB02_ENEMY.hp,direction:1,state:'patrol',stateTimer:0,attackHit:false,warningLogged:false,defeated:false}:null,
  erenAttackTimer:0,erenAttackHit:false,checkpoint:{x:spawn.x,y:spawn.y,id:scene==='graybox'?'R0':labStation},
  complete:false,elapsed:0,readingCue:false,toast:'',toastUntil:0,damageFlash:false,goalPending:false,goalWait:0,goalFollowWait:0,goalRecoveryIssued:false,puzzleBypassGuard:false,
  maxHeight:0,maxSpeed:0,jumpStartY:spawn.y,prevInput:{...controls},
  events:[{time:0,type:'inicio',scene,station:labStation,createdAt:now}]
 };
}

function rebuildWorld(){
 if(!sim)return;
 sim.world=scene==='graybox'?buildGraybox(sim.boxBroken,sim.coopUnlocked,sim.bridgeState==='open'):buildLab();
}

function logEvent(type,data={}){
 if(!sim)return;
 sim.events.push({time:Number(sim.elapsed.toFixed(3)),type,...data});
}

function archiveCurrentAttempt(reason){
 if(!sim||sim.archived)return;
 logEvent('fin_intento',{reason});
 if(!hasMeaningfulAttempt(sim.events)){sim.archived=true;return;}
 const attempt=playtestAttemptPayload();attempt.endedAt=new Date().toISOString();attempt.endedReason=reason;
 attemptHistory.push(JSON.parse(JSON.stringify(attempt)));attemptHistory=attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS);storeAttemptHistory();sim.archived=true;
}

function hasMeaningfulAttempt(events=[]){
 const passive=new Set(['inicio','fin_intento','ver_registro','compartir_registro','copiar_registro','copiar_resumen','estacion']);
 return events.some(event=>!passive.has(event.type));
}

function toast(message,seconds=1.6){
 if(!sim)return;
 sim.toast=message;sim.toastUntil=sim.elapsed+seconds;
}

function bodyRect(entity,w=entity.w,h=entity.h){return{x:entity.x-w/2,y:entity.y,w,h};}
function overlaps(a,b){return a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;}
function pointInRect(x,y,r){return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}
function horizontalSupportRatio(entity,solid,w=entity.w){
 const left=entity.x-w/2,right=entity.x+w/2;
 return clamp((Math.min(right,solid.x+solid.w)-Math.max(left,solid.x))/w,0,1);
}
function hasStableSupport(entity,solid,w=entity.w){
 return horizontalSupportRatio(entity,solid,w)>EPS;
}
function groundSupportState(entity,solids){
 let solid=null,ratio=0;
 for(const candidate of solids){
  if(candidate.id===entity.ignoredSupportId)continue;
  if(Math.abs(entity.y-(candidate.y+candidate.h))>=.08)continue;
  const candidateRatio=horizontalSupportRatio(entity,candidate);
  if(candidateRatio>ratio){solid=candidate;ratio=candidateRatio;}
 }
 return{solid,ratio};
}
function ignoresSolid(entity,solid){
 if(!entity.ignoredSupportId||entity.ignoredSupportId!==solid.id)return false;
 const top=solid.y+solid.h;
 const separated=horizontalSupportRatio(entity,solid)<=EPS;
 const safelyAbove=entity.y>=top+.08;
 const fullyBelow=entity.y+entity.h<=solid.y+EPS;
 if(separated||safelyAbove||fullyBelow){entity.ignoredSupportId=null;return false;}
 return true;
}
function applyErenEdgeSupport(entity,solids){
 // La política Mario no fuerza una caída ni vuelve intangible el soporte anterior.
 // moveBody conserva el apoyo con cualquier solape real y deja caer al cuerpo de
 // forma natural cuando el solape llega a cero. Así U1 nunca puede atravesarse.
 entity.ignoredSupportId=null;
 const supportState=groundSupportState(entity,solids);
 if(supportState.solid)entity.supportRatio=supportState.ratio;
 return false;
}
function targetVisualFootOffset(entity,solids){
 if(!entity.onGround||entity.crouched)return 0;
 const {solid,ratio}=groundSupportState(entity,solids),rule=EDGE_SUPPORT_POLICY.visualFootAnchor;
 if(!solid||ratio>=rule.startRatio)return 0;
 const strength=clamp((rule.startRatio-ratio)/rule.startRatio,0,1),margin=.06;
 const supportCenter=solid.x+solid.w/2;
 const contactX=entity.x<supportCenter?solid.x+margin:solid.x+solid.w-margin;
 return clamp((contactX-entity.x)*strength,-rule.maxOffsetModules,rule.maxOffsetModules);
}
function updateVisualFootAnchor(entity,solids,dt){
 const target=targetVisualFootOffset(entity,solids),speed=TERRAIN_MOUNT_PACK.visualFootAnchor.transitionSpeedModulesPerSecond;
 entity.visualFootOffsetX=approach(entity.visualFootOffsetX||0,target,speed*dt);
}
function hazardCollider(hazard){
 if(hazard.kind!=='spikes')return hazard;
 const insetX=Math.min(.15,hazard.w*.2);
 return{x:hazard.x+insetX,y:hazard.y,w:hazard.w-insetX*2,h:Math.max(.25,hazard.h-.15)};
}

function canFit(entity,w,h,solids){
 const box=bodyRect(entity,w,h);
 return !solids.some(s=>overlaps(box,s));
}

function moveBody(entity,dt,solids){
 entity.lostSupportRatio=null;
 entity.hitWall=false;
 entity.x+=entity.vx*dt;
 let box=bodyRect(entity);
 for(const solid of solids){
  if(ignoresSolid(entity,solid))continue;
  if(!overlaps(box,solid))continue;
  if(entity.vx>0)entity.x=solid.x-entity.w/2;
  else if(entity.vx<0)entity.x=solid.x+solid.w+entity.w/2;
  entity.vx=0;entity.hitWall=true;box=bodyRect(entity);
 }
 entity.onGround=false;
 entity.y+=entity.vy*dt;
 box=bodyRect(entity);
 let bestSupportRatio=0;
 for(const solid of solids){
  if(ignoresSolid(entity,solid))continue;
  if(!overlaps(box,solid))continue;
  if(entity.vy<=0){
   const ratio=horizontalSupportRatio(entity,solid);
   bestSupportRatio=Math.max(bestSupportRatio,ratio);
   entity.y=solid.y+solid.h;entity.onGround=true;entity.supportRatio=ratio;
  }
  else entity.y=solid.y-entity.h;
  entity.vy=0;box=bodyRect(entity);
 }
 if(!entity.onGround&&entity.vy<=0){
  for(const solid of solids){
   if(ignoresSolid(entity,solid))continue;
   const top=solid.y+solid.h;
   const ratio=horizontalSupportRatio(entity,solid);
   if(Math.abs(entity.y-top)<.035)bestSupportRatio=Math.max(bestSupportRatio,ratio);
   if(Math.abs(entity.y-top)<.035&&ratio>EPS){entity.y=top;entity.onGround=true;entity.supportRatio=ratio;entity.vy=0;break;}
  }
 }
 if(!entity.onGround){
  entity.supportRatio=bestSupportRatio;
 }
}

function supportingSolid(entity,solids){
 return groundSupportState(entity,solids).solid;
}

function surfaceAt(x,nearY,solids){
 let best=null;
 for(const solid of solids){
  const top=solid.y+solid.h;
  if(x>=solid.x&&x<=solid.x+solid.w&&top<=nearY+.35&&top>=nearY-2.2&&(!best||top>best))best=top;
 }
 return best;
}

function currentInput(){
 const merged={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
 const activate=name=>{if(name in merged)merged[name]=true;};
 const keyMap={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'up',KeyW:'up',ArrowDown:'crouch',KeyS:'crouch',ShiftLeft:'run',ShiftRight:'run',KeyR:'run',Space:'jump',KeyZ:'jump',KeyK:'jump',KeyX:'action',KeyE:'action',KeyJ:'action',KeyC:'scar',KeyQ:'scar',KeyL:'scar'};
 keyControls.forEach(code=>activate(keyMap[code]));
 pointerControls.forEach(values=>values.forEach(activate));
 Object.keys(nativeControls).forEach(name=>{if(nativeControls[name])activate(name);});
 const pads=navigator.getGamepads?navigator.getGamepads():[];
 for(const pad of pads){
  if(!pad)continue;
  if(pad.axes[0]<-.35||pad.buttons[14]?.pressed)merged.left=true;
  if(pad.axes[0]>.35||pad.buttons[15]?.pressed)merged.right=true;
  if(pad.axes[1]<-.55||pad.buttons[12]?.pressed)merged.up=true;
  if(pad.axes[1]>.55||pad.buttons[13]?.pressed)merged.crouch=true;
  if(pad.buttons[0]?.pressed)merged.jump=true;
  if(pad.buttons[2]?.pressed)merged.action=true;
  if(pad.buttons[1]?.pressed||pad.buttons[7]?.pressed)merged.run=true;
  if(pad.buttons[3]?.pressed||pad.buttons[4]?.pressed)merged.scar=true;
 }
 Object.assign(controls,merged);
 return merged;
}

function setMessageFromProgress(){
 if(!sim)return'';
 if(sim.toastUntil>sim.elapsed)return sim.toast;
 if(scene==='lab'){
  const messages={
   A:'LABORATORIO TÉCNICO · No es una misión y no tiene meta. Compara arranque, frenada, giro y andar/correr.',
   B:'LABORATORIO TÉCNICO · SIN META · Salta desde la marca y comprueba el desnivel seleccionado.',
   C:'LABORATORIO TÉCNICO · SIN META · Cruza el hueco y cambia su anchura para hallar el límite seguro.',
   D:'LABORATORIO TÉCNICO · SIN META · Rompe la caja y prueba de pie/agachado bajo los dos techos.',
   E:'LABORATORIO TÉCNICO · SIN META · Observa cómo Scar resuelve alturas con física propia.',
   F:'LABORATORIO TÉCNICO · SIN META · Toca agua o pinchos y mide cuánto tarda en volver el control.'
  };
  return messages[labStation];
 }
 const x=sim.eren.x;
 if(sim.goalPending){
  if(!actorInGoalZone(sim.eren))return'Vuelve a la zona de meta y espera allí a Scar.';
  return'Permanece en la meta: Scar debe entrar también en la zona final.';
 }
 if(x<5.85)return'Borde tipo Mario: Eren conserva apoyo mientras sus pies sigan tocando la plataforma.';
 if(!sim.boxBroken&&x<9.7)return'Rompe la caja marrón de abajo con ACCIÓN. El pilar gris no se rompe.';
 if(sim.boxBroken&&x<8)return'Mantén ABAJO y atraviesa la abertura bajo U0.';
 if(x<11.3)return'Salta el hueco corto. Puedes pulsar salto un instante o mantenerlo.';
 if(x<14.1)return'Mantén ABAJO para cambiar al collider agachado y pasar.';
 if(x<17.6&&sim.scar.mode==='follow')return'Lee: «Scar, activa la placa». Pulsa SCAR para darle la orden.';
 if(x<19.2)return'Puedes tomar la ruta alta para buscar la estrella.';
 if(!sim.coopUnlocked&&x<24.3){
  if(sim.erenSwitchArmed)return'Palanca lista. Envía a Scar a activar la placa; el orden no importa.';
  if(scarPlateActive())return'Placa de Scar enclavada. Pulsa ACCIÓN junto a la palanca de G2.';
  return'Activa la palanca de Eren y la placa de Scar; el orden no importa.';
 }
 if(x<24.3)return'Compuerta abierta. La ruta principal continúa por el agua.';
 if(x<28.7)return'Mantén CORRER + SALTAR para cruzar el agua.';
 if(x<34.3)return'Salta los pinchos. Andando tienes margen; corriendo también.';
 if(x<36.5)return'Cruza la antigua meta: ahora es el anclaje R3 y abre el tramo GB02.';
 if(x<39)return'Avanza por la zona segura y observa el aviso del enemigo.';
 if(x<43.5&&!sim.enemy?.defeated)return'Acércate con cuidado y pulsa ACCIÓN dos veces para ahuyentar a la criatura.';
 if(x<45.5&&sim.bridgeState!=='open')return'Eren sube por la escalera. Pulsa SCAR para enviar a Scar por el paso exclusivo real.';
 if(x<51.5&&sim.bridgeState==='closed')return'Scar debe llegar agachada a la placa del túnel; Eren espera desde la ruta superior.';
 if(x<55.5&&sim.bridgeState!=='open')return'Espera a que el puente termine de desplegarse antes de cruzar.';
 if(x<60.5)return'Puente enclavado. La ruta superior permite conseguir la segunda estrella.';
 if(x<62.5)return'Salta los pinchos finales. Scar esperará y cruzará con su salto reservado.';
 return'Permanece en la meta: Eren y Scar deben reunirse para completar GB02.';
}

function commandScar(){
 if(!sim||sim.paused)return;
 const scar=sim.scar;
 const nearGb02Pass=scene==='graybox'&&sim.world.marker2&&sim.eren.x>=41.5&&sim.eren.x<=52.5;
 if(nearGb02Pass&&sim.bridgeState!=='open'){
  if(scar.navMission==='gb02_plate'&&(scar.mode==='marker'||scar.mode==='wait')){
   scar.mode='follow';scar.navMission=null;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);
   toast('Scar cancela el paso y vuelve contigo.');logEvent('scar_seguir');
  }else{
   scar.mode='marker';scar.navMission='gb02_plate';scar.navPhase='aproximar_paso_exclusivo';scar.navTargetX=GB02_TUNNEL.approachX;scar.navTargetY=2;scar.navStuck=0;
   toast('Orden recibida: Scar entra por el paso bajo.');logEvent('scar_paso_exclusivo_orden',{fromX:Number(scar.x.toFixed(2)),fromY:Number(scar.y.toFixed(2))});
  }
 }else if(scene==='graybox'&&Math.abs(sim.eren.x-(sim.world.marker.x+.75))<4.2){
  if(scar.mode==='marker'||scar.mode==='wait'){scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);toast('Scar vuelve a seguir a Eren.');logEvent('scar_seguir');}
  else{scar.mode='marker';scar.navPhase='buscar_placa';scar.navTargetX=null;scar.navTargetY=null;scar.navStuck=0;toast('Orden recibida: Scar va a activar la placa.');logEvent('scar_huella',{fromX:Number(scar.x.toFixed(2)),fromY:Number(scar.y.toFixed(2))});}
 }else if(scar.mode==='wait'||scar.mode==='marker'){
  scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);toast('Scar vuelve contigo.');logEvent('scar_seguir');
 }else{
  scar.mode='wait';scar.navPhase='wait';scar.navTargetX=scar.x;scar.navTargetY=scar.y;scar.waitX=scar.x;toast('Scar espera aquí.');logEvent('scar_esperar',{x:Number(scar.x.toFixed(2))});
 }
}

function damageEren(kind){
 const eren=sim.eren;
 if(eren.invuln>0||eren.recover>0)return;
 eren.hearts--;
 logEvent('daño',{kind,hearts:eren.hearts,checkpoint:sim.checkpoint.id});
 const flash=byId('damageFlash');flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');
 eren.x=sim.checkpoint.x;eren.y=sim.checkpoint.y;eren.vx=0;eren.vy=0;eren.onGround=true;eren.supportRatio=1;eren.lostSupportRatio=null;eren.ignoredSupportId=null;eren.visualFootOffsetX=0;eren.recover=.55;eren.invuln=1.25;eren.crouched=false;eren.climbing=false;eren.w=1;eren.h=1.5;sim.erenAttackTimer=0;sim.erenAttackHit=false;clearJumpVisual(eren);
 if(eren.hearts<=0){eren.hearts=3;logEvent('corazones_repuestos');}
 toast('Daño: retorno al último anclaje.',1.1);tone('wrong');
}

function recoverScar(reason){
 const scar=sim.scar;
 if(scar.recoverTimer>0)return;
 scar.recoverTimer=.65;scar.recoverReason=reason;scar.vx=0;scar.vy=0;clearJumpVisual(scar);logEvent('scar_recuperacion',{reason,x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2)),traversal:scar.traversal});
}

function setScarNavigation(scar,phase,targetX,targetY){
 if(scar.navPhase!==phase){scar.navPhase=phase;logEvent('scar_ruta',{phase,targetX:Number(targetX.toFixed(2)),targetY:Number(targetY.toFixed(2))});}
 scar.navTargetX=targetX;scar.navTargetY=targetY;return targetX;
}

function scarMarkerTarget(scar,world){
 if(!scar.onGround&&Number.isFinite(scar.navTargetX))return scar.navTargetX;
 if(scar.navMission==='gb02_plate'&&world.marker2){
  const markerX=world.marker2.x+world.marker2.w/2;
  if(scar.x<GB02_TUNNEL.approachX-.1)return setScarNavigation(scar,'aproximar_paso_exclusivo',GB02_TUNNEL.approachX,2);
  if(scar.x<=GB02_TUNNEL.exitX+.2)return setScarNavigation(scar,'cruzar_paso_exclusivo',markerX,2);
  return setScarNavigation(scar,'volver_a_placa_2',markerX,2);
 }
 const support=supportingSolid(scar,world.solids),marker=world.marker,markerX=marker.x+marker.w/2;
 if(support?.id==='U2')return setScarNavigation(scar,'bajar_u2_a_u1',17.5,4.5);
 if(support?.id==='U3')return setScarNavigation(scar,'bajar_u3_a_g2',22.5,2);
 if(support?.id==='U1')return setScarNavigation(scar,'bajar_u1_a_techo',13,3.5);
 if(support?.id==='TECHO_BAJO')return setScarNavigation(scar,'bajar_techo_a_g1',11,2);
 if(scar.y>marker.y+.2)return setScarNavigation(scar,'buscar_descenso',markerX,marker.y);
 return setScarNavigation(scar,'ir_a_placa',markerX,marker.y);
}

function scarReachedMarker(scar,world){
 if(scar.navMission==='gb02_plate'&&world.marker2){
  const marker=world.marker2,support=supportingSolid(scar,world.solids);
  return support?.id==='G5'&&Math.abs(scar.y-marker.y)<=.1&&Math.abs(scar.x-(marker.x+marker.w/2))<=.45;
 }
 const marker=world.marker,support=supportingSolid(scar,world.solids);
 return!!marker&&support?.id==='G1'&&Math.abs(scar.y-marker.y)<=.1&&Math.abs(scar.x-(marker.x+marker.w/2))<=.5;
}

function scarPlateActive(){
 if(!sim||scene!=='graybox'||!sim.world.marker)return false;
 return sim.scarPlateLatched===true;
}

function erenNearLever(eren=sim?.eren){
 const lever=sim?.world?.lever;
 return!!lever&&eren.y<2.35&&Math.abs(eren.x-(lever.x+lever.w/2))<=1.25;
}

function tryOpenCoopGate(trigger){
 if(sim.coopUnlocked)return true;
 if(!sim.erenSwitchArmed||!scarPlateActive())return false;
 sim.coopUnlocked=true;rebuildWorld();toast('¡Cooperación conseguida! La compuerta queda abierta.',2.2);tone('correct');
 logEvent('puzle_coop_completado',{trigger});logEvent('puerta_coop_abierta',{latched:true,trigger});
 if(sim.scar.mode==='wait'||sim.scar.mode==='marker'){
  sim.scar.mode='follow';sim.scar.navPhase='follow';sim.scar.navTargetX=null;sim.scar.navTargetY=null;sim.scar.waitX=null;sim.scar.recoveryGrace=Math.max(sim.scar.recoveryGrace||0,6);
  logEvent('scar_reanuda_tras_puzle',{x:Number(sim.scar.x.toFixed(2))});
 }
 return true;
}

function tryCoopLever(){
 if(sim.coopUnlocked){toast('La compuerta ya está abierta.');return true;}
 if(!sim.erenSwitchArmed){
  sim.erenSwitchArmed=true;tone('correct');logEvent('palanca_eren_activada',{x:Number(sim.eren.x.toFixed(2)),plateActive:scarPlateActive()});
 }
 if(tryOpenCoopGate('palanca_eren'))return true;
 toast('Palanca activada. Falta que Scar active la placa.',2);return true;
}

function updateScarPosture(scar,world){
 const ceiling=scene==='graybox'?world.solids.find(solid=>solid.id==='TUNEL_SCAR_TECHO_FISICO'):null;
 const direction=scar.facing||1,probeEntity={...scar,x:scar.x+direction*.75,w:1.5,h:GB02_TUNNEL.standingHeight};
 const standingBlocked=!!ceiling&&scar.y<=2.12&&overlaps(bodyRect(probeEntity),ceiling);
 const currentlyUnderCeiling=!!ceiling&&scar.y<=2.12&&overlaps(bodyRect(scar,1.5,GB02_TUNNEL.standingHeight),ceiling);
 const tunnelMission=scar.navMission==='gb02_plate'||(scar.x>=GB02_TUNNEL.entryX-.75&&scar.x<=GB02_TUNNEL.exitX+.75);
 if(tunnelMission&&(standingBlocked||currentlyUnderCeiling)&&!scar.crouched&&canFit(scar,1.5,GB02_TUNNEL.crouchedHeight,world.solids)){
  scar.crouched=true;scar.h=GB02_TUNNEL.crouchedHeight;logEvent('scar_paso_exclusivo_inicio',{x:Number(scar.x.toFixed(2)),collider:'TUNEL_SCAR_TECHO_FISICO'});
 }else if(scar.crouched&&!currentlyUnderCeiling&&!standingBlocked&&canFit(scar,1.5,GB02_TUNNEL.standingHeight,world.solids)){
  scar.crouched=false;scar.h=GB02_TUNNEL.standingHeight;logEvent('scar_paso_exclusivo_fin',{x:Number(scar.x.toFixed(2)),collider:'TUNEL_SCAR_TECHO_FISICO'});
 }
}

function activateGb02Bridge(){
 if(scene!=='graybox'||sim.bridgeState!=='closed')return;
 sim.bridgeState='deploying';sim.bridgeTimer=GB02_BRIDGE.deploySeconds;
 logEvent('placa_scar_2_activada',{latched:true});logEvent('puente_1_desplegando',{duration:GB02_BRIDGE.deploySeconds});
 toast('Scar ha activado la placa. El puente se está desplegando.',2);tone('correct');
}

function updateGb02Bridge(dt){
 if(scene!=='graybox'||sim.bridgeState!=='deploying')return;
 const future={x:GB02_BRIDGE.x,y:GB02_BRIDGE.y,w:GB02_BRIDGE.w,h:GB02_BRIDGE.h};
 const occupied=overlaps(bodyRect(sim.eren),future)||overlaps(bodyRect(sim.scar),future);
 if(occupied){
  if(!sim.bridgeBlockedLogged){sim.bridgeBlockedLogged=true;logEvent('puente_despliegue_bloqueado_seguro');}
  return;
 }
 sim.bridgeTimer=Math.max(0,sim.bridgeTimer-dt);
 if(sim.bridgeTimer>0)return;
 sim.bridgeState='open';sim.bridgeBlockedLogged=false;rebuildWorld();logEvent('puente_1_abierto',{latched:true});
 if(sim.scar.navMission==='gb02_plate'){
  sim.scar.mode='follow';sim.scar.navMission='gb02_exit';sim.scar.navPhase='salir_paso_exclusivo';sim.scar.navTargetX=52.5;sim.scar.navTargetY=2;sim.scar.recoveryGrace=Math.max(sim.scar.recoveryGrace||0,6);
 }
 toast('Puente abierto y enclavado.',1.8);tone('correct');
}

function ladderContains(entity,ladder=sim?.world?.ladder){
 return!!ladder&&overlaps(bodyRect(entity),ladder);
}

function startLadder(eren){
 const ladder=sim.world.ladder;if(!ladder)return false;
 eren.climbing=true;eren.crouched=false;eren.w=1;eren.h=1.5;eren.vx=0;eren.vy=0;eren.onGround=false;clearJumpVisual(eren);
 logEvent('escalera_agarre',{x:Number(eren.x.toFixed(2)),y:Number(eren.y.toFixed(2))});return true;
}

function releaseLadder(eren,reason){
 if(!eren.climbing)return;
 eren.climbing=false;eren.vy=reason==='salto'?8:0;eren.onGround=false;
 if(reason==='salto')startJumpVisual(eren);
 logEvent('escalera_soltar',{reason,x:Number(eren.x.toFixed(2)),y:Number(eren.y.toFixed(2))});
}

function erenAttackBox(eren=sim.eren){
 const w=1,x=eren.facing>0?eren.x+eren.w/2:eren.x-eren.w/2-w;
 return{x,y:eren.y+.15,w,h:1};
}

function enemyBodyBox(enemy=sim.enemy){return enemy?{x:enemy.x-enemy.w/2,y:enemy.y,w:enemy.w,h:enemy.h}:null;}

function updateGb02Enemy(dt){
 const enemy=sim.enemy;if(scene!=='graybox'||!enemy||enemy.defeated)return;
 sim.erenAttackTimer=Math.max(0,(sim.erenAttackTimer||0)-dt);
 const distance=Math.abs(sim.eren.x-enemy.x);
 if(distance<=GB02_ENEMY.warningRange&&!enemy.warningLogged){enemy.warningLogged=true;logEvent('enemigo_aviso',{id:'ENEMY_PATROL_01'});toast('Una criatura bloquea el paso. Usa ACCIÓN cuando estés cerca.',2);}
 if(sim.erenAttackTimer>0&&!sim.erenAttackHit&&overlaps(erenAttackBox(),enemyBodyBox(enemy))){
  sim.erenAttackHit=true;enemy.hp--;enemy.state='hurt';enemy.stateTimer=.28;logEvent('enemigo_impacto',{id:'ENEMY_PATROL_01',hp:enemy.hp});tone('correct');
  if(enemy.hp<=0){enemy.defeated=true;enemy.state='flee';logEvent('enemigo_ahuyentado',{id:'ENEMY_PATROL_01',hits:enemy.maxHp});toast('La criatura se ha alejado.',1.5);}
 }
 if(enemy.defeated)return;
 enemy.stateTimer=Math.max(0,(enemy.stateTimer||0)-dt);
 if(enemy.state==='hurt'){if(enemy.stateTimer<=0)enemy.state='patrol';return;}
 if(enemy.state==='windup'){
  if(enemy.stateTimer<=0){enemy.state='attack';enemy.stateTimer=GB02_ENEMY.attackActive;enemy.attackHit=false;logEvent('enemigo_ataque_activo',{id:'ENEMY_PATROL_01'});}return;
 }
 if(enemy.state==='attack'){
  if(!enemy.attackHit){
   const attack={x:enemy.direction>0?enemy.x:enemy.x-1,y:enemy.y,w:1,h:.5};
   if(overlaps(attack,bodyRect(sim.eren))){enemy.attackHit=true;logEvent('eren_daño_enemigo',{id:'ENEMY_PATROL_01'});damageEren('enemigo');}
  }
  if(enemy.stateTimer<=0){enemy.state='recover';enemy.stateTimer=GB02_ENEMY.attackRecovery;}return;
 }
 if(enemy.state==='recover'){if(enemy.stateTimer<=0)enemy.state='patrol';return;}
 if(distance<=GB02_ENEMY.attackRange){enemy.direction=sim.eren.x>=enemy.x?1:-1;enemy.state='windup';enemy.stateTimer=GB02_ENEMY.attackWindup;logEvent('enemigo_ataque_aviso',{id:'ENEMY_PATROL_01'});return;}
 enemy.x+=enemy.direction*GB02_ENEMY.patrolSpeed*dt;
 const half=enemy.w/2;
 if(enemy.x<GB02_ENEMY.laneMinX+half){enemy.x=GB02_ENEMY.laneMinX+half;enemy.direction=1;}
 if(enemy.x>GB02_ENEMY.laneMaxX-half){enemy.x=GB02_ENEMY.laneMaxX-half;enemy.direction=-1;}
}

function updateEren(input,dt){
 const eren=sim.eren;
 eren.invuln=Math.max(0,eren.invuln-dt);
 if(eren.recover>0){eren.recover=Math.max(0,eren.recover-dt);return;}

 if(scene==='graybox'&&eren.climbing){
  if(input.jump&&!sim.prevInput.jump){releaseLadder(eren,'salto');}
  else if(input.left||input.right){releaseLadder(eren,'lateral');}
  else{
   const ladder=sim.world.ladder,center=ladder.x+ladder.w/2,vertical=(input.up?1:0)-(input.crouch?1:0);
   eren.x=approach(eren.x,center,2*dt);eren.y=clamp(eren.y+vertical*2.5*dt,2,5);eren.vx=0;eren.vy=0;eren.onGround=false;
   if(eren.y>=5-EPS&&vertical>0){eren.climbing=false;eren.ladderCleared=true;eren.x=43.5;eren.y=5;eren.onGround=true;eren.vy=0;logEvent('escalera_salida',{x:43.5,y:5});}
   updateVisualFootAnchor(eren,sim.world.solids,dt);return;
  }
 }
 if(scene==='graybox'&&input.up&&!sim.prevInput.up&&ladderContains(eren)&&(!sim.enemy||sim.enemy.defeated))startLadder(eren);

 if(eren.onGround)eren.coyote=.12;else eren.coyote=Math.max(0,eren.coyote-dt);
 eren.jumpBuffer=Math.max(0,eren.jumpBuffer-dt);
 if(input.jump&&!sim.prevInput.jump)eren.jumpBuffer=.12;

 if(input.crouch&&eren.onGround){
  if(!eren.crouched){eren.crouched=true;eren.w=1.5;eren.h=1;logEvent('agacharse');}
 }else if(eren.crouched&&canFit(eren,1,1.5,sim.world.solids)){
  eren.crouched=false;eren.w=1;eren.h=1.5;
 }

 if(eren.jumpBuffer>0&&eren.coyote>0&&!eren.crouched){
  eren.vy=tuning.jump;eren.onGround=false;eren.coyote=0;eren.jumpBuffer=0;sim.jumpStartY=eren.y;
  startJumpVisual(eren);
  logEvent('salto',{x:Number(eren.x.toFixed(2)),speed:Number(Math.abs(eren.vx).toFixed(2))});
 }
 if(!input.jump&&sim.prevInput.jump&&eren.vy>0)eren.vy*=.45;

 const axis=(input.right?1:0)-(input.left?1:0);
 if(axis)eren.facing=axis;
 const maxSpeed=eren.crouched?2.2:(input.run?tuning.run:tuning.walk);
 const target=axis*maxSpeed;
 const accel=!axis?28:(eren.vx*axis<0?36:(eren.onGround?20:14));
 eren.vx=approach(eren.vx,target,accel*dt);

 if(input.action&&!sim.prevInput.action){
  logEvent('accion',{x:Number(eren.x.toFixed(2))});
  if(scene==='graybox'&&!sim.boxBroken&&Math.abs(eren.x-BOX_CENTER_X)<1.8&&eren.y<2.35){
   sim.boxBroken=true;rebuildWorld();toast('Caja rota. El camino ya está abierto.');tone('correct');logEvent('caja_rota');
  }else if(scene==='graybox'&&erenNearLever(eren)){
   tryCoopLever();
  }else if(scene==='graybox'&&sim.enemy&&!sim.enemy.defeated&&Math.abs(eren.x-sim.enemy.x)<=1.8&&Math.abs(eren.y-sim.enemy.y)<=1.25){
   sim.erenAttackTimer=.2;sim.erenAttackHit=false;logEvent('eren_ataque_inicio',{x:Number(eren.x.toFixed(2)),facing:eren.facing});logEvent('eren_ataque_activo',{duration:.2});
  }else if(scene==='lab'&&Math.abs(eren.x-50.5)<1.8){
   sim.world.solids=sim.world.solids.filter(s=>s.id!=='D_CAJA');toast('Collider de caja retirado.');tone('correct');
  }
 }
 if(input.scar&&!sim.prevInput.scar)commandScar();

 const gravity=eren.vy>0?tuning.gravityUp:tuning.gravityDown;
 eren.ignoredSupportId=null;
 eren.vy=Math.max(-16,eren.vy-gravity*dt);
 moveBody(eren,dt,sim.world.solids);
 applyErenEdgeSupport(eren,sim.world.solids);
 if(scene==='graybox'){
  if(sim.enemy&&!sim.enemy.defeated&&eren.x+eren.w/2>43.5){eren.x=43.5-eren.w/2;eren.vx=Math.min(0,eren.vx);eren.hitWall=true;}
  const scarOnly=sim.world.actorFilters?.find(filter=>filter.id==='PASO_SCAR_1');
  const filterVertical=scarOnly&&eren.y<scarOnly.y+scarOnly.h-EPS&&eren.y+eren.h>scarOnly.y+EPS;
  const filterCrossing=scarOnly&&!eren.ladderCleared&&filterVertical&&(
   (input.right&&eren.x+eren.w/2>=scarOnly.x-EPS&&eren.x<scarOnly.x+scarOnly.w)||
   (input.left&&eren.x-eren.w/2<=scarOnly.x+scarOnly.w+EPS&&eren.x>scarOnly.x)
  );
  if(filterCrossing){
   if(input.right)eren.x=scarOnly.x-eren.w/2;else eren.x=scarOnly.x+scarOnly.w+eren.w/2;
   eren.vx=0;eren.hitWall=true;
   if(!sim.scarOnlyBlockLogged){sim.scarOnlyBlockLogged=true;logEvent('paso_scar_bloquea_eren',{x:Number(eren.x.toFixed(2)),y:Number(eren.y.toFixed(2))});toast('Ese paso es exclusivo de Scar. Eren debe usar la escalera.',1.8);}
  }else if(scarOnly&&Math.abs(eren.x-(scarOnly.x+scarOnly.w/2))>1)sim.scarOnlyBlockLogged=false;
 }
 updateVisualFootAnchor(eren,sim.world.solids,dt);
 updateJumpVisual('eren',eren,dt);
 eren.x=clamp(eren.x+0,sim.world.minX+eren.w/2,sim.world.maxX-eren.w/2);

 if(scene==='graybox'&&!sim.coopUnlocked){
  const safeX=COOP_GATE_X-eren.w/2-EPS;
  if(eren.x>safeX+.05){
   const fromX=eren.x,fromY=eren.y;
   eren.x=safeX;eren.vx=Math.min(0,eren.vx);
   if(sim.checkpoint.id==='R2')sim.checkpoint={x:22,y:2,id:'R1'};
   if(!sim.puzzleBypassGuard){
    sim.puzzleBypassGuard=true;
    logEvent('bypass_puzle_bloqueado',{fromX:Number(fromX.toFixed(2)),fromY:Number(fromY.toFixed(2)),gate:'PUERTA_COOP'});
   }
  }else if(eren.x<safeX-.15)sim.puzzleBypassGuard=false;
 }else sim.puzzleBypassGuard=false;

 sim.maxSpeed=Math.max(sim.maxSpeed,Math.abs(eren.vx));
 sim.maxHeight=Math.max(sim.maxHeight,eren.y-sim.jumpStartY);

 if(scene==='graybox'){
  if(eren.onGround&&eren.x>=21.5&&sim.checkpoint.id==='R0'){sim.checkpoint={x:22,y:2,id:'R1'};logEvent('anclaje',{id:'R1'});}
  if(sim.coopUnlocked&&eren.onGround&&eren.x>=29.2&&['R0','R1'].includes(sim.checkpoint.id)){sim.checkpoint={x:29.5,y:2,id:'R2'};logEvent('anclaje',{id:'R2'});}
  if(eren.onGround&&eren.x>=34.5&&sim.checkpoint.id==='R2'){sim.checkpoint={x:35.5,y:2,id:'R3'};logEvent('anclaje',{id:'R3'});}
  if(sim.bridgeState==='open'&&eren.onGround&&eren.x>=56&&sim.checkpoint.id==='R3'){sim.checkpoint={x:56.5,y:2,id:'R4'};logEvent('anclaje',{id:'R4'});}
  if(!sim.readingCue&&eren.x>=13.7){sim.readingCue=true;logEvent('instruccion_leida',{text:'Scar, activa la placa.'});playAzureSequence(['Scar, activa la placa.']);}
  if(!sim.starCollected&&sim.world.star){
   const star=sim.world.star,dx=eren.x-star.x,dy=(eren.y+eren.h*.55)-star.y;
   if(dx*dx+dy*dy<.8){sim.starCollected=true;toast('Estrella opcional conseguida.');tone('correct');logEvent('estrella');}
  }
  if(!sim.star2Collected&&sim.world.star2){
   const star=sim.world.star2,dx=eren.x-star.x,dy=(eren.y+eren.h*.55)-star.y;
   if(dx*dx+dy*dy<.8){sim.star2Collected=true;toast('Segunda estrella opcional conseguida.');tone('correct');logEvent('estrella_2');}
  }
  if(sim.coopUnlocked&&!sim.complete&&!sim.goalPending&&actorInGoalZone(eren)){
   sim.goalPending=true;sim.goalWait=0;sim.goalFollowWait=0;sim.goalRecoveryIssued=false;
   toast('Meta alcanzada. Espera a Scar.',2);logEvent('meta_espera_scar',{scarX:Number(sim.scar.x.toFixed(2))});
  }
 }

 const hit=sim.world.hazards.find(h=>overlaps(bodyRect(eren),hazardCollider(h)));
 if(hit)damageEren(hit.kind);
 if(eren.y<-2.5)damageEren('caída');
}

function updateScar(dt){
 const scar=sim.scar,eren=sim.eren,world=sim.world;
 scar.recoveryGrace=Math.max(0,(scar.recoveryGrace||0)-dt);
 if(scar.recoverTimer>0){
  scar.recoverTimer-=dt;
  if(scar.recoverTimer<=0){
   const retryGb02Plate=scene==='graybox'&&sim.bridgeState!=='open'&&scar.navMission==='gb02_plate';
   let x=retryGb02Plate?GB02_TUNNEL.approachX:Math.max(world.minX+.9,sim.camera.x-.9),y=retryGb02Plate?2:surfaceAt(x,eren.y,world.solids);
   if(scene==='graybox'&&sim.checkpoint.id==='R4'&&!retryGb02Plate){x=58.5;y=2;}
   if(y===null){x=sim.checkpoint.x-1.7;y=sim.checkpoint.y;}
   scar.x=x;scar.y=y;scar.vx=Math.max(2.2,eren.vx);scar.vy=0;scar.onGround=true;scar.supportRatio=1;scar.lostSupportRatio=null;scar.ignoredSupportId=null;scar.mode=retryGb02Plate?'marker':'follow';scar.navPhase=retryGb02Plate?'aproximar_paso_exclusivo':'follow';scar.navTargetX=retryGb02Plate?GB02_TUNNEL.approachX:null;scar.navTargetY=retryGb02Plate?2:null;scar.navStuck=0;scar.traversal=null;scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=SCAR_GAP_JUMP.retryCooldown;scar.recoveryGrace=3.5;scar.stuck=0;scar.spikeSafetyWaitLogged=false;scar.recoverReason=null;clearJumpVisual(scar);
   if(scar.crouched){scar.crouched=false;scar.h=1;}
  }
  return;
 }

 updateScarPosture(scar,world);
 let supportState=groundSupportState(scar,world.solids),support=supportState.solid;
 if(scar.onGround)scar.supportRatio=supportState.ratio;
 const wantsLowReturn=scar.mode==='marker'||(scar.mode==='follow'&&eren.x<=SCAR_LOW_RETURN.erenMaxX);
 if(!scar.traversal&&scene==='graybox'&&wantsLowReturn&&!scar.crouched&&scar.onGround&&support?.id==='G2'&&scar.x<=SCAR_LOW_RETURN.takeoffMaxX){
  scar.traversal='g2_g1_low_return';scar.navPhase='retorno_bajo_g2_g1';scar.facing=-1;scar.vx=SCAR_LOW_RETURN.speedX;scar.vy=SCAR_LOW_RETURN.speedY;scar.onGround=false;
  startJumpVisual(scar);
  logEvent('scar_salto_retorno_bajo_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_LOW_RETURN.speedX,vy:SCAR_LOW_RETURN.speedY});
 }
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G2'&&scar.x>=SCAR_LONG_JUMP.takeoffMinX&&eren.x>=SCAR_LONG_JUMP.erenMinX){
  scar.traversal='water_long_jump';scar.navPhase='salto_largo_agua';scar.facing=1;scar.vx=SCAR_LONG_JUMP.speedX;scar.vy=SCAR_LONG_JUMP.speedY;scar.onGround=false;
  startJumpVisual(scar);
  logEvent('scar_salto_largo_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_LONG_JUMP.speedX,vy:SCAR_LONG_JUMP.speedY});
 }
 const spikeJumpReady=sim.goalPending||eren.x>=SCAR_SPIKE_JUMP.erenMinX;
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G3'&&scar.x>=SCAR_SPIKE_JUMP.takeoffMinX&&scar.x<32.5&&spikeJumpReady){
  scar.traversal='spike_jump';scar.navPhase='salto_pinchos';scar.facing=1;scar.vx=SCAR_SPIKE_JUMP.speedX;scar.vy=SCAR_SPIKE_JUMP.speedY;scar.onGround=false;
  scar.spikeSafetyWaitLogged=false;
  startJumpVisual(scar);
  logEvent('scar_salto_pinchos_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_SPIKE_JUMP.speedX,vy:SCAR_SPIKE_JUMP.speedY});
 }
 const gb02SpikeJumpReady=sim.goalPending||eren.x>=SCAR_GB02_SPIKE_JUMP.erenMinX;
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G6'&&scar.x>=SCAR_GB02_SPIKE_JUMP.takeoffMinX&&scar.x<60.5&&gb02SpikeJumpReady){
  scar.traversal='gb02_spike_jump';scar.navPhase='salto_pinchos_2';scar.facing=1;scar.vx=SCAR_GB02_SPIKE_JUMP.speedX;scar.vy=SCAR_GB02_SPIKE_JUMP.speedY;scar.onGround=false;scar.spikeSafetyWaitLogged=false;
  startJumpVisual(scar);logEvent('scar_salto_pinchos_2_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_GB02_SPIKE_JUMP.speedX,vy:SCAR_GB02_SPIKE_JUMP.speedY});
 }
 if(scar.traversal){
  const traversal=scar.traversal,isLowReturn=traversal==='g2_g1_low_return',isGb02Spike=traversal==='gb02_spike_jump',settings=isLowReturn?SCAR_LOW_RETURN:(traversal==='water_long_jump'?SCAR_LONG_JUMP:(isGb02Spike?SCAR_GB02_SPIKE_JUMP:SCAR_SPIKE_JUMP));
  scar.facing=isLowReturn?-1:1;scar.vx=settings.speedX;scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);moveBody(scar,dt,world.solids);updateJumpVisual('scar',scar,dt);
  supportState=groundSupportState(scar,world.solids);support=supportState.solid;
  const landingSupport=isLowReturn?'G1':(isGb02Spike?'G6':'G3');
  const landingReady=!isGb02Spike||scar.x>=SCAR_GB02_SPIKE_JUMP.landingMinX;
  if(scar.onGround&&support?.id===landingSupport&&landingReady){
   scar.traversal=null;scar.navPhase=traversal==='water_long_jump'?'aproximacion_pinchos_segura':'follow';scar.navTargetX=null;scar.navTargetY=null;
   if(traversal==='water_long_jump')scar.recoveryGrace=Math.max(scar.recoveryGrace||0,4);
   const successEvent=isLowReturn?'scar_salto_retorno_bajo_exito':(traversal==='water_long_jump'?'scar_salto_largo_exito':(isGb02Spike?'scar_salto_pinchos_2_exito':'scar_salto_pinchos_exito'));
   logEvent(successEvent,{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});
  }
  const longJumpHazard=world.hazards.find(h=>overlaps(bodyRect(scar),hazardCollider(h)));
  if(longJumpHazard||scar.y<-2.5)recoverScar(longJumpHazard?longJumpHazard.kind:'caída');
  return;
 }
 scar.gapJumpCooldown=Math.max(0,(scar.gapJumpCooldown||0)-dt);
 let targetX=eren.x-eren.facing*2;
 if(scar.navMission==='gb02_exit'){
  targetX=52.5;
  if(scar.x>=52.25&&!scar.crouched){scar.navMission=null;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;logEvent('scar_paso_exclusivo_fin_ruta',{x:Number(scar.x.toFixed(2))});}
 }
 if(sim.goalPending&&scar.mode==='follow'&&world.goalZone)targetX=world.goalZone.x+world.goalZone.w/2;
 if(scar.mode==='marker')targetX=scarMarkerTarget(scar,world);
 else if(scar.mode==='wait')targetX=scar.waitX??scar.x;
 const protectedSpikeApproach=scene==='graybox'&&scar.mode==='follow'&&scar.onGround&&support?.id==='G3'&&scar.x<32.5;
 const protectedGb02SpikeApproach=scene==='graybox'&&scar.mode==='follow'&&scar.onGround&&support?.id==='G6'&&scar.x<60.5;
 const waitingForGb02Order=scene==='graybox'&&sim.bridgeState!=='open'&&!scar.navMission&&scar.mode==='follow'&&scar.x>=36.5&&scar.x<GB02_TUNNEL.entryX&&eren.x>=GB02_TUNNEL.entryX;
 if(waitingForGb02Order&&targetX>GB02_TUNNEL.approachX)targetX=GB02_TUNNEL.approachX;
 if(protectedSpikeApproach&&!spikeJumpReady&&targetX>SCAR_SPIKE_JUMP.safeWaitX)targetX=SCAR_SPIKE_JUMP.safeWaitX;
 if(protectedGb02SpikeApproach&&!gb02SpikeJumpReady&&targetX>SCAR_GB02_SPIKE_JUMP.safeWaitX)targetX=SCAR_GB02_SPIKE_JUMP.safeWaitX;
 const dx=targetX-scar.x;
 const preciseGb02Exit=scar.navMission==='gb02_exit';
 const tolerance=(protectedSpikeApproach||protectedGb02SpikeApproach||preciseGb02Exit) ? .08 : (scar.gapJumpActive ? .16 : (sim.goalPending&&scar.mode==='follow' ? .18 : (scar.mode==='follow'?1.45:.16)));
 let axis=Math.abs(dx)>tolerance?Math.sign(dx):0;
 if(protectedSpikeApproach&&!spikeJumpReady&&scar.x>=SCAR_SPIKE_JUMP.safeWaitX-.08){
  axis=0;scar.navPhase='espera_segura_pinchos';
  if(!scar.spikeSafetyWaitLogged){scar.spikeSafetyWaitLogged=true;logEvent('scar_espera_segura_pinchos',{x:Number(scar.x.toFixed(2)),erenX:Number(eren.x.toFixed(2))});}
 }
 if(protectedGb02SpikeApproach&&!gb02SpikeJumpReady&&scar.x>=SCAR_GB02_SPIKE_JUMP.safeWaitX-.08){
  axis=0;scar.navPhase='espera_segura_pinchos_2';
  if(!scar.spikeSafetyWaitLogged){scar.spikeSafetyWaitLogged=true;logEvent('scar_espera_segura_pinchos_2',{x:Number(scar.x.toFixed(2)),erenX:Number(eren.x.toFixed(2))});}
 }
 if(scar.mode==='marker'&&scarReachedMarker(scar,world)){
  if(scar.navMission==='gb02_plate'){
   const marker=world.marker2;scar.mode='wait';scar.navPhase='placa_scar_2_confirmada';scar.navTargetX=marker.x+marker.w/2;scar.navTargetY=marker.y;scar.waitX=scar.navTargetX;axis=0;activateGb02Bridge();
  }else{
   scar.mode='wait';scar.navPhase='placa_confirmada';scar.navTargetX=world.marker.x+world.marker.w/2;scar.navTargetY=world.marker.y;scar.waitX=scar.navTargetX;
   logEvent('scar_en_huella',{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});
   if(!sim.scarPlateLatched){
    sim.scarPlateLatched=true;
    logEvent('placa_scar_activada',{latched:true,leverArmed:sim.erenSwitchArmed});
    logEvent('placa_scar_enclavada',{leverArmed:sim.erenSwitchArmed});
   }
   axis=0;
   if(!tryOpenCoopGate('placa_scar'))toast('Placa de Scar activada. Busca la palanca de Eren.',2);
  }
 }
 if(axis)scar.facing=axis;
 const speed=scar.crouched?2.4:(Math.abs(dx)>7?6.5:(Math.abs(eren.vx)>tuning.walk+.3?5.5:3));
 scar.vx=approach(scar.vx,axis*speed,(axis?22:28)*dt);

 if(scar.gapJumpActive)scar.gapJumpAirTime=(scar.gapJumpAirTime||0)+dt;
 let shouldJump=false,gapJump=false,gapJumpReason=null,reservedTraversalLink=false;
 if(scar.onGround&&axis&&support&&!scar.crouched){
  const intentionalDrop=scar.mode==='marker'&&scar.navPhase.startsWith('bajar_');
  const reservedWaterLink=scene==='graybox'&&scar.mode==='follow'&&support.id==='G2'&&axis>0&&eren.x>=24.5;
  const reservedLowReturn=scene==='graybox'&&wantsLowReturn&&support.id==='G2'&&axis<0;
  const reservedSpikeLink=scene==='graybox'&&scar.mode==='follow'&&support.id==='G3'&&axis>0&&scar.x<32.5;
  const reservedGb02SpikeLink=scene==='graybox'&&scar.mode==='follow'&&support.id==='G6'&&axis>0&&scar.x<60.5;
  reservedTraversalLink=reservedWaterLink||reservedLowReturn||reservedSpikeLink||reservedGb02SpikeLink;
  const edge=axis>0?support.x+support.w:support.x;
  const edgeDistance=axis>0?edge-(scar.x+scar.w/2):(scar.x-scar.w/2)-edge;
  const probeX=edge+axis*.08;
  const aheadSurface=surfaceAt(probeX,scar.y,world.solids);
  if(!intentionalDrop&&!reservedTraversalLink&&edgeDistance<SCAR_GAP_JUMP.anticipationDistance&&aheadSurface===null){shouldJump=true;gapJump=true;gapJumpReason='hueco_anticipado';}
  const higher=world.solids.some(s=>{
   const top=s.y+s.h,front=axis>0?s.x-(scar.x+scar.w/2):(scar.x-scar.w/2)-(s.x+s.w);
   const passableOverhead=s.y>=scar.y+scar.h-EPS;
   return!passableOverhead&&front>=-.05&&front<1.2&&top>scar.y+.25&&top<=scar.y+3.05;
  });
  if(!intentionalDrop&&!reservedTraversalLink&&higher)shouldJump=true;
 }
 const weakSupport=scar.onGround&&supportState.ratio<SCAR_GAP_JUMP.minimumStableSupportRatio-EPS;
 if(weakSupport&&!scar.crouched&&!(scar.mode==='marker'&&scar.navPhase.startsWith('bajar_'))){
  shouldJump=true;gapJump=true;gapJumpReason=supportState.ratio>EPS?'apoyo_insuficiente':'centro_sin_apoyo';
 }
 if(scar.onGround&&scar.hitWall&&axis&&!scar.crouched&&!reservedTraversalLink&&!(scar.mode==='marker'&&scar.navPhase.startsWith('bajar_')))shouldJump=true;
 if(gapJump&&(scar.gapJumpActive||scar.gapJumpCooldown>0)){shouldJump=false;gapJump=false;}
 if(shouldJump){
  const jumpDirection=axis||Math.sign(dx)||scar.facing||1;
  if(gapJump){
   scar.vx=jumpDirection*Math.max(Math.abs(scar.vx),SCAR_GAP_JUMP.speedX);
   if(!scar.gapJumpActive){
    scar.gapJumpActive=true;scar.gapJumpFrom=support?.id||null;scar.gapJumpAirTime=0;scar.ignoredSupportId=support?.id||null;
    logEvent('scar_salto_hueco_inicio',{x:Number(scar.x.toFixed(2)),from:scar.gapJumpFrom,reason:gapJumpReason,supportRatio:Number(supportState.ratio.toFixed(3))});
   }
  }
  scar.facing=jumpDirection;scar.vy=SCAR_GAP_JUMP.speedY;scar.onGround=false;startJumpVisual(scar);logEvent('scar_salto',{x:Number(scar.x.toFixed(2))});
 }
 scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);
 const beforeX=scar.x,beforeY=scar.y;
 moveBody(scar,dt,world.solids);
 updateJumpVisual('scar',scar,dt);

 if(scar.gapJumpActive&&scar.onGround&&scar.gapJumpAirTime>=SCAR_GAP_JUMP.minimumAirTime){
  const landing=groundSupportState(scar,world.solids);
  if(landing.ratio>=SCAR_GAP_JUMP.minimumStableSupportRatio-EPS){
   const crossed=!!landing.solid&&landing.solid.id!==scar.gapJumpFrom;
   logEvent(crossed?'scar_salto_hueco_exito':'scar_salto_hueco_reintento',{from:scar.gapJumpFrom,to:landing.solid?.id||null,x:Number(scar.x.toFixed(2)),supportRatio:Number(landing.ratio.toFixed(3))});
   scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=SCAR_GAP_JUMP.retryCooldown;
  }
 }

 if(scar.mode==='marker'&&axis&&scar.onGround&&Math.abs(scar.x-beforeX)<.003&&Math.abs(scar.y-beforeY)<.003)scar.navStuck+=dt;else scar.navStuck=0;
 if(scar.mode==='marker'&&scar.navStuck>2.5){logEvent('scar_ruta_bloqueada',{phase:scar.navPhase,x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});scar.navStuck=0;recoverScar('ruta_marcador');}

 const hazard=world.hazards.find(h=>overlaps(bodyRect(scar),hazardCollider(h)));
 if(hazard?.kind==='spikes'&&scene==='graybox'&&!scar.crouched&&scar.y>=2-EPS){
  const gb02=hazard.id==='PINCHOS_2',settings=gb02?SCAR_GB02_SPIKE_JUMP:SCAR_SPIKE_JUMP;
  scar.traversal=gb02?'gb02_spike_jump':'spike_jump';scar.navPhase=gb02?'salto_pinchos_2_emergencia':'salto_pinchos_emergencia';scar.facing=1;scar.vx=settings.speedX;scar.vy=settings.speedY;scar.onGround=false;scar.gapJumpActive=false;scar.ignoredSupportId=null;startJumpVisual(scar);
  logEvent(gb02?'scar_salto_pinchos_2_inicio':'scar_salto_pinchos_inicio',{x:Number(scar.x.toFixed(2)),vx:settings.speedX,vy:settings.speedY,emergency:true});
 }else if(hazard||scar.y<-2.5)recoverScar(hazard?hazard.kind:'caída');
 const gb02Active=scene==='graybox'&&(eren.x>=36.5||scar.x>=36.5||scar.navMission==='gb02_plate');
 if(!gb02Active&&!sim.goalPending&&scar.mode==='follow'&&scar.recoveryGrace<=0&&Math.abs(scar.x-eren.x)>15)scar.stuck+=dt;else scar.stuck=0;
 if(scar.stuck>.55)recoverScar('fuera_de_camara');
}

function actorInGoalZone(entity){
 if(scene!=='graybox'||!sim?.world?.goalZone||!entity.onGround)return false;
 const support=supportingSolid(entity,sim.world.solids),zone=sim.world.goalZone;
 return support?.id==='G6'&&pointInRect(entity.x,entity.y,zone);
}

function updateGoalReunion(dt){
 if(scene!=='graybox'||!sim.goalPending||sim.complete)return;
 sim.goalWait+=dt;
 if(sim.scar.mode==='follow')sim.goalFollowWait+=dt;else sim.goalFollowWait=0;
 const scar=sim.scar,support=supportingSolid(scar,sim.world.solids);
 if(scar.recoverTimer<=0&&scar.mode==='follow'&&actorInGoalZone(sim.eren)&&actorInGoalZone(scar)){
  const payload={wait:Number(sim.goalWait.toFixed(2)),followWait:Number(sim.goalFollowWait.toFixed(2)),erenX:Number(sim.eren.x.toFixed(2)),scarX:Number(scar.x.toFixed(2)),zone:[sim.world.goalZone.x,sim.world.goalZone.x+sim.world.goalZone.w]};
  logEvent('meta_reunion_scar',payload);logEvent('meta_gb02_reunion',payload);finishGraybox();return;
 }
 if(sim.goalFollowWait>=6&&!sim.goalRecoveryIssued&&scar.mode==='follow'&&!scar.traversal&&scar.recoverTimer<=0&&support?.id!=='G6'){
  sim.goalRecoveryIssued=true;recoverScar('reunion_meta');
 }
}

function updateCamera(dt){
 const world=sim.world,eren=sim.eren;
 const look=clamp(eren.vx/tuning.run,-1,1)*3;
 const desiredX=clamp(eren.x+look-VIEW.w/2,world.minX,Math.max(world.minX,world.maxX-VIEW.w));
 const desiredY=clamp(eren.y-3.75,world.minY,Math.max(world.minY,world.maxY-VIEW.h));
 sim.camera.x+=(desiredX-sim.camera.x)*(1-Math.exp(-dt/.18));
 sim.camera.y+=(desiredY-sim.camera.y)*(1-Math.exp(-dt/.25));
}

function physicsStep(dt,input){
 if(!sim||!sim.running||sim.paused)return;
 sim.elapsed+=dt;
 for(const control of['left','right','run']){
  if(input[control]&&!sim.prevInput[control])logEvent('control_inicio',{control});
  if(!input[control]&&sim.prevInput[control])logEvent('control_fin',{control});
 }
 updateEren(input,dt);
 updateScar(dt);
 updateGb02Bridge(dt);
 updateGb02Enemy(dt);
 updateGoalReunion(dt);
 if(!sim.paused)updateCamera(dt);
 sim.prevInput={...input};
}

function finishGraybox(){
 sim.complete=true;sim.paused=true;logEvent('meta',{elapsed:Number(sim.elapsed.toFixed(2)),star:sim.starCollected,damage:sim.events.filter(e=>e.type==='daño').length});
 const wins=Number(localStorage.getItem('game-wins')||0)+1;localStorage.setItem('game-wins',String(wins));
 localStorage.setItem('graybox-last-playtest',JSON.stringify(playtestBundle()));
 byId('gameRewardStars').textContent=`${sim.starCollected?'★':'☆'}${sim.star2Collected?'★':'☆'}`;byId('gameReward').classList.remove('hidden');
 tone('correct');setTimeout(()=>tone('correct'),230);playAzureSequence(['¡Nivel ampliado completado! Eren y Scar han llegado juntos.']);
}

function playtestAttemptPayload(){
 const events=sim?sim.events:[];
 return{
  runId:sim?.runId||null,startedAt:sim?.startedAt||null,capturedAt:new Date().toISOString(),scene:sim?.scene||scene,station:sim?.station||labStation,
  tuning:{...tuning},summary:sim?{
   elapsed:Number(sim.elapsed.toFixed(2)),maxSpeed:Number(sim.maxSpeed.toFixed(2)),maxJumpHeight:Number(sim.maxHeight.toFixed(2)),
   hearts:sim.eren.hearts,star:sim.starCollected,star2:sim.star2Collected,starsCollected:Number(sim.starCollected)+Number(sim.star2Collected),complete:sim.complete,damageCount:events.filter(e=>e.type==='daño').length,
   edgeThirdFalls:events.filter(e=>e.type==='caida_borde_tercio').length,edgeFootProbeFalls:events.filter(e=>e.type==='caida_borde_sondas_pie').length,
   edgeRecontactEvents:events.filter(e=>e.type==='caida_borde_sondas_pie'||e.type==='caida_borde_tercio').length,
   jumps:events.filter(e=>e.type==='salto').length,runActivations:events.filter(e=>e.type==='control_inicio'&&e.control==='run').length,
   directionActivations:events.filter(e=>e.type==='control_inicio'&&(e.control==='left'||e.control==='right')).length,
   actionPresses:events.filter(e=>e.type==='accion').length,scarRecoveries:events.filter(e=>e.type==='scar_recuperacion').length,
   scarMarkerCommands:events.filter(e=>e.type==='scar_huella').length,scarMarkerSuccesses:events.filter(e=>e.type==='scar_en_huella').length,
   scarPlateActivations:events.filter(e=>e.type==='placa_scar_activada').length,scarPlateLatches:events.filter(e=>e.type==='placa_scar_enclavada').length,leverAttempts:events.filter(e=>e.type==='palanca_eren_activada').length,
   coopUnlocks:events.filter(e=>e.type==='puerta_coop_abierta').length,puzzleBypassBlocks:events.filter(e=>e.type==='bypass_puzle_bloqueado').length,
   scarLowPasses:events.filter(e=>e.type==='scar_paso_bajo_inicio').length,scarRouteBlocks:events.filter(e=>e.type==='scar_ruta_bloqueada').length,
   scarLowReturns:events.filter(e=>e.type==='scar_salto_retorno_bajo_inicio').length,scarLowReturnSuccesses:events.filter(e=>e.type==='scar_salto_retorno_bajo_exito').length,
   scarLongJumps:events.filter(e=>e.type==='scar_salto_largo_inicio').length,scarLongJumpSuccesses:events.filter(e=>e.type==='scar_salto_largo_exito').length,
   scarSpikeJumps:events.filter(e=>e.type==='scar_salto_pinchos_inicio').length,scarSpikeJumpSuccesses:events.filter(e=>e.type==='scar_salto_pinchos_exito').length,
   scarGapJumps:events.filter(e=>e.type==='scar_salto_hueco_inicio').length,scarGapJumpSuccesses:events.filter(e=>e.type==='scar_salto_hueco_exito').length,
   scarExclusivePasses:events.filter(e=>e.type==='scar_paso_exclusivo_fin').length,bridgeOpens:events.filter(e=>e.type==='puente_1_abierto').length,
   scarGb02SpikeJumps:events.filter(e=>e.type==='scar_salto_pinchos_2_inicio').length,scarGb02SpikeSuccesses:events.filter(e=>e.type==='scar_salto_pinchos_2_exito').length,
   enemyHits:events.filter(e=>e.type==='enemigo_impacto').length,enemyClears:events.filter(e=>e.type==='enemigo_ahuyentado').length,goalReunions:events.filter(e=>e.type==='meta_reunion_scar').length
  }:null,finalState:sim?{
   eren:{x:Number(sim.eren.x.toFixed(2)),y:Number(sim.eren.y.toFixed(2)),vx:Number(sim.eren.vx.toFixed(2)),vy:Number(sim.eren.vy.toFixed(2))},
   scar:{x:Number(sim.scar.x.toFixed(2)),y:Number(sim.scar.y.toFixed(2)),mode:sim.scar.mode,crouched:sim.scar.crouched,navPhase:sim.scar.navPhase,traversal:sim.scar.traversal},
   coopPuzzle:{plateActive:scarPlateActive(),plateLatched:sim.scarPlateLatched,leverArmed:sim.erenSwitchArmed,unlocked:sim.coopUnlocked,bridgeState:sim.bridgeState},
   enemy:sim.enemy?{hp:sim.enemy.hp,state:sim.enemy.state,defeated:sim.enemy.defeated}:null,
   goal:{pending:sim.goalPending,erenInZone:actorInGoalZone(sim.eren),scarInZone:actorInGoalZone(sim.scar)},checkpoint:sim.checkpoint.id
  }:null,events
 };
}

function playtestBundle(){
 const attempts=[...attemptHistory];
 if(sim&&!sim.archived&&hasMeaningfulAttempt(sim.events))attempts.push(playtestAttemptPayload());
 const includedAttempts=attempts.slice(-MAX_PLAYTEST_ATTEMPTS);
 return{
  version:LOG_VERSION,appVersion:APP_VERSION,testMode:TEST_MODE,generatedAt:new Date().toISOString(),
  visuals:{
   packageId:`${LOCOMOTION_PACK.packageId}+${JUMP_PACK.packageId}+${WORLD_ART_PACK.packageId}+${TERRAIN_MOUNT_PACK.packageId}+${UI_ART_PACK.packageId}`,
   packages:{locomotion:LOCOMOTION_PACK.packageId,jump:JUMP_PACK.packageId,worldArt:WORLD_ART_PACK.packageId,terrain:TERRAIN_MOUNT_PACK.packageId,ui:UI_ART_PACK.packageId},status:'GB01_VALIDATED_GB02_CANDIDATE_PLAYTEST',gameReady:false,functionalValidation:FUNCTIONAL_VALIDATION,gb02:GB02_CONTRACT,ppu:100,rootMotion:false,physicsAuthoritative:true,transformScale:[1,1],
   frameCounts:{eren:16,scar:16,locomotion:{eren:10,scar:10},jump:{eren:6,scar:6}},
   timingMs:{locomotion:{eren:LOCOMOTION_PACK.eren.timingMs,scar:LOCOMOTION_PACK.scar.timingMs},jump:{eren:JUMP_PACK.eren.timingMs,scar:JUMP_PACK.scar.timingMs}},thresholds:LOCOMOTION_THRESHOLDS,
   locomotionReview:{status:'ART_R02_PENDING',currentPackageStatus:'SUPERSEDED_CANDIDATE',awaitingPackage:'CANDIDATE_PLAYTEST_R02',integrated:false,erenIdlePlayback:'STATIC_FRAME_00_PENDING_R02',scarIdlePlayback:'ANIMATED_CANDIDATE',contactNormalization:'ALL_GROUNDED_LOCOMOTION_ALPHA_BOUNDS_PLUS_ACTOR_10PX_INSET'},
   jumpArt:JUMP_PACK.packageId,
   worldArt:{status:WORLD_ART_PACK.status,sourceStatus:WORLD_ART_PACK.sourceStatus,gameReady:WORLD_ART_PACK.gameReady,assetCount:Object.keys(WORLD_ART_PACK.assets).length,geometryAuthoritative:WORLD_ART_PACK.geometryAuthoritative,collidersChanged:WORLD_ART_PACK.collidersChanged,runtimePlacementRevision:WORLD_ART_PACK.runtimePlacementRevision,boxFit:WORLD_ART_PACK.assets.boxIntact.fit,boxRemainsFit:WORLD_ART_PACK.assets.boxRemains.fit,plateFit:WORLD_ART_PACK.assets.plateFree.fit,plateVisibleCoverageModules:{free:WORLD_ART_PACK.assets.plateFree.visibleCoverageModules,pressed:WORLD_ART_PACK.assets.platePressed.visibleCoverageModules},visualContactPlane:VISUAL_CONTACT_PLANE,provisionalPlacements:['lever']},
   terrainMount:{packageId:TERRAIN_MOUNT_PACK.packageId,decisionId:TERRAIN_MOUNT_PACK.decisionId,status:TERRAIN_MOUNT_PACK.status,gameReady:TERRAIN_MOUNT_PACK.gameReady,replaces:TERRAIN_MOUNT_PACK.replaces,predecessorStatus:TERRAIN_MOUNT_PACK.predecessorStatus,sourceAssetCount:2,solidRecipeCount:9,ppu:TERRAIN_MOUNT_PACK.ppu,transformScale:TERRAIN_MOUNT_PACK.transformScale,integrationScope:TERRAIN_MOUNT_PACK.integrationScope,renderer:TERRAIN_MOUNT_PACK.renderer,runtimeDrawCallsPerSolid:TERRAIN_MOUNT_PACK.runtimeDrawCallsPerSolid,runtimeHalfTileRepetition:TERRAIN_MOUNT_PACK.runtimeHalfTileRepetition,runtimePrecomposedSolidPng:TERRAIN_MOUNT_PACK.runtimePrecomposedSolidPng,geometryChanged:TERRAIN_MOUNT_PACK.geometryChanged,collidersChanged:TERRAIN_MOUNT_PACK.collidersChanged,physicsChanged:TERRAIN_MOUNT_PACK.physicsChanged,pivotsChanged:TERRAIN_MOUNT_PACK.pivotsChanged,renderOffsets:TERRAIN_MOUNT_PACK.renderOffsets,visualFootAnchor:TERRAIN_MOUNT_PACK.visualFootAnchor,visualContactPlane:TERRAIN_MOUNT_PACK.visualContactPlane,sourceAsset:TERRAIN_MOUNT_PACK.sourceAsset},
   uiArt:{...UI_ART_PACK,runtimePanel:'COLLAPSED_DRAWER_TOP_RIGHT',defaultPanelOpen:false,gameViewport:'FULL_WIDTH',hudHearts:HUD_HEARTS_LAYOUT},
   edgeSupport:{...EDGE_SUPPORT_POLICY,visualContactPlane:VISUAL_CONTACT_PLANE},
   scarGapTraversal:{automaticJump:true,minimumStableSupportRatio:SCAR_GAP_JUMP.minimumStableSupportRatio,anticipationDistance:SCAR_GAP_JUMP.anticipationDistance,retryCooldown:SCAR_GAP_JUMP.retryCooldown,singleActiveJump:true,fallRecovery:true,spikeSafety:'SAFE_WAIT_THEN_FORCED_JUMP',gb02SpikeSafety:'G6_SAFE_WAIT_THEN_RESERVED_JUMP',gb02GlobalJumpChanged:false},
   coopPlate:{actor:'scar',type:'latched_switch',physicalSurface:'shared_ground',activationPersists:true,resumeAfterUnlock:true},
   goalContract:{type:'strict_dual_actor_zone',zone:sim?.world?.goalZone||null,requires:['eren','scar'],simultaneousPresence:true,support:'G6'},
   jumpPhysics:{eren:{takeoffVy:tuning.jump,gravityUp:tuning.gravityUp,gravityDown:tuning.gravityDown,terminalFallVy:-16},scar:{ordinaryTakeoffVy:14.7,longWaterTakeoffVy:SCAR_LONG_JUMP.speedY,spikeTakeoffVy:SCAR_SPIKE_JUMP.speedY,lowReturnTakeoffVy:SCAR_LOW_RETURN.speedY,gb02SpikeTakeoffVy:SCAR_GB02_SPIKE_JUMP.speedY,gb02SpikeSpeedX:SCAR_GB02_SPIKE_JUMP.speedX,gb02SpikeProfile:SCAR_GB02_SPIKE_JUMP.profile,gravityUp:36,gravityDown:44,terminalFallVy:-16}}
  },
  device:{userAgent:navigator.userAgent||'Android WebView',viewport:{width:window.innerWidth||0,height:window.innerHeight||0},pixelRatio:window.devicePixelRatio||1},
  attemptCount:includedAttempts.length,attempts:includedAttempts
 };
}

function compactPlaytestBundle(){
 const bundle=playtestBundle(),keyTypes=new Set(['caja_rota','caida_borde_sondas_pie','scar_en_huella','placa_scar_activada','placa_scar_enclavada','palanca_eren_activada','puzle_coop_completado','puerta_coop_abierta','scar_reanuda_tras_puzle','bypass_puzle_bloqueado','scar_ruta_bloqueada','scar_salto_hueco_inicio','scar_salto_hueco_exito','scar_salto_hueco_reintento','scar_salto_retorno_bajo_inicio','scar_salto_retorno_bajo_exito','scar_salto_largo_inicio','scar_salto_largo_exito','scar_espera_segura_pinchos','scar_salto_pinchos_inicio','scar_salto_pinchos_exito','scar_paso_exclusivo_orden','scar_paso_exclusivo_inicio','scar_paso_exclusivo_fin','placa_scar_2_activada','puente_1_desplegando','puente_1_abierto','enemigo_impacto','enemigo_ahuyentado','escalera_agarre','escalera_salida','scar_espera_segura_pinchos_2','scar_salto_pinchos_2_inicio','scar_salto_pinchos_2_exito','scar_recuperacion','daño','estrella','estrella_2','anclaje','meta_espera_scar','meta_reunion_scar','meta_gb02_reunion','meta']);
 return{
  version:bundle.version,appVersion:bundle.appVersion,testMode:bundle.testMode,generatedAt:bundle.generatedAt,visuals:bundle.visuals,device:bundle.device,attemptCount:bundle.attemptCount,
  attempts:bundle.attempts.map(attempt=>({runId:attempt.runId,startedAt:attempt.startedAt,scene:attempt.scene,station:attempt.station,tuning:attempt.tuning,summary:attempt.summary,finalState:attempt.finalState,keyEvents:attempt.events.filter(event=>keyTypes.has(event.type))}))
 };
}

function worldToScreen(x,y,draw){return{x:draw.ox+(x-sim.camera.x)*draw.scale,y:draw.oy+(sim.camera.y+VIEW.h-y)*draw.scale};}

function drawStar(ctx,x,y,r,draw){
 const p=worldToScreen(x,y,draw);ctx.save();ctx.translate(p.x,p.y);ctx.beginPath();
 for(let i=0;i<10;i++){const angle=-Math.PI/2+i*Math.PI/5,rad=(i%2?r*.45:r)*draw.scale;const px=Math.cos(angle)*rad,py=Math.sin(angle)*rad;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}
 ctx.closePath();ctx.fillStyle='#ffd34f';ctx.fill();ctx.strokeStyle='#6d5410';ctx.lineWidth=2;ctx.stroke();ctx.restore();
}

function artReady(asset){return!!asset?.image?.complete&&!!asset.image.naturalWidth;}

function drawWorldArt(ctx,asset,x,y,w=asset?.worldSize?.w,h=asset?.worldSize?.h,draw,options={}){
 if(!artReady(asset)||!Number.isFinite(w)||!Number.isFinite(h))return false;
 const surfaceOffset=options.alignSurface?(asset.surfaceTopInsetPx||0)/WORLD_ART_PACK.ppu:0;
 const topLeft=worldToScreen(x,y+h+surfaceOffset,draw);
 if(options.alignBottom)topLeft.y+=(asset.bottomTransparentPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 topLeft.y+=(options.contactInsetPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 ctx.save();
 if(options.alpha!==undefined)ctx.globalAlpha=options.alpha;
 if(options.filter)ctx.filter=options.filter;
 ctx.drawImage(asset.image,topLeft.x,topLeft.y,w*draw.scale,h*draw.scale);
 ctx.restore();
 return true;
}

function drawWorldArtFitBounds(ctx,asset,x,y,w,draw,options={}){
 if(!artReady(asset)||!asset.visibleBoundsPx)return false;
 const [sx,sy,sw,sh]=asset.visibleBoundsPx,destH=w*sh/sw,topLeft=worldToScreen(x,y+destH,draw);
 topLeft.y+=(options.contactInsetPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(options.alpha!==undefined)ctx.globalAlpha=options.alpha;
 ctx.drawImage(asset.image,sx,sy,sw,sh,topLeft.x,topLeft.y,w*draw.scale,destH*draw.scale);
 ctx.restore();return true;
}

function withSolidClip(ctx,solid,draw,callback){
 const topLeft=worldToScreen(solid.x,solid.y+solid.h,draw);
 ctx.save();ctx.beginPath();ctx.rect(topLeft.x,topLeft.y,solid.w*draw.scale,solid.h*draw.scale);ctx.clip();
 callback();ctx.restore();
}

function drawNativePlatform(ctx,solid,draw){
 return drawContinuousTerrain(ctx,solid,draw);
}

function drawContinuousTerrain(ctx,solid,draw){
 const asset=TERRAIN_CONTINUOUS_ASSET;
 if(!artReady(asset))return false;
 const sourceW=Math.round(solid.w*asset.ppu),sourceH=Math.round(solid.h*asset.ppu);
 if(sourceW<=0||sourceH<=0||sourceH>asset.canvasPx[1])return false;
 const requested=asset.sourceOffsetsPx[solid.id]||0,sourceX=clamp(requested,0,asset.canvasPx[0]-sourceW);
 const topLeft=worldToScreen(solid.x,solid.y+solid.h,draw);
 ctx.save();ctx.imageSmoothingEnabled=true;
 ctx.drawImage(asset.image,sourceX,0,sourceW,sourceH,topLeft.x,topLeft.y,solid.w*draw.scale,solid.h*draw.scale);
 ctx.restore();return true;
}

function drawGroundTerrain(ctx,solid,draw){
 return drawContinuousTerrain(ctx,solid,draw);
}

function drawNativeTerrain(ctx,solid,draw){
 if(solid.id==='U0_VERTICAL')return drawWorldArt(ctx,worldArt.ruinColumn,solid.x,solid.y,1,4.5,draw,{alignSurface:true});
 if(Math.abs(solid.h-.5)<EPS)return drawNativePlatform(ctx,solid,draw);
 if(solid.kind==='ground')return drawGroundTerrain(ctx,solid,draw);
 return false;
}

function drawSolidWorldArt(ctx,solid,draw){
 if(scene!=='graybox')return false;
 if(solid.id==='CAJA_ROMPIBLE')return drawWorldArt(ctx,worldArt.boxIntact,solid.x,solid.y,1,1,draw,{contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
 if(!['ground','upper','roof'].includes(solid.kind))return false;
 return drawNativeTerrain(ctx,solid,draw);
}

function drawHazard(ctx,h,draw){
 const left=worldToScreen(h.x,h.y+h.h,draw),w=h.w*draw.scale,height=h.h*draw.scale;
 if(h.kind==='water'){
  const useWorldArt=scene==='graybox'&&h.id==='AGUA'&&Math.abs(h.w-4)<EPS&&artReady(worldArt.water);
  ctx.fillStyle=useWorldArt?'#0e6688cc':'#2c99c4bb';ctx.fillRect(left.x,left.y,w,height);
  if(useWorldArt){
   const artH=worldArt.water.worldSize.h;
   drawWorldArt(ctx,worldArt.water,h.x,h.y+h.h-artH,h.w,artH,draw);
  }else{
   ctx.strokeStyle='#7fdbef';ctx.lineWidth=2;ctx.beginPath();
   for(let x=left.x;x<=left.x+w;x+=draw.scale*.5)ctx.lineTo(x,left.y+Math.sin((x-left.x)/draw.scale*Math.PI*2)*3);ctx.stroke();
  }
 }else{
  const count=Math.max(1,Math.round(h.w/.5)),unit=w/count;ctx.fillStyle='#df4b45';ctx.strokeStyle='#6e2422';ctx.lineWidth=1.5;
  for(let i=0;i<count;i++){ctx.beginPath();ctx.moveTo(left.x+i*unit,left.y+height);ctx.lineTo(left.x+(i+.5)*unit,left.y);ctx.lineTo(left.x+(i+1)*unit,left.y+height);ctx.closePath();ctx.fill();ctx.stroke();}
 }
 if(debug){const hit=hazardCollider(h),p=worldToScreen(hit.x,hit.y+hit.h,draw);ctx.save();ctx.strokeStyle='#00e5ff';ctx.setLineDash([4,3]);ctx.strokeRect(p.x,p.y,hit.w*draw.scale,hit.h*draw.scale);ctx.restore();}
}

function locomotionState(entity){
 if(!entity.onGround||entity.crouched)return null;
 const speed=Math.abs(entity.vx);
 if(speed<LOCOMOTION_THRESHOLDS.idleMaxSpeed)return'idle';
 return speed>=LOCOMOTION_THRESHOLDS.runMinSpeed?'run':'walk';
}

function selectLocomotionFrame(character,entity,elapsed=sim?.elapsed||0){
 const state=locomotionState(entity);
 if(!state)return null;
 const frames=locomotionFrames[character][state],timingMs=LOCOMOTION_PACK[character].timingMs[state];
 const index=character==='eren'&&state==='idle'?0:Math.floor(elapsed*1000/timingMs)%frames.length;
 return{state,index,timingMs,...frames[index]};
}

function selectJumpFrame(character,entity){
 if(entity.crouched)return null;
 const state=entity.jumpVisualState||(!entity.onGround?(entity.vy>0?'subida':'caida'):null);
 if(!state||!jumpFrames[character][state])return null;
 const frames=jumpFrames[character][state],timingMs=JUMP_PACK[character].timingMs[state];
 let index=0;
 if(Array.isArray(timingMs)&&frames.length>1){
  const elapsedMs=Math.max(0,(entity.jumpVisualTime||0)*1000);
  index=elapsedMs<timingMs[0]?0:Math.min(frames.length-1,1);
 }
 return{kind:'jump',state,index,timingMs,worldSize:JUMP_PACK[character].worldSize,...frames[index]};
}

function selectCharacterFrame(character,entity,elapsed=sim?.elapsed||0){
 const jumpFrame=selectJumpFrame(character,entity);
 if(jumpFrame)return jumpFrame;
 const locomotionFrame=selectLocomotionFrame(character,entity,elapsed);
 return locomotionFrame?{kind:'locomotion',worldSize:LOCOMOTION_PACK[character].worldSize,...locomotionFrame}:null;
}

function drawCharacterPlaceholder(ctx,entity,label,color,draw){
 if(entity.recoverTimer>0)return;
 const topLeft=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw),w=entity.w*draw.scale,h=entity.h*draw.scale;
 const character=label==='S'?'scar':'eren',offset=TERRAIN_MOUNT_PACK.renderOffsets[character];
 topLeft.y+=(entity.onGround?offset.groundedInsetPx:offset.airborneInsetPx)/TERRAIN_MOUNT_PACK.ppu*draw.scale;
 ctx.save();ctx.fillStyle=color;ctx.strokeStyle=label==='S'?'#e7edf3':'#8b1d1d';ctx.lineWidth=Math.max(2,draw.scale*.035);
 const radius=Math.min(w,h)*.22;ctx.beginPath();
 if(ctx.roundRect)ctx.roundRect(topLeft.x,topLeft.y,w,h,radius);else ctx.rect(topLeft.x,topLeft.y,w,h);
 ctx.fill();ctx.stroke();
 ctx.fillStyle=label==='S'?'#f6f7f8':'#fff';ctx.font=`900 ${Math.max(11,draw.scale*.32)}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,topLeft.x+w/2,topLeft.y+h/2);
 const faceX=topLeft.x+(entity.facing>0?w*.78:w*.22);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(faceX,topLeft.y+h*.28,Math.max(1.6,draw.scale*.045),0,Math.PI*2);ctx.fill();
 if(debug){ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.lineWidth=1.5;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
}

function drawCharacter(ctx,entity,character,label,color,draw){
 if(entity.recoverTimer>0)return;
 if(label==='E'&&entity.invuln>0&&Math.floor(entity.invuln*12)%2===0)return;
 const frame=selectCharacterFrame(character,entity);
 if(!frame||!frame.image.complete||!frame.image.naturalWidth){drawCharacterPlaceholder(ctx,entity,label,color,draw);return;}
 const visual=frame.worldSize,contactGaps=CONTACT_BOTTOM_GAPS_PX[character]?.[frame.state]||[],contactGapPx=frame.kind==='locomotion'?(contactGaps[frame.index]||0):0;
 const offset=TERRAIN_MOUNT_PACK.renderOffsets[character],contactInsetPx=entity.onGround?offset.groundedInsetPx:offset.airborneInsetPx;
 const renderOffsetYPx=contactInsetPx+contactGapPx;
 const renderX=entity.x+(character==='eren'?(entity.visualFootOffsetX||0):0);
 const topLeft=worldToScreen(renderX-visual.w/2,entity.y+visual.h,draw),pivot=worldToScreen(renderX,entity.y,draw),w=visual.w*draw.scale,h=visual.h*draw.scale;
 topLeft.y+=renderOffsetYPx/TERRAIN_MOUNT_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(entity.facing<0){ctx.translate(pivot.x,0);ctx.scale(-1,1);ctx.translate(-pivot.x,0);}
 ctx.drawImage(frame.image,topLeft.x,topLeft.y,w,h);
 if(debug){ctx.setLineDash([7,4]);ctx.strokeStyle='#ffd34f';ctx.lineWidth=1.25;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
 if(debug){
  const collider=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw);
  const requiredRatio=entity.minGroundSupportRatio||0,requiredWidth=entity.w*requiredRatio,foot=worldToScreen(entity.x-requiredWidth/2,entity.y,draw);
  ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.lineWidth=1.5;ctx.strokeRect(collider.x,collider.y,entity.w*draw.scale,entity.h*draw.scale);ctx.setLineDash([]);
  if(requiredRatio>0){ctx.strokeStyle=entity.onGround?'#74f59a':'#ff7b72';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(foot.x,foot.y-2);ctx.lineTo(foot.x+requiredWidth*draw.scale,foot.y-2);ctx.stroke();}
  ctx.fillStyle='#f4fbff';ctx.font='700 9px monospace';ctx.textAlign='center';ctx.fillText(`apoyo ${Math.round((entity.supportRatio||0)*100)}%`,collider.x+entity.w*draw.scale/2,collider.y-4);ctx.restore();
 }
}

function render(){
 if(!sim)return;
 const canvas=byId('gameCanvas'),bounds=canvas.getBoundingClientRect();
 if(!bounds.width||!bounds.height)return;
 const dpr=Math.min(2,window.devicePixelRatio||1),pixelW=Math.round(bounds.width*dpr),pixelH=Math.round(bounds.height*dpr);
 if(canvas.width!==pixelW||canvas.height!==pixelH){canvas.width=pixelW;canvas.height=pixelH;}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,bounds.width,bounds.height);
 const scale=Math.min(bounds.width/VIEW.w,bounds.height/VIEW.h),draw={scale,ox:(bounds.width-VIEW.w*scale)/2,oy:(bounds.height-VIEW.h*scale)/2};
 ctx.fillStyle='#0b0f14';ctx.fillRect(0,0,bounds.width,bounds.height);
 const gradient=ctx.createLinearGradient(0,draw.oy,0,draw.oy+VIEW.h*scale);gradient.addColorStop(0,'#19222b');gradient.addColorStop(1,'#10151b');ctx.fillStyle=gradient;ctx.fillRect(draw.ox,draw.oy,VIEW.w*scale,VIEW.h*scale);

 ctx.save();ctx.beginPath();ctx.rect(draw.ox,draw.oy,VIEW.w*scale,VIEW.h*scale);ctx.clip();
 const firstX=Math.floor(sim.camera.x*2)/2,lastX=sim.camera.x+VIEW.w;
 for(let x=firstX;x<=lastX+.5;x+=.5){const p=worldToScreen(x,0,draw),major=Math.abs(x-Math.round(x/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(p.x,draw.oy);ctx.lineTo(p.x,draw.oy+VIEW.h*scale);ctx.stroke();}
 for(let y=Math.floor(sim.camera.y*2)/2;y<=sim.camera.y+VIEW.h+.5;y+=.5){const p=worldToScreen(0,y,draw),major=Math.abs(y-Math.round(y/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(draw.ox,p.y);ctx.lineTo(draw.ox+VIEW.w*scale,p.y);ctx.stroke();}

 if(scene==='lab'){
  for(let x=0;x<96;x+=16){const a=worldToScreen(x,sim.camera.y+VIEW.h,draw);ctx.fillStyle=(x/16)%2?'#ffffff08':'#00000010';ctx.fillRect(a.x,draw.oy,16*scale,VIEW.h*scale);}
 }

 for(const solid of sim.world.solids){
  const p=worldToScreen(solid.x,solid.y+solid.h,draw),w=solid.w*scale,h=solid.h*scale;
  const artDrawn=drawSolidWorldArt(ctx,solid,draw);
  if(!artDrawn){
   ctx.fillStyle=solid.kind==='box'?'#98683e':solid.kind==='gate'?'#34445c':solid.kind==='roof'?'#777f87':solid.kind==='upper'?'#626d78':'#59636c';ctx.fillRect(p.x,p.y,w,h);
   ctx.fillStyle=solid.kind==='box'?'#c58a51':solid.kind==='gate'?'#76a5c8':'#88939d';ctx.fillRect(p.x,p.y,w,Math.min(5,h*.15));ctx.strokeStyle='#2a3036';ctx.lineWidth=1.2;ctx.strokeRect(p.x,p.y,w,h);
   if(solid.id==='CAJA_ROMPIBLE'){
    ctx.strokeStyle='#5f3d24';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+w,p.y+h);ctx.moveTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.stroke();
   }
  }
  if(solid.id==='PUERTA_COOP'){
   ctx.strokeStyle='#9dc7e4';ctx.lineWidth=Math.max(2,scale*.06);for(let y=p.y+scale*.45;y<p.y+h;y+=scale*.65){ctx.beginPath();ctx.moveTo(p.x,y);ctx.lineTo(p.x+w,y);ctx.stroke();}
   ctx.fillStyle='#ef5b5b';ctx.beginPath();ctx.arc(p.x+w/2,p.y+h*.56,Math.max(4,scale*.12),0,Math.PI*2);ctx.fill();
  }
  if(debug&&solid.id){
   if(artDrawn){ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#9be8ff';ctx.lineWidth=1.2;ctx.strokeRect(p.x,p.y,w,h);ctx.restore();}
   ctx.fillStyle='#e3e8ee';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(solid.id,p.x+3,p.y+12);
  }
 }
 if(scene==='graybox'&&sim.boxBroken)drawWorldArt(ctx,worldArt.boxRemains,6.5,2,1,1,draw,{alpha:.92,alignBottom:true,contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
 sim.world.hazards.forEach(h=>drawHazard(ctx,h,draw));

 if(scene==='graybox'&&sim.bridgeState==='deploying'){
  const progress=1-clamp(sim.bridgeTimer/GB02_BRIDGE.deploySeconds,0,1),w=GB02_BRIDGE.w*progress,p=worldToScreen(GB02_BRIDGE.x,GB02_BRIDGE.y+GB02_BRIDGE.h,draw);
  ctx.fillStyle='#87a7b8cc';ctx.fillRect(p.x,p.y,w*scale,GB02_BRIDGE.h*scale);ctx.strokeStyle='#c9e6f2';ctx.strokeRect(p.x,p.y,w*scale,GB02_BRIDGE.h*scale);
 }

 if(sim.world.ladder){
  const ladder=sim.world.ladder,p=worldToScreen(ladder.artX,ladder.artY+ladder.artH,draw),w=ladder.artW*scale,h=ladder.artH*scale;
  ctx.strokeStyle='#b98b52';ctx.lineWidth=Math.max(3,scale*.08);ctx.beginPath();ctx.moveTo(p.x+w*.2,p.y);ctx.lineTo(p.x+w*.2,p.y+h);ctx.moveTo(p.x+w*.8,p.y);ctx.lineTo(p.x+w*.8,p.y+h);ctx.stroke();
  ctx.lineWidth=Math.max(2,scale*.055);for(let y=p.y+scale*.35;y<p.y+h;y+=scale*.45){ctx.beginPath();ctx.moveTo(p.x+w*.2,y);ctx.lineTo(p.x+w*.8,y);ctx.stroke();}
  if(debug){const grip=worldToScreen(ladder.x,ladder.y+ladder.h,draw);ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#f6d365';ctx.strokeRect(grip.x,grip.y,ladder.w*scale,ladder.h*scale);ctx.restore();}
 }
 if(debug)for(const filter of sim.world.actorFilters||[]){
  const p=worldToScreen(filter.x,filter.y+filter.h,draw);ctx.save();ctx.setLineDash([4,3]);ctx.strokeStyle='#f3c83b';ctx.lineWidth=1.5;ctx.strokeRect(p.x,p.y,filter.w*scale,filter.h*scale);ctx.fillStyle='#f3c83b';ctx.font='700 9px monospace';ctx.fillText(filter.id,p.x+3,p.y+11);ctx.restore();
 }

 if(sim.world.marker){
  const m=sim.world.marker,p=worldToScreen(m.x,m.y+m.h,draw),active=scarPlateActive(),plateAsset=active?worldArt.platePressed:worldArt.plateFree;
  if(scene==='graybox')drawNativePlatform(ctx,{id:'PLACA_BASE',x:m.x,y:m.y-.5,w:m.w,h:.5},draw);
  const plateDrawn=scene==='graybox'&&drawWorldArtFitBounds(ctx,plateAsset,m.x,m.y,m.w,draw,{contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
  if(!plateDrawn){const contactY=p.y+VISUAL_CONTACT_PLANE.propInsetPx/VISUAL_CONTACT_PLANE.ppu*scale;ctx.fillStyle=active?'#4ed58a':'#f3c83b';ctx.fillRect(p.x,contactY,m.w*scale,Math.max(4,m.h*scale));ctx.strokeStyle=active?'#174d31':'#4f4214';ctx.strokeRect(p.x,contactY,m.w*scale,Math.max(4,m.h*scale));}
  ctx.fillStyle=active?'#dfffee':'#f7f1cf';ctx.font=`900 ${Math.max(10,scale*.2)}px Arial`;ctx.textAlign='center';ctx.fillText(active?'ACTIVA':'SCAR',p.x+m.w*scale/2,p.y-4);
 }
 if(sim.world.marker2){
  const m=sim.world.marker2,p=worldToScreen(m.x,m.y+m.h,draw),active=sim.bridgeState!=='closed';
  ctx.fillStyle=active?'#4ed58a':'#f3c83b';ctx.fillRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));ctx.strokeStyle=active?'#174d31':'#4f4214';ctx.strokeRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));
  ctx.fillStyle=active?'#dfffee':'#f7f1cf';ctx.font=`900 ${Math.max(10,scale*.2)}px Arial`;ctx.textAlign='center';ctx.fillText(active?'PUENTE':'SCAR',p.x+m.w*scale/2,p.y-4);
 }
 if(sim.world.lever){
  const lever=sim.world.lever,p=worldToScreen(lever.x,lever.y+lever.h,draw),w=lever.w*scale,h=lever.h*scale,active=sim.erenSwitchArmed;
  const leverDrawn=scene==='graybox'&&drawWorldArt(ctx,worldArt.lever,lever.x,lever.y,1.5,2,draw,{alpha:active?1:.72,filter:active?'none':'saturate(.65)',contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
  if(!leverDrawn){
   ctx.fillStyle=active?'#2d9d65':'#7c8794';ctx.fillRect(p.x+w*.2,p.y+h*.45,w*.6,h*.55);ctx.strokeStyle='#252b32';ctx.lineWidth=1.5;ctx.strokeRect(p.x+w*.2,p.y+h*.45,w*.6,h*.55);
   ctx.strokeStyle=active?'#65efaa':'#ef6262';ctx.lineWidth=Math.max(3,scale*.08);ctx.beginPath();ctx.moveTo(p.x+w*.5,p.y+h*.5);ctx.lineTo(p.x+w*(active?.78:.3),p.y+h*.15);ctx.stroke();
  }
  ctx.fillStyle='#f7fbff';ctx.font=`900 ${Math.max(10,scale*.2)}px Arial`;ctx.textAlign='center';ctx.fillText(sim.coopUnlocked?'ABIERTA':active?'LISTA':'EREN',p.x+w*.5,p.y-4);
 }
 if(sim.world.star&&!sim.starCollected){
  const star=sim.world.star;
  if(!(scene==='graybox'&&drawWorldArt(ctx,worldArt.star,star.x-.5,star.y-.5,1,1,draw)))drawStar(ctx,star.x,star.y,star.r,draw);
 }
 if(sim.world.star2&&!sim.star2Collected){const star=sim.world.star2;drawStar(ctx,star.x,star.y,star.r,draw);}
 if(sim.world.goal){const g=sim.world.goal,p=worldToScreen(g.x,g.y+g.h,draw);ctx.strokeStyle='#e6edf3';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x,p.y+g.h*scale);ctx.stroke();ctx.fillStyle='#ef4a4a';ctx.fillRect(p.x,p.y,g.w*scale*.72,g.h*scale*.42);}
 for(const checkpoint of sim.world.checkpoints){const p=worldToScreen(checkpoint.x,checkpoint.y+.2,draw);ctx.fillStyle=checkpoint.id===sim.checkpoint.id?'#62d6ff':'#3f6d7d';ctx.beginPath();ctx.moveTo(p.x,p.y-7);ctx.lineTo(p.x+7,p.y);ctx.lineTo(p.x,p.y+7);ctx.lineTo(p.x-7,p.y);ctx.closePath();ctx.fill();}
 for(const label of sim.world.labels){const p=worldToScreen(label.x,10.15,draw);ctx.fillStyle='#dce4ec';ctx.font=`900 ${Math.max(10,scale*.25)}px Arial`;ctx.textAlign='center';ctx.fillText(label.text,p.x,p.y);}

 if(sim.enemy&&!sim.enemy.defeated){
  const enemy=sim.enemy,p=worldToScreen(enemy.x-enemy.w/2,enemy.y+enemy.h,draw),w=enemy.w*scale,h=enemy.h*scale;
  ctx.save();ctx.fillStyle=enemy.state==='attack'?'#ef5350':enemy.state==='windup'?'#ffb74d':'#6f566f';ctx.strokeStyle='#241c28';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(p.x+w/2,p.y+h*.58,w*.42,h*.28,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.lineWidth=Math.max(1.5,scale*.035);for(const side of[-1,1])for(let i=0;i<3;i++){const yy=p.y+h*(.42+i*.15);ctx.beginPath();ctx.moveTo(p.x+w/2+side*w*.25,yy);ctx.lineTo(p.x+w/2+side*w*.48,yy+h*.16);ctx.stroke();}
  ctx.fillStyle='#fff';ctx.font=`900 ${Math.max(9,scale*.18)}px Arial`;ctx.textAlign='center';ctx.fillText(`${enemy.hp}/${enemy.maxHp}`,p.x+w/2,p.y-4);ctx.restore();
  if(debug){ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#ff7b72';ctx.strokeRect(p.x,p.y,w,h);ctx.restore();}
 }
 drawCharacter(ctx,sim.scar,'scar','S','#17191c',draw);drawCharacter(ctx,sim.eren,'eren','E','#e54747',draw);
 if(scene==='graybox'&&sim.erenAttackTimer>0){
  const hit=erenAttackBox(sim.eren),p=worldToScreen(hit.x,hit.y+hit.h,draw);ctx.save();ctx.fillStyle='#ffd34f55';ctx.strokeStyle='#ffd34f';ctx.strokeRect(p.x,p.y,hit.w*scale,hit.h*scale);ctx.fillRect(p.x,p.y,hit.w*scale,hit.h*scale);ctx.restore();
 }
 if(debug){
  if(Number.isFinite(sim.scar.navTargetX)&&Number.isFinite(sim.scar.navTargetY)){
   const from=worldToScreen(sim.scar.x,sim.scar.y+sim.scar.h*.5,draw),to=worldToScreen(sim.scar.navTargetX,sim.scar.navTargetY+.2,draw);
   ctx.strokeStyle='#62d6ff';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(to.x,to.y);ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle='#bdefff';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(sim.scar.navPhase,to.x+5,to.y-5);
  }
  const deadW=3*scale,deadH=1.5*scale;ctx.strokeStyle='#ffd34faa';ctx.setLineDash([7,5]);ctx.strokeRect(draw.ox+(VIEW.w*scale-deadW)/2,draw.oy+(VIEW.h*scale-deadH)/2,deadW,deadH);ctx.setLineDash([]);
  ctx.fillStyle='#fff';ctx.font='700 11px monospace';ctx.textAlign='left';ctx.fillText(`cam ${sim.camera.x.toFixed(2)}, ${sim.camera.y.toFixed(2)} · 60 Hz`,draw.ox+8,draw.oy+16);
 }
 ctx.restore();
}

function updateHud(){
 if(!sim)return;
 updateHeartHud(sim.eren.hearts);
 byId('gameStars').textContent=String(Number(sim.starCollected)+Number(sim.star2Collected));
 byId('metricSpeed').textContent=`${format(Math.abs(sim.eren.vx))} m/s`;
 byId('metricHeight').textContent=`${format(Math.max(0,sim.eren.y-2))} m`;
 byId('metricScar').textContent=sim.scar.recoverTimer>0?'RETORNO':sim.scar.crouched?'PASO BAJO':sim.scar.mode==='follow'?'SIGUE':sim.scar.mode==='marker'?'VA A PLACA':'ESPERA';
 byId('metricState').textContent=sim.eren.recover>0?'RETORNO':sim.eren.climbing?'ESCALERA':sim.eren.crouched?'AGACHADO':sim.eren.onGround?'SUELO':'AIRE';
 byId('gamePrompt').textContent=setMessageFromProgress();
}

function updateHeartHud(currentHearts){
 const target=byId('gameHearts'),count=clamp(Math.trunc(currentHearts),0,HUD_HEARTS_LAYOUT.slots);
 target.style.display='inline-grid';
 target.style.gridTemplateColumns=`repeat(${HUD_HEARTS_LAYOUT.slots}, ${HUD_HEARTS_LAYOUT.slotWidthEm}em)`;
 target.style.width=`${HUD_HEARTS_LAYOUT.containerWidthEm}em`;
 target.style.justifyItems='center';
 target.style.alignItems='center';
 target.style.whiteSpace='nowrap';
 target.style.textAlign='center';
 target.setAttribute('role','img');
 target.setAttribute('aria-label',`${count} de ${HUD_HEARTS_LAYOUT.slots} corazones`);
 target.innerHTML=Array.from({length:HUD_HEARTS_LAYOUT.slots},(_,index)=>
  `<span aria-hidden="true" data-heart-slot="${index+1}">${index<count?HUD_HEARTS_LAYOUT.filledGlyph:HUD_HEARTS_LAYOUT.emptyGlyph}</span>`
 ).join('');
}

function gameLoop(time){
 if(!sim||!sim.running)return;
 if(!previousTime)previousTime=time;
 const delta=Math.min(.05,(time-previousTime)/1000);previousTime=time;accumulator+=delta;
 const input=currentInput();
 while(accumulator>=FIXED_DT){physicsStep(FIXED_DT,input);accumulator-=FIXED_DT;}
 render();
 if(time-lastHudUpdate>90){updateHud();lastHudUpdate=time;}
 frameHandle=requestAnimationFrame(gameLoop);
}

function resetSimulation(reason='reinicio_manual'){
 const wasRunning=!!(sim&&sim.running);if(reason)archiveCurrentAttempt(reason);sim=createSimulation();accumulator=0;previousTime=0;
 byId('gameReward').classList.add('hidden');updateHud();render();
 if(!wasRunning&&!frameHandle)frameHandle=requestAnimationFrame(gameLoop);
}

function setScene(next,reason=`cambio_escena_${scene}_a_${next}`){
 archiveCurrentAttempt(reason);scene=next;labStation='A';
 byId('playGraybox').classList.toggle('active',scene==='graybox');byId('playLab').classList.toggle('active',scene==='lab');
 byId('labControls').classList.toggle('hidden',scene!=='lab');
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===labStation));
 resetSimulation(null);
}

function teleportStation(station){
 if(scene!=='lab')return;archiveCurrentAttempt(`cambio_estacion_${labStation}_a_${station}`);labStation=station;
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===station));
 resetSimulation(null);logEvent('estacion',{station});
}

function setControllerMode(enabled){
 document.body.classList.toggle('controller-mode',enabled);byId('controllerStatus').classList.toggle('hidden',!enabled);
}

function setGamePanel(open){
 const game=byId('game'),panel=byId('gamePanel'),toggle=byId('toggleGamePanel');
 game.classList.toggle('panel-open',!!open);
 panel.setAttribute('aria-hidden',open?'false':'true');
 toggle.setAttribute('aria-expanded',open?'true':'false');
}

function startGame(){
 stopNarration();show('game');byId('appTitle').textContent='Eren y Scar · Nivel 1 ampliado';
 archiveCurrentAttempt('nuevo_inicio');cancelAnimationFrame(frameHandle);frameHandle=0;sim=createSimulation();previousTime=0;accumulator=0;lastHudUpdate=0;
 byId('gameReward').classList.add('hidden');setControllerMode(false);setGamePanel(false);updateHud();frameHandle=requestAnimationFrame(gameLoop);
}

function openLandscapeGame(){
 if(!TEST_MODE&&!Number(localStorage.getItem('game-tokens')||0)&&!completedStories().size){byId('gameStatus').textContent='Primero completa un cuento nuevo';tone('wrong');return;}
 document.body.classList.add('game-mode');if(window.AndroidLayout)AndroidLayout.landscape();startGame();
}

function closeLandscapeGame(){
 archiveCurrentAttempt('salir_juego');if(sim)sim.running=false;cancelAnimationFrame(frameHandle);frameHandle=0;stopNarration();setControllerMode(false);document.body.classList.remove('game-mode');
 setGamePanel(false);
 if(window.AndroidLayout)AndroidLayout.portrait();renderMenu();
}

function savePlaytestLog(){
 if(!sim)return'';
 const json=JSON.stringify(playtestBundle(),null,2);localStorage.setItem('graybox-last-playtest',json);byId('playtestLogText').value=json;return json;
}

function openPlaytestDialog(recordEvent=true){
 if(!sim)return;
 if(recordEvent)logEvent('ver_registro');
 savePlaytestLog();logDialogWasPaused=sim.paused;sim.paused=true;byId('playtestLogDialog').classList.remove('hidden');
}

function closePlaytestDialog(){
 byId('playtestLogDialog').classList.add('hidden');if(sim&&!sim.complete)sim.paused=logDialogWasPaused;
}

function sharePlaytest(){
 if(!sim)return;
 logEvent('compartir_registro');const json=savePlaytestLog();
 if(window.AndroidShare&&typeof window.AndroidShare.shareText==='function'){
  window.AndroidShare.shareText('Registro playtest · Eren y Scar',json);toast('Elige dónde enviar el registro.');
 }else{
  openPlaytestDialog(false);toast('Registro guardado. Puedes copiarlo.');
 }
}

async function copyPlaytest(){
 if(!sim)return;
 logEvent('copiar_registro');const json=savePlaytestLog(),area=byId('playtestLogText');let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Registro copiado.':'Mantén pulsado el texto para copiarlo.');
}

async function copyPlaytestSummary(){
 if(!sim)return;
 logEvent('copiar_resumen');const json=JSON.stringify(compactPlaytestBundle(),null,2),area=byId('playtestLogText');area.value=json;localStorage.setItem('graybox-last-playtest-summary',json);let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Resumen copiado.':'Resumen mostrado: mantén pulsado para copiarlo.');
}

function bindPointerHold(element){
 const names=(element.dataset.controls||'').split(/\s+/).filter(Boolean);
 const release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,names);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

function bindPointerPress(id,name){
 const element=byId(id),release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,[name]);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

document.querySelectorAll('[data-controls]').forEach(bindPointerHold);
bindPointerPress('jump','jump');bindPointerPress('action','action');bindPointerPress('scarAction','scar');

window.addEventListener('keydown',event=>{
 if(!document.body.classList.contains('game-mode'))return;
 if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(event.code))event.preventDefault();
 keyControls.add(event.code);
});
window.addEventListener('keyup',event=>keyControls.delete(event.code));
window.addEventListener('blur',()=>{keyControls.clear();pointerControls.clear();Object.keys(nativeControls).forEach(key=>nativeControls[key]=false);});

window.androidGameKey=(control,pressed)=>{if(!sim||!sim.running)return;setControllerMode(true);if(control in nativeControls)nativeControls[control]=pressed;};
window.androidGameAxis=(x,y)=>{if(!sim||!sim.running)return;setControllerMode(true);nativeControls.left=x<-.35;nativeControls.right=x>.35;nativeControls.up=y<-.55;nativeControls.crouch=y>.55;};
window.addEventListener('gamepadconnected',()=>setControllerMode(true));window.addEventListener('gamepaddisconnected',()=>setControllerMode(false));
byId('gameViewport').addEventListener('pointerdown',event=>{if(!event.target.closest?.('button'))setControllerMode(false);});

byId('directGame').onclick=openLandscapeGame;byId('openGame').onclick=openLandscapeGame;byId('playReward').onclick=openLandscapeGame;byId('exitGame').onclick=closeLandscapeGame;
byId('toggleGamePanel').onclick=()=>setGamePanel(!byId('game').classList.contains('panel-open'));byId('closeGamePanel').onclick=()=>setGamePanel(false);
byId('gameRewardOk').onclick=closeLandscapeGame;byId('gameRewardAgain').onclick=()=>setScene('graybox','probar_otra_vez');
byId('playGraybox').onclick=()=>setScene('graybox','seleccion_graybox');byId('playLab').onclick=()=>setScene('lab','seleccion_laboratorio');
byId('resetGame').onclick=()=>resetSimulation('reinicio_manual');
byId('toggleDebug').onclick=()=>{debug=!debug;byId('toggleDebug').textContent=`Colliders: ${debug?'sí':'no'}`;render();};
byId('exportPlaytest').onclick=sharePlaytest;byId('showPlaytest').onclick=()=>openPlaytestDialog(true);
byId('copyPlaytest').onclick=copyPlaytest;byId('copyPlaytestSummary').onclick=copyPlaytestSummary;byId('sharePlaytest').onclick=sharePlaytest;byId('closePlaytest').onclick=closePlaytestDialog;
document.querySelectorAll('[data-station]').forEach(button=>button.onclick=()=>teleportStation(button.dataset.station));

function bindRange(id,key,output,suffix=''){
 const input=byId(id),target=byId(output);
 input.addEventListener('input',()=>{tuning[key]=Number(input.value);target.textContent=`${format(input.value)}${suffix}`;});
 input.addEventListener('change',()=>{logEvent('ajuste_metrica',{key,value:tuning[key]});if(key==='labHeight'||key==='labGap')resetSimulation(`ajuste_${key}`);});
}
bindRange('heightTuning','labHeight','heightOutput',' m');bindRange('gapTuning','labGap','gapOutput',' m');
bindRange('walkTuning','walk','walkOutput');bindRange('runTuning','run','runOutput');bindRange('jumpTuning','jump','jumpOutput');
byId('gravityTuning').addEventListener('input',event=>{tuning.gravityDown=Number(event.target.value);byId('gravityOutput').textContent=event.target.value;});
byId('gravityTuning').addEventListener('change',()=>logEvent('ajuste_metrica',{key:'gravityDown',value:tuning.gravityDown}));

})();
