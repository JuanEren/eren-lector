# Locuciones locales para compilaciones reproducibles

La compilación normal busca, por este orden:

1. `ci/audio/Eren-Locuciones-Locales.zip`;
2. `ci/audio/locuciones-azure.zip` (nombre heredado compatible);
3. el caché heredado de GitHub Actions.

El ZIP debe ser el artefacto `Eren-Locuciones-Locales` descargado de GitHub Actions y debe subirse sin editar, extraer, renombrar internamente ni recomprimir. El workflow lo descomprime directamente en `app/src/main/assets/www/assets/audio`.

Azure solo puede ejecutarse desde **Actions → Compilar APK → Run workflow** activando manualmente `regenerar_locuciones`. Los eventos `push` y las ejecuciones manuales con esa opción desactivada nunca llaman a Azure.

Una vez versionado `Eren-Locuciones-Locales.zip`, las compilaciones dejan de depender tanto de Azure como de la caducidad del caché de Actions.
