# Decisión de build · R13

Fecha: 26/08/2026  
Build: `38.0.0-graybox-r13-offline-audio-build-candidate`  
Estado: `OFFLINE_AUDIO_BY_DEFAULT`  
`GAME_READY=false`

## Diagnóstico del fallo recibido

El workflow restauró correctamente el caché y falló inmediatamente después, antes de realizar una petición HTTP a Azure. La traza sitúa el error en `scripts/generate-azure-audio.mjs:17`, durante la evaluación de los datos de `app.js`:

```text
window.__uiR02=UI_R02_PACK;
ReferenceError: window is not defined
```

La causa era doble:

1. el workflow ejecutaba el generador en todas las builds siempre que existieran los secretos de Azure, aunque los MP3 ya estuvieran recuperados;
2. la versión activa del generador evaluaba código de navegador dentro de Node sin proporcionar un objeto `window`.

Por tanto, no fue una caída del servicio Azure ni un problema de credenciales.

## Contrato adoptado

### Compilación normal

1. Recupera `ci/audio/Eren-Locuciones-Locales.zip` si está versionado.
2. Durante la transición, puede recuperar el caché histórico `azure-tts-v1` o `azure-tts-v2`.
3. Ejecuta `node scripts/generate-azure-audio.mjs --verify-only`.
4. Verifica tamaño y presencia de todas las locuciones previstas.
5. Compila la APK sin llamar a Azure.

No existe ninguna condición por secretos que pueda activar síntesis en un evento `push`.

### Regeneración excepcional

Azure solo se ejecuta desde `workflow_dispatch` cuando el usuario activa expresamente `regenerar_locuciones`. El generador conserva los archivos válidos y crea únicamente los ausentes.

### Persistencia definitiva

Cada build válida publica el artefacto `Eren-Locuciones-Locales`. Tras descargarlo una vez y guardarlo sin modificar como `ci/audio/Eren-Locuciones-Locales.zip`, el proyecto deja de depender también del caché de GitHub Actions.

## Corrección del evaluador

`scripts/extract-audio-catalogue.mjs` crea un entorno aislado compatible con los datos de navegador (`window`, `globalThis`, `document`, `localStorage` y `navigator`). La prueba R13 reproduce expresamente la línea `window.__uiR02=UI_R02_PACK` y confirma que Node extrae el catálogo sin error.

## Observación sobre el repositorio activo

La captura no muestra los pasos de validación que ya figuraban en la actualización anterior. Esto indica que `.github/workflows/build-apk.yml` no se aplicó al árbol del repositorio o quedó la versión antigua. Guardar el ZIP de actualización como un archivo no modifica el proyecto: R13 debe descomprimirse sobre la raíz y debe incluirse la carpeta oculta `.github`.

## Alcance no modificado

- geometría, física, colliders y cámara de GB01;
- ampliación GB02 R12;
- contacto visual R10;
- HUD de tres casillas R11;
- contenidos y voz aprobados de las locuciones existentes.

R13 cambia únicamente infraestructura de build, extracción del catálogo, validación y persistencia de audio.
