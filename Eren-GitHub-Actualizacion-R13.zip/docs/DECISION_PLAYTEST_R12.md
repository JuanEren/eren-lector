# Decisión de playtest · R12

Fecha: 26/08/2026  
Build: `37.0.0-graybox-r12-gb02-route-playtest-candidate`  
Registro: `GB02-v01`  
Estado: `GB01_VALIDATED_GB02_CANDIDATE_PLAYTEST`  
`GAME_READY=false`

## Diagnóstico del registro recibido

El intento incompleto de 210,6 segundos pertenece a `scene="lab"`, estación `A`, no al nivel ampliado. Ese laboratorio de R11 tenía `goal=null`. Los eventos repetidos `B_SALIDA → scar_recuperacion:water` y `F0/F1 → scar_recuperacion:spikes` procedían de estaciones técnicas de límite de salto y daño, no de una misión resoluble.

La interfaz no lo comunicaba con suficiente claridad y Scar intentaba seguir a Eren por pruebas que no estaban diseñadas como ruta cooperativa. Se corrigen ambos problemas: el laboratorio muestra `SIN META` en todas sus estaciones y Scar espera por defecto salvo en la estación `E`, dedicada a su comportamiento.

## Decisión sobre el agachado

Se adopta la alternativa propuesta en el playtest: un paso realmente exclusivo de Scar y una ruta diferente para Eren.

- `TUNEL_SCAR_TECHO_FISICO` define el espacio real disponible.
- Scar mantiene collider de pie `1,5 × 1` hasta que una comprobación adelantada detecta que no cabe.
- Solo entonces cambia al collider bajo `1,5 × 0,5`.
- Al quedar libre el collider de pie, recupera su altura y registra la salida.
- Se elimina el agachado basado únicamente en coordenadas de GB01.
- Eren no atraviesa el filtro `PASO_SCAR_1` ni siquiera agachado; su alternativa es `ESCALERA_E1_GRIP → U4 → TUNEL_TECHO_1`.

## Decisión sobre el salto final

La reproducción automatizada mostró que el salto alto ordinario de Scar chocaba contra la cara inferior de `U6` y descendía sobre `PINCHOS_2`. No se modifica la física global.

Se introduce un único perfil contextual para el enlace final:

- inicio seguro: `x=59,5`;
- requisito: Eren ha alcanzado `x≥62,5` o ha abierto la espera de meta;
- `vx=8,2`;
- `vy=8,5`;
- gravedad heredada `36/44` y terminal `-16`;
- perfil: `LOW_LONG_CLEARANCE_UNDER_U6`.

El resultado es un salto bajo y largo que conserva separación respecto a la plataforma superior y aterriza después de los pinchos.

## Alcance integrado

- mundo ampliado de `36,5` a `64,5` módulos;
- G4, U4, G5, túnel, puente, G6, U5 y U6;
- enemigo terrestre provisional de dos impactos;
- escalera de Eren;
- paso exclusivo de Scar con collider real;
- placa y puente enclavados;
- segunda estrella opcional;
- pinchos finales y meta dual estricta sobre G6;
- telemetría específica y separación explícita del laboratorio.

## Resultado de QA automatizada

- túnel de Scar: `20/20`, `0` recuperaciones;
- apertura del puente: `20/20`;
- salto final y reunión: `20/20`, `0` recuperaciones por pinchos;
- enemigo: dos impactos exactos;
- filtro de actor: Eren bloqueado de pie y agachado;
- escalera: agarre y salida confirmados;
- regresión GB01, apoyo de borde, contacto visual y HUD: `PASS`.

## Pendiente antes de aprobación funcional de GB02

1. Completar al menos un intento íntegro en Android sin daño y otro con daño intencionado.
2. Confirmar claridad del aviso del enemigo y de la orden a Scar.
3. Sustituir placeholders solo después de auditar los assets; sin escalar, estirar ni deformar PNG.
4. Refinar el tileset conservando `100 PPU`, escala `1:1` y colliders independientes del dibujo.
