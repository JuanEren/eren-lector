# GAME DESIGN · GRAYBOX 02 R02 · IMPLEMENTACIÓN AUTORIZADA

Fecha: 26/08/2026  
Decisión: `GAMEDESIGN-GB02-20260826-R02`  
Sustituye: `GAMEDESIGN-GB02-20260826-R01`  
Estado: `IMPLEMENTATION_AUTHORIZED` · `ARTE_PROVISIONAL_PERMITIDO` · `GAME_READY=false`

El playtest Android del 26/08/2026 valida funcionalmente GB01. El ajuste R11 del HUD de corazones se aplica en paralelo y el refinamiento artístico del tileset ya no bloquea la construcción mecánica de esta ampliación. Los contratos R01 contenidos en el paquete siguen siendo la fuente exacta de geometría, enemigo y QA; R02 únicamente formaliza su autorización.

Este paquete amplía el graybox funcional sin alterar el tramo ya validado. El recorrido pasa de `36,5 × 12` a `64,5 × 12` módulos y añade tres aprendizajes controlados:

1. primer enemigo terrestre y combate básico con el botón Acción;
2. separación visible de rutas: Eren usa una escalera y Scar un paso exclusivo;
3. placa de Scar que despliega y enclava un puente de 4 módulos.

El antiguo final de `GB01` se convierte en el punto de control `R3`. La nueva meta dual está al final de `G6`.

## Qué contiene

- plano funcional exacto y mapa en SVG/PNG;
- contrato del enemigo, hitbox, hurtbox, daño y estados;
- matriz de beats y criterios de aceptación;
- prompt listo para la Gema de Gemini, empezando por auditoría y no por generación;
- reglas obligatorias de extracción y montaje modular;
- inventario de assets reutilizables, ausentes y candidatos a rehacer.

## Qué no contiene

- código de la ampliación;
- PNG nuevos generados por IA;
- integración del lote candidato de enemigos ya archivado;
- cambios de salto, gravedad, borde, colliders del graybox anterior o navegación ya validada;
- promoción a `GAME_READY`.

## Orden correcto

1. Aplicar R11 sobre la base ya validada de GB01.
2. Construir `GB02` en arte gris/funcional siguiendo las medidas exactas del contrato R01.
3. Probar por fases geometría/meta, combate, escalera/túnel, puente y recorrido final.
4. Ejecutar en paralelo el prompt de Gemini con el atlas y catálogos indicados.
5. Exigir primero `CONTROL_PREVIO` y la tabla de auditoría; no generar todo de golpe.
6. Integrar únicamente assets que superen la puerta técnica del documento `06_REGLAS_MONTAJE_TILESET_MODULAR_R01.md`.

## Criterio de cierre del graybox actual

`GB01` está `FUNCTIONAL_VALIDATED_ART_PENDING`: la APK R10 confirmó en dispositivo el contacto a `+10 px` y el funcionamiento de las mecánicas. El refinamiento artístico del tileset permanece como trabajo separado y no reabre la física validada.
