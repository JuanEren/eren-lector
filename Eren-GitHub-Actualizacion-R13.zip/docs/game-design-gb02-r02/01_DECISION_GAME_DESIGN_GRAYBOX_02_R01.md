# Decisión de Game Design · Graybox 02 R01

## 1. Objetivo

Extender el segmento jugable actual con complejidad real, pero sin introducir varias incógnitas a la vez. El nuevo tramo debe enseñar una idea, comprobarla y combinarla antes de la meta.

La ampliación conserva íntegros los módulos `x=0–36,5` de `GB01`. Desde `x=36,5` añade `28` módulos y termina en `x=64,5`. La altura contractual continúa en `12` módulos.

## 2. Decisión de alcance

### Mecánicas que entran en GB02

| ID | Mecánica | Función pedagógica | Obligatoriedad |
|---|---|---|---|
| `MEC-COMBATE-01` | Ataque básico de Eren contra patrulla terrestre | Enseñar lectura de aviso, distancia y ventana de Acción | Obligatoria |
| `MEC-ESCALERA-01` | Agarre, subida, bajada y salida superior de Eren | Introducir conexión vertical controlada | Obligatoria |
| `MEC-SCAR-PASO-01` | Entrada y salida por paso exclusivo visible | Separar rutas sin teletransporte opaco | Obligatoria |
| `MEC-PUENTE-SCAR-01` | Placa exclusiva de Scar, enclavada, despliega puente | Convertir la separación en cooperación causal | Obligatoria |
| `MEC-RUTA-ESTRELLA-01` | Plataformas superiores opcionales | Recompensar dominio del salto sin bloquear el avance | Opcional |

### Mecánicas que no entran todavía

- enemigo volador;
- enemigo fijo vegetal/ruina;
- salto sobre la cabeza del enemigo;
- combate de Scar;
- plataforma móvil obligatoria;
- combos, armas, proyectiles, bloqueo o resistencia;
- puzle con más de una orden simultánea a Scar.

Estas exclusiones son intencionadas: primero se valida un único enemigo, una única ventana de ataque y una única cadena cooperativa.

## 3. Enemigo elegido

La primera familia será `ENEMIGO_TERRESTRE_PATRULLA_M1_R01`, con concepto visual recomendado de **araña de ruina**. La elección encaja con las reacciones previstas de Scar, permite una caja baja de `1 × 1` módulo y evita una silueta humanoide agresiva.

En términos narrativos el enemigo se **ahuyenta**, no se representa muerte gráfica. Su lógica completa se define en `03_CONTRATO_ENEMIGO_TERRESTRE_R01.md`.

## 4. Curva del nuevo tramo

1. `R3 / transición`: dos módulos seguros para reconocer el nuevo sector.
2. `Beat 12 / observar`: el enemigo patrulla detrás de una línea de seguridad y muestra un aviso legible.
3. `Beat 13 / actuar`: Eren aprende Acción, recibe como máximo un daño y dispone de retorno seguro.
4. `Beat 14 / separar`: Eren sube por la escalera; Scar entra por el paso felino visible.
5. `Beat 15 / cooperar`: la placa de Scar despliega el puente; su estado queda enclavado.
6. `Beat 16 / dominar`: Eren puede tomar una estrella por la ruta alta; la ruta baja sigue siendo válida.
7. `Beat 17 / reunir`: Eren y Scar deben estar simultáneamente en la nueva meta.

## 5. Reglas de dificultad

- El primer enemigo aparece después de `2,5` módulos completamente seguros.
- No hay peligro mortal detrás del enemigo ni caída inmediata durante el tutorial.
- La primera patrulla es única. No se duplica hasta conseguir al menos `8/10` superaciones sin daño en playtest.
- El puente no se retrae al abandonar la placa; se enclava para no castigar a Scar ni crear bloqueo irreversible.
- La orden de Scar usa el botón de la pata ya existente. Acción sigue reservada a Eren.
- La estrella del tramo es opcional y nunca bloquea la meta.
- La nueva meta mantiene el contrato estricto de presencia simultánea de Eren y Scar.

## 6. Invariantes heredados

- `1 módulo = 100 px`; paso mínimo funcional `0,5 módulo = 50 px`.
- `transformScale=[1,1]`; ningún sprite se estira para encajar.
- Eren: caminar `3,5`, correr `6`, salto `15,9`, gravedad subida `36`, bajada `44`, terminal `-16`.
- Apoyo de borde: `ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN`.
- Scar conserva física, navegación y recuperación propias.
- Los tres corazones son de Eren; Scar no consume corazones.
- Las estrellas las recoge Eren.
- No se alteran los `36,5` módulos del graybox ya aprobado.

## 7. Puerta de aprobación

La ampliación no pasa de `DESIGN_ONLY` a build hasta que existan:

- geometría importada desde el contrato, sin redimensionamiento libre;
- hitboxes/hurtboxes visibles en modo depuración;
- ruta de Scar comprobada veinte veces sin teletransporte visible ni aparición dentro de colisión;
- escalera comprobada desde suelo, salto, caída, salida y soltarse;
- puente incapaz de cerrar al jugador o a Scar dentro del agua;
- un playtest completo sin daño y otro recibiendo daño intencionadamente;
- auditoría de assets de Gemini devuelta y revisada antes de integrar PNG candidatos.

