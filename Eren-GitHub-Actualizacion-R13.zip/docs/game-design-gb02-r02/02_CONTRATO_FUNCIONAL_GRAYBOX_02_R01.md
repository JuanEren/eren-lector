# Contrato funcional · Graybox 02 R01

Sistema de coordenadas: `x` crece hacia la derecha; `y` es la base del rectángulo; medidas en módulos. Todas las dimensiones y posiciones estáticas usan pasos de `0,5`.

## 1. Extensión global

- tamaño total: `64,5 × 12`;
- tramo heredado e inmutable: `x=0–36,5`;
- tramo nuevo: `x=36,5–64,5`;
- antigua meta `x=34,5–36,5`: pasa a checkpoint `R3`, no termina el nivel;
- nueva meta estricta: `x=62,5–64,5`.

## 2. Sólidos nuevos

| ID | x | y | w | h | Superficie superior | Función |
|---|---:|---:|---:|---:|---:|---|
| `G4` | 36,5 | 0 | 9 | 2 | 2 | Entrada segura y tutorial de enemigo |
| `U4` | 43 | 4,5 | 2,5 | 0,5 | 5 | Salida superior de la escalera |
| `G5` | 45,5 | 0 | 6 | 2 | 2 | Suelo del paso de Scar |
| `TUNEL_TECHO_1` | 45,5 | 3 | 6 | 0,5 | 3,5 | Techo bajo y ruta superior de Eren |
| `PUENTE_1` | 51,5 | 1,5 | 4 | 0,5 | 2 | Sólido dinámico tras activar placa |
| `G6` | 55,5 | 0 | 9 | 2 | 2 | Dominio, estrella opcional y meta |
| `U5` | 57 | 3,5 | 1,5 | 0,5 | 4 | Primer apoyo opcional |
| `U6` | 59 | 5 | 2 | 0,5 | 5,5 | Apoyo de estrella opcional |

`PUENTE_1` nace inactivo y sin collider. Al activarse se vuelve visible y sólido en un solo estado enclavado. No existe fase de cierre en GB02.

## 3. Triggers y elementos funcionales

| ID | x | y | w | h | Tipo | Regla |
|---|---:|---:|---:|---:|---|---|
| `R3` | 34,5 | 2 | 2 | 0,5 | checkpoint | Reemplaza la antigua meta final |
| `TUTORIAL_ENEMIGO` | 37,5 | 2 | 1 | 1,5 | texto | Se dispara una vez; no pausa la física |
| `ENEMY_PATROL_01` | 39 | 2 | 4,5 | 1 | carril | El enemigo nunca sale de este intervalo |
| `ESCALERA_E1_ART` | 42,5 | 1,5 | 1 | 3,5 | arte sin sólido | Tamaño contractual vertical |
| `ESCALERA_E1_GRIP` | 42 | 2 | 2 | 3 | trigger | Sobresale 0,5 a cada lado; centra suavemente |
| `PASO_SCAR_1` | 45,5 | 2 | 0,5 | 1 | filtro de actor | Scar atraviesa; Eren queda bloqueado incluso agachado |
| `PLACA_SCAR_2` | 50 | 2 | 1,5 | 0,5 | placa enclavada | Despliega `PUENTE_1` |
| `AGUA_2` | 51,5 | -2 | 4 | 3,5 | peligro | Superficie visible en `y=1,5` |
| `ESTRELLA_2` | 59,5 | 5,5 | 1 | 1 | coleccionable | Solo Eren; opcional |
| `PINCHOS_2` | 60,5 | 2 | 1,5 | 0,5 | peligro | Un corazón y retorno a `R3` o apoyo seguro posterior |
| `META_GB02` | 62,5 | 2 | 2 | 0,5 | meta dual | Presencia simultánea de Eren y Scar |

## 4. Rutas autorizadas

### Eren

`R3 → G4 → combate → ESCALERA_E1 → U4 → TUNEL_TECHO_1 → descenso a G5 → esperar puente → PUENTE_1 → G6 → META_GB02`.

En `G6` puede desviarse por `U5 → U6 → ESTRELLA_2` y volver al suelo antes de los pinchos.

### Scar

`R3 → G4 → PASO_SCAR_1 → corredor bajo de G5 → PLACA_SCAR_2 → salida visible → PUENTE_1 → G6 → META_GB02`.

Scar no usa la escalera en esta primera integración. La entrada y la salida del pasadizo deben ser visibles o quedar enlazadas por cámara; si se usa una breve ocultación dentro del túnel, nunca reaparece delante de Eren ni atraviesa un sólido.

## 5. Escalera de Eren

- arriba dentro de `ESCALERA_E1_GRIP`: `escalera_agarre`;
- centrado horizontal suave, máximo `2 módulos/s`, sin teletransporte;
- velocidad vertical de trepa inicial: `2,5 módulos/s`;
- gravedad normal desactivada solo mientras está agarrado;
- arriba/abajo: trepa; izquierda/derecha o salto: se suelta;
- al llegar a `y=5`, reproduce salida superior y coloca los pies sobre `U4`;
- nunca cambia el tamaño de Eren ni el collider de `1 × 1,5` de trepa.

## 6. Puente

Estados:

1. `OCULTO_NO_SOLIDO`;
2. `DESPLEGANDO` durante `0,6 s`, todavía no transitable;
3. `ABIERTO_SOLIDO_ENCLAVADO`.

La transición a sólido ocurre únicamente al terminar la animación. Antes de activarlo se comprueba que Eren y Scar no estén dentro del rectángulo futuro. Si alguno invade la zona, la animación espera y registra `puente_despliegue_bloqueado_seguro`; no empuja ni teletransporta.

## 7. Checkpoints y fallos

- `R3` queda activo al entrar en la ampliación.
- Tras cruzar el puente se activa `R4` en `x=56,5`, sin asset nuevo: reutiliza el portal apagado/encendido.
- Agua, pinchos o derrota de Eren consumen un corazón y recuperan en el último checkpoint.
- Scar utiliza el último apoyo seguro cercano; nunca consume corazones.
- Reiniciar el intento restaura enemigo, placa, puente, estrella y meta.

## 8. Telemetría mínima

- `enemigo_aviso`, `eren_ataque_inicio`, `eren_ataque_activo`, `enemigo_impacto`, `enemigo_ahuyentado`, `eren_daño_enemigo`;
- `escalera_agarre`, `escalera_salida`, `escalera_soltar`;
- `scar_paso_exclusivo_inicio/fin`, `placa_scar_2_activada`, `puente_1_desplegando/abierto`;
- `estrella_2`, `anclaje R3/R4`, `meta_gb02_reunion`.

