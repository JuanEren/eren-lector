# Contrato de enemigo · Patrulla terrestre M1 R01

ID de familia: `ENEMIGO_TERRESTRE_PATRULLA_M1_R01`  
Concepto recomendado: `ARAÑA_RUINA_R01`  
Estado del arte: `MISSING_FUNCTIONAL_ASSET`  
Estado de integración: `DESIGN_ONLY` · `NO_INTEGRAR_CANDIDATOS_SIN_QA`

## 1. Intención

Primer adversario legible, lento y no gráfico. Enseña a esperar el aviso y pulsar Acción a distancia correcta. Scar alerta del peligro, pero no combate en esta versión.

## 2. Cajas funcionales

Todas las medidas son independientes del dibujo.

| Caja | Tamaño | Posición relativa al pivote plantar | Uso |
|---|---:|---|---|
| `body` | 1 × 1 | centro inferior | Movimiento y apoyo |
| `hurtbox` | 1 × 1 | coincide con `body` | Recibe golpe de Eren |
| `attackHitbox` | 1 × 0,5 | un módulo delante, base a +0,5 | Daña a Eren solo en fase activa |
| `awareness` | 3 × 1,5 | centrada y orientada | Activa aviso; no daña |
| `patrolLane` | 4,5 × 1 | mundo `x=39–43,5` | Límite duro de patrulla |

El enemigo no posee collider lateral sólido contra Eren o Scar: se evita empuje, bloqueo de túnel y aplastamiento. Solo colisiona con suelo/paredes para su propia navegación.

## 3. Hitbox de Eren

El ataque reutiliza la secuencia `Acción/golpe` de cuatro fotogramas.

| Fase | Duración inicial | Hitbox |
|---|---:|---|
| preparación | 0,12 s | apagada |
| activa | 0,08 s | 1 × 1 módulo, adyacente delante de Eren, base +0,5 |
| recuperación | 0,18 s | apagada |
| bloqueo mínimo entre ataques | hasta completar 0,45 s | no puede reiniciarse |

La hitbox se refleja con `facing`; nunca se escala. Cada activación conserva un `attackId` y un mismo enemigo solo puede recibir un impacto por `attackId`.

No se permite:

- golpear a través de un sólido;
- hacer daño antes de la fase activa;
- mantener la hitbox durante caminar/correr;
- aplicar dos impactos con un único fotograma activo;
- convertir Acción en un botón nuevo o cambiar el botón de Scar.

## 4. Máquina de estados del enemigo

| Estado | Duración / condición | Salida |
|---|---|---|
| `IDLE` | 0,4–0,8 s en extremo | `PATROL` |
| `PATROL` | velocidad 1,5 módulos/s | `ALERT` si Eren entra en awareness |
| `ALERT` | 0,45 s, animación/sonido inequívocos | `ATTACK` si sigue en rango; si no, `PATROL` |
| `ATTACK` | activa hitbox durante 0,20 s | `RECOVER` |
| `RECOVER` | 0,55 s, sin daño | `PATROL` o `ALERT` |
| `HIT` | 0,25 s, sin atacar | `PATROL` si queda 1 punto; `FLEE` si 0 |
| `FLEE` | 0,45 s | desactiva cajas y desaparece fuera de cámara/entre partículas discretas |

Puntos de resistencia: `2`.  
Daño del golpe de Eren: `1`.  
Daño del ataque enemigo: `1 corazón`.  
Invulnerabilidad de Eren tras impacto: `1,25 s`.  
Retroceso visual/físico máximo: `1 módulo`, sin atravesar sólidos ni caer automáticamente al vacío.  
Pausa de impacto: `0,06 s`, solo audiovisual; la simulación no acumula pasos.

## 5. Reglas de justicia

- La animación `ALERT` y el icono `!` aparecen antes de toda hitbox enemiga.
- El ataque se cancela si una pared separa al enemigo de Eren.
- El enemigo gira en los extremos sin rebasar el carril.
- Al quedar a menos de `0,5` módulos de un borde no autorizado, gira; nunca cae persiguiendo.
- Durante `HIT` y `FLEE` su hitbox de ataque está apagada.
- No daña por contacto pasivo con `body`.
- Eren puede retirarse al área segura de entrada en todo momento.
- Scar se detiene a `2` módulos del carril, muestra `!` y maúlla una vez; después espera. No recibe daño ni consume corazones.
- No hay enemigo encima de agua, pinchos, escalera, puerta o placa en el tutorial.

## 6. Arte requerido

Lienzo recomendado: `150 × 100 px = 1,5 × 1 módulo`, transparente, pivote común `(75,100)`. La caja visible puede ocupar menos, pero todos los fotogramas comparten lienzo, escala, pivote y línea de suelo.

| Clip | Fotogramas mínimos | Bucle |
|---|---:|---|
| reposo | 2 | sí |
| caminar | 4 | sí |
| aviso | 2 | no |
| ataque | 4 | no |
| impacto | 2 | no |
| ahuyentado | 3 | no |

Orientación maestra a la derecha; la izquierda se obtiene por reflejo controlado. El dibujo no puede contener `!`, polvo, impacto ni sombra horneados: son VFX separados.

## 7. Depuración obligatoria

- `body`: cian;
- `hurtbox`: amarillo;
- `attackHitbox`: rojo solo mientras está activa;
- `awareness`: blanco discontinuo;
- texto: estado, HP, `attackId`, dirección y tiempo restante.

## 8. Pruebas de aceptación

1. Diez ataques fuera de distancia: `0` impactos.
2. Diez ataques dentro de distancia: exactamente `1` impacto por pulsación.
3. Ataque con pared entre ambos: `0` impactos.
4. Enemigo avisa y Eren retrocede: la hitbox se cancela o no alcanza.
5. Eren recibe daño: pierde exactamente un corazón y no encadena daño durante `1,25 s`.
6. Dos golpes válidos: entra en `FLEE`, desactiva cajas y no vuelve hasta reiniciar/checkpoint según contrato.
7. Veinte patrullas completas: `0` salidas del carril y `0` caídas.
8. Scar: `20/20` esperas seguras, sin corazones, sin teletransporte y sin bloquear a Eren.
9. Modo depuración muestra hitbox únicamente durante `0,08 s` del golpe de Eren y `0,20 s` del enemigo.
10. Reinicio de intento restaura HP, posición y estado inicial.

