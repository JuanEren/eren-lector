# Matriz de mecánicas, beats y QA · GB02 R01

## 1. Secuencia de juego

| Beat | Intervalo x | Enseña | Presión | Salida demostrable |
|---|---:|---|---|---|
| 11 · transición | 34,5–37,5 | `R3`, continuidad del graybox | ninguna | checkpoint activado |
| 12 · observar | 37,5–39 | aviso de Scar y patrulla | baja | jugador reconoce carril y `!` |
| 13 · combatir | 39–43,5 | alcance, aviso, Acción y recuperación | media | enemigo ahuyentado con 2 golpes |
| 14 · separar | 42,5–51,5 | escalera de Eren + paso exclusivo de Scar | baja | ambos llegan a extremos visibles |
| 15 · cooperar | 50–55,5 | orden de Scar, placa y puente enclavado | media | puente abierto sin bloqueo |
| 16 · dominar | 55,5–62 | estrella opcional + pinchos conocidos | media | ruta baja completa o estrella recogida |
| 17 · reunir | 62,5–64,5 | meta dual estricta | baja | ambos presentes simultáneamente |

## 2. Mensajes educativos propuestos

- Beat 12: `Scar ha visto un peligro. Espera al aviso de la criatura.`
- Beat 13: `Pulsa ACCIÓN cuando estés cerca. Tras golpear, vuelve a separarte.`
- Beat 14: `Eren sube por la escalera. Scar puede entrar por el hueco de la pata.`
- Beat 15: `Pulsa SCAR para que active la placa y despliegue el puente.`
- Beat 16: `La estrella es opcional. Puedes seguir por abajo.`
- Beat 17: `Reúne a Eren y Scar en la salida.`

Los mensajes aparecen una vez por intento, se cierran al iniciar la acción correcta y no ocultan al enemigo, bordes, escalera, placa o puente.

## 3. Matriz de dependencias

| Sistema | Depende de | No puede modificar |
|---|---|---|
| combate | Acción Eren + clip golpe + corazones | botón Scar, salto, collider base |
| escalera | controles arriba/abajo + clips Eren | velocidad horizontal fuera de escalera |
| paso Scar | navegación propia + cuarto botón | collider agachado de Eren |
| puente | placa Scar enclavada + sólido dinámico | agua, geometría heredada, cámara |
| ruta estrella | salto ya validado | meta o progreso obligatorio |
| meta GB02 | zona dual + Scar reunida | colección de estrella opcional |

## 4. Orden de implementación

### Fase A · Solo geometría gris

- importar G4, U4, G5, techo de túnel, agua, puente inactivo, G6, U5 y U6;
- dibujar rutas y triggers en depuración;
- recorrer con Eren y Scar sin enemigo ni arte nuevo.

Puerta A: cero penetraciones, cero bloqueos y veinte rutas de Scar.

### Fase B · Escalera y paso Scar

- integrar escalera de Eren;
- integrar filtro visible del paso exclusivo;
- validar entrada, salida, vuelta atrás y recuperación.

Puerta B: Eren no cruza el filtro agachado; Scar no aparece dentro de un sólido.

### Fase C · Puente

- placa enclavada;
- animación de despliegue y activación diferida del collider;
- checkpoint R4 tras el agua.

Puerta C: no existe cierre ni bloqueo irreversible; ambos cruzan veinte veces.

### Fase D · Enemigo gris

- cajas funcionales antes del sprite;
- máquina de estados, daño e invulnerabilidad;
- telemetría y depuración.

Puerta D: las diez pruebas del contrato del enemigo pasan con primitivas.

### Fase E · Arte candidato

- integrar solamente assets `REUSE_OK` o `CANDIDATE_QA_PASS`;
- no tocar cajas funcionales para adaptarlas al PNG;
- repetir pruebas A–D y playtest Android.

## 5. Casos críticos

| Caso | Resultado exigido |
|---|---|
| Eren ataca mirando al lado contrario | hitbox aparece solo detrás de la nueva orientación, no en ambos lados |
| Eren pulsa Acción repetidamente | no salta recuperación ni duplica impacto |
| Eren entra agachado al paso Scar | filtro visible lo detiene sin penetración |
| Scar recibe orden lejos de la entrada | acude físicamente; no se teletransporta |
| Eren llega al agua antes de la placa | cae/recibe daño; nunca pisa un puente invisible |
| Scar activa placa con Eren en la zona futura | el puente espera; no lo empuja |
| Eren muere tras abrir puente | recupera en checkpoint y el estado sigue el contrato de reinicio del intento |
| Scar queda al otro lado | sigue ruta visible por puente o espera; reunión fuera de cámara es último recurso |
| Eren obtiene estrella y Scar no está en meta | nivel no termina |
| Ambos llegan sin estrella | nivel termina: estrella es opcional |

## 6. Métricas del playtest

- tiempo hasta entender el primer ataque;
- golpes fallidos antes del primer impacto;
- daños recibidos por enemigo;
- porcentaje que entiende la escalera sin ayuda adicional;
- órdenes a Scar antes de activar la placa;
- bloqueos/recuperaciones de Scar;
- caídas al agua antes/después de desplegar puente;
- porcentaje que intenta la estrella opcional;
- tiempo de espera en la meta por el compañero.

Objetivos iniciales:

- `≥80 %` ahuyenta al enemigo sin perder más de un corazón;
- `≥80 %` activa el puente con una o dos órdenes a Scar;
- `20/20` recorridos automáticos de Scar sin muerte, penetración o teletransporte visible;
- `0` daños a través de paredes;
- `0` bloqueos irreversibles;
- `0` cambios en física heredada de GB01.

