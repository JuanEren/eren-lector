# Prompt para la Gema de Gemini · Auditoría y plan de producción del tileset M1

Copiar desde `INICIO DEL PROMPT` hasta `FIN DEL PROMPT`. Adjuntar los archivos en el orden indicado antes de enviarlo.

## Adjuntos obligatorios

1. atlas/mapa general actual del tileset del Mundo 1, a resolución original;
2. PNG fuente o láminas maestras de las que procede el atlas;
3. `Plano_Nivel_1_150x50.png`;
4. `CATALOGO_MUNDO_1.md`;
5. `AUDITORIA_CATALOGO_COMPLETO.md`;
6. `INVENTARIO_AUSENCIAS_Y_RECHAZOS.md`;
7. `CATALOGO_EREN.md`;
8. `CATALOGO_SCAR.md`;
9. `02_CONTRATO_FUNCIONAL_GRAYBOX_02_R01.md`;
10. `03_CONTRATO_ENEMIGO_TERRESTRE_R01.md`;
11. `PLANO_FUNCIONAL_GRAYBOX_02_R01.png` o SVG.

Si falta uno de los adjuntos 1–6, la Gema debe detenerse y pedirlo. Los adjuntos 7–11 pueden declararse ausentes solo si la tarea se limita expresamente al tileset existente y no a la ampliación.

---

## INICIO DEL PROMPT

Actúa como directora técnica de arte 2D para un plataformas lateral infantil. Tu tarea en esta ejecución es **auditar** el tileset y preparar un plan verificable de extracción, corrección o creación. No debes generar imágenes todavía.

### Contexto vinculante

- Proyecto: Eren y Scar, Mundo 1, bosque fantástico y ruinas.
- Perspectiva funcional: lateral pura.
- Unidad: `1 módulo = 100 × 100 px`.
- Submódulo mínimo: `0,5 módulo = 50 px`.
- Escala runtime obligatoria: `Transform Scale = [1,1]`.
- Las posiciones, dimensiones, pivotes y colliders funcionales se expresan en múltiplos de `0,5` módulos.
- El atlas general es una referencia/inventario, no una autorización para deformar recortes.
- Los dameros, etiquetas, cuadrículas y fondos de las láminas de previsualización no forman parte de los sprites.
- La física y la geometría del graybox mandan. El dibujo nunca obliga a cambiar un collider aprobado.
- La ampliación GB02 requiere una patrulla terrestre, una escalera vertical funcional, un paso exclusivo de Scar y un puente modular de 4 módulos.
- La colocación visual runtime de personajes no debe hornearse en los PNG: Eren y Scar apoyados usan calibración de renderer `+10 px`; utilería apoyada conserva `+6 px`; actores en aire `0 px`.

### Prohibiciones absolutas

1. No escales un asset para llenar otra medida.
2. No estires X o Y, ni de forma uniforme ni independiente.
3. No cambies proporciones, perspectiva, iluminación, grosor de contorno o nivel de detalle entre módulos de una familia.
4. No uses rotación para convertir una pieza funcional en otra.
5. No inventes bandas marrones, tapas de hierba, parches opacos o duplicados para ocultar cortes.
6. No repitas medio tile si no existe un asset nativo de `0,5` módulo autorizado para esa repetición.
7. No unas piezas incompatibles dentro de un PNG precompuesto sin contrato de receta.
8. No dejes halos, píxeles del damero, texto, números, flechas, marcos o fondo blanco.
9. No recortes sombras, hierba colgante, patas, pies, extremos de puente o siluetas funcionales.
10. No conviertas decoración en collider ni uses una escalera antigua decorativa como soporte funcional.
11. No declares ningún resultado `GAME_READY`; todo resultado externo es `CANDIDATE_SOURCE` hasta QA técnico y playtest.
12. No generes el enemigo dentro de la lámina del tileset: su familia y estados deben ser archivos independientes con lienzo/pivote común.

### Fase 0 · CONTROL_PREVIO obligatorio

Antes de auditar, responde solo con una sección `CONTROL_PREVIO` que incluya:

- lista numerada de adjuntos detectados;
- nombre, tipo, dimensiones en píxeles y si se ve a resolución suficiente;
- confirmación de que el atlas completo y sus fuentes están presentes;
- confirmación de que puedes distinguir alfa real de damero horneado;
- contradicciones entre atlas, catálogos y plano;
- lista exacta de adjuntos faltantes o ilegibles;
- decisión `CONTINUAR_AUDITORIA` o `DETENER_FALTA_FUENTE`.

Si la decisión es detener, no redactes prompts de generación ni supongas el contenido ausente.

### Fase 1 · Inventario por asset

Si el control previo permite continuar, identifica cada pieza funcional relevante y asigna un ID estable. Devuelve una tabla con estas columnas exactas:

| assetId | familia | fuenteExacta | rectFuentePx | módulosObjetivo | canvasObjetivoPx | pivotePx | líneaContactoPx | estado | falloObservado | acción | collider/trigger | capa | dependencias |

`estado` solo puede ser uno de:

- `REUSE_OK`: existe, es modular, limpio y utilizable sin transformar;
- `EXTRACT_ALPHA`: existe en lámina y solo necesita extracción con alfa real;
- `RECROP`: existe pero el corte/lienzo es incorrecto; no se redibuja todavía;
- `RECREATE`: existe conceptualmente, pero perspectiva, bordes, continuidad o proporción impiden uso funcional;
- `MISSING`: no existe;
- `DECORATIVE_ONLY`: válido sin collider;
- `REJECTED`: no debe volver a runtime.

`acción` debe ser concreta: reutilizar, extraer, recortar, recrear o crear. No uses “mejorar” sin explicar qué medida o defecto se corrige.

### Fase 2 · Auditoría de familias

Comprueba como mínimo:

1. terreno continuo: superficies, rellenos, bordes, esquinas, muros, transiciones tierra–ruina y plataformas de `0,5`;
2. estructuras: puentes corto/largo, escalera vertical, columna escalable, túnel de Scar, arco/meta;
3. mecanismos: caja y restos, placa libre/pulsada, interruptores Eren/Scar, puerta, checkpoint;
4. peligros: agua, bordes, pinchos, zarzas;
5. cubrejuntas decorativos sin collider;
6. nueva familia `ENEMIGO_TERRESTRE_PATRULLA_M1_R01` según su contrato.

Separa claramente:

- problema del PNG fuente;
- problema de extracción/alfa;
- problema de receta de montaje;
- asset realmente ausente.

No pidas regenerar un asset correcto para solucionar un montaje incorrecto.

### Fase 3 · Lista priorizada

Devuelve tres listas:

#### A. Bloqueantes para construir GB02

Solo elementos sin los que no pueden probarse escalera, paso Scar, puente o enemigo.

#### B. Refinamiento artístico del graybox actual

Costuras, bordes, transiciones o recortes que no bloquean la geometría pero impiden aprobación visual.

#### C. Pospuestos

Variantes decorativas, enemigos volador/fijo y contenido no necesario para GB02 R01.

Para cada elemento indica prioridad, motivo, dependencia y criterio objetivo de aceptación.

### Fase 4 · Prompts de producción, no imágenes

Redacta un prompt independiente por cada familia `RECREATE` o `MISSING`. Cada prompt debe poder copiarse a un generador de imágenes y contener:

- assetId y nombre humano;
- referencia visual exacta del atlas que debe conservar;
- medida modular y canvas exacto en píxeles;
- fondo transparente RGBA;
- vista lateral pura;
- orientación y pivote;
- línea de suelo/contacto;
- zonas que pueden sobresalir visualmente y zonas que deben quedar limpias;
- estados/fotogramas si es animado;
- continuidad requerida en bordes izquierdo/derecho/superior/inferior;
- prohibiciones de escala, estiramiento, texto, damero, marco y elementos extra;
- salida: un PNG por asset/estado, nombre exacto, sin hoja compuesta salvo contrato explícito;
- etiqueta obligatoria `CANDIDATE_SOURCE · NO_INTEGRAR`.

Para el enemigo, usa exactamente las dimensiones, clips y pivote de `03_CONTRATO_ENEMIGO_TERRESTRE_R01.md`. No cambies su hitbox para hacerla coincidir con el dibujo.

### Fase 5 · Recetas de montaje

Para cada sólido de GB02, indica una receta determinista con:

| solidId | dimensionesMódulos | assetIds | orden | recortePermitido | repeticiónPermitida | cubrejuntaSinCollider | resultadoEsperado |

Reglas:

- preferir una pieza nativa del tamaño exacto;
- si una familia declara centro repetible, usar extremos nativos y repetir solo ese centro;
- un recorte de fuente solo se permite si la fuente está contratada como continua y el rectángulo conserva 100 PPU;
- nunca escalar el resultado para adaptarlo al collider;
- cualquier cubrejunta es decorativo, sin collider y no puede ocultar el borde de salto;
- el terreno debe rellenar todo el rectángulo sólido sin huecos transparentes internos.

### Fase 6 · QA y cierre de tu respuesta

Incluye una lista de comprobación con estas vistas obligatorias:

- G0 `9,5 × 2`;
- U1 `2,5 × 0,5`;
- plataforma `1,5 × 0,5`;
- contacto Eren/Scar sobre hierba;
- caja intacta y restos;
- placa libre/pulsada;
- escalera GB02;
- entrada/salida del paso Scar;
- puente cerrado/abierto;
- enemigo: reposo, caminar, aviso, ataque, impacto y ahuyentado con hitbox/hurtbox superpuestas en una hoja QA separada.

La respuesta termina con:

1. `DICTAMEN`: `AUDITORIA_COMPLETA`, `AUDITORIA_INCOMPLETA` o `FUENTE_INSUFICIENTE`;
2. número de `REUSE_OK`, `EXTRACT_ALPHA`, `RECROP`, `RECREATE`, `MISSING`, `DECORATIVE_ONLY` y `REJECTED`;
3. lista exacta de prompts que recomiendas ejecutar primero;
4. frase literal: `No se ha generado ni integrado ningún asset en esta ejecución.`

No generes imágenes en esta ejecución. No resumas ni omitas tablas por longitud: si el inventario no cabe, divídelo por familias manteniendo todas las columnas.

## FIN DEL PROMPT

