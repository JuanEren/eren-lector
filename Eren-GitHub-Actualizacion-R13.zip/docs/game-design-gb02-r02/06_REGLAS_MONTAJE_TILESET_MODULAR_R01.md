# Reglas obligatorias de montaje modular · Mundo 1 R01

Estas reglas son vinculantes para Gemini, Arte, Game Design y runtime. Un resultado que incumpla una sola regla funcional vuelve a `CANDIDATE_SOURCE` o `REJECTED`; nunca se corrige moviendo colliders aprobados.

## 1. Retícula y escala

- `1 módulo = 100 px`.
- `0,5 módulo = 50 px`.
- `PPU=100`.
- `transformScale=[1,1]` en todos los elementos funcionales.
- No existe “ajustar al hueco”: el hueco elige un asset/receta de su medida exacta.
- Están prohibidos el escalado libre, el estiramiento X/Y, la corrección de proporción y la rotación de piezas funcionales.
- El reflejo horizontal solo se permite cuando el contrato lo autoriza, conserva el pivote y no cambia iluminación direccional incompatible.

## 2. PNG fuente

- RGBA con transparencia real cuando el asset no deba ser opaco.
- Sin damero horneado, fondo blanco, etiquetas, retícula, marco o leyenda.
- Un asset o estado por archivo salvo hoja de animación contratada.
- Nombre estable: `familia-elemento-medida-estado-rNN.png`.
- No recortar salientes visuales previstos: hierba, raíces, patas, pies, cola, extremos de puente.
- Los márgenes transparentes se documentan; no se compensan desplazando cada instancia a ojo.
- Todos los estados de una familia comparten lienzo, pivote, escala y línea de contacto.

## 3. Contacto y pivotes

- Los colliders y triggers se definen por contrato, no por `visibleBounds` improvisado.
- El pivote funcional se registra en píxeles y módulos.
- Personajes: el runtime compensa transparencia inferior por fotograma y aplica el perfil visual aprobado; esa compensación no se hornea en los PNG.
- Referencia candidata R10: Eren/Scar apoyados `+10 px`; actores en aire `0 px`; utilería apoyada `+6 px`.
- La hierba puede solapar visualmente unos píxeles, pero el terreno opaco sigue rellenando el sólido completo.
- Caja, restos, placa, palanca y puente usan su propia línea de contacto común; no se hunden con el valor de los actores.

## 4. Terreno

- Cada collider rectangular recibe una receta determinista.
- Prioridad 1: pieza nativa de tamaño exacto.
- Prioridad 2: extremos nativos + centro declarado repetible.
- Prioridad 3: recorte 1:1 de una fuente continua contratada a 100 PPU.
- No se precompone una captura estirada del collider.
- No se repite medio tile salvo que el archivo sea nativo de `0,5` módulo.
- No se añaden bandas de tierra, segunda tapa de hierba ni relleno superpuesto.
- Los bordes externos, esquinas y transiciones deben tener piezas propias; no se simulan tapando el corte con una copia central.
- El interior de un sólido debe quedar cubierto por píxel opaco válido; cero huecos transparentes, halos o líneas del fondo.

## 5. Cubrejuntas

- Solo se aceptan raíces, musgo, lianas, grietas, piedras o hierba contratados como decoración.
- `collider=false`, `trigger=false`.
- No cambian la silueta transitable ni esconden el punto exacto de despegue/aterrizaje.
- No pueden tapar estrellas, mecanismos, enemigos, pinchos, agua o entrada/salida de rutas de Scar.
- Si una costura requiere un cubrejunta en todas las instancias, la receta de terreno está mal y debe corregirse.

## 6. Plataformas, puentes y escaleras

- Las plataformas conservan grosor modular real; no son franjas de hierba flotantes sin cuerpo previsto.
- Una plataforma móvil reutiliza una plataforma válida; el movimiento pertenece a código/metadatos, no al PNG.
- El puente de GB02 mide exactamente `4 × 0,5` módulos abierto. Puede construirse con extremos y centro repetible solo si los tres assets se generan a 100 PPU y los empalmes son continuos.
- El collider del puente se activa después de la animación, nunca durante una imagen todavía abierta.
- La escalera vertical de Eren mide `1 × 3,5` módulos. El trigger puede sobresalir `0,5` a cada lado; la escalera visual no se ensancha para llenar el trigger.
- Las cinco escaleras antiguas rechazadas son `DECORATIVE_ONLY`; no reciben collider ni trigger de trepa.

## 7. Personajes y enemigo

- Eren: lienzo `300×200`, pivote `(150,200)`; no redimensionar por pose.
- Scar: todos los estados comparten lienzo/pivote y línea plantar; no cortar cabeza, cola o patas.
- Enemigo terrestre R01: lienzo `150×100`, pivote `(75,100)`, visual de `1,5×1`; `body/hurtbox=1×1` independientes.
- Hitboxes y hurtboxes no se hornean en el sprite.
- Orientación contraria por reflejo controlado; no se crea una escala distinta.
- VFX `!`, `?`, polvo, impacto y sombra son capas independientes.

## 8. Importación y trazabilidad

Cada importación debe registrar:

- `assetId`;
- archivo fuente y rectángulo de origen;
- SHA-256;
- canvas y dimensiones visibles;
- PPU;
- pivote;
- medida modular;
- collider/trigger asociado o `none`;
- capa y orden de dibujo;
- estado (`CANDIDATE_SOURCE`, `CANDIDATE_QA_PASS`, `APPROVED_FUNCTIONAL`, `REJECTED`);
- receta de montaje consumidora.

Los archivos externos entran en una zona de importación separada. Nunca sobrescriben maestros aprobados hasta comparar hashes, vista alfa y montaje en retícula.

## 9. Puerta visual obligatoria

Antes de compilar se renderizan, con colliders visibles y sin ellos:

1. G0 `9,5×2`;
2. U1 `2,5×0,5`;
3. una plataforma `1,5×0,5`;
4. Eren y Scar en reposo, caminar y correr;
5. caja intacta/restos y placa libre/pulsada;
6. escalera vertical y salida superior;
7. paso exclusivo de Scar, entrada y salida;
8. puente de GB02 cerrado/desplegando/abierto;
9. enemigo con body, hurtbox y hitbox por estado.

Rechazo automático si aparece cualquiera de estos fallos:

- costura, halo, damero o fondo;
- cambio de escala entre piezas/estados;
- personaje o mecanismo flotando;
- personaje enterrado en más de la calibración aprobada;
- collider desplazado para seguir al dibujo;
- plataforma sin cuerpo o con grosor incoherente;
- asset decorativo usado como funcional;
- texto/etiqueta dentro de un PNG runtime;
- repetición no contratada o recorte fuera de 100 PPU.

## 10. Regla de promoción

Un asset solo pasa a `APPROVED_FUNCTIONAL` cuando supera:

1. inspección alfa y dimensiones;
2. retícula 50/100 px;
3. comparación con la estética del atlas;
4. montaje sin escala ni parches;
5. prueba con collider/trigger contractual;
6. regresión del graybox;
7. playtest en dispositivo cuando afecte contacto, lectura o interacción.

La aprobación visual de una lámina no equivale a aprobación funcional de sus recortes.

