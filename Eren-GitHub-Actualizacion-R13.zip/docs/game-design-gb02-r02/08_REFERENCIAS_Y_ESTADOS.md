# Referencias, autoridad y estado de los assets

## Fuentes vinculantes incluidas

- `REFERENCIA_Plano_Nivel_1_150x50.png`: macroplano aprobado; GB02 no altera el tramo heredado.
- `REFERENCIAS/REGLAS_CONTROLES_EREN_SCAR.md`: autoridad de botones y separación de capacidades.
- `REFERENCIAS/REGLAS_OBLIGATORIAS_FUENTE.md`: retícula, colisión, arte y persistencia.
- `REFERENCIAS/ESTADO_PRODUCCION.md`: estado operativo previo.
- `REFERENCIAS/CATALOGO_MUNDO_1.md`: familias disponibles y estados conocidos.
- `REFERENCIAS/AUDITORIA_CATALOGO_COMPLETO.md`: auditoría histórica del catálogo.
- `REFERENCIAS/INVENTARIO_AUSENCIAS_Y_RECHAZOS.md`: ausencias y rechazos que no pueden reintegrarse por accidente.
- `REFERENCIAS/CATALOGO_EREN.md` y `CATALOGO_SCAR.md`: secuencias existentes y pendientes.

## Decisiones de autoridad

1. El contrato funcional de este paquete gobierna geometría, triggers, hitboxes y rutas de GB02.
2. El atlas/tileset gobierna estética, pero nunca cambia medidas aprobadas.
3. Un asset catalogado no se considera integrable solo por existir.
4. Las cinco escaleras antiguas rechazadas siguen siendo decorativas; GB02 requiere una escalera funcional nueva o rehecha.
5. El lote archivado `ENEMIGOS_M1_CANDIDATE_WORK_R01` es una referencia candidata, no una autorización de integración. Debe compararse contra `03_CONTRATO_ENEMIGO_TERRESTRE_R01.md` y superar QA.
6. Ningún resultado de Gemini asciende por sí mismo de `CANDIDATE_SOURCE`.

## Estado de esta entrega

- diseño de recorrido: `DESIGN_APPROVED_FOR_GRAYBOX_BUILD`;
- arte nuevo: `NOT_GENERATED`;
- código GB02: `NOT_IMPLEMENTED`;
- enemigo: `DESIGN_ONLY`;
- refinamiento del tileset: `AUDIT_REQUIRED`;
- R10 de contacto: entrega separada; no forma parte de esta ampliación.

## Conflictos resueltos

- Los tres corazones pertenecen a Eren. Scar no recibe daño ni gasta corazones.
- Acción es el ataque de Eren; el botón contextual de Scar conserva sus órdenes.
- La estrella opcional la recoge Eren.
- La nueva ruta de Scar es visible y causal; no se introduce teletransporte como solución primaria.
- Los `36,5` módulos existentes permanecen congelados. El antiguo final pasa a checkpoint `R3` sin rediseñar el tramo.
