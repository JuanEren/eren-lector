# Handoff de implementación · GB02 R01

## Orden de trabajo

1. Importar `02_CONTRATO_FUNCIONAL_GRAYBOX_02_R01.md` como datos de geometría; no remodelar a ojo.
2. Mantener GB01 intacto y convertir su antigua meta en `R3`.
3. Construir primero G4–G6, U4–U6, túnel, agua y triggers con arte gris.
4. Implementar el enemigo con cajas de depuración visibles y sin PNG definitivo.
5. Implementar escalera, paso de Scar y puente por separado; probar cada uno antes de combinarlos.
6. Añadir telemetría y pruebas deterministas.
7. Integrar arte únicamente después de la auditoría y la puerta de montaje.

## Orden de integración recomendado

| Fase | Contenido | Puerta antes de continuar |
|---|---|---|
| A | geometría + checkpoints | recorrido completo sin arte |
| B | enemigo + ataque de Eren | 10/10 golpes válidos y 0 falsos |
| C | escalera de Eren | entrada/salida/soltar sin penetración |
| D | paso exclusivo de Scar | 20/20 rutas visibles y seguras |
| E | placa + puente enclavado | 20/20 aperturas sin encerrar actores |
| F | estrella + meta dual | recorrido opcional y reunión correctos |
| G | arte candidato | escala 1:1, pivotes y QA de montaje |

## Congelados

- física de salto, caída y borde de Eren;
- navegación y recuperación actuales de Scar fuera del nuevo tramo;
- UI y botones;
- terreno y geometría de GB01;
- perfil visual R10 de contacto cuando sea aprobado en dispositivo.

## Salida de telemetría

El log nuevo debe identificar un paquete `GB02-R01` independiente, mantener compatibilidad con los intentos GB01 y añadir los eventos del apartado 8 del contrato funcional. Ningún fallo de la ampliación se corrige alterando los valores congelados.
