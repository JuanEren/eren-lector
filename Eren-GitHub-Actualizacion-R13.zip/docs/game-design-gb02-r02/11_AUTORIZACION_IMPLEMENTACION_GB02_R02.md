# Autorización de implementación · GB02 R02

Fecha: 26/08/2026  
ID: `GAMEDESIGN-GB02-20260826-R02`  
Estado: `IMPLEMENTATION_AUTHORIZED` · `GAME_READY=false`

## Base autorizante

El playtest Android valida el contacto de pies y patas, la locomoción, el salto, la ruta de Scar, el puzle cooperativo, los peligros y la meta de GB01. El tileset necesita refinamiento artístico, pero esa deuda no bloquea la ampliación funcional.

R11 corrige de forma independiente el HUD de corazones. No cambia geometría ni mecánicas y puede integrarse antes o en paralelo a la primera fase de GB02.

## Fuente de verdad

Los documentos R01 incluidos en este paquete no se reinterpretan:

- `02_CONTRATO_FUNCIONAL_GRAYBOX_02_R01.md`: geometría, triggers, checkpoints y meta;
- `03_CONTRATO_ENEMIGO_TERRESTRE_R01.md`: estados, hitboxes, hurtboxes, daño y QA;
- `04_MATRIZ_MECANICAS_BEATS_Y_QA_R01.md`: secuencia de aprendizaje y aceptación;
- `06_REGLAS_MONTAJE_TILESET_MODULAR_R01.md`: 100 PPU, escala 1:1 y montaje sin deformación;
- `10_HANDOFF_IMPLEMENTACION.md`: orden técnico base.

## Secuencia obligatoria de implementación

### Fase 1 · Extensión y cierre nuevo

- ampliar el mundo a `64,5 × 12` módulos;
- congelar `x=0–36,5` sin alterar ningún sólido, collider o trigger existente;
- convertir la antigua meta en checkpoint `R3`;
- añadir G4, U4, G5, techo de túnel, puente provisional, G6, U5 y U6 con las medidas contractuales;
- mover la meta dual a `x=62,5–64,5`;
- extender límites de cámara sin cambiar su comportamiento validado en GB01.

Puerta: Eren y Scar atraviesan la ampliación con placeholders y la antigua meta ya no termina el nivel.

### Fase 2 · Primer enemigo y combate

- una sola araña de ruina provisional en el carril `x=39–43,5`;
- `2 HP`, body/hurtbox `1×1`, hitbox enemiga `1×0,5`, ataque de Eren `1×1`;
- daño solo por hitbox activa, nunca por contacto pasivo;
- Eren recibe invulnerabilidad temporal según contrato;
- Scar avisa, se mantiene fuera del combate y no pierde corazones.

Puerta: destruir/ahuyentar con dos golpes, recibir daño de ataque y retirarse son reproducibles; las hitboxes no atraviesan muros.

### Fase 3 · Separación Eren/Scar

- escalera utilizable solo por Eren;
- paso visible exclusivo para Scar bajo el techo de G5;
- reencuentro legible antes del puente;
- sin teletransporte silencioso ni cambio de tamaño de colliders.

Puerta: cada actor completa únicamente su ruta y ambos vuelven a reunirse.

### Fase 4 · Puente cooperativo enclavado

- placa de Scar en `x=50–51,5`;
- despliegue del puente de `4×0,5` módulos;
- el puente queda enclavado y nunca se cierra sobre un actor;
- tras desbloquearlo Scar reanuda su seguimiento.

Puerta: Eren no puede cruzar el agua antes de la activación y ambos pueden cruzar después sin bloqueo permanente.

### Fase 5 · Cierre y opcional

- estrella opcional de la ruta alta;
- pinchos finales;
- meta estricta con presencia simultánea de Eren y Scar;
- telemetría nueva sin perder compatibilidad con los intentos GB01.

Puerta: ruta principal completa, ruta opcional recuperable y meta dual reproducible.

## Política de arte durante el graybox

Se permiten rectángulos, siluetas y placeholders inequívocos. No se permite escalar, estirar, deformar, parchear o montar de forma destructiva los PNG del tileset para simular assets ausentes. El arte definitivo se integra solo cuando supere su auditoría técnica.

## Cierre de esta autorización

`codeImplemented=false` y `artIntegrated=false` en esta entrega. La siguiente build debe empezar por la Fase 1 y registrar cada puerta por separado; un fallo nuevo de GB02 nunca autoriza a modificar el tramo congelado de GB01.
