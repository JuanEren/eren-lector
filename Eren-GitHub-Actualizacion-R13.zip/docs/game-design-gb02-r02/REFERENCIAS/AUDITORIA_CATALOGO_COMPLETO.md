# Auditoría completa del catálogo guardado · Mundo 1

## Alcance y criterio

Esta auditoría revisa exclusivamente los assets ya guardados. No incluye las pruebas generadas después de iniciar la auditoría ni crea sustituciones.

Estados utilizados:

- **Aprobado visual:** diseño, estética y función representada son válidos.
- **Aprobado técnico:** archivo individual utilizable directamente, con alfa y geometría compatible.
- **Pendiente técnico:** diseño válido, pero debe separarse de la lámina y documentar caja, pivote, capa o fotogramas.
- **Decorativo:** puede variar perspectiva, pero no tendrá collider ni interacción obligatoria.
- **Rechazado funcional:** no puede utilizarse con colisión por perspectiva o geometría incorrecta.

## Resultado global

- Láminas maestras revisadas: **19 de 19**.
- Láminas funcionales: **5 de 5** revisadas.
- Láminas decorativas: **5 de 5** revisadas.
- Láminas animadas y de efectos: **9 de 9** revisadas.
- Todas las láminas mantienen la dirección artística aprobada.
- Ninguna lámina completa puede utilizarse directamente como atlas final: contiene varias piezas y/o fondo de presentación.
- La serie `terrain-v3` sí dispone de archivos individuales técnicamente regulares.
- La muestra de 15 piezas dispone de alfa individual, pero requiere normalización de metadatos.

## 1. Funcionales

| Archivo/familia | Perspectiva y lectura | Estado | Observaciones obligatorias |
|---|---|---|---|
| 01 Terreno y transiciones | Lateral coherente | Aprobado visual | Extraer piezas; usar `terrain-v3` como base regular |
| `terrain-v3` tierra | Lateral; 1×3 módulos por archivo | Aprobado técnico condicionado | Alfa real; falta registrar collider, pivote y línea caminable comunes |
| `terrain-v3` ruina | Lateral; 1×3 módulos por archivo | Aprobado técnico condicionado | Alfa real; falta registrar collider, pivote y línea caminable comunes |
| `terrain-v3` transición | Lateral; 1×3 módulos por archivo | Aprobado técnico condicionado | Alfa real; falta registrar collider, pivote y línea caminable comunes |
| `terrain-v2` | Estética compatible, lienzo 220×418 irregular | Rechazado funcional | Solo referencia o decoración sin colisión |
| 02 Estructuras de recorrido | Mayoritariamente lateral | Aprobado visual | Plataformas, puentes, columnas, tronco, túnel y meta deben separarse y recibir medidas en pasos de 0,5 |
| 03 Objetos y mecanismos | Mezcla frontal y profundidad controlada | Aprobado visual con excepciones | Caja y placa antiguas rechazadas; resto compatible tras normalización |
| 04 Agua y peligros | Superficies y peligros laterales claros | Aprobado visual | Charca cenital solo decorativa; agua profunda no es recorrido; pinchos y zarzas funcionales tras separar collider |
| 05 Lava modular | Superficie lateral clara | Aprobado visual | Piscina cenital, salpicaduras, calor y sombras son decorativos/VFX; canales y cascadas sí representan peligro funcional |

### Muestra individual de 15 piezas

| Nº | Asset | Clasificación definitiva |
|---:|---|---|
| 01 | Suelo 1×1 | Funcional; pendiente de metadatos comunes |
| 02 | Suelo 3×1 | Funcional; pendiente de metadatos comunes |
| 03 | Plataforma flotante | Funcional; normalizar caja y superficie caminable |
| 04 | Plataforma de piedra | Funcional; normalizar caja y superficie caminable |
| 05 | Columna de piedra | Funcional; normalizar ancho, altura y uniones |
| 06 | Tronco hueco | Funcional; normalizar hueco, techo y suelo |
| 07 | Túnel de Scar | Funcional; normalizar hueco exclusivo de Scar |
| 08 | Agua | Peligro funcional y capa visual; normalizar ancho/profundidad |
| 09 | Caja anterior | **Rechazada funcional; solo decorativa** |
| 10 | Placa anterior | **Rechazada funcional; solo decorativa** |
| 11 | Interruptor mural | Funcional; válido sobre muro lateral |
| 12 | Puerta de acertijo | Funcional; normalizar caja, pivote y área de interacción |
| 13 | Cofre | Funcional; perspectiva suficientemente lateral |
| 14 | Estrella | Funcional como coleccionable; definir caja de recogida |
| 15 | Pinchos | Funcional; perspectiva lateral y lectura clara |

## 2. Decorativos

| Lámina | Estado visual | Estado técnico | Clasificación |
|---|---|---|---|
| 01 Cubrejuntas y cortes | Aprobada | Pendiente de separar piezas | Decorativos sin colisión; pueden solapar terreno sin alterar la lectura |
| 02 Vegetación y naturaleza | Aprobada | Parte de la lámina tiene alfa, pero contiene fondo y varias piezas | Decorativos sin colisión; rana/caracol estáticos no bloquean |
| 03 Ruinas y utilería | Aprobada | Parte de la lámina tiene alfa, pero contiene fondo y varias piezas | Decorativos sin colisión; vallas, barriles y vasijas no pueden bloquear salvo que se creen versiones funcionales diferentes |
| 04 Paralaje y fondos | Aprobada | Pendiente de separar franjas | Fondo/paralaje; sin collider, sin interacción y con velocidad de cámara propia |
| 05 Primer plano y profundidad | Aprobada | Pendiente de separar franjas y recortes | Primer plano sin colisión y con zonas de exclusión sobre personajes y peligros |

### Comprobación de reglas decorativas

- La variedad de perspectiva es aceptable porque ninguna pieza decorativa tendrá collider.
- Las ruinas, barriles, vallas, ramas y rocas de estas láminas no podrán reutilizarse como obstáculos funcionales sin crear una variante frontal normalizada.
- Las franjas de primer plano y paralaje no pueden tapar estrellas, mecanismos, bordes de salto ni enemigos.
- Las charcas cenitales y piscinas de lava cenitales quedan expresamente clasificadas como decoración/VFX.

## 3. Animados y efectos

| Lámina | Estado visual | Validación técnica necesaria |
|---|---|---|
| 01 Vegetación animada | Aprobada | Separar cada fila; igualar lienzo, pivote y base en sus 4 fotogramas |
| 02 Agua y fuego animados | Aprobada | Agua: misma línea superior; cascada: mismo ancho; fuego: mismo punto de emisión; charca cenital sin colisión |
| 03 Mecanismos animados | Aprobada con excepciones | Rechazar secuencias de caja y placa antiguas; interruptor, Scar, cofre, puerta y portal deben mantener caja/pivote constante |
| 04 Fauna pequeña | Aprobada como ambiental | Sin colisión; separar secuencias y eliminar las bases vegetales repetidas si se desean sprites móviles independientes |
| 05 Aves y animales de fondo | Aprobada como ambiental | Sin colisión; uniformar lienzos por secuencia; pájaros, ardilla, conejo y peces son capas ambientales |
| 06 Efectos de juego | Aprobada visualmente | El fondo degradado forma parte de la lámina; extraer polvo, impacto, agua y recogida con alfa real |
| 07 Iluminación y sombras | Aprobada | Solo capas de mezcla; sin collider; sombras de contacto ancladas al pivote del receptor |
| 08 Lluvia y tormenta | Aprobada | Sin collider; separar intensidades, impactos, ondas, goteos y relámpagos; respetar reducción de destellos |
| 09 Lava animada | Aprobada | Superficie/cascada con caja fija; salpicaduras, burbujas, calor y sombra como VFX sin collider |

## 4. Assets rechazados o pendientes de sustitución futura

### Rechazados funcionales confirmados

1. Caja anterior de la muestra individual.
2. Placa de presión anterior de la muestra individual.
3. Todos los fotogramas animados derivados de esa caja anterior.
4. Todos los fotogramas animados derivados de esa placa anterior.
5. Serie `terrain-v2` como geometría funcional.

### No rechazados, pero aún no utilizables directamente

- Todas las piezas que solo existen dentro de una lámina maestra.
- Todas las animaciones sin fotogramas separados y lienzos normalizados.
- Cualquier asset sin ficha de tamaño modular, pivote, collider y capa.

## 5. Posibles ausencias a confirmar después de separar el catálogo

- Variantes funcionales frontales definitivas de caja y placa.
- Colliders y metadatos de todos los objetos interactivos.
- Enemigos funcionales y sus animaciones, que no forman parte de estas 19 láminas.
- Sprites de Eren y Scar, gestionados fuera de este catálogo de mundo.

No se recreará ninguna ausencia o rechazo hasta cerrar y aprobar esta auditoría.

## 6. Avance de normalización técnica

Se ha cerrado un primer lote de producción con **45 archivos existentes**: 32 módulos de terreno V3 y 13 estructuras, objetos y peligros procedentes de la muestra individual aprobada. Todos usan 100 px por módulo, paso mínimo de 0,5, transparencia RGBA y metadatos modulares. El resultado está documentado en `PRODUCCION/ESTADO_PRODUCCION.md` y `PRODUCCION/VALIDACION_FUNCIONALES.txt`.

Este avance no convierte automáticamente las piezas contenidas en las láminas maestras en assets listos: continúan pendientes de separación y validación individual.

## 7. Recuperación de las láminas funcionales

Las cinco láminas funcionales originales eran imágenes RGB con el damero de transparencia horneado. Se han conservado intactas y se han recuperado **61 piezas** mediante recorte, eliminación controlada del fondo claro, escalado proporcional y colocación en lienzos de 50 px. Las 61 han superado la comprobación de tamaño modular, RGBA y transparencia real.

La piscina de lava con perspectiva cenital queda clasificada como decoración sin collider. Las 60 piezas restantes son funcionales o estados visuales de elementos funcionales.

## 8. Recuperación de las láminas decorativas

Se han separado y validado **150 piezas decorativas**: 60 cubrejuntas, 26 piezas de vegetación, 28 ruinas/utilería, 11 capas de paralaje y 25 elementos de primer plano. Todas carecen de collider e interacción obligatoria.

La revisión visual rechazó 11 segmentaciones automáticas que mezclaban piezas solapadas o incluían residuos. Esos archivos permanecen expresamente fuera del manifiesto aprobado. En los elementos de primer plano se recomienda mezcla multiplicar para conservar profundidad sin halos claros sobre el escenario.

## 9. Recuperación de animaciones y efectos

Se han preparado **66 secuencias con 258 fotogramas**. Cada secuencia mantiene lienzo, pivote y punto de anclaje comunes. Se revisaron y corrigieron franjas de fotogramas vecinos, filas solapadas, un fotograma vacío de puerta y la separación de lluvia, goteos, iluminación e impactos.

Las animaciones de la caja y placa antiguas quedan excluidas. Los mecanismos animados conservan una geometría funcional externa e invariable; VFX, fauna, clima e iluminación no incorporan collider.

## 10. Cierre de terreno y ausencias

Se recuperaron 31 piezas adicionales de la lámina de terreno: 26 quedan aprobadas como funcionales y cinco escaleras únicamente como decoración, ya que sus peldaños no siguen incrementos exactos de 0,5.

Con ello, las sustituciones gráficas funcionales obligatorias del mundo quedan reducidas a caja rompible, placa de presión y escalera modular. También faltan enemigos funcionales. Eren, Scar, interfaz educativa y audio se auditarán como catálogos independientes.
