# Catálogo funcional de Eren

## Norma bloqueada

- Lienzo común del arte: **300×200 px = 3×2 módulos**.
- Pivote común: **(150, 200)**, centro inferior.
- Escala corporal constante; está prohibido redimensionar una pose de forma independiente.
- Orientación maestra hacia la derecha; la izquierda se obtiene mediante reflejo horizontal.
- Collider independiente del dibujo:
  - de pie: **1×1,5 módulos**;
  - agachado/arrastre: **1,5×1 módulos**;
  - aéreo: **1×1,5 módulos**.
- El cambio de postura modifica collider y animación, nunca la escala del personaje.

## Secuencias disponibles

| Secuencia | Fotogramas | Uso |
|---|---:|---|
| Reposo | 1 | Espera y lectura |
| Caminar | 2 | Desplazamiento normal |
| Correr | 2 | Desplazamiento rápido |
| Agacharse | 1 | Entrada o permanencia bajo obstáculo |
| Arrastrarse | 2 | Movimiento bajo |
| Salto vertical | 5 | Salto sin dirección horizontal |
| Salto hacia delante | 5 | Salto desde caminar o dirección normal |
| Salto corriendo | 5 | Salto largo con inercia |
| Acción/golpe | 4 | Cajas, objetos y combate futuro |
| Acariciar a Scar | Pendiente | Respuesta contextual del botón exclusivo de Scar |
| Patada | 1 | Variante de acción opcional |
| Interacción | 4 | Interruptores, empuje y mecanismos |
| Impacto/recuperación | 4 | Pérdida de corazón y retorno al control |
| Derrota/recuperación | 2 | Caída y reincorporación |
| Celebración | 2 | Meta, estrella o premio |
| Agarre de escalera | 2 | Captura desde salto o caída |
| Subir escalera | 2 | Alternancia de manos y pies |
| Bajar escalera | 2 | Descenso controlado |
| Salida superior | 1 | Transición de escalera a plataforma |
| Soltarse | 1 | Abandono voluntario y caída |

Total: **48 fotogramas en 19 secuencias**.

## Selección de salto en el juego

- Sin dirección horizontal: `salto_vertical`.
- Con dirección, sin correr: `salto_adelante`.
- Con dirección y botón correr activo: `salto_corriendo`.

La trayectoria pertenece a la física; la animación no altera por sí misma el collider ni teletransporta al personaje.

## Escalera vertical

- La escalera funcional mide **1×3,5 módulos**.
- Durante agarre, subida y bajada Eren se representa **de espaldas**, mirando a la escalera. La vista lateral o frontal queda prohibida para esas fases.
- Solo la aproximación, la salida superior y el gesto de soltarse pueden girar parcialmente el cuerpo.
- Su zona de agarre puede sobresalir **0,5 módulo** a cada lado, pero no tiene colisión sólida.
- Si Eren está en salto o caída, coincide con la zona de agarre y se pulsa **arriba**, cambia a `escalera_agarre`.
- Al engancharse, se centra suavemente en el eje de la escalera; nunca se teletransporta desde fuera de la zona de agarre.
- Arriba/abajo reproducen las secuencias correspondientes y desplazan verticalmente.
- Izquierda/derecha o salto permiten soltarse; se conserva una pequeña inercia y comienza la caída.
- En la parte superior se reproduce `escalera_salida_superior` y después se devuelve el control sobre la plataforma.
- Mientras está agarrado se desactiva la gravedad normal y se usa un collider de trepa de **1×1,5 módulos**.
