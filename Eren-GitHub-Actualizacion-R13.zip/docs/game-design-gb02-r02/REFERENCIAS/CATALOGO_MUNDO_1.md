# Catálogo aprobado · Mundo 1: Bosque fantástico y ruinas

## Estado del catálogo

- Dirección artística: **aprobada**.
- Familias funcionales, decorativas, ambientales y animadas: **aprobadas como maestros visuales**.
- Uso directo en el juego: **pendiente de normalización técnica**.
- Los dameros o fondos visibles en algunas láminas forman parte de las previsualizaciones y no deben incluirse en los sprites finales.
- Cada pieza final deberá extraerse o regenerarse individualmente con transparencia alfa real, caja modular exacta, anclaje y metadatos.

## 1. Assets funcionales

### Terreno y transiciones

- Tierra, piedra y ruina.
- Rellenos sin hierba.
- Superficies de 1×1, 2×1 y 3×1 módulos.
- Muros verticales, bordes y esquinas.
- Transiciones tierra–ruina en ambos sentidos.
- Escalones de piedra.

### Estructuras de recorrido

- Plataformas de piedra, tierra y raíces.
- Puentes cortos y largos.
- Escaleras y columnas escalables.
- Columnas de soporte de varias alturas.
- Paso bajo tronco para Eren agachado.
- Túnel pequeño exclusivo de Scar.
- Arco y base de meta.

### Objetos y mecanismos

- Caja rompible: intacta, dañada, rota y restos.
- Placa de presión: libre y presionada.
- Interruptor de pared: apagado y encendido.
- Interruptor de Scar: apagado y encendido.
- Cofre de acertijo: cerrado y abierto.
- Altar de acertijo.
- Puerta: cerrada y abierta.
- Llave, estrella y corazón.
- Punto de control inactivo y activo.
- Señal de retorno, inicio, meta y pedestal interactivo.

### Agua, peligros y lava

- Agua superficial, profunda, bordes, charca y cascada.
- Pinchos simples, dobles y triples.
- Zarzas, plataforma móvil, plataforma frágil y borde de vacío.
- Lava superficial y profunda, canales, bordes, piscina y cascada.
- Basalto frío, piedra caliente, fisuras, burbujas, brasas y distorsión térmica.

## 2. Assets decorativos

### Cubrejuntas y cortes

- Raíces, musgo, lianas, grietas, piedras y hierba colgante.
- Uniones tierra–piedra y madera–piedra.
- Bordes laterales y esquinas.
- Todos sin colisión.

### Vegetación y naturaleza

- Hierbas, helechos, plantas, flores, arbustos y hongos.
- Ramas, troncos, raíces, rocas, hojas, bellotas y piñas.
- Nidos, plumas, caracolas y pequeños animales estáticos.

### Ruinas y utilería

- Columnas, arcos, esculturas, santuarios y piezas derruidas.
- Antorchas y braseros apagados.
- Cuerdas, vallas, carteles sin texto, barriles, sacos, cestas y vasijas.
- Ruedas, cadenas, anillas y refuerzos.

### Paralaje y primer plano

- Niebla, montañas, bosques, ruinas y cascadas lejanas.
- Troncos y copas a distintas profundidades.
- Rayos de luz y follaje frontal.
- Hierba, lianas, ramas y troncos próximos a cámara.
- Zonas de exclusión visual alrededor de personajes, plataformas y peligros.

## 3. Assets animados y efectos

- Vegetación: bucles suaves de 4 fotogramas.
- Agua: superficie de 4; cascadas y salpicaduras de 6.
- Fuego: antorchas y braseros de 6.
- Mecanismos: cajas, placas, interruptores, cofres, puertas y puntos de control.
- Fauna: rana, mariposa, luciérnaga, caracol, insectos, aves, ardilla, conejo y peces.
- Efectos de Eren y Scar: caminar, correr, saltar, aterrizar, agacharse/arrastrarse, golpear, salpicar y recoger.
- Iluminación: sombras de contacto, oclusión ambiental, rayos, luces cálidas y mágicas, reflejos de agua, niebla y partículas.
- Lluvia: tres densidades, impactos simples, ondas, goteos, humedad, relámpagos y truenos.
- Lava: superficie, burbujas, cascada, impactos, brasas y calor.

## 4. Reglas de normalización técnica

- Unidad base: módulo cuadrado 1×1.
- Subdivisión mínima permitida: 0,5 módulo.
- Medidas admitidas: 0,5; 1; 1,5; 2; 3; 4 y múltiplos enteros necesarios.
- Prohibidas medidas arbitrarias como 1,33 o 1,38 módulos.
- Formato final: PNG o WebP con alfa real; sin fondos incorporados.
- Cada asset tendrá caja, pivote, línea de suelo, zona visible y colisión documentadas.
- Las superficies caminables serán horizontales y coincidirán exactamente con la colisión.
- Los elementos decorativos no tendrán colisión.
- Los assets animados conservarán el mismo pivote, caja y línea de suelo en todos los fotogramas.
- Los personajes y objetos nunca podrán crecer, encoger o desplazarse entre estados por diferencias de lienzo.

## 5. Rendimiento y accesibilidad

- Animaciones ambientales de 3–6 fotogramas.
- Máximo recomendado de 2–3 luces dinámicas visibles.
- Sombras estructurales y oclusión preferentemente estáticas.
- Animales y partículas se activarán de forma puntual, no simultánea.
- Opciones para reducir partículas, primer plano, lluvia, relámpagos e iluminación.
- Relámpagos normalmente como resplandor lejano, sin destello blanco completo.
- Música, ambiente, lluvia, truenos, efectos y voz/maullido tendrán control de volumen compatible con la configuración general.

## 6. Mecánicas ambientales

- Agua, vacío, pinchos y lava restan un corazón y devuelven al último punto seguro.
- Después del daño existirá una breve invulnerabilidad.
- La lluvia sobre Eren y Scar usará impactos ocasionales simplificados.
- Los truenos sonarán con retraso variable respecto al destello.
- La lava emitirá luz cálida controlada y utilizará pocas partículas.

## Estructura de carpetas

- `01_funcionales`: geometría, estructuras, objetos, mecanismos, agua, peligros y lava.
- `02_decorativos`: cubrejuntas, naturaleza, ruinas, paralaje y primer plano.
- `03_animados_efectos`: vegetación, agua, fuego, mecanismos, fauna, VFX, iluminación, lluvia y lava.

