# Catálogo funcional de Scar

## Reglas técnicas obligatorias

- Todos los fotogramas compartirán lienzo, escala, pivote y línea de suelo.
- Ninguna pose puede recortar cabeza, cola o patas.
- La caja visual puede variar, pero la caja física se mantendrá estable por estado.
- Las secuencias bajas conservarán una altura reducida constante y nunca harán crecer a Scar.
- Los desplazamientos se producirán mediante la física del personaje, no moviendo el dibujo dentro del lienzo.
- Se producirán versiones orientadas a derecha e izquierda mediante volteo controlado, sin cambiar pivote ni colisión.

## Mecánicas aprobadas que debe cubrir

1. Seguir a Eren manteniendo su propia posición física y apoyándose en suelo y plataformas.
2. Permanecer quieta, andar y correr.
3. Saltar verticalmente, hacia delante y durante la carrera.
4. Tener fases diferenciadas de impulso, subida, caída y aterrizaje.
5. Agacharse y avanzar por zonas bajas, pudiendo ir hacia delante o atrás sin ser expulsada.
6. Recorrer plataformas y cambios de altura sin flotar ni copiar directamente la altura de Eren.
7. Explorar rutas opcionales y desplazarse hacia un punto para sugerir un camino.
8. Avisar de peligro mediante exclamación, pequeño salto/reacción y maullido.
9. Dar una pista mediante interrogación, gesto de atención y maullido distinto.
10. Activar mecanismos exclusivos de Scar con salto, apoyo o golpe de pata para abrir puertas o puentes.
11. Reaccionar ante arañas, serpientes y futuros enemigos; alertar, ayudar o ahuyentarlos cuando proceda.
12. Esperar durante preguntas, operaciones y puzles sin interferir con la interfaz.
13. Acompañar el retorno por rutas ya recorridas y reunirse con Eren si queda separada.
14. Reaccionar a agua, vacío, pinchos y lava sin quedarse suspendida ni bloquear el nivel.
15. Utilizar conexiones verticales propias: escaleras, huecos felinos y caminos alternativos habilitados por Eren.
16. Esperar, acudir o activar un punto mediante una orden contextual de Eren.

## Reglas complementarias cerradas

- Los tres corazones pertenecen a Eren. Scar no consume corazones.
- Si Scar alcanza un peligro o queda fuera de una ruta válida, se reproduce una reacción breve y reaparece en el último apoyo seguro próximo a Eren.
- Las conexiones verticales de Scar se resuelven según la jerarquía definida en el apartado siguiente; no se utilizará una reaparición brusca si existe una solución visible y jugable.
- Las estrellas las recoge Eren. Scar puede detectarlas o señalar su dirección, pero no recogerlas automáticamente.
- Scar no rompe las cajas funcionales de Eren salvo que un nivel marque expresamente un objeto ligero exclusivo para ella.

## Jerarquía de navegación vertical y cooperación

1. **Ruta habilitada por Eren — solución preferente.** Eren empuja una caja, baja una rampa, abre una compuerta, despliega un puente o activa un elevador para que Scar pueda subir. Esta opción crea cooperación y debe utilizarse en los puntos importantes del nivel.
2. **Paso exclusivo de Scar.** Scar entra por un hueco, tronco, tubería o pasadizo visible y reaparece por una salida conectada en la otra altura. Debe verse la entrada, la salida y una animación de entrar/salir.
3. **Escalera vertical compartida.** Scar puede trepar por determinadas escaleras preparadas para ella, con animación trasera de patas alternas y cola equilibrando. La escalera debe marcar una zona de agarre válida.
4. **Ruta alternativa autónoma.** Scar abandona brevemente la cámara por un camino secundario y entra caminando en la nueva planta. Se empleará donde el trazado haga comprensible que ha llegado por otro lado.
5. **Reunión de seguridad — último recurso.** Si ninguna ruta es viable o Scar queda bloqueada, reaparece fuera de cámara y entra andando cerca de Eren. Nunca aparecerá instantáneamente delante del jugador ni dentro de una colisión.

La orden de compañero utilizará un **cuarto botón exclusivo de Scar**, identificado mediante una pata. El botón **Acción** seguirá reservado para golpear, romper, abrir o manipular objetos del escenario.

El botón de Scar tendrá respuestas contextuales sencillas:

- Junto a Scar y sin un objetivo funcional próximo: Eren la acaricia.
- Scar separada de Eren: la llama para que acuda.
- Junto a un punto exclusivo de Scar: le ordena entrar, saltar, activar o investigar ese punto.
- Scar ocupando un mecanismo: le ordena esperar o abandonarlo, según el estado del mecanismo.

No se utilizará un menú radial durante los primeros niveles. El icono de la pata podrá cambiar brevemente para anticipar la orden disponible, y una indicación superior explicará la acción durante el tutorial.

## Secuencias obligatorias

| Grupo | Secuencia | Estado |
|---|---|---|
| Locomoción | Reposo | Existente, necesita animación |
| Locomoción | Andar | Existente como pose; faltan fotogramas |
| Locomoción | Correr | Existente como pose; faltan fotogramas |
| Movimiento bajo | Agacharse quieta | Existente como pose; necesita normalización |
| Movimiento bajo | Caminar agachada / arrastrarse | Existente como pose; faltan fotogramas |
| Salto | Salto vertical | Falta |
| Salto | Salto hacia delante | Parcial; existe una pose |
| Salto | Salto corriendo | Falta |
| Salto | Caída | Falta |
| Salto | Aterrizaje | Falta |
| Exploración | Observar / localizar | Falta |
| Exploración | Indicar dirección | Falta |
| Avisos | Interrogación / pista | Falta reacción; icono y audio ya previstos |
| Avisos | Exclamación / peligro | Falta reacción; icono y audio ya previstos |
| Interacción | Golpe de pata | Parcial; existe una pose |
| Interacción | Activar interruptor por apoyo | Falta |
| Interacción | Activar interruptor con salto | Falta |
| Cooperación | Esperar / quedarse | Falta |
| Cooperación | Acudir a un punto | Usa locomoción; falta respuesta visual |
| Cooperación | Recibir caricia | Falta |
| Cooperación | Entrar en hueco | Falta |
| Cooperación | Salir de hueco | Falta |
| Cooperación | Trepar escalera de espaldas | Falta |
| Cooperación | Bajar escalera de espaldas | Falta |
| Enemigos | Alerta / bufido / ahuyentar | Falta |
| Peligro | Daño / sobresalto | Falta |
| Peligro | Recuperación / reaparición | Falta |
| Sistema | Espera en puzle o diálogo | Puede partir de reposo |
| Sistema | Reunirse con Eren | Usa correr y salto con control de ruta |

## Validación previa a montaje

- Scar y Eren deben apoyar sus patas y pies en la misma superficie física.
- Scar debe aterrizar por su propia colisión en cada plataforma.
- Al saltar Eren, Scar no puede copiar su coordenada vertical.
- Bajo un obstáculo, Scar no puede levantarse hasta disponer de altura libre.
- Si Eren cambia de ruta o utiliza una escalera, Scar resolverá la conexión mediante la jerarquía de navegación y nunca se teletransportará dentro de una pared ni sobre un peligro.
- Los iconos `?` y `!` se colocarán como elementos independientes sobre Scar para no duplicar todos los fotogramas.
