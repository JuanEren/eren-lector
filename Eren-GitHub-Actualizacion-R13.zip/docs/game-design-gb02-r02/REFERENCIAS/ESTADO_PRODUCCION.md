# Estado de producción del catálogo · Mundo 1

## Norma técnica bloqueada

- Escala: **100 px = 1 módulo**.
- Subdivisión mínima y única: **0,5 módulo = 50 px**.
- Toda medida funcional, posición, pivote, collider y trigger usa múltiplos exactos de 0,5.
- Escalado artístico permitido: uniforme; queda prohibido deformar ancho y alto por separado.
- Perspectiva funcional: lateral coherente.
- Decoración, paralaje y VFX: sin collider ni interacción obligatoria.

## Bloque A · Archivos existentes normalizados y comprobados

Resultado automático: **APROBADO (45/45 archivos)**.

| Familia | Cantidad | Estado |
|---|---:|---|
| Terreno tierra V3, 1×3 | 12 | Listo para producción |
| Terreno ruina V3, 1×3 | 8 | Listo para producción |
| Transiciones V3, 1×3 | 12 | Listo para producción |
| Estructuras normalizadas | 7 | Listas para producción |
| Objetos normalizados | 4 | Listos para producción |
| Peligros normalizados | 2 | Listos para producción |

Las 13 piezas no pertenecientes al terreno se revisaron además visualmente sobre transparencia. Conservan proporción, lectura lateral y alineación inferior.

## Bloque B · Diseño aprobado, todavía no convertido en archivo de producción

Estas familias existen dentro de las láminas maestras y no deben colocarse aún directamente en el nivel:

- variantes restantes de terreno y transiciones;
- puentes, escaleras, columnas y estructuras adicionales;
- mecanismos adicionales, señalización, llave, corazón y punto de control;
- zarzas y variantes funcionales de agua y lava;
- toda animación que todavía no tenga fotogramas separados con lienzo y pivote constantes;
- toda pieza decorativa que todavía no haya sido recortada de su lámina.

Su estética está aprobada. Su preparación técnica sigue pendiente.

## Bloque C · Rechazados como funcionales

- caja antigua en perspectiva tres cuartos;
- placa antigua en perspectiva tres cuartos;
- animaciones derivadas de esa caja y de esa placa;
- terreno V2 como geometría funcional por usar lienzo irregular.

Pueden conservarse únicamente como referencia o decoración sin collider cuando corresponda.

## Condición para incorporar una pieza nueva al Bloque A

1. Debe proceder del catálogo ya guardado.
2. Debe separarse con transparencia real.
3. Debe asignarse a un lienzo modular en pasos de 0,5.
4. Debe mantener la perspectiva funcional si tendrá collider.
5. Debe registrar tamaño, pivote, collider/trigger y capa.
6. Debe superar la validación automática y la revisión visual.

No se crearán sustituciones nuevas hasta terminar la separación y comprobación de todas las piezas existentes aprovechables.

## Bloque D · Piezas recuperadas de las láminas maestras

Se han separado y normalizado **61 piezas adicionales** de las láminas funcionales existentes:

| Familia | Cantidad | Clasificación |
|---|---:|---|
| Estructuras y recorrido | 15 | Funcionales |
| Objetos y mecanismos | 18 | Funcionales o estados funcionales |
| Agua y peligros | 16 | Funcionales o estados funcionales |
| Lava | 12 | 11 funcionales y 1 decorativa |

Resultado técnico: **APROBADO (61/61)**.

- Todas tienen canal alfa real; se eliminó el damero horneado de las láminas sin modificar los originales.
- Todos los lienzos son múltiplos exactos de 50 px.
- Se mantuvo la proporción artística y el anclaje inferior.
- La piscina de lava cenital se clasifica como `decorative-only-no-collider`.
- Las parejas abierto/cerrado, encendido/apagado y los estados de plataforma frágil se registran como estados funcionales, no como obstáculos independientes incompatibles.

El manifiesto individual se encuentra en `PRODUCCION/02_extraidos_laminas/MANIFIESTO_EXTRAIDOS.json`.

### Total técnico disponible hasta este punto

- Primer bloque normalizado: 45 archivos.
- Recuperados de láminas maestras: 61 archivos.
- **Total preparado y comprobado: 106 archivos.**

## Bloque E · Catálogo decorativo separado y comprobado

Se han preparado **150 assets decorativos** a partir de las cinco láminas maestras:

| Familia | Cantidad | Capa prevista |
|---|---:|---|
| Cubrejuntas y cortes | 60 | Superposición sobre terreno |
| Vegetación y naturaleza | 26 | Plano medio decorativo |
| Ruinas y utilería | 28 | Plano medio decorativo |
| Paralaje y fondos | 11 | Fondo con velocidad propia |
| Primer plano y profundidad | 25 | Oclusión frontal; mezcla multiplicar recomendada |

Los **150/150** cumplen:

- lienzos en múltiplos de 50 px;
- transparencia RGBA completa;
- collider prohibido;
- interacción obligatoria prohibida;
- clasificación de capa registrada.

Durante la revisión visual se retiraron **11 recortes defectuosos** porque unían varias piezas solapadas o conservaban residuos ajenos. Permanecen fuera del manifiesto aprobado en `PRODUCCION/RECHAZADOS_EXTRACCION_DECORATIVOS` y no pueden utilizarse en niveles.

### Total acumulado preparado

- Funcionales y estados funcionales: 105 archivos.
- Decorativos aprobados: 151 archivos, incluida la piscina cenital de lava clasificada anteriormente.
- **Total aprobado y preparado: 256 archivos.**

## Bloque F · Animaciones y efectos

Se han separado y validado **66 secuencias**, con **258 fotogramas**:

| Familia | Secuencias |
|---|---:|
| Vegetación animada | 5 |
| Agua y fuego | 5 |
| Mecanismos | 5 |
| Fauna pequeña | 6 |
| Fauna de fondo | 7 |
| Efectos de juego | 8 |
| Iluminación y sombras | 11 |
| Lluvia y tormenta | 11 |
| Lava | 8 |

Comprobaciones superadas:

- 258/258 fotogramas RGBA y no vacíos.
- Lienzo idéntico dentro de cada secuencia.
- Lienzos en múltiplos exactos de 50 px.
- Pivote común por secuencia.
- Caja antigua y placa antigua, junto con sus animaciones, excluidas.
- Los VFX y la fauna ambiental no tienen collider.
- Los mecanismos utilizan el collider estático del objeto funcional; su animación no altera la geometría jugable.

### Total gráfico acumulado

- Funcionales y decorativos preparados anteriormente: 256 imágenes.
- Fotogramas animados y VFX: 258 imágenes.
- **Total preparado y validado: 514 imágenes**, organizadas además en 66 secuencias.

## Bloque G · Terreno restante recuperado

La comparación final con el catálogo maestro reveló 31 piezas de terreno que todavía no se habían separado:

- 26 piezas de tierra, ruina, esquinas y transiciones aprobadas como funcionales mediante geometría exterior de cuadrícula.
- 5 escaleras existentes reclasificadas como decorativas: sus peldaños dibujados no coinciden con incrementos exactos de 0,5 y no pueden definir colisión.

Resultado: **APROBADO (31/31)** dentro de su clasificación correcta.

### Total definitivo de assets existentes preparados

- Funcionales y estados funcionales: 131 imágenes.
- Decorativos: 156 imágenes.
- Fotogramas de animación y VFX: 258 imágenes.
- **Total: 545 imágenes validadas.**

## Bloque H · Sustituciones funcionales nuevas aprobadas

Se han generado, normalizado y aprobado las tres sustituciones funcionales que faltaban:

| Familia | Archivos | Medida modular | Resultado |
|---|---:|---:|---|
| Caja rompible | 4 estados | 1×1 | APROBADO |
| Placa de presión lateral | 2 estados | 1,5×0,5 | APROBADO |
| Escalera modular | 2 direcciones | 3×1,5 | APROBADO |

Comprobaciones superadas:

- ocho archivos RGBA con transparencia real;
- lienzos en múltiplos exactos de 50 px;
- escalado artístico uniforme, sin deformación independiente de ejes;
- perspectiva lateral funcional;
- pivote inferior común en los estados de cada objeto;
- collider/trigger registrado por separado del dibujo;
- tres peldaños exactos de 1×0,5 en ambas escaleras.

### Total gráfico actualizado

- Funcionales y estados funcionales: **139 imágenes**.
- Decorativos: **156 imágenes**.
- Fotogramas de animación y VFX: **258 imágenes**.
- **Total: 553 imágenes validadas.**

Las sustituciones gráficas obligatorias del mundo quedan cerradas. Permanecen pendientes las familias de enemigos. Personajes, interfaz educativa y audio se gestionan en catálogos independientes.
