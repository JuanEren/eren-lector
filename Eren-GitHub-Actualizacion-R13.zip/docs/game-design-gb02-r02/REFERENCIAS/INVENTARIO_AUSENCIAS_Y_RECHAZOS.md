# Inventario definitivo de ausencias y rechazos · Mundo 1

## Criterio

Esta lista se obtiene después de revisar las láminas funcionales, decorativas y animadas. No confunde una ausencia gráfica con una mecánica que puede reutilizar un asset existente.

## 1. Sustituciones gráficas obligatorias completadas

| Estado | Asset preparado | Verificación superada |
|---|---|---|---|
| APROBADO | Caja rompible funcional | Vista frontal lateral coherente; 1×1; collider 1×1; estados intacta, dañada, rotura y restos; lienzo y pivote idénticos |
| APROBADO | Placa de presión funcional | Vista lateral; 1,5×0,5; trigger 1,5×0,5; estados libre/pulsada; lienzo y pivote constantes |
| APROBADO | Escalera modular funcional | 3×1,5; tres peldaños de 1×0,5; variantes izquierda y derecha; navegación exterior exacta |

Los ocho archivos de producción, sus metadatos y la comprobación sobre cuadrícula se conservan en `PRODUCCION/06_sustituciones_funcionales`.

## 2. Assets funcionales ausentes para enemigos

No existe ningún enemigo funcional dentro de las 19 láminas revisadas. Para disponer de variedad mínima en los niveles hacen falta:

| Prioridad | Familia | Estados mínimos | Caja sugerida |
|---|---|---|---|
| B | Enemigo terrestre patrulla | reposo, caminar, aviso, ataque, impacto y derrota | 1×1 o 1,5×1 |
| B | Enemigo volador | vuelo, aviso, picado, impacto y derrota | 1×1 |
| B | Enemigo fijo vegetal o ruina | reposo, aviso, ataque, impacto y derrota | 1×1,5 |

Las cajas son propuestas modulares y deben confirmarse en el diseño del enemigo antes de generar arte.

## 3. No necesitan un asset gráfico nuevo

| Mecánica | Solución aprobada |
|---|---|
| Plataforma móvil | Reutilizar una plataforma funcional existente; el movimiento pertenece a código/metadatos |
| Punto de control | Reutilizar portal apagado/encendido y su secuencia de activación |
| Borde de vacío | Se construye con final de terreno, zona de muerte y niebla/oclusor; no requiere bloque funcional visible |
| Señal de retorno | Reutilizar y reflejar horizontalmente la señal de dirección |
| Inicio y meta | Bandera, arco y base de meta ya disponibles |
| Altar de acertijo | Pedestal de puzle ya disponible |
| Coleccionables y HUD | Llave, estrella y corazón ya disponibles; la interfaz utiliza variantes escaladas sin collider |
| Caminos de Scar | Túnel, pedestal e interruptor de Scar ya disponibles |
| Agua y lava | Superficies, profundidades, bordes, cascadas y VFX disponibles |

## 4. Rechazados que no requieren sustitución

- `terrain-v2`: sustituido por Terrain V3 y las 26 piezas adicionales recuperadas.
- Cinco escaleras antiguas: pueden mantenerse como decoración, pero no como soporte funcional.
- Piscina cenital de lava: permanece como decoración/VFX, nunca como colisión.
- Once recortes decorativos compuestos o con residuos: existen suficientes alternativas aprobadas; no se sustituyen de forma automática.

## 5. Personajes fuera del catálogo de mundo

Eren y Scar se gestionan como catálogo de personajes independiente. Antes de integrarlos deben superar una auditoría específica porque ya se observaron estos fallos:

- pies de Eren recortados o fuera de la línea de suelo;
- Eren aumenta de tamaño al agacharse;
- pies de Eren aparecen sobre la cabeza en determinados estados;
- cabeza de Scar recortada durante el salto;
- Scar cambia de altura y línea de suelo;
- Scar queda suspendido cuando Eren aterriza sobre plataformas.

Secuencias mínimas a normalizar: reposo, caminar, correr, salto/subida/caída/aterrizaje, agacharse, arrastrarse, acción/golpe, daño y celebración. Todos los estados compartirán escala corporal, pivote plantar y caja modular coherente.

## 6. Interfaz educativa fuera del catálogo de mundo

Necesita un catálogo separado, reutilizable entre mundos:

- aviso de estrellas pendientes antes de cruzar la meta;
- pregunta de comprensión con tres respuestas sencillas;
- puzle de arrastrar, encajar y rotar piezas;
- operaciones de suma/resta con respuestas múltiples;
- relato breve y pregunta asociada;
- iconos de interacción de Scar, interrogación y exclamación.

## 7. Audio todavía ausente

No se han localizado archivos de audio en este catálogo. Deben prepararse posteriormente, con licencia documentada:

- pasos, carrera, arrastre, salto y aterrizaje;
- golpe, rotura de caja, interruptores, puerta, cofre, llave y estrella;
- daño, agua, pinchos y lava;
- maullidos de Scar para aviso, interrogación y reacción;
- ambiente de bosque, fauna, agua, fuego, lluvia y trueno retardado;
- melodía ambiental ligera, con volumen inicial bajo y bucle limpio.

## 8. Orden de producción siguiente

1. Auditar y normalizar completamente Eren y Scar.
2. Diseñar las tres familias de enemigos.
3. Preparar el catálogo de interfaz educativa.
4. Seleccionar, documentar y normalizar el audio.
5. Revalidar el catálogo completo antes de llenar el nivel base con assets.
