# Reglas de controles de Eren y Scar

## Cruceta izquierda

- Ocho direcciones pulsables, incluidas las cuatro diagonales.
- No puede desaparecer durante el nivel.
- Permite combinar dirección con los botones de la derecha.

## Botones derechos

1. **Acción:** golpear, romper cajas, abrir y manipular objetos.
2. **Correr:** modifica la velocidad mientras se mantiene pulsado.
3. **Saltar:** salto vertical, hacia delante o corriendo según dirección y velocidad.
4. **Scar:** órdenes exclusivas de compañera y caricia.

## Botón Scar

- Identificador: icono de pata claramente diferente de Acción.
- No ejecuta golpes ni manipula objetos destinados a Eren.
- Junto a Scar: caricia, salvo que exista una interacción de compañera claramente prioritaria.
- Scar alejada: llamada.
- Cerca de un punto de Scar: acudir, investigar, entrar, saltar o activar.
- Scar en un mecanismo: esperar o liberar el mecanismo.
- En tutoriales, la orden disponible aparece en la franja superior.
- No se emplean menús radiales en los niveles iniciales.
- Debe poder pulsarse simultáneamente con la cruceta cuando la orden lo requiera.

## Disposición

- Se conservarán los tres botones principales ya aprobados: Acción arriba, Correr abajo a la izquierda y Saltar abajo a la derecha.
- El botón Scar se añadirá como botón secundario de menor diámetro, próximo al grupo derecho pero sin tapar Acción, Correr ni Saltar.
- La zona central de juego y la franja superior de objetivos no se reducen para alojarlo.
