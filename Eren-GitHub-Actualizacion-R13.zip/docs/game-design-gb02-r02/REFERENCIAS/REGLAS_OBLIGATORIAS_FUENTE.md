# Reglas obligatorias de producción de niveles y assets

## Flujo obligatorio

1. Diseñar el nivel completo sobre cuadrícula modular.
2. Comprobar todas las mecánicas sobre el plano.
3. Si existe cualquier error, volver al paso 1. Si todo es correcto, bloquear la geometría.
4. Seleccionar, crear y normalizar los assets funcionales necesarios del catálogo aprobado.
5. Colocar los assets funcionales exactamente sobre el plano bloqueado.
6. Comparar ubicación, tamaño, alineación, pivotes, capas y colisiones con el plano del paso 1.
7. Repetir la comprobación completa de mecánicas con los assets colocados.
8. Si existe cualquier fallo en el paso 7, volver al paso 1. Si todo es correcto, bloquear el nivel funcional.
9. Añadir assets de corte y cubrejuntas sin colisión.
10. Añadir decoración, paralaje, primer plano, iluminación y animaciones.
11. Realizar una comprobación visual y de rendimiento final sin modificar la geometría validada.

## Puertas de validación

- No se colocan assets sobre una geometría no validada.
- No se incorporan assets conceptuales directamente: antes deben tener transparencia real, medidas modulares, pivote y colisión.
- No se decora un nivel cuyas mecánicas funcionales no hayan sido aprobadas.
- Ningún problema mecánico se corrige ocultándolo con arte: obliga a volver al diseño base.

## Reglas de geometría y colisión

- Cuadrícula base regular con unidad principal de 1 × 1 módulo.
- La única subdivisión permitida es de 0,5 módulo. Todas las medidas funcionales deben ser múltiplos exactos de 0,5: 0,5; 1; 1,5; 2; 2,5; 3; etc.
- Quedan prohibidas dimensiones o desplazamientos intermedios como 0,6; 0,75; 1,2; 1,3; 1,8; 2,7 o cualquier valor que no sea múltiplo exacto de 0,5.
- Esta regla se aplica obligatoriamente a posición X/Y, anchura, altura, pivotes, puntos de apoyo, colliders, plataformas, huecos, escalones, puertas, cajas, mecanismos, peligros y zonas de interacción.
- El tamaño funcional mínimo permitido es 0,5 × 0,5 módulos. A partir de ahí, cada dimensión solo puede aumentar o disminuir en pasos de 0,5 módulo.
- Un asset puede tener hojas, musgo, raíces, brillos u otros remates visuales fuera de su celda, pero su anclaje, soporte, volumen funcional y colisión deben permanecer ajustados a la retícula de 0,5 módulos.
- No se permite escalar un asset funcional libremente para que «parezca encajar». Primero se le asigna una medida modular válida y después se normaliza el arte conservando su proporción y perspectiva lateral.
- Plataformas, huecos y distancias deben respetar los límites de salto aprobados.
- Ninguna estrella o recompensa puede quedar fuera del alcance real.
- Ningún interruptor, puerta, cofre, acertijo, caja o mecanismo se coloca junto a un borde sin espacio seguro de aproximación y salida.
- El paso agachado debe ser físicamente imposible de superar saltando.
- La ruta inferior debe disponer de una salida alcanzable.
- Arte visible y colisión deben coincidir.
- Eren, Scar y objetos conservarán una línea de suelo y un pivote constantes.

## Reglas de arte y capas

- Todos los assets básicos funcionales deben compartir una misma perspectiva lateral compatible con la cuadrícula, la escala modular y la lectura inmediata de sus apoyos y colisiones.
- Suelo, plataformas, columnas, escalones, cajas rompibles, puertas, cofres, mecanismos, interruptores, peligros y demás objetos interactivos no pueden utilizar perspectiva isométrica, cenital, angular o falsa profundidad que desplace visualmente su base respecto de la colisión.
- Antes de aprobar un asset funcional se comprobará que su cara de apoyo, pivote, anchura, altura y zona de interacción pueden ajustarse exactamente a múltiplos de 0,5 módulo sin deformar el dibujo.
- Si un asset no encaja con la perspectiva funcional común, queda automáticamente clasificado como decorativo y no puede tener collider, bloquear el paso, recibir golpes, activar mecanismos ni contener una interacción necesaria.
- Los assets decorativos sí pueden variar de perspectiva, escala aparente y profundidad para aportar diversidad y estética, siempre que permanezcan en capas sin colisión y no alteren la lectura del recorrido jugable.
- La profundidad visual se construirá con decoración, paralaje y superposición; nunca inclinando o deformando los assets funcionales.
- Orden orientativo: fondo lejano → paralaje medio → geometría funcional → personajes/objetos → decoración frontal controlada → interfaz.
- Los cubrejuntas pueden solaparse, pero nunca cambiar la lectura de la colisión.
- La decoración no puede ocultar peligros, plataformas, estrellas o mecanismos.
- El primer plano utilizará zonas de exclusión alrededor de elementos jugables.
- Los elementos animados no modificarán su caja funcional entre fotogramas.

## Reglas de rendimiento

- Animaciones cortas y reutilizables.
- Iluminación dinámica limitada; sombras y oclusión estáticas cuando sea posible.
- Partículas, animales y efectos climáticos con límites simultáneos.
- Calidad adaptable para reducir primer plano, partículas, lluvia, relámpagos, luces y fauna.
- No se aprobará el nivel sin comprobar rendimiento en el dispositivo móvil objetivo.

## Estado actual

- Plano del Nivel 1: validado y bloqueado.
- Catálogo visual del Mundo 1: aprobado.
- Siguiente fase: normalización técnica de los assets funcionales necesarios para el Nivel 1 conforme a incrementos exactos de 0,5 módulos.
- El paso de colocación sobre el plano todavía no ha comenzado.
- Las pruebas de montaje que usaron medidas no múltiplos de 0,5 quedan rechazadas y no pueden reutilizarse como base funcional.
