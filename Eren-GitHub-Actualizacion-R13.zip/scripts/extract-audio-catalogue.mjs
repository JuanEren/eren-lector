import fs from 'node:fs/promises';
import vm from 'node:vm';

const REQUIRED_ARRAYS = ['stories', 'levelAdditions', 'advancedQuestions', 'celebrations', 'gamePhrases'];

function createBrowserSafeSandbox() {
  const localStorage = {
    getItem() { return null; },
    setItem() {},
    removeItem() {},
    clear() {},
  };
  const document = {
    body: {},
    documentElement: {},
    createElement() { return { style: {}, dataset: {}, append() {}, appendChild() {}, setAttribute() {} }; },
    getElementById() { return null; },
    querySelector() { return null; },
    querySelectorAll() { return []; },
    addEventListener() {},
  };
  const sandbox = {
    console: { log() {}, warn() {}, error() {} },
    document,
    localStorage,
    navigator: { language: 'es-ES' },
    location: { href: 'https://local.invalid/' },
    setTimeout() { return 0; },
    clearTimeout() {},
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  return sandbox;
}

export function audioId(text) {
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++) {
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619);
  }
  return (hash >>> 0).toString(16);
}

export async function extractAudioCatalogue(appFile) {
  const source = await fs.readFile(appFile, 'utf8');
  const marker = source.match(/\blet\s+story\s*=/);
  if (!marker || marker.index === undefined) {
    throw new Error('No se encontró el límite del catálogo de lectura en app.js.');
  }

  const dataSection = source.slice(0, marker.index);
  const sandbox = createBrowserSafeSandbox();
  vm.createContext(sandbox);

  const expression = `${dataSection}\nJSON.stringify({stories,levelAdditions,advancedQuestions,celebrations,gamePhrases,uiPack:window.__uiR02||null})`;
  const encoded = vm.runInContext(expression, sandbox, {
    timeout: 2000,
    filename: 'app-catalogue.vm.js',
  });
  const catalogue = JSON.parse(encoded);

  for (const field of REQUIRED_ARRAYS) {
    if (!Array.isArray(catalogue[field])) {
      throw new Error(`El catálogo de audio no contiene el array ${field}.`);
    }
  }
  if (!catalogue.stories.length || !catalogue.celebrations.length || !catalogue.gamePhrases.length) {
    throw new Error('El catálogo de audio está vacío o incompleto.');
  }
  return catalogue;
}
