import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { audioId, extractAudioCatalogue } from '../scripts/extract-audio-catalogue.mjs';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const workflow = await fs.readFile(path.join(projectRoot, '.github/workflows/build-apk.yml'), 'utf8');
const generator = await fs.readFile(path.join(projectRoot, 'scripts/generate-azure-audio.mjs'), 'utf8');

assert.match(workflow, /regenerar_locuciones:/);
assert.match(workflow, /github\.event_name == 'workflow_dispatch' && inputs\.regenerar_locuciones/);
assert.match(workflow, /generate-azure-audio\.mjs --verify-only/);
assert.match(workflow, /ci\/audio\/Eren-Locuciones-Locales\.zip/);
assert.match(workflow, /azure-tts-v1-/);
assert.doesNotMatch(workflow, /if:\s*env\.AZURE_SPEECH_KEY/);
assert.match(generator, /if \(!verifyOnly && \(!key \|\| !region\)\)/);
assert.match(generator, /La compilación normal no llama a Azure/);

const temporaryDirectory = await fs.mkdtemp(path.join(os.tmpdir(), 'eren-r13-audio-'));
const fixture = path.join(temporaryDirectory, 'app.js');
await fs.writeFile(fixture, `
const stories=[{items:[{text:'Una historia.',extra:[],qs:[]}]}];
const levelAdditions=[[[]]];
const advancedQuestions=[[]];
const celebrations=['Muy bien.'];
const gamePhrases=['Continúa.'];
const UI_R02_PACK={packageId:'UI_EDUCATIVA_R02_CANDIDATE'};
window.__uiR02=UI_R02_PACK;
let story=null;
`, 'utf8');

try {
  const catalogue = await extractAudioCatalogue(fixture);
  assert.equal(catalogue.stories.length, 1);
  assert.equal(catalogue.uiPack.packageId, 'UI_EDUCATIVA_R02_CANDIDATE');
  assert.equal(audioId('Eren'), audioId('Eren'));
} finally {
  await fs.rm(temporaryDirectory, { recursive: true, force: true });
}

console.log(JSON.stringify({
  test: 'AZURE_BUILD_R13_OFFLINE_AUDIO',
  status: 'PASS',
  normalBuildCallsAzure: false,
  browserCatalogueInNode: 'PASS',
  localAudioPack: 'SUPPORTED',
}, null, 2));
