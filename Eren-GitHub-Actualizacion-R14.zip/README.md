# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 37.0.0 · candidata GB02 R03 · revisión R14

R14 aplica el contrato aprobado `GB02 R03` (SHA-256 `dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4`) directamente sobre la baseline funcional R11. R12 y R13 se preservan en el repositorio, pero no forman parte de la cadena de aplicación.

Incluye exclusivamente:

- viewport de altura 10,8 y ancho dinámico `max(19,2; 10,8 × aspecto)`, a ancho completo y escala uniforme;
- postura baja de Eren solo ante un volumen `LOW_CLEARANCE` que bloquee realmente el collider normal, sin perfil bajo falso para Scar;
- caja y pilar heredados ajustados visualmente a sus colliders existentes, sin mutar geometría ni contacto;
- extensión 36,5–64,5 con transitabilidad dual y ruta nominal de Scar plana, sin salto, peligro ni teletransporte;
- guardián de 2 HP con alerta de 0,45 s y consecuencias atómicas sobre barrera, escalera y liberación de Scar;
- placa enclavada de Scar y puente que espera zona libre, se despliega 0,6 s sin collider y queda sólido;
- R4 condicionado a puente sólido y ambos actores seguros sobre G6;
- estrella opcional y meta estrictamente dual, con llamada física a Scar a los 2 s y un único evento de cierre;
- Laboratorio `QA_ONLY` de estaciones A–E, invisible e inaccesible en builds normales.

Se conservan sin cambios los valores de locomoción, salto, gravedad, colliders de actores y contacto visual R10, además del HUD estable de tres casillas R11. No se integra ningún tileset nuevo.

La validación automatizada se ejecuta con `node tests/gb02-r03-smoke.mjs` y `node tests/hud-hearts-r11-smoke.mjs`.

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
