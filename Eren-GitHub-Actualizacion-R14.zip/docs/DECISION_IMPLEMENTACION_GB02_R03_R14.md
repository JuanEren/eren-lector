# Decisión de implementación · GB02 R03 · R14

## Identidad

- Revisión de implementación: `R14`.
- Aplicación directa después de: `R11`.
- Contrato aprobado: `GB02 R03`.
- SHA-256 contractual: `dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4`.
- Baseline de repositorio auditada: `main@cf94cb32c2923a2810e1516ac93e75528ff9b320`.
- R12/R13: presentes, íntegros, preservados y no aplicados.

## Decisión

R14 implementa únicamente las reglas aprobadas de GB02 R03 sobre la baseline funcional R11:

1. viewport de 10,8 módulos de alto y ancho `max(19,2; 10,8 × aspecto)`;
2. postura baja de Eren condicionada a restricción `LOW_CLEARANCE` real, sin perfil bajo de Scar;
3. congruencia visual de caja y pilar con los colliders heredados, sin mutarlos;
4. geometría GB02 entre x=36,5 y x=64,5 y transitabilidad dual;
5. guardián de 2 HP, alerta de 0,45 s, cero daño pasivo y consecuencias atómicas;
6. placa de Scar enclavada, despliegue de puente de 0,6 s sin collider y sólido permanente;
7. ruta nominal de Scar a y=2 sin saltos, peligros, recuperación ni teletransporte;
8. R4 solo con puente sólido y ambos personajes seguros en G6;
9. estrella opcional y meta simultánea dual con llamada física a Scar tras 2 s;
10. Laboratorio `QA_ONLY` A–E oculto e inaccesible en builds normales.

## Congelado

Se preservan los valores R10 de locomoción, salto, gravedad, contacto, apoyo, colliders de Eren/Scar y planos visuales +10/+6 px. Se preserva el HUD fijo R11.

## Exclusiones

- No merge a `main`.
- No release ni publicación.
- No borrados.
- No integración de tileset ni assets nuevos.
- No aplicación total ni parcial de R12/R13.

## Resultado

Implementación candidata con QA automatizado PASS. `GAME_READY=false` hasta el cierre artístico y las decisiones externas que no forman parte de R14.
