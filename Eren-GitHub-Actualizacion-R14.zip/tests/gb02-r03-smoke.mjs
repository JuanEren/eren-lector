import vm from 'node:vm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('game.css', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');

const CONTRACT_SHA = 'dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4';
const idleInput = { left: false, right: false, up: false, crouch: false, run: false, jump: false, action: false, scar: false };

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id; this.dataset = {}; this.classList = new ClassList(); this.listeners = new Map();
    this.style = {}; this.textContent = ''; this.innerHTML = ''; this.value = ''; this.offsetWidth = 10;
    this.attributes = new Map(); this.disabled = false; this.width = 0; this.height = 0;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, pointerId: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  closest(selector) { return selector === 'button' ? this : null; }
}

function createHarness({ qaOnly, width = 1920, height = 1080 }) {
  const exportedSource = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={
 getSim:()=>sim,
 reset:reason=>resetSimulation(reason),
 step:(input={},dt=FIXED_DT)=>physicsStep(dt,{...${JSON.stringify(idleInput)},...input}),
 buildGraybox,
 rebuildWorld,
 viewportWorldSize,
 currentViewportWorldSize,
 lowClearanceConstraint,
 canFit,
 bodyRect,
 overlaps,
 supportingSolid,
 actorInGoalZone,
 getTuning:()=>({...tuning}),
 getContract:()=>JSON.parse(JSON.stringify(GB02_CONTRACT)),
 getContact:()=>JSON.parse(JSON.stringify(VISUAL_CONTACT_PLANE)),
 getTestMode:()=>TEST_MODE,
 setScene,
 render
};
})();`);

  const elements = new Map();
  for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
  const get = id => elements.get(id);
  const controlMap = {
    moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
    moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
  };
  for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
  for (const [id, value] of Object.entries({ walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;
  const stations = [...html.matchAll(/data-station="([A-Z])"/g)].map(match => { const element = new Element(); element.dataset.station = match[1]; return element; });
  const body = new Element('body');
  const document = {
    body,
    getElementById: id => get(id),
    querySelectorAll: selector => selector === '[data-controls]' ? [...elements.values()].filter(element => element.dataset.controls) : selector === '[data-station]' ? stations : [],
    createElement: () => new Element(),
    addEventListener() {},
    execCommand: () => true,
  };
  const gradient = { addColorStop() {} };
  const context2d = new Proxy({ createLinearGradient: () => gradient }, {
    get(target, key) { if (key in target) return target[key]; return () => {}; },
    set(target, key, value) { target[key] = value; return true; },
  });
  get('gameCanvas').getContext = () => context2d;
  get('gameCanvas').getBoundingClientRect = () => ({ width, height });
  const storage = new Map();
  const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
  const listeners = new Map();
  const window = {
    document, devicePixelRatio: 1, innerWidth: width, innerHeight: height, __EREN_QA_ONLY__: qaOnly,
    addEventListener(type, callback) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(callback); },
    dispatchEvent(event) { for (const callback of listeners.get(event.type) || []) callback(event); },
    requestAnimationFrame() { return 1; }, cancelAnimationFrame() {},
  };
  class Image {
    constructor() { this.complete = false; this.naturalWidth = 0; this.naturalHeight = 0; this.decoding = ''; this._src = ''; }
    set src(value) { this._src = value; }
    get src() { return this._src; }
  }
  const sandbox = {
    window, document, navigator: { getGamepads: () => [], userAgent: 'GB02-QA' }, localStorage,
    requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
    setTimeout: callback => { callback(); return 1; }, clearTimeout() {}, console, Image,
    completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
    tone() {}, playAzureSequence() {}, renderMenu() {},
  };
  window.localStorage = localStorage;
  vm.createContext(sandbox);
  vm.runInContext(exportedSource, sandbox, { filename: 'graybox-game.js' });
  return { window, get, stations, body };
}

const normal = createHarness({ qaOnly: false });
if (normal.window.__grayboxTest.getTestMode() !== false) throw new Error('La build normal quedó en modo QA.');
if (!normal.get('playLab').classList.contains('hidden') || !normal.get('playLab').disabled || normal.get('playLab').getAttribute('aria-hidden') !== 'true') throw new Error('Laboratorio QA_ONLY visible o activable en build normal.');
normal.get('playLab').click();
if (normal.get('playLab').classList.contains('active')) throw new Error('La build normal permitió entrar al Laboratorio QA_ONLY.');

const { window, get, stations } = createHarness({ qaOnly: true });
const api = window.__grayboxTest;
get('directGame').click();
if (!api.getSim()) throw new Error('No se inició la simulación QA de GB02.');
if (get('playLab').classList.contains('hidden') || get('playLab').disabled || get('playLab').getAttribute('aria-hidden') !== 'false') throw new Error('La build QA no habilitó su Laboratorio QA_ONLY.');
if (stations.map(item => item.dataset.station).join('') !== 'ABCDE') throw new Error('El laboratorio no contiene exactamente las estaciones A–E.');

const contract = api.getContract();
if (contract.id !== 'GB02_R03_APPROVED' || contract.sha256 !== CONTRACT_SHA || contract.baseline !== 'R11' || contract.preservedNotApplied.join(',') !== 'R12,R13' || contract.frozenContactRevision !== 'R10') throw new Error('Identidad, baseline o exclusiones del contrato GB02 R03 incorrectas.');
if (!sourceText.includes("APP_VERSION='37.0.0-graybox-gb02-r03-candidate-r14'") || !sourceText.includes("LOG_VERSION='GB02-R03-v1'") || !gradle.includes('versionCode = 38') || !gradle.includes('versionName = "37.0.0-graybox-gb02-r03-candidate-r14"')) throw new Error('Versionado R14 desalineado.');

const tuning = api.getTuning(), contact = api.getContact();
if (tuning.walk !== 3.5 || tuning.run !== 6 || tuning.jump !== 15.9 || tuning.gravityUp !== 36 || tuning.gravityDown !== 44) throw new Error('La física/locomoción congelada R10 cambió.');
if (contact.actorInsetPx !== 10 || contact.propInsetPx !== 6 || contact.collidersChanged !== false || contact.physicsChanged !== false) throw new Error('El contacto visual R10 cambió.');

const world = api.getSim().world;
const exactSolids = {
  G4: [36.5, 0, 9, 2], U4: [43, 4.5, 2.5, .5], G5: [45.5, 0, 6, 2], TUNEL_TECHO_1: [45.5, 3.5, 6, .5],
  G6: [55.5, 0, 9, 2], U5: [57, 3.5, 1.5, .5], U6: [59, 5, 2, .5], BARRERA_GB02: [42.5, 2, 1, 5],
};
for (const [id, expected] of Object.entries(exactSolids)) {
  const solid = world.solids.find(item => item.id === id);
  if (!solid || [solid.x, solid.y, solid.w, solid.h].some((value, index) => value !== expected[index])) throw new Error(`Geometría contractual incorrecta: ${id}.`);
}
if (world.maxX !== 64.5 || world.maxY !== 12 || world.bridgePlate.x !== 49.5 || world.goalZone.x !== 62.5 || world.goalZone.w !== 2 || world.star.bounds.x !== 59.5 || world.star.bounds.y !== 5.5) throw new Error('Límites u objetivos GB02 incorrectos.');
if (!sourceText.includes("drawWorldArtToCollider(ctx,worldArt.boxIntact,solid,draw") || !sourceText.includes("'G0','G1','G2','G3','U0_VERTICAL','TECHO_BAJO','U1','U2','U3'")) throw new Error('La congruencia caja–pilar–collider o la separación de arte heredado no está fijada.');

for (const [width, height, expectedW] of [[1200, 900, 19.2], [1920, 1080, 19.2], [2520, 1080, 25.2], [3840, 1080, 38.4]]) {
  const view = api.viewportWorldSize(width, height);
  if (Math.abs(view.w - expectedW) > 1e-9 || view.h !== 10.8) throw new Error(`Viewport incorrecto para ${width}:${height}.`);
}
if (!sourceText.includes('scale=bounds.width/viewport.w') || !sourceText.includes('const draw={scale,ox:0') || sourceText.includes('bounds.width-VIEW.w*scale')) throw new Error('El render no ocupa todo el ancho con escala uniforme.');

api.reset('qa_postura_baja');
let sim = api.getSim();
Object.assign(sim.eren, { x: 4.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
api.step({ crouch: true });
if (sim.eren.crouched || sim.eren.w !== 1 || sim.eren.h !== 1.5) throw new Error('ABAJO activó postura baja sin restricción real.');
sim.boxBroken = true; api.rebuildWorld();
Object.assign(sim.eren, { x: 5.55, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
api.step({ right: true, crouch: true });
if (!sim.eren.crouched || sim.eren.w !== 1.5 || sim.eren.h !== 1 || !sim.events.some(event => event.type === 'agacharse' && event.reason === 'LOW_CLEARANCE')) throw new Error('La restricción LOW_CLEARANCE real no activó el perfil aprobado de Eren.');
Object.assign(sim, { coopUnlocked: true, enemyHp: 0, enemyState: 'defeated', enemyDefeated: true, barrierOpen: true, ladderEnabled: true, scarReleased: true }); api.rebuildWorld();
Object.assign(sim.eren, { x: 46.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
api.step({ right: true, crouch: true });
if (sim.eren.crouched || !api.canFit(sim.eren, 1, 1.5, sim.world.solids)) throw new Error('El túnel transitable de 1,5 m fuerza postura baja falsa.');
Object.assign(sim.scar, { x: 12.6, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 12.6 });
for (let i = 0; i < 20; i++) api.step({});
if (sim.scar.crouched || sim.scar.w !== 1.5 || sim.scar.h !== 1 || sim.events.some(event => event.type === 'scar_paso_bajo_inicio')) throw new Error('Scar todavía usa un collider bajo falso.');

api.reset('qa_enemigo_consecuencia'); sim = api.getSim();
sim.coopUnlocked = true; api.rebuildWorld();
Object.assign(sim.eren, { x: 40.5, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0 });
Object.assign(sim.scar, { x: 38, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 38 });
for (let i = 0; i < 30; i++) api.step({});
if (sim.enemyState !== 'alert' || sim.eren.hearts !== 3 || sim.events.some(event => event.type === 'daño')) throw new Error(`Alerta de 0,45 s o ausencia de daño pasivo incorrecta: ${JSON.stringify({state:sim.enemyState,elapsed:sim.enemyAlertElapsed,hearts:sim.eren.hearts,x:sim.eren.x,y:sim.eren.y,damage:sim.events.filter(event=>event.type==='daño')})}`);
api.step({ action: true }); api.step({}); api.step({ action: true }); api.step({});
if (!sim.enemyDefeated || sim.enemyHp !== 0 || !sim.barrierOpen || !sim.ladderEnabled || !sim.scarReleased || sim.world.solids.some(item => item.id === 'BARRERA_GB02')) throw new Error('El enemigo 2 HP no aplicó todas sus consecuencias.');
const atomicEvents = ['enemigo_derrotado', 'barrera_gb02_retirada', 'escalera_gb02_habilitada', 'scar_gb02_liberado'].map(type => sim.events.find(event => event.type === type));
if (atomicEvents.some(event => !event) || new Set(atomicEvents.map(event => event.time)).size !== 1 || new Set(atomicEvents.map(event => event.atomicTime)).size !== 1) throw new Error('Las consecuencias del enemigo no fueron atómicas.');

Object.assign(sim.scar, { x: 50.25, y: 2, vx: 0, vy: 0, onGround: true, mode: 'follow', waitX: null, bridgeWait: false, recoverTimer: 0, traversal: null });
Object.assign(sim.eren, { x: 53, y: 1.6, vx: 0, vy: 0, onGround: false, recover: 0, invuln: 0 });
api.step({});
if (!sim.bridgePlateLatched || sim.bridgeState !== 'pending_empty' || sim.world.solids.some(item => item.id === 'PUENTE_1')) throw new Error('El puente no esperó la zona ocupada sin collider.');
Object.assign(sim.eren, { x: 47, y: 2, vx: 0, vy: 0, onGround: true });
api.step({});
if (sim.bridgeState !== 'deploying' || sim.world.solids.some(item => item.id === 'PUENTE_1')) throw new Error('El despliegue no comenzó vacío y sin collider.');
for (let i = 0; i < 34; i++) api.step({});
if (sim.world.solids.some(item => item.id === 'PUENTE_1')) throw new Error('El collider apareció antes de 0,6 s.');
for (let i = 0; i < 3; i++) api.step({});
if (sim.bridgeState !== 'solid' || !sim.world.solids.some(item => item.id === 'PUENTE_1') || sim.scar.bridgeWait || sim.scar.mode !== 'follow') throw new Error('El puente no quedó sólido, permanente y con Scar reanudado.');

const routeRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  api.reset(`qa_ruta_scar_${repetition}`); const run = api.getSim();
  Object.assign(run, { coopUnlocked: true, enemyHp: 0, enemyState: 'defeated', enemyDefeated: true, barrierOpen: true, ladderEnabled: true, scarReleased: true, bridgePlateLatched: true, bridgeState: 'solid', bridgeDeployElapsed: .6 });
  api.rebuildWorld();
  Object.assign(run.eren, { x: 63.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', waitX: null, bridgeWait: false, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0, ignoredSupportId: null });
  let minY = run.scar.y, maxY = run.scar.y;
  for (let frame = 0; frame < 720 && !run.complete; frame++) { api.step({}); minY = Math.min(minY, run.scar.y); maxY = Math.max(maxY, run.scar.y); }
  const routeEvents = run.events.filter(event => event.type.startsWith('scar_salto') || event.type === 'scar_recuperacion');
  const metaEvents = run.events.filter(event => event.type === 'meta');
  if (!run.complete || routeEvents.length || metaEvents.length !== 1 || Math.abs(minY - 2) > .001 || Math.abs(maxY - 2) > .001 || run.scar.crouched) throw new Error(`Ruta segura de Scar falló en repetición ${repetition}.`);
  routeRuns.push({ repetition, frames: Math.round(run.elapsed * 60), jumps: 0, recoveries: 0, minY, maxY, complete: true });
}

api.reset('qa_meta_llamada_fisica'); sim = api.getSim();
Object.assign(sim, { coopUnlocked: true, enemyHp: 0, enemyState: 'defeated', enemyDefeated: true, barrierOpen: true, ladderEnabled: true, scarReleased: true, bridgePlateLatched: true, bridgeState: 'solid' }); api.rebuildWorld();
Object.assign(sim.eren, { x: 63.5, y: 2, vx: 0, vy: 0, onGround: true, recover: 0, invuln: 0 });
Object.assign(sim.scar, { x: 40, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 40, bridgeWait: false, recoverTimer: 0, recoveryGrace: 0, traversal: null });
const scarStartX = sim.scar.x;
for (let i = 0; i < 125; i++) api.step({});
const call = sim.events.find(event => event.type === 'meta_llamada_scar');
if (!call || call.afterSeconds !== 2 || call.teleport !== false || sim.scar.mode !== 'follow' || sim.scar.x <= scarStartX || sim.events.some(event => event.type === 'scar_recuperacion')) throw new Error('La meta no llamó a Scar por ruta física tras 2 s.');

get('playLab').click();
if (api.getSim().scene !== 'lab' || get('labControls').classList.contains('hidden')) throw new Error('Laboratorio QA_ONLY no abrió en modo QA.');
stations.find(item => item.dataset.station === 'E').click();
if (api.getSim().station !== 'E' || !get('labObjective').textContent.includes('puente')) throw new Error('La estación E no expone su objetivo.');
get('labNext').click();
if (api.getSim().station !== 'A') throw new Error('Siguiente no recorre A–E de forma cíclica.');
get('labExit').click();
if (api.getSim().scene !== 'graybox') throw new Error('Salir no vuelve a GB02.');

if (!css.includes('.station-buttons{display:grid;grid-template-columns:repeat(5,1fr)') || !css.includes('.qa-only.hidden{display:none!important}')) throw new Error('La UI QA A–E o su ocultación normal no está fijada.');

const result = {
  result: 'PASS', contract: contract.id, sha256: contract.sha256, baseline: contract.baseline,
  preservedNotApplied: contract.preservedNotApplied, frozen: { locomotion: true, jump: true, physics: true, contactR10: true },
  viewport: ['4:3', '16:9', '21:9', '32:9'], lowPostureOnlyReal: true, scarNormalCollider: [1.5, 1],
  enemyConsequencesAtomic: true, bridgeDeploySeconds: .6, bridgeColliderDuringDeploy: false,
  scarSafeRouteRuns: routeRuns.length, scarSafeRouteFailures: 0, dualGoalPhysicalCallSeconds: 2,
  qaOnlyLab: { normalBuildHidden: true, stations: 'A-E' }, tilesetIntegrated: false,
};
const evidenceDir = process.env.GB02_EVIDENCE_DIR;
if (evidenceDir) {
  await mkdir(evidenceDir, { recursive: true });
  const generatedAt = new Date().toISOString();
  await writeFile(`${evidenceDir}/GB02_R03_QA_MATRIX.json`, `${JSON.stringify({
    schema: 'EREN_GB02_R03_QA_MATRIX_V1', generatedAt, appVersion: '37.0.0-graybox-gb02-r03-candidate-r14',
    contract: { id: contract.id, sha256: contract.sha256, baseline: contract.baseline, preservedNotApplied: contract.preservedNotApplied },
    result: 'PASS', checks: result,
  }, null, 2)}\n`);
  await writeFile(`${evidenceDir}/SCAR_RUTA_SEGURA_GB02_R03_20_REPETICIONES.json`, `${JSON.stringify({
    schema: 'SCAR_SAFE_ROUTE_GB02_R03_V1', generatedAt, contractSha256: contract.sha256,
    nominalRoute: { fromX: 36.8, toGoalX: 63.5, surfaceY: 2, bridge: 'PUENTE_1_SOLID', jumpsRequired: false, teleportsAllowed: false, hazards: false },
    repetitions: routeRuns.length, results: routeRuns,
    summary: { completions: routeRuns.filter(run => run.complete).length, jumps: 0, recoveries: 0, failures: 0, result: 'PASS' },
  }, null, 2)}\n`);
}
console.log(JSON.stringify(result));
