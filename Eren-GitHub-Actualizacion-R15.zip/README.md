# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 38.0.0 · candidata GB02 R04 · revisión R15

R15 corrige las condiciones del playtest Android R14 sobre `GB02_R03_APPROVED` (SHA-256 `dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4`). Mantiene R11 como baseline funcional, preserva sin aplicar R12/R13 y congela locomoción, salto y contacto R10 fuera de los estados locales autorizados.

Incluye:

- guardián ofensivo con patrulla, alerta, persecución, anticipación, embestida baja esquivable, daño e impacto;
- golpe temporizado de Eren y derrota a 2 HP con las tres consecuencias atómicas heredadas;
- trepa de escalera con agarre, subida, bajada y salida superior; solo U4 se ignora durante ese estado;
- U4 alineada con el extremo de la escalera y salida estable sobre su superficie;
- paso de 0,75 m exclusivo de Scar, con perfil bajo real solo mientras existe la restricción;
- placa del puente bloqueada hasta que el jugador pulse SCAR dentro de la zona contextual;
- telemetría R15 para ataques, esquivas, daño, trepa, orden, paso bajo, enclavamiento y meta;
- Laboratorio `QA_ONLY`, viewport panorámico, HUD de tres casillas y meta dual heredados.

Los estados nuevos usan fallbacks graybox animados. No se inventan PNG: continúan pendientes `CANDIDATE_PLAYTEST_R02` para corregir la alternancia de piernas de Eren y los lotes finales de agachado, golpe, escalera y guardián. No se integra tileset.

La validación automatizada se ejecuta con `node tests/gb02-r04-smoke.mjs` y `node tests/hud-hearts-r11-smoke.mjs`.

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
