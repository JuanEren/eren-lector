plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 39
        versionName = "38.0.0-graybox-gb02-r04-candidate-r15"
    }
}
