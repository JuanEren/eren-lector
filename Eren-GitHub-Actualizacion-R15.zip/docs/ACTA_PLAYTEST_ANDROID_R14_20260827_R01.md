# ACTA DE PLAYTEST ANDROID · R14 · 27/08/2026

Estado: **PASS_WITH_CONDITIONS · BASE_FUNCIONAL_ACEPTADA · CORRECCION_R15_OBLIGATORIA · GAME_READY=false**

## Identidad probada

- Aplicación: `37.0.0-graybox-gb02-r03-candidate-r14`.
- Registro: `GB02-R03-v1`.
- Dispositivo: Samsung Galaxy S24 Ultra, Android 16, viewport 891×411 CSS px, DPR 3,5.
- Contrato heredado: `GB02_R03_APPROVED`, SHA-256 `dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4`.
- Fuente de implementación: `Eren-GitHub-Actualizacion-R14.zip`, SHA-256 `12c774e8713f76257a9f3e0e062d5998ba54151d17ae7cee0c3e749d0f1e3d1d`.

## Resultado observado

Se recibieron cuatro intentos. Tres completaron GB02 con reunión física de Eren y Scar; el cuarto fue una exploración parcial. Los tiempos completos fueron 125,60 s, 46,67 s y 106,73 s. En los tres cierres completos constan derrota del guardián, despliegue del puente y reunión dual.

| Comprobación R14 | Resultado |
|---|---|
| Viewport panorámico a ancho completo | PASS |
| Postura baja solo ante restricción real | PASS técnico; falta un uso obligatorio de Scar |
| Caja, pilar, representación y collider congruentes | PASS |
| Transitabilidad dual por rutas autorizadas | PASS con corrección de diseño del puente |
| Consecuencias visibles del guardián y la placa | PASS |
| Ruta de Scar sin teletransporte obligatorio | PASS de usuario |
| Laboratorio oculto en build normal | PASS |
| Meta dual sin softlock | PASS |

## Condiciones obligatorias para R15

1. El guardián dejará de ser un objetivo inmóvil: patrulla, alerta, persigue, anticipa y ejecuta un ataque esquivable mediante salto o separación. Solo su ventana ofensiva causa daño.
2. El ataque de Eren tendrá estado, ventana y feedback propios; se mantienen 2 HP del guardián y las consecuencias atómicas al derrotarlo.
3. La escalera usará un estado de trepa. Dentro de su corredor no se resolverá la plataforma superior como obstáculo lateral/techo; la salida termina apoyada encima de U4.
4. U4 se extiende hasta el extremo de la escalera para que representación y geometría coincidan.
5. Scar no enclava la placa del puente por mera presencia. Antes debe existir una orden contextual del botón Scar.
6. La placa queda tras un paso de 0,75 m de luz: Eren no cabe ni agachado; Scar debe adoptar perfil bajo real y recupera su perfil normal al salir.
7. Eren puede saltar el hueco del puente; eso no abre el paso ni permite completar la ruta obligatoria de Scar.
8. Se añaden estados visuales funcionales para trepa, agachado, golpe y guardián. Los fotogramas artísticos definitivos siguen pendientes y no se simulará su existencia en el manifiesto.

## Evidencias visuales

- `docs/evidencias-r15/playtest-r14/01-1000503585.jpg` · SHA-256 `66777522ddcf381f87d6efa256587cd3d1d53880b7d579a8201fa4aba1dfcb3c`.
- `docs/evidencias-r15/playtest-r14/02-1000503583.jpg` · SHA-256 `76835c6bb04b2399962b656413102c21273e9d44f734b644ab8d00bf387008d6`.
- `docs/evidencias-r15/playtest-r14/03-1000503581.jpg` · SHA-256 `443b30e2ea168ea8296ad9e26af556081aca3f51944e799c436792c4309bb498`.
- `docs/evidencias-r15/playtest-r14/04-1000503587.jpg` · SHA-256 `94cf22a4cabccd463a276e94bcbd0839242110ba3748835ca3fa399647a713ea`.

Las capturas 02 y 03 muestran a Eren intersectando la cara inferior/salida de U4 y la escalera parcialmente fuera de la plataforma. La secuencia del registro muestra `placa_puente_scar_enclavada` sin una orden contextual previa en GB02, lo que confirma la activación automática.
