# CONTRATO CORRECTIVO · GB02 R04 · CANDIDATA R15

ID: `GB02_R04_PLAYTEST_CORRECTION`  
Base: `R14_ANDROID_PASS_WITH_CONDITIONS` sobre baseline funcional R11  
Estado: `AUTHORIZED_BY_PLAYTEST_CONDITIONS · IMPLEMENTATION_CANDIDATE · GAME_READY=false`

## Invariantes heredadas

- Locomoción: caminar 3,5 m/s y correr 6 m/s.
- Salto de Eren: impulso 15,9 m/s; gravedad ascendente 36 y descendente 44; terminal −16.
- Contacto visual R10: actores +10 px, utilería +6 px; colliders y terreno heredados sin mutación global.
- Viewport: altura 10,8; ancho `max(19,2; 10,8 × aspecto)`.
- R12/R13 preservadas y no aplicadas.
- Laboratorio `QA_ONLY`; meta dual física; consecuencias atómicas del guardián; puente sin collider durante despliegue.

## C1 · Guardián ofensivo

| Parámetro | Valor R15 |
|---|---:|
| HP | 2 |
| Carril de patrulla | x=38,2–41,8 |
| Velocidad de patrulla | 1,25 m/s |
| Velocidad de persecución | 2,35 m/s |
| Alerta inicial | 0,45 s |
| Anticipación del golpe | 0,45 s |
| Embestida | 0,30 s a 5,2 m/s |
| Ventana activa | 0,10–0,24 s de la embestida |
| Altura del hitbox | 0,85 m desde el suelo |
| Recuperación | 0,50 s |
| Invulnerabilidad de Eren tras impacto | 1,00 s |
| Ataque de Eren | 0,10 s de anticipación; alcance 1,45 m; recuperación total 0,32 s |

El contacto corporal pasivo no daña. Saltar por encima de 0,85 m o salir del alcance evita la ventana. Cada intento ofensivo registra inicio, ventana, impacto o esquiva y recuperación.

## C2 · Escalera y U4

- Escalera visual: `[42,5; 1,5; 1; 3,5]`, centro x=43 y extremo superior y=5.
- U4: `[42,5; 4,5; 3; 0,5]`, extendida hasta el extremo izquierdo de la escalera.
- Captura: arriba dentro del volumen `[42; 2; 2; 3]`.
- Estados: `agarre`, `subida`, `bajada`, `salida_superior`, `suelta`.
- Velocidad de trepa: 3,2 m/s. Salida superior: 0,38 s hacia `(43,65; 5)`.
- Mientras existe un estado de trepa, solo U4 se excluye de la resolución del cuerpo de Eren dentro del corredor. El resto del mundo sigue sólido.
- Al terminar, Eren queda sobre U4, con gravedad y control R10 restaurados.

## C3 · Paso bajo exclusivo de Scar

- Techo `TUNEL_BAJO_SCAR`: `[45,5; 2,75; 4; 0,5]`.
- Luz libre: 0,75 m.
- Eren de pie (1,5 m) y agachado (1 m) queda bloqueado.
- Scar normal (1 m) queda bloqueada y cambia a perfil bajo `1,5×0,65 m` solo si el perfil bajo cabe realmente.
- Scar recupera `1,5×1 m` al salir y solo si hay espacio.
- En el paso bajo no salta, no se recupera y no teletransporta.

## C4 · Orden contextual del puente

- Antes de una orden válida, Scar espera ante el túnel y la presencia sobre la placa no puede enclavarla.
- Una pulsación del botón Scar con Eren en la zona contextual x=43,5–51,5 registra `scar_orden_puente` y envía a Scar a la placa.
- La placa solo se enclava si `bridgeCommanded=true`, Scar está en `bridge_marker`, se apoya en G5 y solapa la placa.
- Después se conserva el despliegue R14: espera zona libre, 0,6 s sin collider y estado sólido permanente.
- El salto de Eren sobre el agua no cambia `bridgeCommanded`, `bridgePlateLatched` ni `bridgeState`.

## C5 · Estados visuales y arte

R15 implementa estados de runtime y fallbacks graybox animados para:

- Eren: postura baja, desplazamiento bajo, ataque, agarre/trepa/salida de escalera e impacto.
- Scar: postura baja y desplazamiento bajo.
- Guardián: patrulla, alerta, persecución, anticipación, embestida, impacto, recuperación y derrota.

No se añaden PNG inexistentes. `CANDIDATE_PLAYTEST_R02` continúa pendiente para corregir alternancia de piernas de Eren y aportar fotogramas finales. El guardián, golpe y escalera requieren un lote artístico nuevo con manifiesto propio antes de una candidata gráfica.

## Criterios de aceptación

1. 20/20 subidas completas sin atasco, penetración residual ni desactivación global de U4.
2. 20/20 rutas de Scar: una orden, un paso bajo, un enclavamiento, cero saltos/recuperaciones/teletransportes entre G4 y G6.
3. 0/20 enclavamientos sin orden del botón Scar.
4. Eren bloqueado 20/20 bajo el túnel tanto de pie como agachado.
5. El guardián ejecuta al menos un ataque; una prueba recibe daño y otra lo esquiva por salto.
6. Dos golpes válidos de Eren derrotan al guardián; barrera, escalera y liberación comparten tiempo atómico.
7. Viewport, caja/pilar, Laboratorio oculto, HUD, meta dual, R10 y exclusión de R12/R13 siguen pasando.

