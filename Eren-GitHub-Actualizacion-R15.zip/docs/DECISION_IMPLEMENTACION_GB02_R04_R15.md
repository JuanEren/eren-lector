# Decisión de implementación · GB02 R04 · R15

Fecha: 27/08/2026  
Reserva: `CODEX-GB02-R14-PLAYTEST-R15-CORRECTION-20260827-R01`  
Estado: `SOURCE_CANDIDATE_QA_PASS · APK_PENDING_CI_AND_DEVICE_PLAYTEST · GAME_READY=false`

## Base verificada

- Playtest R14: `PASS_WITH_CONDITIONS` sobre `37.0.0-graybox-gb02-r03-candidate-r14`.
- Contrato padre: `GB02_R03_APPROVED`, SHA-256 `dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4`.
- Contrato correctivo: `GB02_R04_PLAYTEST_CORRECTION`, SHA-256 `02692ced658695b7e5ce95d9b1709448835b16427812e8393c61bc67466e6055`.
- Baseline funcional: R11. R12/R13 se preservan y no se aplican.
- Locomoción, salto y contacto R10 permanecen congelados fuera de los estados locales autorizados.

## Implementado

1. Guardián ofensivo: patrulla, alerta, persecución, anticipación, embestida baja, impacto, recuperación y daño con invulnerabilidad de Eren.
2. Golpe de Eren temporizado; dos impactos válidos mantienen las consecuencias atómicas heredadas.
3. Escalera con agarre, subida, bajada, suelta y salida superior. Solo U4 se ignora durante la trepa; al terminar vuelve a ser sólido.
4. U4 extendida hasta el extremo superior de la escalera.
5. Túnel de 0,75 m exclusivo de Scar: Eren no cabe; Scar adopta `1,5×0,65` solo ante la restricción y restaura `1,5×1` al salir.
6. La placa del puente requiere una orden contextual del botón Scar. La mera presencia queda bloqueada y registrada.
7. Ruta del puente reservada como tránsito terrestre de Scar, sin salto anticipatorio ante el techo.
8. Estados visuales graybox animados y telemetría para combate, golpe, impacto, postura baja, trepa y orden cooperativa.

## Arte pendiente declarado

No se han inventado fotogramas PNG. Continúan pendientes:

- `CANDIDATE_PLAYTEST_R02` para corregir la alternancia de piernas de Eren;
- lotes finales de agachado de Eren y Scar;
- golpe de Eren, escalera y guardián.

Los fallbacks actuales permiten validar funcionamiento y sensaciones, pero no constituyen arte final.

## Límites

Sin merge a main, borrados, release, reintentos del conector GitHub ni integración de tileset. La APK queda pendiente del workflow manual suministrado y de su playtest Android.
