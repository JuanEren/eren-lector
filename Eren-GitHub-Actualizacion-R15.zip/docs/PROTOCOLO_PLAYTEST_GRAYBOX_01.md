# Protocolo breve de playtest · GB01

## Objetivo

Decidir si movimiento, salto, cámara, colliders, Scar y retorno son suficientemente claros y agradables antes de montar el Nivel 1 completo o aplicar arte final.

## Preparación

- Probar en el dispositivo Android habitual y en horizontal.
- Hacer primero una pasada con controles táctiles y después otra con mando.
- Mantener los valores iniciales durante la primera pasada.
- No explicar la solución salvo bloqueo de más de 20 segundos.

## Pasada 0 · locomoción E1/S1 y salto E2/S2 candidatos

1. En suelo seguro, observar dos ciclos completos de reposo de Eren y Scar mirando a derecha e izquierda.
2. Caminar a ambos lados con Eren; después mantener Correr y repetir. Confirmar apoyo plantar, ausencia de recorte y que el arte no modifica la aceleración ni la frenada.
3. Alejar a Scar para provocar andar, correr y velocidad de alcance. Observar cambios de estado y seguimiento en ambos sentidos sin reescalado aparente.
4. Probar con Eren salto vertical, hacia delante y corriendo; repetir el salto y seguimiento de Scar. Verificar `impulso-00 → impulso-01`, subida hasta el ápice, caída y `aterrizaje-00 → aterrizaje-01` sobre suelo y plataformas, en ambos sentidos. El paso bajo conserva deliberadamente su placeholder; nunca debe reutilizar carrera.
5. Activar colliders: el marco amarillo representa el lienzo artístico completo y el cian el collider externo. Ambos deben conservar el mismo pivote inferior central también durante impulso, subida, caída y aterrizaje.
6. Repetir con controles táctiles y con mando. No ajustar física, geometría ni escala de fotogramas durante esta pasada; cualquier deslizamiento se contrasta primero con timings y umbrales.

## Pasada 1 · Graybox 01

1. Caminar, frenar y cambiar de sentido en la primera plataforma.
2. Intentar saltar la entrada y golpear su parte gris: `U0_VERTICAL` debe permanecer. Romper solo la caja marrón inferior con `ACCIÓN`, comprobar que de pie aún bloquea y atravesar la abertura agachado.
3. Probar G0→G1 primero andando sin saltar —debe caer— y después con salto corto y salto mantenido; ambos saltos deben disponer de un aterrizaje natural antes de `TECHO_BAJO`.
4. Pasar agachado bajo el techo de 1 módulo.
5. Leer «Scar, activa la placa» y usar el botón `SCAR`.
   - Repetir una vez con Scar detrás del túnel y otra con Scar sobre la plataforma superior.
   - La orden solo es correcta si termina físicamente sobre la huella de la ruta inferior y la placa cambia a verde.
6. Probar el enclavamiento cooperativo antes de cruzar el agua:
   - Activar primero la palanca de G2 sin Scar: debe mostrar `LISTA`, pero la compuerta permanece cerrada; enviar después a Scar y comprobar que abre.
   - Reiniciar y resolver en el orden contrario: activar primero la placa con Scar, llamarla para que se marche y accionar después la palanca; debe abrir de la misma forma.
   - Comprobar que una sola pisada enclava la placa: marcharse no la libera ni exige volver a activarla.
   - Intentar saltar, trepar o rodear la compuerta cerrada desde G2, U1, U2 y U3; no debe existir *bypass*, coronación ni activación de R2.
7. Probar por separado la ruta baja G1→G2 y la ruta alta U1→U2→U3. G1→G2 no debe poder cruzarse andando, pero sí con un salto normal desde apoyo completo; ambas rutas deben converger antes de la palanca y conservar la estrella como recompensa opcional.
   - Con Scar en G2 y Eren a la izquierda, pulsar `SCAR`: debe volver a G1 con un salto bajo y cruzar gateando bajo U1/`TECHO_BAJO`, sin subir a U1.
8. Una vez abierta la compuerta, pulsar `SCAR` para llamar a Scar, cruzar el agua con `CORRER + SALTAR` y observar si Scar ejecuta su salto largo sin caer ni desaparecer.
9. Saltar las dos puntas andando y comprobar que existe margen visible. En otro intento, tocarlas deliberadamente una vez para comprobar daño y retorno.
10. Alcanzar la meta y comprobar que la celebración espera a que Scar llegue a G3.

Registrar especialmente:

- Si Eren se siente pesado, controlado o nervioso.
- Si el salto parece corto, correcto o flotante.
- Si la cámara anticipa bien sin marear.
- Si se entiende qué hace el botón de Scar.
- Si se descubre sin explicación oral que la placa de Scar y la palanca de Eren son necesarias y pueden completarse en cualquier orden.
- Si el rombo derecho se reconoce sin explicación: Scar azul arriba, Correr verde izquierda, Acción roja derecha y Saltar amarillo abajo.
- Si el retorno tras daño es inmediato y no frustrante.

## Pasada 2 · Laboratorio

- `A`: comparar andar/correr, frenada y giro.
- `B`: variar el desnivel entre 1,5 y 4 módulos.
- `C`: variar el hueco entre 1 y 5 módulos.
- `D`: comprobar caja, techo de pie y techo agachado.
- `E`: observar a Scar en superficies de distinta altura.
- `F`: repetir agua, pinchos y retorno.

Usar `Ajuste vivo de sensaciones` para modificar una sola variable cada vez. Tras cada cambio, reiniciar la estación y repetir exactamente la misma acción.

## Criterio de salida

No se aprueba el Nivel 1 completo hasta que:

- no haya enganches visibles de collider;
- el hueco obligatorio de 4 módulos falle andando y sea fiable corriendo;
- la caja inferior no pueda omitirse, `U0_VERTICAL` permanezca tras romperla, el paso exija agacharse y los dos pinchos puedan saltarse andando sin una salida o aterrizaje al límite;
- G0→G1 y G1→G2 exijan saltar sin pedir una salida al límite y U1→U2→U3 siga siendo una ruta válida y legible;
- la palanca pueda quedar lista sin Scar pero no abra por sí sola, ambos órdenes resuelvan el puzle, la compuerta cerrada selle desde todos los apoyos alcanzables, R2 permanezca bloqueado y la apertura quede enclavada;
- Scar complete la prueba sin copiar la altura de Eren;
- Scar vuelva de G2 por G1 y el paso bajo sin subir a U1 ni encadenar saltos erráticos;
- Scar atraviese el agua 10/10 veces con el enlace contextual y cero recuperaciones por agua;
- daño y retorno devuelvan control en menos de 1 segundo;
- cruceta, correr y saltar admitan pulsación simultánea;
- el jugador pueda terminar el tramo sin explicación externa.

El botón `Compartir registro` guarda la sesión en el dispositivo y abre el menú nativo de Android para enviarla. `Ver registro` permite copiar el JSON completo o un resumen compacto para ChatGPT. El registro conserva hasta diez intentos con actividad —excluye aperturas vacías del visor— e incluye ajustes, métricas, orden de resolución, activación/liberación de placa, palanca, apertura de compuerta, bloqueos de bypass, retorno bajo de Scar, salto largo, recuperación, reunión en meta, estados finales y eventos temporales.

Desde R15 el resumen añade ataques, impactos y esquivas del guardián; golpes válidos o fallidos de Eren; agarre y salida superior de escalera; bloqueo del túnel para Eren; orden contextual de Scar; entrada/salida del perfil bajo; bloqueo de enclavamiento sin orden; y despliegue del puente. Estos eventos permiten distinguir una ruta física válida de una activación automática o una recuperación.
