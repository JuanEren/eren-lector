import vm from 'node:vm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('game.css', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');

const PARENT_CONTRACT_SHA = 'dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4';
const R15_CONTRACT_SHA = '02692ced658695b7e5ce95d9b1709448835b16427812e8393c61bc67466e6055';
const idleInput = { left: false, right: false, up: false, crouch: false, run: false, jump: false, action: false, scar: false };

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id; this.dataset = {}; this.classList = new ClassList(); this.listeners = new Map();
    this.style = {}; this.textContent = ''; this.innerHTML = ''; this.value = ''; this.offsetWidth = 10;
    this.attributes = new Map(); this.disabled = false; this.width = 0; this.height = 0;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, pointerId: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  closest(selector) { return selector === 'button' ? this : null; }
}

function createHarness({ qaOnly, width = 1920, height = 1080 }) {
  const exportedSource = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={
 getSim:()=>sim,
 reset:reason=>resetSimulation(reason),
 step:(input={},dt=FIXED_DT)=>physicsStep(dt,{...${JSON.stringify(idleInput)},...input}),
 buildGraybox,
 rebuildWorld,
 viewportWorldSize,
 currentViewportWorldSize,
 lowClearanceConstraint,
 scarLowClearanceConstraint,
 canFit,
 bodyRect,
 overlaps,
 supportingSolid,
 commandScar,
 updateGb02,
 enemyAttackRect,
 actorInGoalZone,
 getTuning:()=>({...tuning}),
 getContract:()=>JSON.parse(JSON.stringify(GB02_CONTRACT)),
 getContact:()=>JSON.parse(JSON.stringify(VISUAL_CONTACT_PLANE)),
 getTestMode:()=>TEST_MODE,
 setScene,
 render
};
})();`);

  const elements = new Map();
  for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
  const get = id => elements.get(id);
  const controlMap = {
    moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
    moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
  };
  for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
  for (const [id, value] of Object.entries({ walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;
  const stations = [...html.matchAll(/data-station="([A-Z])"/g)].map(match => { const element = new Element(); element.dataset.station = match[1]; return element; });
  const body = new Element('body');
  const document = {
    body,
    getElementById: id => get(id),
    querySelectorAll: selector => selector === '[data-controls]' ? [...elements.values()].filter(element => element.dataset.controls) : selector === '[data-station]' ? stations : [],
    createElement: () => new Element(),
    addEventListener() {},
    execCommand: () => true,
  };
  const gradient = { addColorStop() {} };
  const context2d = new Proxy({ createLinearGradient: () => gradient }, {
    get(target, key) { if (key in target) return target[key]; return () => {}; },
    set(target, key, value) { target[key] = value; return true; },
  });
  get('gameCanvas').getContext = () => context2d;
  get('gameCanvas').getBoundingClientRect = () => ({ width, height });
  const storage = new Map();
  const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
  const listeners = new Map();
  const window = {
    document, devicePixelRatio: 1, innerWidth: width, innerHeight: height, __EREN_QA_ONLY__: qaOnly,
    addEventListener(type, callback) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(callback); },
    dispatchEvent(event) { for (const callback of listeners.get(event.type) || []) callback(event); },
    requestAnimationFrame() { return 1; }, cancelAnimationFrame() {},
  };
  class Image {
    constructor() { this.complete = false; this.naturalWidth = 0; this.naturalHeight = 0; this.decoding = ''; this._src = ''; }
    set src(value) { this._src = value; }
    get src() { return this._src; }
  }
  const sandbox = {
    window, document, navigator: { getGamepads: () => [], userAgent: 'GB02-QA' }, localStorage,
    requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
    setTimeout: callback => { callback(); return 1; }, clearTimeout() {}, console, Image,
    completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
    tone() {}, playAzureSequence() {}, renderMenu() {},
  };
  window.localStorage = localStorage;
  vm.createContext(sandbox);
  vm.runInContext(exportedSource, sandbox, { filename: 'graybox-game.js' });
  return { window, get, stations, body };
}


const stepFrames = (api, frames, input = {}) => { for (let frame = 0; frame < frames; frame++) api.step(input); };
const openGb02 = (api, sim) => {
  Object.assign(sim, {
    coopUnlocked: true, enemyHp: 0, enemyState: 'defeated', enemyDefeated: true,
    barrierOpen: true, ladderEnabled: true, scarReleased: true,
  });
  api.rebuildWorld();
};

const normalR15 = createHarness({ qaOnly: false });
if (normalR15.window.__grayboxTest.getTestMode() !== false) throw new Error('La build normal quedó en modo QA.');
if (!normalR15.get('playLab').classList.contains('hidden') || !normalR15.get('playLab').disabled || normalR15.get('playLab').getAttribute('aria-hidden') !== 'true') throw new Error('Laboratorio QA_ONLY visible o activable en build normal.');
normalR15.get('playLab').click();
if (normalR15.get('playLab').classList.contains('active')) throw new Error('La build normal permitió entrar al Laboratorio QA_ONLY.');

const qaR15 = createHarness({ qaOnly: true });
const apiR15 = qaR15.window.__grayboxTest;
qaR15.get('directGame').click();
if (!apiR15.getSim()) throw new Error('No se inició la simulación QA de GB02 R04.');
if (qaR15.get('playLab').classList.contains('hidden') || qaR15.get('playLab').disabled || qaR15.get('playLab').getAttribute('aria-hidden') !== 'false') throw new Error('La build QA no habilitó el Laboratorio QA_ONLY.');
if (qaR15.stations.map(item => item.dataset.station).join('') !== 'ABCDE') throw new Error('El laboratorio no contiene exactamente las estaciones A–E.');

const contractR15 = apiR15.getContract();
if (contractR15.id !== 'GB02_R04_PLAYTEST_CORRECTION' || contractR15.sha256 !== R15_CONTRACT_SHA || contractR15.parentId !== 'GB02_R03_APPROVED' || contractR15.parentSha256 !== PARENT_CONTRACT_SHA || contractR15.baseline !== 'R14_ANDROID_PASS_WITH_CONDITIONS' || contractR15.functionalBaseline !== 'R11') throw new Error('Identidad o cadena contractual R15 incorrecta.');
if (contractR15.preservedNotApplied.join(',') !== 'R12,R13' || contractR15.frozenContactRevision !== 'R10' || !contractR15.scarRoute.requiredLowPass || !contractR15.scarRoute.bridgeRequiresCommand) throw new Error('R15 no preserva exclusiones, contacto o ruta contractual.');
if (!sourceText.includes("APP_VERSION='38.0.0-graybox-gb02-r04-candidate-r15'") || !sourceText.includes("LOG_VERSION='GB02-R04-v1'") || !gradle.includes('versionCode = 39') || !gradle.includes('versionName = "38.0.0-graybox-gb02-r04-candidate-r15"')) throw new Error('Versionado R15 desalineado.');

const tuningR15 = apiR15.getTuning();
const contactR15 = apiR15.getContact();
if (tuningR15.walk !== 3.5 || tuningR15.run !== 6 || tuningR15.jump !== 15.9 || tuningR15.gravityUp !== 36 || tuningR15.gravityDown !== 44) throw new Error('La locomoción, salto o física congelada R10 cambió.');
if (contactR15.actorInsetPx !== 10 || contactR15.propInsetPx !== 6 || contactR15.collidersChanged !== false || contactR15.physicsChanged !== false) throw new Error('El contacto visual R10 cambió.');

const worldR15 = apiR15.getSim().world;
const solidsR15 = {
  G4: [36.5, 0, 9, 2], U4: [42.5, 4.5, 3, .5], G5: [45.5, 0, 6, 2],
  TUNEL_BAJO_SCAR: [45.5, 2.75, 4, .5], G6: [55.5, 0, 9, 2],
};
for (const [id, expected] of Object.entries(solidsR15)) {
  const solid = worldR15.solids.find(item => item.id === id);
  if (!solid || [solid.x, solid.y, solid.w, solid.h].some((value, index) => value !== expected[index])) throw new Error(`Geometría R15 incorrecta: ${id}.`);
}
if (worldR15.ladder.art.x !== 42.5 || worldR15.ladder.art.y + worldR15.ladder.art.h !== 5 || worldR15.ladder.topExit.x !== 42.5 || worldR15.bridgePlate.x !== 49.5 || worldR15.goalZone.x !== 62.5 || worldR15.goalZone.w !== 2) throw new Error('Escalera, placa o meta R15 desalineadas.');
if (!worldR15.lowClearanceVolumes.some(volume => volume.id === 'LOW_SCAR_BRIDGE' && volume.tag === 'SCAR_ONLY_LOW_CLEARANCE' && volume.h === .75)) throw new Error('Falta el paso bajo exclusivo de Scar.');
if (!sourceText.includes("drawWorldArtToCollider(ctx,worldArt.boxIntact,solid,draw") || !sourceText.includes("'G0','G1','G2','G3','U0_VERTICAL','TECHO_BAJO','U1','U2','U3'")) throw new Error('La congruencia caja–pilar–collider heredada no está fijada.');

for (const [width, height, expectedW] of [[1200, 900, 19.2], [1920, 1080, 19.2], [2520, 1080, 25.2], [3840, 1080, 38.4]]) {
  const view = apiR15.viewportWorldSize(width, height);
  if (Math.abs(view.w - expectedW) > 1e-9 || view.h !== 10.8) throw new Error(`Viewport incorrecto para ${width}:${height}.`);
}
if (!sourceText.includes('scale=bounds.width/viewport.w') || !sourceText.includes('const draw={scale,ox:0') || sourceText.includes('bounds.width-VIEW.w*scale')) throw new Error('El render no ocupa todo el ancho con escala uniforme.');

apiR15.reset('qa_posturas_r15');
let simR15 = apiR15.getSim();
Object.assign(simR15.eren, { x: 4.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
apiR15.step({ crouch: true });
if (simR15.eren.crouched) throw new Error('ABAJO activó postura baja de Eren sin restricción real.');
simR15.boxBroken = true; apiR15.rebuildWorld();
Object.assign(simR15.eren, { x: 5.55, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
apiR15.step({ right: true, crouch: true });
if (!simR15.eren.crouched || simR15.eren.w !== 1.5 || simR15.eren.h !== 1 || simR15.eren.visualState !== 'bajo') throw new Error('La restricción real heredada no activa el estado bajo de Eren.');
openGb02(apiR15, simR15);
const tunnelProbe = { x: 47, y: 2, w: 1, h: 1.5 };
if (apiR15.canFit(tunnelProbe, 1, 1.5, simR15.world.solids) || apiR15.canFit(tunnelProbe, 1.5, 1, simR15.world.solids) || !apiR15.canFit(tunnelProbe, 1.5, .65, simR15.world.solids)) throw new Error('La luz de 0,75 m no discrimina Eren de pie/agachado y Scar bajo.');

const ladderRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  apiR15.reset(`qa_escalera_r15_${repetition}`);
  const run = apiR15.getSim(); openGb02(apiR15, run);
  Object.assign(run.eren, { x: 43, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 38, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 38, recoverTimer: 0 });
  stepFrames(apiR15, 100, { up: true });
  const exits = run.events.filter(event => event.type === 'escalera_salida_superior_completa');
  const support = apiR15.supportingSolid(run.eren, run.world.solids);
  if (exits.length !== 1 || run.ladderState !== null || Math.abs(run.eren.x - 43.65) > .001 || Math.abs(run.eren.y - 5) > .001 || support?.id !== 'U4' || run.eren.ignoredSupportId !== null || run.events.some(event => event.type === 'escalera_suelta')) throw new Error(`Salida de escalera falló en repetición ${repetition}.`);
  ladderRuns.push({ repetition, exits: exits.length, x: run.eren.x, y: run.eren.y, support: support.id, ignoredSupportRestored: true });
}

apiR15.reset('qa_guardian_impacto'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'windup', enemyStateElapsed: 0, enemyX: 40.5, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 39.3, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
stepFrames(apiR15, 70);
if (simR15.eren.hearts !== 2 || !simR15.events.some(event => event.type === 'enemigo_ataque_inicio') || !simR15.events.some(event => event.type === 'enemigo_impacta_eren')) throw new Error('El guardián no ejecutó una ofensiva con daño.');

apiR15.reset('qa_guardian_esquiva'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'windup', enemyStateElapsed: 0, enemyX: 40.5, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 39.3, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
stepFrames(apiR15, 35, { jump: true }); stepFrames(apiR15, 35);
if (simR15.eren.hearts !== 3 || !simR15.events.some(event => event.type === 'enemigo_ataque_esquivado') || simR15.events.some(event => event.type === 'enemigo_impacta_eren')) throw new Error(`El salto no esquivó la ventana baja del guardián: ${JSON.stringify({hearts:simR15.eren.hearts,y:simR15.eren.y,state:simR15.enemyState,events:simR15.events.filter(event=>event.type.startsWith('enemigo_')||event.type==='salto')})}`);

apiR15.reset('qa_guardian_derrota'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'recover', enemyStateElapsed: 0, enemyX: 40.2, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 39.2, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
apiR15.step({ action: true }); stepFrames(apiR15, 22); apiR15.step({ action: true }); stepFrames(apiR15, 22);
if (!simR15.enemyDefeated || simR15.enemyHp !== 0 || !simR15.barrierOpen || !simR15.ladderEnabled || !simR15.scarReleased || simR15.world.solids.some(item => item.id === 'BARRERA_GB02')) throw new Error('Dos golpes temporizados no derrotaron al guardián y aplicaron sus consecuencias.');
const atomicR15 = ['enemigo_derrotado', 'barrera_gb02_retirada', 'escalera_gb02_habilitada', 'scar_gb02_liberado'].map(type => simR15.events.find(event => event.type === type));
if (atomicR15.some(event => !event) || new Set(atomicR15.map(event => event.time)).size !== 1 || new Set(atomicR15.map(event => event.atomicTime)).size !== 1) throw new Error('Las consecuencias R15 del guardián no fueron atómicas.');

const scarRouteRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  apiR15.reset(`qa_scar_paso_bajo_r15_${repetition}`);
  const run = apiR15.getSim(); openGb02(apiR15, run);
  Object.assign(run.eren, { x: 43.65, y: 5, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 50.25, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 50.25, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0 });
  apiR15.updateGb02(1 / 60);
  if (run.bridgePlateLatched || run.bridgeState !== 'stowed' || run.bridgeCommanded || !run.events.some(event => event.type === 'placa_puente_sin_orden_bloqueada')) throw new Error(`La placa se enclavó sin orden en repetición ${repetition}: ${JSON.stringify({latched:run.bridgePlateLatched,state:run.bridgeState,commanded:run.bridgeCommanded,scar:{x:run.scar.x,y:run.scar.y,mode:run.scar.mode,support:apiR15.supportingSolid(run.scar,run.world.solids)?.id},events:run.events.slice(-5)})}`);
  Object.assign(run.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', waitX: null, bridgeWait: false, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1 });
  const routeStart = run.events.length;
  apiR15.step({ scar: true }); apiR15.step({});
  for (let frame = 0; frame < 600 && run.bridgeState !== 'solid'; frame++) apiR15.step({});
  if (run.bridgeState !== 'solid' || !run.bridgePlateLatched || run.bridgeCommandCount !== 1 || !run.world.solids.some(item => item.id === 'PUENTE_1')) throw new Error(`Orden, placa o puente falló en repetición ${repetition}.`);
  Object.assign(run.eren, { x: 63.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  for (let frame = 0; frame < 720 && !run.complete; frame++) apiR15.step({});
  const routeEvents = run.events.slice(routeStart);
  const lowStarts = routeEvents.filter(event => event.type === 'scar_paso_bajo_inicio');
  const lowEnds = routeEvents.filter(event => event.type === 'scar_paso_bajo_fin');
  const forbidden = routeEvents.filter(event => event.type.startsWith('scar_salto') || event.type === 'scar_recuperacion');
  if (!run.complete || lowStarts.length !== 1 || lowEnds.length !== 1 || forbidden.length || run.scar.crouched || routeEvents.filter(event => event.type === 'scar_orden_puente').length !== 1 || routeEvents.filter(event => event.type === 'placa_puente_scar_enclavada').length !== 1) throw new Error(`Ruta baja segura de Scar falló en repetición ${repetition}: ${JSON.stringify({complete:run.complete,bridge:run.bridgeState,scar:{x:run.scar.x,y:run.scar.y,mode:run.scar.mode,crouched:run.scar.crouched,recover:run.scar.recoverTimer},lowStarts,lowEnds,forbidden,commands:routeEvents.filter(event=>event.type==='scar_orden_puente'),latches:routeEvents.filter(event=>event.type==='placa_puente_scar_enclavada'),last:routeEvents.slice(-20)})}`);
  scarRouteRuns.push({ repetition, complete: true, commands: 1, lowPasses: 1, lowRestores: 1, latches: 1, jumps: 0, recoveries: 0 });
}

qaR15.get('playLab').click();
if (apiR15.getSim().scene !== 'lab' || qaR15.get('labControls').classList.contains('hidden')) throw new Error('Laboratorio QA_ONLY no abrió en modo QA.');
qaR15.stations.find(item => item.dataset.station === 'D').click();
if (apiR15.getSim().station !== 'D' || !qaR15.get('labObjective').textContent.includes('paso bajo')) throw new Error('La estación D no expone escalera y paso bajo.');
qaR15.stations.find(item => item.dataset.station === 'E').click();
if (apiR15.getSim().station !== 'E' || !qaR15.get('labObjective').textContent.includes('guardián')) throw new Error('La estación E no expone combate y orden cooperativa.');
qaR15.get('labNext').click();
if (apiR15.getSim().station !== 'A') throw new Error('Siguiente no recorre A–E de forma cíclica.');
qaR15.get('labExit').click();
if (apiR15.getSim().scene !== 'graybox') throw new Error('Salir no vuelve a GB02.');
if (!css.includes('.station-buttons{display:grid;grid-template-columns:repeat(5,1fr)') || !css.includes('.qa-only.hidden{display:none!important}')) throw new Error('La UI QA A–E o su ocultación normal no está fijada.');
if (!sourceText.includes('R15_RUNTIME_VISUALS') || !sourceText.includes('drawFunctionalCharacterState') || !sourceText.includes('drawEnemyFunctional') || !sourceText.includes("erenLegAlternation:'PENDING_R02_ART_NOT_FAKED'")) throw new Error('Los estados visuales funcionales o la declaración de arte pendiente no están trazados.');

const resultR15 = {
  result: 'PASS', contract: contractR15.id, parentContractSha256: contractR15.parentSha256,
  baseline: contractR15.baseline, functionalBaseline: contractR15.functionalBaseline,
  preservedNotApplied: contractR15.preservedNotApplied, frozen: { locomotion: true, jump: true, contactR10: true },
  viewport: ['4:3', '16:9', '21:9', '32:9'], erenTunnelBlockedStandingAndCrouched: true,
  enemy: { offensiveAttackHit: true, jumpDodge: true, erenHitsToDefeat: 2, consequencesAtomic: true },
  ladder: { repetitions: ladderRuns.length, failures: 0, onlyIgnoredSolid: 'U4' },
  scarSafeRoute: { repetitions: scarRouteRuns.length, failures: 0, commands: 20, lowPasses: 20, jumps: 0, recoveries: 0 },
  bridge: { autoLatchesWithoutCommand: 0, deployments: 20, colliderDuringDeploy: false },
  qaOnlyLab: { normalBuildHidden: true, stations: 'A-E' }, tilesetIntegrated: false, gameReady: false,
};

const evidenceDirR15 = process.env.GB02_EVIDENCE_DIR;
if (evidenceDirR15) {
  await mkdir(evidenceDirR15, { recursive: true });
  const generatedAt = new Date().toISOString();
  await writeFile(`${evidenceDirR15}/GB02_R04_QA_MATRIX.json`, `${JSON.stringify({ schema: 'EREN_GB02_R04_QA_MATRIX_V1', generatedAt, appVersion: '38.0.0-graybox-gb02-r04-candidate-r15', contract: contractR15, result: 'PASS', checks: resultR15 }, null, 2)}\n`);
  await writeFile(`${evidenceDirR15}/LADDER_GB02_R04_20_REPETICIONES.json`, `${JSON.stringify({ schema: 'EREN_LADDER_GB02_R04_V1', generatedAt, repetitions: ladderRuns.length, results: ladderRuns, summary: { completions: 20, stuck: 0, residualPenetrations: 0, failures: 0, result: 'PASS' } }, null, 2)}\n`);
  await writeFile(`${evidenceDirR15}/SCAR_RUTA_BAJA_GB02_R04_20_REPETICIONES.json`, `${JSON.stringify({ schema: 'SCAR_LOW_ROUTE_GB02_R04_V1', generatedAt, repetitions: scarRouteRuns.length, results: scarRouteRuns, summary: { completions: 20, commands: 20, lowPasses: 20, autoLatches: 0, jumps: 0, recoveries: 0, failures: 0, result: 'PASS' } }, null, 2)}\n`);
}

console.log(JSON.stringify(resultR15));
