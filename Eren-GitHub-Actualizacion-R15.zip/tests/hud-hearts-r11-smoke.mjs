import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../app/src/main/assets/www/graybox-game.js', import.meta.url), 'utf8');
const gradle = await readFile(new URL('../app/build.gradle.kts', import.meta.url), 'utf8');
const layoutMatch = source.match(/const HUD_HEARTS_LAYOUT=(\{[\s\S]*?\});\nconst EDGE_SUPPORT_POLICY=/);
const functionMatch = source.match(/(function updateHeartHud\(currentHearts\)\{[\s\S]*?\n\})\n\nfunction gameLoop/);
if (!layoutMatch || !functionMatch) throw new Error('No se encontró el contrato o el renderer de corazones R11.');

const target = {
  style: {},
  attributes: new Map(),
  innerHTML: '',
  setAttribute(name, value) { this.attributes.set(name, String(value)); },
  getAttribute(name) { return this.attributes.get(name) ?? null; },
};
const sandbox = {
  byId: id => {
    if (id !== 'gameHearts') throw new Error(`ID inesperado: ${id}`);
    return target;
  },
  clamp: (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value)),
};
vm.createContext(sandbox);
vm.runInContext(`const HUD_HEARTS_LAYOUT=${layoutMatch[1]};\n${functionMatch[1]}\nglobalThis.renderHearts=updateHeartHud;`, sandbox);

const footprints = [];
for (const hearts of [3, 2, 1, 0]) {
  sandbox.renderHearts(hearts);
  const slots = [...target.innerHTML.matchAll(/data-heart-slot=/g)].length;
  const filled = [...target.innerHTML.matchAll(/>♥<\/span>/g)].length;
  const empty = [...target.innerHTML.matchAll(/>♡<\/span>/g)].length;
  footprints.push(`${target.style.width}|${target.style.gridTemplateColumns}`);
  if (slots !== 3 || filled !== hearts || empty !== 3 - hearts) throw new Error(`Estado incorrecto para ${hearts} corazones.`);
  if (target.getAttribute('aria-label') !== `${hearts} de 3 corazones` || target.getAttribute('role') !== 'img') throw new Error(`Accesibilidad incorrecta para ${hearts} corazones.`);
}

if (new Set(footprints).size !== 1 || footprints[0] !== '3.3em|repeat(3, 1.1em)') throw new Error('La huella del HUD cambia cuando baja la vida.');
if (!source.includes("APP_VERSION='38.0.0-graybox-gb02-r04-candidate-r15'") || !source.includes("LOG_VERSION='GB02-R04-v1'") || !gradle.includes('versionCode = 39') || !gradle.includes('versionName = "38.0.0-graybox-gb02-r04-candidate-r15"')) throw new Error('La candidata R15 no conserva el HUD R11 con versionado alineado.');

console.log(JSON.stringify({ result: 'PASS', contract: 'FIXED_THREE_SLOTS_R11', states: [3, 2, 1, 0], footprint: footprints[0] }));
