/* Graybox funcional 01 · Eren y Scar
 * Física a 60 Hz. Unidades del mundo en módulos (1 módulo = 100 px de autoría).
 * Integra arte funcional del Mundo 1 como montaje candidato sin cambiar la geometría autorizada.
 * R10 conserva la física permisiva validada y calibra exclusivamente su lectura:
 * actores apoyados a +10 px, utilería preservada a +6 px, normalización alfa de
 * toda la locomoción terrestre y terreno continuo sin mover colliders ni trayectorias.
 * R11 registra la validación funcional en Android y fija el HUD de vida en tres
 * casillas estables. R14 añade el contrato aprobado GB02 R03. R15 aplica las
 * condiciones del playtest Android sin incorporar R12/R13: combate ofensivo,
 * trepa acotada, paso bajo real de Scar y orden contextual para el puente.
 * R16 integra únicamente el arte funcional candidato entregado por Diseño
 * Gráfico sobre el PASS mecánico R15. Física, geometría, colliders, controles
 * y contacto R10 permanecen congelados.
 */
(()=>{
'use strict';

const byId=id=>document.getElementById(id);
const VIEW={minW:19.2,h:10.8};
const FIXED_DT=1/60;
const TEST_MODE=window.__EREN_QA_ONLY__===true;
const APP_VERSION='39.0.0-functional-art-gb02-r04-candidate-r16';
const LOG_VERSION='GB02-R04-ART-R16-v1';
const PLAYTEST_HISTORY_KEY='graybox-playtest-attempts-gb02-r04-art-r16-v1';
const MAX_PLAYTEST_ATTEMPTS=10;
const GB02_CONTRACT={
 id:'GB02_R04_PLAYTEST_CORRECTION',sha256:'02692ced658695b7e5ce95d9b1709448835b16427812e8393c61bc67466e6055',parentId:'GB02_R03_APPROVED',parentSha256:'dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4',
 baseline:'R14_ANDROID_PASS_WITH_CONDITIONS',functionalBaseline:'R11',preservedNotApplied:['R12','R13'],frozenContactRevision:'R10',
 world:{minX:0,maxX:64.5,minY:0,maxY:12},viewport:{height:10.8,minimumWidth:19.2,policy:'MAX_MINIMUM_OR_ASPECT'},
 scarRoute:{nominalY:2,jumps:0,teleports:0,hazards:0,repetitions:20,requiredLowPass:true,bridgeRequiresCommand:true},
 lab:{status:'QA_ONLY',normalBuildVisibility:'HIDDEN',stations:['A','B','C','D','E']}
};
const FUNCTIONAL_VALIDATION={
 status:'GB02_R04_MECHANICS_VALIDATED',validatedAt:'2026-08-27',devicePlaytest:'R15_PASS',
 contactR10:'APPROVED',mechanics:'R15_DEVICE_PASS_FROZEN',remainingWork:[
  'DEVICE_PLAYTEST_R16_VISUAL','FUNCTIONAL_ART_CANDIDATE_REVIEW','DECORATION_AND_BACKGROUNDS_LATER'
 ],
 gameReady:false
};
const HUD_HEARTS_LAYOUT={
 status:'FIXED_THREE_SLOTS_R11',slots:3,containerWidthEm:3.3,slotWidthEm:1.1,
 anchor:'CENTER_STABLE',filledGlyph:'♥',emptyGlyph:'♡',logicChanged:false
};
const EDGE_SUPPORT_POLICY={
 status:'ACTIVE_NORMAL_PERMISSIVE_SUPPORT_V28_MARIO_GOLDEN',appliesTo:['eren'],diagnosticOnly:false,
 model:'natural_overlap',minimumOverlapRatio:.001,automaticFall:false,naturalFallWhenNoOverlap:true,
 preserveHorizontalVelocity:true,edgePush:false,snap:false,ignoredSupport:false,
 supersedes:'ACTIVE_DUAL_FOOT_PROBE_V29_GOLDEN',
 visualFootAnchor:{status:'ACTIVE_R08',startRatio:.42,maxOffsetModules:.42,physicsChanged:false}
};
const BOX_CENTER_X=7;
const COOP_GATE_X=24;
const SCAR_GAP_JUMP={minimumStableSupportRatio:.5,speedX:4.2,speedY:14.7,anticipationDistance:.48,retryCooldown:.4,minimumAirTime:.12};
const SCAR_LONG_JUMP={takeoffMinX:23.1,erenMinX:25,speedX:8.5,speedY:13.5};
const SCAR_SPIKE_JUMP={safeWaitX:31,takeoffMinX:30.95,erenMinX:33.4,speedX:5.5,speedY:14.7};
const SCAR_LOW_RETURN={takeoffMaxX:20.8,erenMaxX:18,speedX:-6.5,speedY:8.5};
const ENEMY_COMBAT={
 patrolMinX:38.2,patrolMaxX:41.8,patrolSpeed:1.25,chaseSpeed:2.35,alertSeconds:.45,
 windupSeconds:.45,lungeSeconds:.3,lungeSpeed:5.2,activeFrom:.1,activeUntil:.24,recoverySeconds:.5,
 attackTriggerDistance:1.55,hitboxHeight:.85,erenInvulnerabilitySeconds:1,erenKnockbackX:5.4,erenKnockbackY:8.5,
 erenAttackWindupSeconds:.1,erenAttackDurationSeconds:.32,erenAttackReach:1.45,enemyHitStunSeconds:.28
};
const LADDER_TRAVERSAL={
 centerX:43,bottomY:2,topY:5,captureSpeed:6,climbSpeed:3.2,topExitStartY:3.35,
 exitSeconds:.38,exitX:43.65,exitY:5,ignoredSolidId:'U4'
};
const SCAR_LOW_PROFILE={normal:{w:1.5,h:1},low:{w:1.5,h:.65},approachDistance:.62};
const BRIDGE_COMMAND={erenMinX:43.5,erenMaxX:51.5,waitX:45.05,plateX:50.25};
const R16_RUNTIME_VISUALS={
 status:'FUNCTIONAL_ART_CANDIDATE_INTEGRATED',gameReady:false,finalPngIntegrated:true,
 eren:['idle','walk','run','jump','running_jump','bajo','crawl','golpe','impacto','escalera_agarre','escalera_subida','escalera_bajada','escalera_salida_superior','escalera_liberacion'],
 scar:['idle','walk','run','jump','paso_bajo_entrada','bajo','paso_bajo_salida','wait','confirm','danger'],
 enemy:['patrol','alerting','chase','windup','lunge','hit','recover','defeated'],
 world:['S012_escalera','S020_puente'],missingArtPackages:[],reviewRequired:['ANDROID_R16_VISUAL_CONTACT','LOOP_CONTINUITY','FINAL_ART_APPROVAL']
};
const LOCOMOTION_THRESHOLDS={idleMaxSpeed:.25,runMinSpeed:4.5};
const CONTACT_BOTTOM_GAPS_PX={
 eren:{idle:[0,0,0,0],walk:[0,0,0,0],run:[0,0,0,30,0,0,0,0]},
 scar:{idle:[0,0,0,0],walk:[0,0,0,0,0,0],run:[0,0,0,0,0,0]}
};
const VISUAL_CONTACT_PLANE={
 status:'ACTIVE_R10',profile:'CALIBRATED_ACTORS_10PX_PROPS_6PX',insetPx:10,actorInsetPx:10,propInsetPx:6,ppu:100,actorMode:'GROUNDED_ONLY',propMode:'STATIC_SUPPORT_CONTACT_PRESERVED_R09',
 appliesTo:['eren','scar','plate','box','boxRemains','lever'],terrainCoverage:'FULL_SOLID_UNCHANGED',
 terrainPixelsChanged:false,geometryChanged:false,collidersChanged:false,physicsChanged:false
};
const UI_ART_PACK=window.__uiR02||{
 packageId:'UI_EDUCATIVA_R02_CANDIDATE',handoffId:'UI-20260825-R02',status:'CANDIDATE_TECHNICAL_EXTRACTION',integrationStatus:'INTEGRATED_TECHNICAL_QA_PASS',gameReady:false,assetCount:16,
 textRendering:'NATIVE_LOCALISABLE',nineSlice:'CANDIDATE_DEVICE_REVIEW',puzzleReceiver:'ACTIVE_PIECE_ALPHA_MASK',requiresDevicePlaytest:true
};
const R16_ART_ROOT='assets/playtest/arte-gb02-r16-r01';
const R16_FUNCTIONAL_ART_PACK={
 packageId:'ARTE_GB02_R16_ASSETS_FUNCIONALES_R01_CANDIDATE_PLAYTEST',sourceZipSha256:'9839aed8faf4f3412e9ec7b99fd14a54bfc319ba7014299910c329f3868d0e90',
 status:'CANDIDATE_PLAYTEST',gameReady:false,assetCount:101,ppu:100,transformScale:[1,1],rootMotion:false,physicsAuthoritative:true,
 mechanicsBaseline:'GB02-R04-v1 / R15',mechanicsModified:false,geometryChanged:false,collidersChanged:false,physicsChanged:false,
 referenceOnlyExcluded:['Eren: atlas 4×4 de movimiento.png','Eren cae con pies separados.png','Atlas de animación de Scar.png']
};
const LOCOMOTION_PACK={
 packageId:`${R16_FUNCTIONAL_ART_PACK.packageId}/LOCOMOTION_R02`,status:'CANDIDATE_PLAYTEST',ppu:100,transformScale:[1,1],rootMotion:false,
 eren:{worldSize:{w:3,h:2},canvasPx:[300,200],pivotPx:[150,200],timingMs:{idle:320,walk:120,run:90},clips:{
  idle:['eren-reposo-r02-00-candidate.png','eren-reposo-r02-01-candidate.png','eren-reposo-r02-02-candidate.png','eren-reposo-r02-03-candidate.png'],
  walk:['eren-caminar-r02-00-candidate.png','eren-caminar-r02-01-candidate.png','eren-caminar-r02-02-candidate.png','eren-caminar-r02-03-candidate.png'],
  run:['eren-correr-r02-00-candidate.png','eren-correr-r02-01-candidate.png','eren-correr-r02-02-candidate.png','eren-correr-r02-03-candidate.png','eren-correr-r02-04-candidate.png','eren-correr-r02-05-candidate.png','eren-correr-r02-06-candidate.png','eren-correr-r02-07-candidate.png']
 }},
 scar:{worldSize:{w:2,h:1.5},canvasPx:[200,150],pivotPx:[100,150],timingMs:{idle:320,walk:120,run:90},clips:{
  idle:['scar-reposo-r02-00-candidate.png','scar-reposo-r02-01-candidate.png','scar-reposo-r02-02-candidate.png','scar-reposo-r02-03-candidate.png'],
  walk:['scar-caminar-r02-00-candidate.png','scar-caminar-r02-01-candidate.png','scar-caminar-r02-02-candidate.png','scar-caminar-r02-03-candidate.png','scar-caminar-r02-04-candidate.png','scar-caminar-r02-05-candidate.png'],
  run:['scar-correr-r02-00-candidate.png','scar-correr-r02-01-candidate.png','scar-correr-r02-02-candidate.png','scar-correr-r02-03-candidate.png','scar-correr-r02-04-candidate.png','scar-correr-r02-05-candidate.png']
 }}
};
const JUMP_PACK={
 packageId:`${R16_FUNCTIONAL_ART_PACK.packageId}/SALTO_E02_R02+SALTO_CARRERA_R01+S2_SALTO_REUSE`,incrementalOver:LOCOMOTION_PACK.packageId,status:'CANDIDATE_PLAYTEST',gameReady:false,ppu:100,transformScale:[1,1],rootMotion:false,physicsAuthoritative:true,
 eren:{worldSize:{w:3,h:2},canvasPx:[300,200],pivotPx:[150,200],colliderModules:[1,1.5],timingMs:{impulso:[90,70],subida:'physics_hold',caida:'physics_hold',aterrizaje:[80,160]},clips:{
  impulso:['eren-salto-impulso-00-candidate.png','eren-salto-impulso-01-candidate.png'],
  subida:['eren-salto-subida-00-candidate.png'],caida:['eren-salto-caida-r02-00-candidate.png'],
  aterrizaje:['eren-salto-aterrizaje-00-candidate.png','eren-salto-aterrizaje-01-candidate.png']
 }},
 erenRun:{worldSize:{w:3,h:2},canvasPx:[300,200],pivotPx:[150,200],colliderModules:[1,1.5],timingMs:{impulso:[90,70],subida:'physics_hold',caida:'physics_hold',aterrizaje:[80,160]},clips:{
  impulso:['eren-salto-carrera-impulso-00-candidate.png','eren-salto-carrera-despegue-00-candidate.png'],
  subida:['eren-salto-carrera-subida-00-candidate.png'],caida:['eren-salto-carrera-caida-00-candidate.png'],
  aterrizaje:['eren-salto-carrera-aterrizaje-00-candidate.png','eren-salto-carrera-aterrizaje-01-candidate.png']
 }},
 scar:{worldSize:{w:2,h:1.5},canvasPx:[200,150],pivotPx:[100,150],colliderModules:[1.5,1],timingMs:{impulso:[90,70],subida:'physics_hold',caida:'physics_hold',aterrizaje:[80,160]},clips:{
  impulso:['scar-salto-impulso-00-candidate.png','scar-salto-impulso-01-candidate.png'],
  subida:['scar-salto-subida-00-candidate.png'],caida:['scar-salto-caida-00-candidate.png'],
  aterrizaje:['scar-salto-aterrizaje-00-candidate.png','scar-salto-aterrizaje-01-candidate.png']
 }}
};
const EREN_ACTION_PACK={worldSize:{w:3,h:2},timingMs:{crouch:[160,160],crawl:[120,120,120,120],attack:[100,100,120],impact:[90,100,90]},clips:{
 crouch:['eren-agacharse-00-candidate.png','eren-agacharse-01-candidate.png'],crawl:['eren-arrastrarse-00-candidate.png','eren-arrastrarse-01-candidate.png','eren-arrastrarse-02-candidate.png','eren-arrastrarse-03-candidate.png'],
 attack:['eren-accion-00-candidate.png','eren-accion-01-candidate.png','eren-accion-02-candidate.png'],impact:['eren-impacto-00-candidate.png','eren-impacto-01-candidate.png','eren-recuperacion-00-candidate.png']
}};
const EREN_LADDER_PACK={worldSize:{w:3,h:2},timingMs:{grip:[90,90],up:[150,150],down:[150,150],exit:[380],release:[120]},clips:{
 grip:['eren-escalera-agarre-00-candidate.png','eren-escalera-agarre-01-candidate.png'],up:['eren-escalera-subida-00-candidate.png','eren-escalera-subida-01-candidate.png'],
 down:['eren-escalera-bajada-00-candidate.png','eren-escalera-bajada-01-candidate.png'],exit:['eren-escalera-salida-superior-00-candidate.png'],release:['eren-escalera-liberacion-00-candidate.png']
}};
const SCAR_LOW_PACK={worldSize:{w:2,h:1.5},timingMs:{enter:[100,100],move:[110,110,110,110],exit:[100,100]},clips:{
 enter:['scar-paso-bajo-entrada-00-candidate.png','scar-paso-bajo-entrada-01-candidate.png'],move:['scar-paso-bajo-avance-00-candidate.png','scar-paso-bajo-avance-01-candidate.png','scar-paso-bajo-avance-02-candidate.png','scar-paso-bajo-avance-03-candidate.png'],exit:['scar-paso-bajo-salida-00-candidate.png','scar-paso-bajo-salida-01-candidate.png']
}};
const SCAR_SIGNAL_PACK={worldSize:{w:2,h:1.5},timingMs:{danger:[160,160,160],confirm:[320],wait:[320]},clips:{
 danger:['scar-aviso-00-candidate.png','scar-aviso-01-candidate.png','scar-aviso-02-candidate.png'],confirm:['scar-confirmar-00-candidate.png'],wait:['scar-esperar-00-candidate.png']
}};
const ENEMY_ART_PACK={worldSize:{w:2,h:1.5},timingMs:{idle:[280,280],walk:[110,110,110,110,110,110],alert:[225,225],windup:[225,225],lunge:[300],impact:[280],defeat:[300,450],recover:[170,160,170]},clips:{
 idle:['idle/arana-idle-00.png','idle/arana-idle-01.png'],walk:['walk/arana-walk-00.png','walk/arana-walk-01.png','walk/arana-walk-02.png','walk/arana-walk-03.png','walk/arana-walk-04.png','walk/arana-walk-05.png'],
 alert:['alert/arana-alert-00.png','alert/arana-alert-01.png'],windup:['attack/arana-attack-00.png','attack/arana-attack-01.png'],lunge:['attack/arana-attack-02.png'],impact:['impact/arana-impact-00.png'],
 defeat:['defeat/arana-defeat-00.png','defeat/arana-defeat-01.png'],recover:['impact/arana-impact-00.png','idle/arana-idle-01.png','idle/arana-idle-00.png']
}};
const loadFrame=src=>{const image=new Image();image.decoding='async';image.src=src;return{src,image};};
const loadClips=(root,clips)=>Object.fromEntries(Object.entries(clips).map(([state,names])=>[state,names.map(name=>loadFrame(`${root}/${name}`))]));
const locomotionFrames={eren:loadClips(`${R16_ART_ROOT}/01_EREN/LOCOMOTION_R02/frames`,LOCOMOTION_PACK.eren.clips),scar:loadClips(`${R16_ART_ROOT}/02_SCAR/LOCOMOTION_R02/frames`,LOCOMOTION_PACK.scar.clips)};
const jumpFrames={eren:loadClips(`${R16_ART_ROOT}/01_EREN/SALTO_E02_R02/frames`,JUMP_PACK.eren.clips),erenRun:loadClips(`${R16_ART_ROOT}/01_EREN/SALTO_CARRERA_R01/frames`,JUMP_PACK.erenRun.clips),scar:loadClips(`${R16_ART_ROOT}/02_SCAR/S2_SALTO_REUSE/frames`,JUMP_PACK.scar.clips)};
const erenActionFrames=loadClips(`${R16_ART_ROOT}/01_EREN/E3_REUSE/frames`,EREN_ACTION_PACK.clips);
const erenLadderFrames=loadClips(`${R16_ART_ROOT}/01_EREN/ESCALERA_R01_EXTRACT/frames`,EREN_LADDER_PACK.clips);
const scarLowFrames=loadClips(`${R16_ART_ROOT}/02_SCAR/PASO_BAJO_R01/frames`,SCAR_LOW_PACK.clips);
const scarSignalFrames=loadClips(`${R16_ART_ROOT}/02_SCAR/S3_SENALES_REUSE/frames`,SCAR_SIGNAL_PACK.clips);
const enemyArtFrames=loadClips(`${R16_ART_ROOT}/03_ARANA/ARANA_R01_REUSE/frames`,ENEMY_ART_PACK.clips);
const r16WorldArt={
 ladder:{path:'04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5.png',worldSize:{w:1,h:3.5},sha256:'49e685f14bca4de1de28b3564f49c1ec06713b38bd763a3eff964e6e6064c667'},
 bridge:{path:'04_ESTRUCTURAS_CANONICAS/S020-puente-madera-4_5x1.png',worldSize:{w:4.5,h:1},sha256:'0afd0d11f231b8a6239033fd7552d0155e66c776b1a2fdb5af51194ccce9316e'}
};
for(const asset of Object.values(r16WorldArt))Object.assign(asset,loadFrame(`${R16_ART_ROOT}/${asset.path}`));
const WORLD_ART_PACK={
 packageId:'MUNDO1_FUNCTIONAL_ART_GRAYTEST_R01',runtimePlacementRevision:'CALIBRATED_ACTOR_CONTACT_PROFILE_R10',status:'CANDIDATE_PLACEMENT',gameReady:false,ppu:100,
 sourceStatus:'APPROVED_FUNCTIONAL',geometryAuthoritative:true,collidersChanged:false,
 assets:{
  earth0:{path:'terrain/earth-00.png',worldSize:{w:1,h:3},surfaceTopInsetPx:38},
  earth1:{path:'terrain/earth-01.png',worldSize:{w:1,h:3},surfaceTopInsetPx:27},
  natural1:{path:'terrain/suelo-natural-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:1},
  terrainFill1:{path:'terrain/terreno-relleno-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:3},
  terrainTop1:{path:'terrain/terreno-superficie-1x1.png',worldSize:{w:1,h:1},surfaceTopInsetPx:14},
  terrainTop2:{path:'terrain/terreno-superficie-2x1.png',worldSize:{w:2,h:1},surfaceTopInsetPx:3},
  terrainTop4:{path:'terrain/terreno-superficie-4x1.png',worldSize:{w:4,h:1},surfaceTopInsetPx:3},
  terrainPlatform15:{path:'terrain/terreno-plataforma-1_5x0_5.png',worldSize:{w:1.5,h:.5},canvasPx:[150,50],surfaceTopInsetPx:7},
  terrainFillHalf:{path:'terrain/terreno-relleno-0_5x0_5.png',worldSize:{w:.5,h:.5},surfaceTopInsetPx:0,nativeModule:true},
  terrainSurfaceHalf:{path:'terrain/terreno-tapa-canto-0_5x0_5.png',worldSize:{w:.5,h:.5},surfaceTopInsetPx:0,nativeModule:true},
  ruinColumn:{path:'terrain/columna-ruina-1x4_5.png',worldSize:{w:1,h:4.5},surfaceTopInsetPx:17},
  boxIntact:{path:'objects/caja-rompible-intacta-1x1.png',worldSize:{w:1,h:1},visibleBoundsPx:[0,10,100,90],fit:'NORMALIZED_SOURCE_CONTACT_INSET_R09'},
  boxRemains:{path:'objects/caja-rompible-restos-1x1.png',worldSize:{w:1,h:1},bottomTransparentPx:2,fit:'SOURCE_BOTTOM_CONTACT_INSET_R09'},
  plateFree:{path:'objects/placa-presion-libre-1_5x0_5.png',worldSize:{w:1.5,h:.5},visibleBoundsPx:[39,13,74,21],visibleCoverageModules:1.5,fit:'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09'},
  platePressed:{path:'objects/placa-presion-pulsada-1_5x0_5.png',worldSize:{w:1.5,h:.5},visibleBoundsPx:[31,18,85,18],visibleCoverageModules:1.5,fit:'VISIBLE_BOUNDS_UNIFORM_WIDTH_CONTACT_INSET_R09'},
  lever:{path:'objects/interruptor-muro-1_5x2.png',worldSize:{w:1.5,h:2},placement:'PROVISIONAL_OVER_EXISTING_TRIGGER'},
  star:{path:'objects/estrella-1x1.png',worldSize:{w:1,h:1},pivot:'center'},
  water:{path:'hazards/agua-4x1_5.png',worldSize:{w:4,h:1.5}},
  spikeReference:{path:'hazards/pincho-1x1_5.png',worldSize:{w:1,h:1.5},placement:'NOT_RENDERED_COLLIDER_MISMATCH'}
 }
};
const WORLD_ART_ROOT='assets/playtest/mundo1-functional';
const worldArt=Object.fromEntries(Object.entries(WORLD_ART_PACK.assets).map(([id,definition])=>{
 const src=`${WORLD_ART_ROOT}/${definition.path}`,image=new Image();image.decoding='async';image.src=src;
 return[id,{...definition,src,image}];
}));
const TERRAIN_CONTINUOUS_ASSET={
 src:'assets/playtest/terrain-r08/terrain-continuous-950x200-r08.png',canvasPx:[950,200],ppu:100,
 sourceOffsetsPx:{G0:0,G1:180,G2:430,G3:90,U1:540,U2:720,U3:780,TECHO_BAJO:350,PLACA_BASE:610}
};
TERRAIN_CONTINUOUS_ASSET.image=new Image();
TERRAIN_CONTINUOUS_ASSET.image.decoding='async';
TERRAIN_CONTINUOUS_ASSET.image.src=TERRAIN_CONTINUOUS_ASSET.src;
const TERRAIN_MOUNT_PACK={
 packageId:'TERRAIN-CONTACT-MOUNT-20260826-R07',decisionId:'GB-PLAYTEST-20260826-R10',status:'CANDIDATE_PLAYTEST',gameReady:false,
 replaces:'TERRAIN-CONTACT-MOUNT-20260826-R06',predecessorStatus:'CANDIDATE_ACTOR_CONTACT_TOO_HIGH',
 ppu:100,transformScale:[1,1],integrationScope:'ACTOR_CONTACT_VISUAL_ONLY',runtimeDrawCallsPerSolid:1,runtimeHalfTileRepetition:false,
 renderer:'CONTINUOUS_SOURCE_CROP_100PPU_WITH_CALIBRATED_CONTACT_PROFILE',runtimePrecomposedSolidPng:false,
 geometryChanged:false,collidersChanged:false,physicsChanged:false,pivotsChanged:false,
 renderOffsets:{axis:'screen_y_positive_down',eren:{groundedInsetPx:10,airborneInsetPx:0},scar:{groundedInsetPx:10,airborneInsetPx:0},props:{groundedInsetPx:6},mode:'GROUNDED_ACTOR_CALIBRATION_PLUS_PER_FRAME_ALPHA_GAP'},
 visualFootAnchor:{status:'ACTIVE_R08',physicsChanged:false,startRatio:.42,maxOffsetModules:.42,transitionSpeedModulesPerSecond:4},
 visualContactPlane:VISUAL_CONTACT_PLANE,
 sourceAsset:{file:'terrain-continuous-950x200-r08.png',canvasPx:[950,200],ppu:100,opaque:true,firstVisibleRow:0,sha256:'c4d267fce07a8aa162fde57bdefa2e469a4f8c107e6a37e88099c8e3023b5066'},
 assets:{
  groundAndPlatforms:'terrain-continuous-950x200-r08.png',upperColumn:'ruinColumn'
 }
};
const EPS=.001;
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const approach=(value,target,amount)=>value<target?Math.min(value+amount,target):Math.max(value-amount,target);
const format=value=>Number(value).toFixed(1).replace('.',',');
const rect=(id,x,y,w,h,kind='ground')=>({id,x,y,w,h,kind});
const viewportWorldSize=(width,height)=>{
 const safeWidth=Math.max(1,Number(width)||1920),safeHeight=Math.max(1,Number(height)||1080);
 return{w:Math.max(VIEW.minW,VIEW.h*(safeWidth/safeHeight)),h:VIEW.h,aspect:safeWidth/safeHeight};
};
const currentViewportWorldSize=()=>{
 const bounds=byId('gameCanvas')?.getBoundingClientRect?.()||{};
 return viewportWorldSize(bounds.width||window.innerWidth||1920,bounds.height||window.innerHeight||1080);
};

const tuning={walk:3.5,run:6,jump:15.9,gravityUp:36,gravityDown:44,labHeight:3,labGap:4};
const controls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const nativeControls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const keyControls=new Set();
const pointerControls=new Map();
let scene='graybox';
let labStation='A';
let debug=false;
let sim=null;
let frameHandle=0;
let previousTime=0;
let accumulator=0;
let lastHudUpdate=0;
let logDialogWasPaused=false;
let attemptHistory=loadAttemptHistory();

function loadAttemptHistory(){
 try{const value=JSON.parse(localStorage.getItem(PLAYTEST_HISTORY_KEY)||'[]');return Array.isArray(value)?value.slice(-MAX_PLAYTEST_ATTEMPTS):[];}
 catch(error){return[];}
}

function storeAttemptHistory(){
 try{localStorage.setItem(PLAYTEST_HISTORY_KEY,JSON.stringify(attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS)));}
 catch(error){}
}

function body(x,y,w,h,minGroundSupportRatio=0){
 return{x,y,w,h,minGroundSupportRatio,vx:0,vy:0,onGround:true,supportRatio:1,lostSupportRatio:null,ignoredSupportId:null,facing:1,crouched:false,coyote:.12,jumpBuffer:0,invuln:0,recover:0,hitWall:false,jumpVisualState:null,jumpVisualTime:0,jumpVisualVariant:'ordinary',visualFootOffsetX:0,visualState:null,visualStateTime:0};
}

function startJumpVisual(entity,variant='ordinary'){
 entity.jumpVisualState='impulso';entity.jumpVisualTime=0;entity.jumpVisualVariant=variant;
}

function clearJumpVisual(entity){
 entity.jumpVisualState=null;entity.jumpVisualTime=0;entity.jumpVisualVariant='ordinary';
}

function jumpPhaseDurationMs(character,state){
 const timing=JUMP_PACK[character].timingMs[state];
 return Array.isArray(timing)?timing.reduce((total,value)=>total+value,0):Infinity;
}

function updateJumpVisual(character,entity,dt){
 const state=entity.jumpVisualState;
 if(state==='aterrizaje'){
  entity.jumpVisualTime+=dt;
  if(entity.jumpVisualTime*1000>=jumpPhaseDurationMs(character,'aterrizaje'))clearJumpVisual(entity);
  return;
 }
 if(entity.onGround){
  if(state==='impulso'||state==='subida'||state==='caida'){entity.jumpVisualState='aterrizaje';entity.jumpVisualTime=0;}
  return;
 }
 if(!state){entity.jumpVisualState=entity.vy>0?'subida':'caida';entity.jumpVisualTime=0;return;}
 if(state==='impulso'){
  entity.jumpVisualTime+=dt;
  if(entity.jumpVisualTime*1000>=jumpPhaseDurationMs(character,'impulso')){entity.jumpVisualState=entity.vy>0?'subida':'caida';entity.jumpVisualTime=0;}
  return;
 }
 const physicsState=entity.vy>0?'subida':'caida';
 if(state!==physicsState){entity.jumpVisualState=physicsState;entity.jumpVisualTime=0;}else entity.jumpVisualTime+=dt;
}

function buildGraybox(boxBroken=false,coopUnlocked=false,gb02={}){
 const solids=[
  rect('G0',0,0,9.5,2),rect('G1',11,0,7,2),rect('G2',19.5,0,5,2),rect('G3',28.5,0,8,2),
  rect('U0_VERTICAL',6.5,3,1,4.5,'upper'),rect('TECHO_BAJO',12.5,3,1.5,.5,'roof'),
  rect('U1',14,4,2.5,.5,'upper'),rect('U2',18.5,6,1.5,.5,'upper'),rect('U3',21,4.5,1.5,.5,'upper'),
  rect('G4',36.5,0,9,2),rect('U4',42.5,4.5,3,.5,'upper'),
  rect('G5',45.5,0,6,2),rect('TUNEL_BAJO_SCAR',45.5,2.75,4,.5,'roof'),
  rect('G6',55.5,0,9,2),rect('U5',57,3.5,1.5,.5,'upper'),rect('U6',59,5,2,.5,'upper')
 ];
 if(!boxBroken)solids.push(rect('CAJA_ROMPIBLE',6.5,2,1,1,'box'));
 if(!coopUnlocked)solids.push(rect('PUERTA_COOP',COOP_GATE_X,2,.5,10,'gate'));
 if(!gb02.barrierOpen)solids.push(rect('BARRERA_GB02',42.5,2,1,5,'gate'));
 if(gb02.bridgeState==='solid')solids.push(rect('PUENTE_1',51.5,1.5,4,.5,'bridge'));
 return{
  minX:0,maxX:64.5,minY:0,maxY:12,solids,
  hazards:[rect('AGUA',24.5,-2,4,3.5,'water'),rect('PINCHOS',32.5,2,1,.5,'spikes'),rect('AGUA_GB02',51.5,-2,4,3.5,'water')],
  star:{id:'ESTRELLA_GB02',x:60,y:6,r:.34,bounds:{x:59.5,y:5.5,w:1,h:1}},
  marker:{id:'PLACA_SCAR',x:15,y:2,w:1.5,h:.5},
  lever:{id:'PALANCA_EREN',x:21.5,y:2,w:1,h:1.5},
  enemy:{id:'ENEMIGO_GB02',x:40.5,y:2,w:1,h:1.5,lane:{x:ENEMY_COMBAT.patrolMinX,y:2,w:ENEMY_COMBAT.patrolMaxX-ENEMY_COMBAT.patrolMinX,h:1}},
  barrier:{id:'BARRERA_GB02',x:42.5,y:2,w:1,h:5},
  ladder:{id:'ESCALERA_GB02',art:{x:42.5,y:1.5,w:1,h:3.5},grip:{x:42,y:2,w:2,h:3},topExit:{x:42.5,y:3.25,w:1.6,h:1.75}},
  bridgePlate:{id:'PLACA_PUENTE_SCAR',x:49.5,y:2,w:1.5,h:.5},
  bridge:{id:'PUENTE_1',x:51.5,y:1.5,w:4,h:.5,state:gb02.bridgeState||'stowed'},
  tutorial:{prompt:{x:37.5,y:2,w:1,h:1.5},arm:{x:38.5,y:2,w:.5,h:1.5}},
  lowClearanceVolumes:[
   {id:'LOW_U0',tag:'LOW_CLEARANCE',x:6.5,y:2,w:1,h:1,standingBlockedBy:'U0_VERTICAL'},
   {id:'LOW_TECHO_BAJO',tag:'LOW_CLEARANCE',x:12.5,y:2,w:1.5,h:1,standingBlockedBy:'TECHO_BAJO'},
   {id:'LOW_SCAR_BRIDGE',tag:'SCAR_ONLY_LOW_CLEARANCE',x:45.5,y:2,w:4,h:.75,standingBlockedBy:'TUNEL_BAJO_SCAR'}
  ],
  goal:{x:64,y:2,w:.5,h:2},goalZone:{x:62.5,y:2,w:2,h:.5},
  checkpoints:[{id:'R0',x:4.5,y:2},{id:'R1',x:22,y:2},{id:'R2',x:29.5,y:2},{id:'R3',x:34.5,y:2},{id:'R4',x:56.5,y:2}],
  labels:[{x:37.9,text:'GB02 · ALERTA Y CONSECUENCIA'},{x:48.5,text:'TRÁNSITO DUAL'},{x:60.5,text:'META DUAL'}]
 };
}

function buildLab(){
 const solids=[
  rect('A_SUELO',0,0,16,2),
  rect('B_SUELO',16,0,16,2),rect('B_TECHO_REAL',20,3,3,.5,'roof'),
  rect('C_SUELO',32,0,16,2),rect('C_CAJA',35,2,1,1,'box'),rect('C_PILAR',35,3,1,4.5,'upper'),
  rect('D_SUELO',48,0,16,2),rect('D_TUNEL_DUAL',54,3.5,5,.5,'roof'),
  rect('E_SUELO',64,0,16,2),rect('E_BARRERA',70,2,1,5,'gate')
 ];
 return{
  minX:0,maxX:80,minY:0,maxY:12,solids,hazards:[],star:null,marker:null,goal:null,checkpoints:[],
  lowClearanceVolumes:[{id:'LAB_LOW_REAL',tag:'LOW_CLEARANCE',x:20,y:2,w:3,h:1,standingBlockedBy:'B_TECHO_REAL'}],
  labels:[
   {x:8,text:'A · VIEWPORT'},{x:24,text:'B · POSTURA REAL'},{x:40,text:'C · CAJA/PILAR'},
   {x:56,text:'D · TRÁNSITO DUAL'},{x:72,text:'E · PUZLE Y META'}
  ]
 };
}

const LAB_STATIONS=['A','B','C','D','E'];
const LAB_OBJECTIVES={
 A:'Objetivo A: validar ancho completo y escala uniforme en 4:3, 16:9, 21:9 y 32:9.',
 B:'Objetivo B: confirmar que ABAJO solo activa postura baja ante LOW_CLEARANCE real.',
 C:'Objetivo C: superponer caja, pilar, arte visible y collider sin divergencias.',
 D:'Objetivo D: validar paso bajo exclusivo de Scar, escalera y salida superior sin atasco.',
 E:'Objetivo E: validar ataque del guardián, orden de Scar, puente y meta dual sin softlock.'
};
const stationSpawns={A:{x:2,y:2},B:{x:18,y:2},C:{x:33.5,y:2},D:{x:49.5,y:2},E:{x:65.5,y:2}};
const stationScarSpawns={A:{x:3.5,y:2},B:{x:19.5,y:2},C:{x:38,y:2},D:{x:51.5,y:2},E:{x:67,y:2}};

function createSimulation(){
 const spawn=scene==='graybox'?{x:4.5,y:2}:stationSpawns[labStation];
 const eren=body(spawn.x,spawn.y,1,1.5);
 eren.hearts=3;
 const scarSpawn=scene==='graybox'?{x:spawn.x-1.7,y:spawn.y}:stationScarSpawns[labStation];
 const scar=body(scarSpawn.x,scarSpawn.y,1.5,1);
 scar.mode='follow';scar.recoverTimer=0;scar.recoveryGrace=0;scar.stuck=0;scar.navStuck=0;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.traversal=null;scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=0;scar.spikeSafetyWaitLogged=false;scar.signalState=null;scar.signalTime=0;
 const gb02={barrierOpen:false,bridgeState:'stowed'};
 const world=scene==='graybox'?buildGraybox(false,false,gb02):buildLab();
 const viewport=currentViewportWorldSize();
 const cameraX=clamp(spawn.x-viewport.w*.36,world.minX,Math.max(world.minX,world.maxX-viewport.w));
 const now=new Date().toISOString();
 return{
  runId:`run-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,startedAt:now,archived:false,
  running:true,paused:false,scene,station:labStation,world,eren,scar,camera:{x:cameraX,y:0,viewW:viewport.w,viewH:viewport.h},
  boxBroken:false,erenSwitchArmed:false,scarPlateLatched:false,coopUnlocked:false,starCollected:false,checkpoint:{x:spawn.x,y:spawn.y,id:scene==='graybox'?'R0':labStation},
  enemyHp:2,enemyState:'patrol',enemyStateElapsed:0,enemyX:40.5,enemyFacing:-1,enemyAttackFacing:-1,enemyHitApplied:false,enemyDefeated:false,enemyDefeatVisualElapsed:0,barrierOpen:false,ladderEnabled:false,scarReleased:false,
  erenAttackState:null,erenAttackElapsed:0,erenAttackApplied:false,erenAttackLanded:false,ladderState:null,ladderStateElapsed:0,ladderExitFrom:null,
  bridgeCommanded:false,bridgeCommandCount:0,bridgeAutoBlockLogged:false,bridgePlateLatched:false,bridgeState:'stowed',bridgeDeployElapsed:0,bridgeWaitLogged:false,tunnelBlockLogged:false,r4Unlocked:false,
  complete:false,elapsed:0,readingCue:false,gb02Cue:false,toast:'',toastUntil:0,damageFlash:false,goalPending:false,goalWait:0,goalCallIssued:false,puzzleBypassGuard:false,
  maxHeight:0,maxSpeed:0,jumpStartY:spawn.y,prevInput:{...controls},
  events:[{time:0,type:'inicio',scene,station:labStation,createdAt:now}]
 };
}

function rebuildWorld(){
 if(!sim)return;
 sim.world=scene==='graybox'?buildGraybox(sim.boxBroken,sim.coopUnlocked,{barrierOpen:sim.barrierOpen,bridgeState:sim.bridgeState}):buildLab();
}

function logEvent(type,data={}){
 if(!sim)return;
 sim.events.push({time:Number(sim.elapsed.toFixed(3)),type,...data});
}

function archiveCurrentAttempt(reason){
 if(!sim||sim.archived)return;
 logEvent('fin_intento',{reason});
 if(!hasMeaningfulAttempt(sim.events)){sim.archived=true;return;}
 const attempt=playtestAttemptPayload();attempt.endedAt=new Date().toISOString();attempt.endedReason=reason;
 attemptHistory.push(JSON.parse(JSON.stringify(attempt)));attemptHistory=attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS);storeAttemptHistory();sim.archived=true;
}

function hasMeaningfulAttempt(events=[]){
 const passive=new Set(['inicio','fin_intento','ver_registro','compartir_registro','copiar_registro','copiar_resumen','estacion']);
 return events.some(event=>!passive.has(event.type));
}

function toast(message,seconds=1.6){
 if(!sim)return;
 sim.toast=message;sim.toastUntil=sim.elapsed+seconds;
}

function bodyRect(entity,w=entity.w,h=entity.h){return{x:entity.x-w/2,y:entity.y,w,h};}
function overlaps(a,b){return a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;}
function pointInRect(x,y,r){return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}
function horizontalSupportRatio(entity,solid,w=entity.w){
 const left=entity.x-w/2,right=entity.x+w/2;
 return clamp((Math.min(right,solid.x+solid.w)-Math.max(left,solid.x))/w,0,1);
}
function hasStableSupport(entity,solid,w=entity.w){
 return horizontalSupportRatio(entity,solid,w)>EPS;
}
function groundSupportState(entity,solids){
 let solid=null,ratio=0;
 for(const candidate of solids){
  if(candidate.id===entity.ignoredSupportId)continue;
  if(Math.abs(entity.y-(candidate.y+candidate.h))>=.08)continue;
  const candidateRatio=horizontalSupportRatio(entity,candidate);
  if(candidateRatio>ratio){solid=candidate;ratio=candidateRatio;}
 }
 return{solid,ratio};
}
function ignoresSolid(entity,solid){
 if(!entity.ignoredSupportId||entity.ignoredSupportId!==solid.id)return false;
 const top=solid.y+solid.h;
 const separated=horizontalSupportRatio(entity,solid)<=EPS;
 const safelyAbove=entity.y>=top+.08;
 const fullyBelow=entity.y+entity.h<=solid.y+EPS;
 if(separated||safelyAbove||fullyBelow){entity.ignoredSupportId=null;return false;}
 return true;
}
function applyErenEdgeSupport(entity,solids){
 // La política Mario no fuerza una caída ni vuelve intangible el soporte anterior.
 // moveBody conserva el apoyo con cualquier solape real y deja caer al cuerpo de
 // forma natural cuando el solape llega a cero. Así U1 nunca puede atravesarse.
 entity.ignoredSupportId=null;
 const supportState=groundSupportState(entity,solids);
 if(supportState.solid)entity.supportRatio=supportState.ratio;
 return false;
}
function targetVisualFootOffset(entity,solids){
 if(!entity.onGround||entity.crouched)return 0;
 const {solid,ratio}=groundSupportState(entity,solids),rule=EDGE_SUPPORT_POLICY.visualFootAnchor;
 if(!solid||ratio>=rule.startRatio)return 0;
 const strength=clamp((rule.startRatio-ratio)/rule.startRatio,0,1),margin=.06;
 const supportCenter=solid.x+solid.w/2;
 const contactX=entity.x<supportCenter?solid.x+margin:solid.x+solid.w-margin;
 return clamp((contactX-entity.x)*strength,-rule.maxOffsetModules,rule.maxOffsetModules);
}
function updateVisualFootAnchor(entity,solids,dt){
 const target=targetVisualFootOffset(entity,solids),speed=TERRAIN_MOUNT_PACK.visualFootAnchor.transitionSpeedModulesPerSecond;
 entity.visualFootOffsetX=approach(entity.visualFootOffsetX||0,target,speed*dt);
}
function hazardCollider(hazard){
 if(hazard.kind!=='spikes')return hazard;
 const insetX=Math.min(.15,hazard.w*.2);
 return{x:hazard.x+insetX,y:hazard.y,w:hazard.w-insetX*2,h:Math.max(.25,hazard.h-.15)};
}

function canFit(entity,w,h,solids){
 const box=bodyRect(entity,w,h);
 return !solids.some(s=>overlaps(box,s));
}

function lowClearanceConstraint(entity,input,world){
 if(!entity.onGround||!world.lowClearanceVolumes?.length)return null;
 const axis=(input.right?1:0)-(input.left?1:0);
 const projected={...entity,x:entity.x+axis*.65};
 const standing=bodyRect(projected,1,1.5),crouched=bodyRect(projected,1.5,1);
 return world.lowClearanceVolumes.find(volume=>{
  if(volume.tag!=='LOW_CLEARANCE'||!overlaps(standing,volume))return false;
  const blocker=world.solids.find(s=>s.id===volume.standingBlockedBy);
  const standingBlocked=!!blocker&&overlaps(standing,blocker);
  const lowFits=!world.solids.some(s=>overlaps(crouched,s));
  return standingBlocked&&lowFits;
 })||null;
}

function scarLowClearanceConstraint(scar,world){
 if(!world.lowClearanceVolumes?.length)return null;
 const direction=scar.facing||1,projected={...scar,x:scar.x+direction*SCAR_LOW_PROFILE.approachDistance};
 const normal=bodyRect(projected,SCAR_LOW_PROFILE.normal.w,SCAR_LOW_PROFILE.normal.h);
 const low=bodyRect(projected,SCAR_LOW_PROFILE.low.w,SCAR_LOW_PROFILE.low.h);
 return world.lowClearanceVolumes.find(volume=>{
  if(volume.tag!=='SCAR_ONLY_LOW_CLEARANCE'||!overlaps(normal,volume))return false;
  const blocker=world.solids.find(s=>s.id===volume.standingBlockedBy);
  const normalBlocked=!!blocker&&overlaps(normal,blocker);
  const lowFits=!world.solids.some(s=>overlaps(low,s));
  return normalBlocked&&lowFits;
 })||null;
}

function enemyBodyRect(){
 return{x:sim.enemyX-.5,y:2,w:1,h:1.5};
}

function enemyAttackRect(){
 const facing=sim.enemyAttackFacing||sim.enemyFacing||1;
 return{x:sim.enemyX+(facing>0?.15:-.95),y:2,w:.8,h:ENEMY_COMBAT.hitboxHeight};
}

function setEnemyState(state,data={}){
 if(sim.enemyState===state)return;
 sim.enemyState=state;sim.enemyStateElapsed=0;
 logEvent(`enemigo_${state}`,data);
}

function setActorVisualState(entity,state){
 entity.visualState=state;entity.visualStateTime=0;
}

function updateActorVisualState(entity,dt){
 if(!entity.visualState)return;
 if(entity.visualState==='bajo')entity.visualStateTime+=dt;
 if(entity.visualState==='paso_bajo_entrada'){
  entity.visualStateTime+=dt;
  if(entity.visualStateTime>=.2)setActorVisualState(entity,entity.crouched?'bajo':null);
  return;
 }
 if(entity.visualState==='paso_bajo_salida'||entity.visualState==='escalera_liberacion'){
  entity.visualStateTime+=dt;
  if(entity.visualStateTime>=.2)setActorVisualState(entity,null);
  return;
 }
 if(entity.visualState==='impacto'){
  entity.visualStateTime+=dt;
  if(entity.visualStateTime>=.28)setActorVisualState(entity,null);
 }
}

function setScarSignal(state){
 if(!sim?.scar)return;
 sim.scar.signalState=state;sim.scar.signalTime=0;
}

function updateScarSignal(scar,dt){
 if(!scar.signalState)return;
 scar.signalTime+=dt;
 if(scar.signalState==='confirm'&&scar.signalTime>=.32){scar.signalState=null;scar.signalTime=0;}
}

function moveBody(entity,dt,solids){
 entity.lostSupportRatio=null;
 entity.hitWall=false;
 entity.x+=entity.vx*dt;
 let box=bodyRect(entity);
 for(const solid of solids){
  if(ignoresSolid(entity,solid))continue;
  if(!overlaps(box,solid))continue;
  if(entity.vx>0)entity.x=solid.x-entity.w/2;
  else if(entity.vx<0)entity.x=solid.x+solid.w+entity.w/2;
  entity.vx=0;entity.hitWall=true;box=bodyRect(entity);
 }
 entity.onGround=false;
 entity.y+=entity.vy*dt;
 box=bodyRect(entity);
 let bestSupportRatio=0;
 for(const solid of solids){
  if(ignoresSolid(entity,solid))continue;
  if(!overlaps(box,solid))continue;
  if(entity.vy<=0){
   const ratio=horizontalSupportRatio(entity,solid);
   bestSupportRatio=Math.max(bestSupportRatio,ratio);
   entity.y=solid.y+solid.h;entity.onGround=true;entity.supportRatio=ratio;
  }
  else entity.y=solid.y-entity.h;
  entity.vy=0;box=bodyRect(entity);
 }
 if(!entity.onGround&&entity.vy<=0){
  for(const solid of solids){
   if(ignoresSolid(entity,solid))continue;
   const top=solid.y+solid.h;
   const ratio=horizontalSupportRatio(entity,solid);
   if(Math.abs(entity.y-top)<.035)bestSupportRatio=Math.max(bestSupportRatio,ratio);
   if(Math.abs(entity.y-top)<.035&&ratio>EPS){entity.y=top;entity.onGround=true;entity.supportRatio=ratio;entity.vy=0;break;}
  }
 }
 if(!entity.onGround){
  entity.supportRatio=bestSupportRatio;
 }
}

function supportingSolid(entity,solids){
 return groundSupportState(entity,solids).solid;
}

function surfaceAt(x,nearY,solids){
 let best=null;
 for(const solid of solids){
  const top=solid.y+solid.h;
  if(x>=solid.x&&x<=solid.x+solid.w&&top<=nearY+.35&&top>=nearY-2.2&&(!best||top>best))best=top;
 }
 return best;
}

function currentInput(){
 const merged={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
 const activate=name=>{if(name in merged)merged[name]=true;};
 const keyMap={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'up',KeyW:'up',ArrowDown:'crouch',KeyS:'crouch',ShiftLeft:'run',ShiftRight:'run',KeyR:'run',Space:'jump',KeyZ:'jump',KeyK:'jump',KeyX:'action',KeyE:'action',KeyJ:'action',KeyC:'scar',KeyQ:'scar',KeyL:'scar'};
 keyControls.forEach(code=>activate(keyMap[code]));
 pointerControls.forEach(values=>values.forEach(activate));
 Object.keys(nativeControls).forEach(name=>{if(nativeControls[name])activate(name);});
 const pads=navigator.getGamepads?navigator.getGamepads():[];
 for(const pad of pads){
  if(!pad)continue;
  if(pad.axes[0]<-.35||pad.buttons[14]?.pressed)merged.left=true;
  if(pad.axes[0]>.35||pad.buttons[15]?.pressed)merged.right=true;
  if(pad.axes[1]<-.55||pad.buttons[12]?.pressed)merged.up=true;
  if(pad.axes[1]>.55||pad.buttons[13]?.pressed)merged.crouch=true;
  if(pad.buttons[0]?.pressed)merged.jump=true;
  if(pad.buttons[2]?.pressed)merged.action=true;
  if(pad.buttons[1]?.pressed||pad.buttons[7]?.pressed)merged.run=true;
  if(pad.buttons[3]?.pressed||pad.buttons[4]?.pressed)merged.scar=true;
 }
 Object.assign(controls,merged);
 return merged;
}

function setMessageFromProgress(){
 if(!sim)return'';
 if(sim.toastUntil>sim.elapsed)return sim.toast;
 if(scene==='lab'){
 const messages={
   A:'A · Verifica 4:3, 16:9, 21:9 y 32:9: ancho completo y escala uniforme.',
   B:'B · ABAJO solo cambia el collider al entrar en LOW_CLEARANCE real.',
   C:'C · Superpón arte, caja, pilar y colliders: sus límites deben coincidir.',
   D:'D · Repite la escalera y el paso de 0,75 m exclusivo de Scar.',
   E:'E · Esquiva al guardián, ordena la placa y completa la meta dual.'
  };
  return messages[labStation];
 }
 const x=sim.eren.x;
 if(sim.goalPending){
  if(!actorInGoalZone(sim.eren))return'Vuelve a la zona de meta y espera allí a Scar.';
  return'Permanece en la meta: Scar debe entrar también en la zona final.';
 }
 if(x<5.85)return'Borde tipo Mario: Eren conserva apoyo mientras sus pies sigan tocando la plataforma.';
 if(!sim.boxBroken&&x<9.7)return'Rompe la caja marrón de abajo con ACCIÓN. El pilar gris no se rompe.';
 if(sim.boxBroken&&x<8)return'Mantén ABAJO y atraviesa la abertura bajo U0.';
 if(x<11.3)return'Salta el hueco corto. Puedes pulsar salto un instante o mantenerlo.';
 if(x<14.1)return'Mantén ABAJO para cambiar al collider agachado y pasar.';
 if(x<17.6&&sim.scar.mode==='follow')return'Lee: «Scar, activa la placa». Pulsa SCAR para darle la orden.';
 if(x<19.2)return'Puedes tomar la ruta alta para buscar la estrella.';
 if(!sim.coopUnlocked&&x<24.3){
  if(sim.erenSwitchArmed)return'Palanca lista. Envía a Scar a activar la placa; el orden no importa.';
  if(scarPlateActive())return'Placa de Scar enclavada. Pulsa ACCIÓN junto a la palanca de G2.';
  return'Activa la palanca de Eren y la placa de Scar; el orden no importa.';
 }
 if(x<24.3)return'Compuerta abierta. La ruta principal continúa por el agua.';
 if(x<28.7)return'Mantén CORRER + SALTAR para cruzar el agua.';
 if(x<34.3)return'Salta los pinchos. Andando tienes margen; corriendo también.';
 if(x<36.5)return'R3 · GB01 queda atrás. Continúa hacia el tramo panorámico.';
 if(!sim.enemyDefeated){
  if(sim.enemyState==='alerting')return'El guardián te ha visto: prepárate para saltar su embestida.';
  if(sim.enemyState==='windup')return'¡Ataque inminente! Salta o aléjate de la franja baja.';
  if(sim.enemyState==='lunge')return'Esquiva la embestida; después contraataca con ACCIÓN.';
  if(sim.enemyState==='recover')return'Ahora: acércate y pulsa ACCIÓN durante su recuperación.';
  return'El guardián patrulla y ataca. Esquiva, acércate y golpéalo dos veces.';
 }
 if(sim.ladderState)return sim.ladderState==='salida_superior'?'Salida superior: Eren está superando el borde de U4.':'Mantén ARRIBA para trepar; izquierda, derecha o salto sueltan la escalera.';
 if(x<43.5)return'Barrera retirada: pulsa ARRIBA frente a la escalera para trepar hasta U4.';
 if(!sim.bridgeCommanded)return'Pulsa SCAR: ordénale pasar bajo el túnel y ponerse en la placa del puente.';
 if(!sim.bridgePlateLatched)return'Scar atraviesa el paso de 0,75 m con postura baja real; Eren no cabe.';
 if(sim.bridgeState!=='solid')return'Placa enclavada: el puente espera la zona libre y se despliega sin collider durante 0,6 s.';
 if(!sim.r4Unlocked)return'Puente sólido: reúne a Eren y Scar a salvo sobre G6 para activar R4.';
 if(x<62.5)return'Ruta opcional alta para la estrella; Scar continúa por la ruta segura y plana.';
 return'Permanece en la meta: Eren y Scar deben coincidir físicamente en la zona final.';
}

function commandScar(){
 if(!sim||sim.paused)return;
 const scar=sim.scar;
 setScarSignal('confirm');
 if(scene==='graybox'&&sim.barrierOpen&&!sim.bridgePlateLatched&&sim.eren.x>=BRIDGE_COMMAND.erenMinX&&sim.eren.x<=BRIDGE_COMMAND.erenMaxX){
  if(sim.bridgeCommanded&&scar.mode==='bridge_marker'){
   toast('Scar ya está atravesando el paso bajo hacia la placa.',1.4);logEvent('scar_orden_puente_repetida');return;
  }
  sim.bridgeCommanded=true;sim.bridgeCommandCount++;
  scar.mode='bridge_marker';scar.navPhase='ir_a_placa_puente';scar.navTargetX=BRIDGE_COMMAND.plateX;scar.navTargetY=2;scar.navStuck=0;scar.waitX=null;scar.bridgeWait=false;scar.facing=1;
  toast('Scar, pasa por debajo y ponte en la placa del puente.',2);tone('correct');
  logEvent('scar_orden_puente',{command:sim.bridgeCommandCount,fromX:Number(scar.x.toFixed(2)),targetX:BRIDGE_COMMAND.plateX});
 }else if(scene==='graybox'&&Math.abs(sim.eren.x-(sim.world.marker.x+.75))<4.2){
  if(scar.mode==='marker'||scar.mode==='wait'){scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);toast('Scar vuelve a seguir a Eren.');logEvent('scar_seguir');}
  else{scar.mode='marker';scar.navPhase='buscar_placa';scar.navTargetX=null;scar.navTargetY=null;scar.navStuck=0;toast('Orden recibida: Scar va a activar la placa.');logEvent('scar_huella',{fromX:Number(scar.x.toFixed(2)),fromY:Number(scar.y.toFixed(2))});}
 }else if(scar.mode==='wait'||scar.mode==='marker'||scar.mode==='bridge_marker'){
  scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);toast('Scar vuelve contigo.');logEvent('scar_seguir');
 }else{
  scar.mode='wait';scar.navPhase='wait';scar.navTargetX=scar.x;scar.navTargetY=scar.y;scar.waitX=scar.x;toast('Scar espera aquí.');logEvent('scar_esperar',{x:Number(scar.x.toFixed(2))});
 }
}

function damageEren(kind){
 const eren=sim.eren;
 if(eren.invuln>0||eren.recover>0)return;
 eren.hearts--;
 logEvent('daño',{kind,hearts:eren.hearts,checkpoint:sim.checkpoint.id});
 const flash=byId('damageFlash');flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');
 sim.ladderState=null;sim.erenAttackState=null;sim.erenAttackApplied=false;sim.erenAttackLanded=false;
 eren.x=sim.checkpoint.x;eren.y=sim.checkpoint.y;eren.vx=0;eren.vy=0;eren.onGround=true;eren.supportRatio=1;eren.lostSupportRatio=null;eren.ignoredSupportId=null;eren.visualFootOffsetX=0;eren.recover=.55;eren.invuln=1.25;eren.crouched=false;eren.w=1;eren.h=1.5;clearJumpVisual(eren);setActorVisualState(eren,'impacto');
 if(eren.hearts<=0){eren.hearts=3;logEvent('corazones_repuestos');}
 toast('Daño: retorno al último anclaje.',1.1);tone('wrong');
}

function damageErenFromEnemy(){
 const eren=sim.eren;
 if(eren.invuln>0||eren.recover>0)return false;
 eren.hearts--;
 logEvent('enemigo_impacta_eren',{hearts:eren.hearts,enemyX:Number(sim.enemyX.toFixed(2))});
 logEvent('daño',{kind:'guardián',hearts:eren.hearts,checkpoint:sim.checkpoint.id,checkpointReturn:false});
 const flash=byId('damageFlash');flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');
 sim.ladderState=null;sim.erenAttackState=null;sim.erenAttackApplied=false;sim.erenAttackLanded=false;
 eren.invuln=ENEMY_COMBAT.erenInvulnerabilitySeconds;eren.vx=(eren.x<sim.enemyX?-1:1)*ENEMY_COMBAT.erenKnockbackX;eren.vy=ENEMY_COMBAT.erenKnockbackY;eren.onGround=false;eren.crouched=false;eren.w=1;eren.h=1.5;startJumpVisual(eren);setActorVisualState(eren,'impacto');
 if(eren.hearts<=0){
  eren.hearts=3;eren.x=sim.checkpoint.x;eren.y=sim.checkpoint.y;eren.vx=0;eren.vy=0;eren.onGround=true;eren.recover=.55;eren.invuln=1.25;clearJumpVisual(eren);logEvent('corazones_repuestos');
 }
 toast('¡El guardián golpea! Salta su próxima embestida.',1.4);tone('wrong');return true;
}

function recoverScar(reason){
 const scar=sim.scar;
 if(scar.recoverTimer>0)return;
 scar.recoverTimer=.65;scar.vx=0;scar.vy=0;clearJumpVisual(scar);logEvent('scar_recuperacion',{reason});
}

function setScarNavigation(scar,phase,targetX,targetY){
 if(scar.navPhase!==phase){scar.navPhase=phase;logEvent('scar_ruta',{phase,targetX:Number(targetX.toFixed(2)),targetY:Number(targetY.toFixed(2))});}
 scar.navTargetX=targetX;scar.navTargetY=targetY;return targetX;
}

function scarMarkerTarget(scar,world){
 if(!scar.onGround&&Number.isFinite(scar.navTargetX))return scar.navTargetX;
 const support=supportingSolid(scar,world.solids),marker=world.marker,markerX=marker.x+marker.w/2;
 if(support?.id==='U2')return setScarNavigation(scar,'bajar_u2_a_u1',17.5,4.5);
 if(support?.id==='U3')return setScarNavigation(scar,'bajar_u3_a_g2',22.5,2);
 if(support?.id==='U1')return setScarNavigation(scar,'bajar_u1_a_techo',13,3.5);
 if(support?.id==='TECHO_BAJO')return setScarNavigation(scar,'bajar_techo_a_g1',11,2);
 if(scar.y>marker.y+.2)return setScarNavigation(scar,'buscar_descenso',markerX,marker.y);
 return setScarNavigation(scar,'ir_a_placa',markerX,marker.y);
}

function scarReachedMarker(scar,world){
 const marker=world.marker,support=supportingSolid(scar,world.solids);
 return!!marker&&support?.id==='G1'&&Math.abs(scar.y-marker.y)<=.1&&Math.abs(scar.x-(marker.x+marker.w/2))<=.5;
}

function scarPlateActive(){
 if(!sim||scene!=='graybox'||!sim.world.marker)return false;
 return sim.scarPlateLatched===true;
}

function erenNearLever(eren=sim?.eren){
 const lever=sim?.world?.lever;
 return!!lever&&eren.y<2.35&&Math.abs(eren.x-(lever.x+lever.w/2))<=1.25;
}

function tryOpenCoopGate(trigger){
 if(sim.coopUnlocked)return true;
 if(!sim.erenSwitchArmed||!scarPlateActive())return false;
 sim.coopUnlocked=true;rebuildWorld();toast('¡Cooperación conseguida! La compuerta queda abierta.',2.2);tone('correct');
 logEvent('puzle_coop_completado',{trigger});logEvent('puerta_coop_abierta',{latched:true,trigger});
 if(sim.scar.mode==='wait'||sim.scar.mode==='marker'){
  sim.scar.mode='follow';sim.scar.navPhase='follow';sim.scar.navTargetX=null;sim.scar.navTargetY=null;sim.scar.waitX=null;sim.scar.recoveryGrace=Math.max(sim.scar.recoveryGrace||0,6);
  logEvent('scar_reanuda_tras_puzle',{x:Number(sim.scar.x.toFixed(2))});
 }
 return true;
}

function tryCoopLever(){
 if(sim.coopUnlocked){toast('La compuerta ya está abierta.');return true;}
 if(!sim.erenSwitchArmed){
  sim.erenSwitchArmed=true;tone('correct');logEvent('palanca_eren_activada',{x:Number(sim.eren.x.toFixed(2)),plateActive:scarPlateActive()});
 }
 if(tryOpenCoopGate('palanca_eren'))return true;
 toast('Palanca activada. Falta que Scar active la placa.',2);return true;
}

function updateScarPosture(scar,world){
 const constraint=scarLowClearanceConstraint(scar,world);
 if(constraint&&!scar.crouched){
  scar.crouched=true;scar.w=SCAR_LOW_PROFILE.low.w;scar.h=SCAR_LOW_PROFILE.low.h;setActorVisualState(scar,'paso_bajo_entrada');
  logEvent('scar_paso_bajo_inicio',{reason:'LOW_CLEARANCE',volume:constraint.id,x:Number(scar.x.toFixed(2)),height:scar.h});
 }else if(scar.crouched&&!constraint&&canFit(scar,SCAR_LOW_PROFILE.normal.w,SCAR_LOW_PROFILE.normal.h,world.solids)){
  scar.crouched=false;scar.w=SCAR_LOW_PROFILE.normal.w;scar.h=SCAR_LOW_PROFILE.normal.h;setActorVisualState(scar,'paso_bajo_salida');
  logEvent('scar_paso_bajo_fin',{reason:'CLEARANCE_OK',x:Number(scar.x.toFixed(2)),height:scar.h});
 }
}

function defeatGb02Enemy(){
 sim.enemyDefeated=true;sim.enemyState='defeated';sim.enemyStateElapsed=0;sim.enemyDefeatVisualElapsed=0;
 sim.barrierOpen=true;sim.ladderEnabled=true;sim.scarReleased=true;
 rebuildWorld();
 const atomicTime=Number(sim.elapsed.toFixed(3));
 logEvent('enemigo_derrotado',{hp:0,atomicTime});
 logEvent('barrera_gb02_retirada',{atomicTime});
 logEvent('escalera_gb02_habilitada',{atomicTime});
 logEvent('scar_gb02_liberado',{atomicTime});
 toast('Guardián vencido: barrera fuera, escalera activa y Scar liberado.',2.2);tone('correct');
 return true;
}

function applyErenAttackHit(){
 if(sim.enemyDefeated||sim.erenAttackApplied)return false;
 sim.erenAttackApplied=true;
 const eren=sim.eren,dx=sim.enemyX-eren.x,facingOk=Math.abs(dx)<.08||Math.sign(dx)===eren.facing;
 const verticalOk=eren.y<3.35,withinReach=Math.abs(dx)<=ENEMY_COMBAT.erenAttackReach;
 if(!facingOk||!verticalOk||!withinReach){logEvent('eren_golpe_falla',{enemyDistance:Number(Math.abs(dx).toFixed(2)),facingOk,verticalOk});return false;}
 if(sim.enemyState==='hit'){
  logEvent('eren_golpe_falla',{enemyDistance:Number(Math.abs(dx).toFixed(2)),reason:'ENEMY_HIT_STUN'});return false;
 }
 sim.erenAttackLanded=true;sim.enemyHp=Math.max(0,sim.enemyHp-1);logEvent('enemigo_golpe',{hp:sim.enemyHp,source:'eren_attack_window'});setEnemyState('hit',{hp:sim.enemyHp});
 if(sim.enemyHp>0){toast('Impacto: queda 1 punto de resistencia.',1);tone('correct');return true;}
 return defeatGb02Enemy();
}

function tryAttackGb02Enemy(){
 if(scene!=='graybox'||sim.enemyDefeated||sim.eren.x<37.2||sim.eren.x>42.35||sim.eren.y>3.6)return false;
 if(sim.erenAttackState){toast('Termina el golpe anterior.',.5);return true;}
 sim.erenAttackState='golpe';sim.erenAttackElapsed=0;sim.erenAttackApplied=false;sim.erenAttackLanded=false;setActorVisualState(sim.eren,'golpe');
 logEvent('eren_golpe_inicio',{x:Number(sim.eren.x.toFixed(2)),facing:sim.eren.facing,windup:ENEMY_COMBAT.erenAttackWindupSeconds});return true;
}

function updateErenAttack(dt){
 if(!sim.erenAttackState)return;
 sim.erenAttackElapsed+=dt;sim.eren.visualStateTime+=dt;
 if(!sim.erenAttackApplied&&sim.erenAttackElapsed+.0001>=ENEMY_COMBAT.erenAttackWindupSeconds)applyErenAttackHit();
 if(sim.erenAttackElapsed+.0001>=ENEMY_COMBAT.erenAttackDurationSeconds){
  logEvent('eren_golpe_fin',{hit:sim.erenAttackLanded});sim.erenAttackState=null;sim.erenAttackElapsed=0;sim.erenAttackApplied=false;sim.erenAttackLanded=false;if(sim.eren.visualState==='golpe')setActorVisualState(sim.eren,null);
 }
}

function beginLadderTraversal(input){
 const eren=sim.eren,ladder=sim.world.ladder;
 if(scene!=='graybox'||!sim.ladderEnabled||sim.ladderState||!input.up||!ladder||!overlaps(bodyRect(eren),ladder.grip))return false;
 sim.ladderState='agarre';sim.ladderStateElapsed=0;sim.ladderExitFrom=null;sim.erenAttackState=null;
 eren.crouched=false;eren.w=1;eren.h=1.5;eren.vx=0;eren.vy=0;eren.onGround=false;eren.visualFootOffsetX=0;clearJumpVisual(eren);setActorVisualState(eren,'escalera_agarre');
 logEvent('escalera_agarre_inicio',{x:Number(eren.x.toFixed(2)),y:Number(eren.y.toFixed(2)),centerX:LADDER_TRAVERSAL.centerX});return true;
}

function releaseLadder(input,reason){
 const eren=sim.eren,axis=(input.right?1:0)-(input.left?1:0);
 sim.ladderState=null;sim.ladderStateElapsed=0;sim.ladderExitFrom=null;
 eren.vx=(axis||eren.facing||1)*(input.jump?3.2:2.2);eren.vy=input.jump?7.5:0;eren.onGround=false;
 if(input.jump)startJumpVisual(eren);
 setActorVisualState(eren,'escalera_liberacion');
 logEvent('escalera_suelta',{reason,x:Number(eren.x.toFixed(2)),y:Number(eren.y.toFixed(2))});
}

function updateErenLadder(input,dt){
 const eren=sim.eren,state=sim.ladderState;
 if(!state)return false;
 sim.ladderStateElapsed+=dt;eren.vx=0;eren.vy=0;eren.onGround=false;eren.ignoredSupportId=LADDER_TRAVERSAL.ignoredSolidId;
 const lateral=input.left||input.right,jumpPressed=input.jump&&!sim.prevInput.jump;
 if(state!=='salida_superior'&&(lateral||jumpPressed)){releaseLadder(input,lateral?'lateral':'salto');return true;}
 if(state==='agarre'){
  eren.x=approach(eren.x,LADDER_TRAVERSAL.centerX,LADDER_TRAVERSAL.captureSpeed*dt);
  eren.y=clamp(eren.y,LADDER_TRAVERSAL.bottomY,LADDER_TRAVERSAL.topExitStartY);
  if(Math.abs(eren.x-LADDER_TRAVERSAL.centerX)<=.025||sim.ladderStateElapsed>=.18){
   eren.x=LADDER_TRAVERSAL.centerX;sim.ladderState='subida';sim.ladderStateElapsed=0;setActorVisualState(eren,'escalera_subida');
   logEvent('escalera_agarre_completo',{x:eren.x,y:Number(eren.y.toFixed(2))});
  }
  return true;
 }
 if(state==='subida'||state==='bajada'){
  const vertical=(input.up?1:0)-(input.crouch?1:0);
  if(vertical>0&&state!=='subida'){sim.ladderState='subida';sim.ladderStateElapsed=0;setActorVisualState(eren,'escalera_subida');}
  if(vertical<0&&state!=='bajada'){sim.ladderState='bajada';sim.ladderStateElapsed=0;setActorVisualState(eren,'escalera_bajada');}
  eren.x=approach(eren.x,LADDER_TRAVERSAL.centerX,LADDER_TRAVERSAL.captureSpeed*dt);
  eren.y=clamp(eren.y+vertical*LADDER_TRAVERSAL.climbSpeed*dt,LADDER_TRAVERSAL.bottomY,LADDER_TRAVERSAL.topExitStartY);
  eren.visualStateTime+=Math.abs(vertical)*dt;
  if(vertical>0&&eren.y>=LADDER_TRAVERSAL.topExitStartY-EPS){
   sim.ladderState='salida_superior';sim.ladderStateElapsed=0;sim.ladderExitFrom={x:eren.x,y:eren.y};setActorVisualState(eren,'escalera_salida_superior');
   logEvent('escalera_salida_superior_inicio',{fromX:Number(eren.x.toFixed(2)),fromY:Number(eren.y.toFixed(2)),toX:LADDER_TRAVERSAL.exitX,toY:LADDER_TRAVERSAL.exitY});
  }else if(vertical<0&&eren.y<=LADDER_TRAVERSAL.bottomY+EPS){
   sim.ladderState=null;eren.y=LADDER_TRAVERSAL.bottomY;eren.onGround=true;eren.ignoredSupportId=null;setActorVisualState(eren,null);logEvent('escalera_salida_inferior');
  }
  return true;
 }
 if(state==='salida_superior'){
  const start=sim.ladderExitFrom||{x:LADDER_TRAVERSAL.centerX,y:LADDER_TRAVERSAL.topExitStartY};
  const raw=clamp(sim.ladderStateElapsed/LADDER_TRAVERSAL.exitSeconds,0,1),t=raw*raw*(3-2*raw);
  eren.x=start.x+(LADDER_TRAVERSAL.exitX-start.x)*t;eren.y=start.y+(LADDER_TRAVERSAL.exitY-start.y)*t;eren.visualStateTime+=dt;
  if(raw>=1-EPS){
   sim.ladderState=null;sim.ladderStateElapsed=0;sim.ladderExitFrom=null;eren.x=LADDER_TRAVERSAL.exitX;eren.y=LADDER_TRAVERSAL.exitY;eren.vx=0;eren.vy=0;eren.onGround=true;eren.supportRatio=1;eren.ignoredSupportId=null;setActorVisualState(eren,null);
   logEvent('escalera_salida_superior_completa',{x:eren.x,y:eren.y,support:'U4'});toast('Escalera superada: salida libre sobre la plataforma.',1.1);
  }
  return true;
 }
 return true;
}

function updateEren(input,dt){
 const eren=sim.eren;
 eren.invuln=Math.max(0,eren.invuln-dt);
 updateActorVisualState(eren,dt);
 if(eren.recover>0){eren.recover=Math.max(0,eren.recover-dt);return;}
 if(input.scar&&!sim.prevInput.scar)commandScar();
 if(sim.ladderState||beginLadderTraversal(input)){
  updateErenLadder(input,dt);sim.maxHeight=Math.max(sim.maxHeight,eren.y-sim.jumpStartY);return;
 }

 if(eren.onGround)eren.coyote=.12;else eren.coyote=Math.max(0,eren.coyote-dt);
 eren.jumpBuffer=Math.max(0,eren.jumpBuffer-dt);
 if(input.jump&&!sim.prevInput.jump)eren.jumpBuffer=.12;

 const lowConstraint=lowClearanceConstraint(eren,input,sim.world);
 if(input.crouch&&lowConstraint){
  if(!eren.crouched){eren.crouched=true;eren.w=1.5;eren.h=1;setActorVisualState(eren,'bajo');logEvent('agacharse',{reason:'LOW_CLEARANCE',volume:lowConstraint.id});}
 }else if(eren.crouched&&canFit(eren,1,1.5,sim.world.solids)){
  eren.crouched=false;eren.w=1;eren.h=1.5;if(eren.visualState==='bajo')setActorVisualState(eren,null);logEvent('levantarse',{reason:'CLEARANCE_OK'});
 }

 if(eren.jumpBuffer>0&&eren.coyote>0&&!eren.crouched){
  eren.vy=tuning.jump;eren.onGround=false;eren.coyote=0;eren.jumpBuffer=0;sim.jumpStartY=eren.y;
  startJumpVisual(eren,Math.abs(eren.vx)>=LOCOMOTION_THRESHOLDS.runMinSpeed?'running':'ordinary');
  logEvent('salto',{x:Number(eren.x.toFixed(2)),speed:Number(Math.abs(eren.vx).toFixed(2))});
 }
 if(!input.jump&&sim.prevInput.jump&&eren.vy>0)eren.vy*=.45;

 const axis=(input.right?1:0)-(input.left?1:0);
 if(axis)eren.facing=axis;
 const maxSpeed=eren.crouched?2.2:(input.run?tuning.run:tuning.walk);
 const target=axis*maxSpeed;
 const accel=!axis?28:(eren.vx*axis<0?36:(eren.onGround?20:14));
 eren.vx=approach(eren.vx,target,accel*dt);

 if(input.action&&!sim.prevInput.action){
  logEvent('accion',{x:Number(eren.x.toFixed(2))});
  if(scene==='graybox'&&!sim.boxBroken&&Math.abs(eren.x-BOX_CENTER_X)<1.8&&eren.y<2.35){
   sim.boxBroken=true;rebuildWorld();toast('Caja rota. El camino ya está abierto.');tone('correct');logEvent('caja_rota');
  }else if(scene==='graybox'&&erenNearLever(eren)){
   tryCoopLever();
  }else if(tryAttackGb02Enemy()){
   // El puzle del guardián consume la acción y aplica sus consecuencias atómicas.
  }else if(scene==='lab'&&Math.abs(eren.x-35.5)<1.8){
   sim.world.solids=sim.world.solids.filter(s=>s.id!=='C_CAJA');toast('Collider de caja retirado.');tone('correct');
  }
 }
 updateErenAttack(dt);

 const gravity=eren.vy>0?tuning.gravityUp:tuning.gravityDown;
 eren.ignoredSupportId=null;
 eren.vy=Math.max(-16,eren.vy-gravity*dt);
 moveBody(eren,dt,sim.world.solids);
 applyErenEdgeSupport(eren,sim.world.solids);
 updateVisualFootAnchor(eren,sim.world.solids,dt);
 updateJumpVisual('eren',eren,dt);
 eren.x=clamp(eren.x+0,sim.world.minX+eren.w/2,sim.world.maxX-eren.w/2);
 if(scene==='graybox'&&eren.hitWall&&eren.x>=44.85&&eren.x<=45.05&&!sim.tunnelBlockLogged){sim.tunnelBlockLogged=true;logEvent('eren_tunel_scar_bloqueado',{standingHeight:1.5,crouchedHeight:1,clearance:.75});toast('Ese paso es demasiado bajo para Eren. Ordena a Scar que entre.',1.5);}

 if(scene==='graybox'&&!sim.coopUnlocked){
  const safeX=COOP_GATE_X-eren.w/2-EPS;
  if(eren.x>safeX+.05){
   const fromX=eren.x,fromY=eren.y;
   eren.x=safeX;eren.vx=Math.min(0,eren.vx);
   if(sim.checkpoint.id==='R2')sim.checkpoint={x:22,y:2,id:'R1'};
   if(!sim.puzzleBypassGuard){
    sim.puzzleBypassGuard=true;
    logEvent('bypass_puzle_bloqueado',{fromX:Number(fromX.toFixed(2)),fromY:Number(fromY.toFixed(2)),gate:'PUERTA_COOP'});
   }
  }else if(eren.x<safeX-.15)sim.puzzleBypassGuard=false;
 }else sim.puzzleBypassGuard=false;

 if(scene==='graybox'&&!sim.barrierOpen){
  const safeX=sim.world.barrier.x-eren.w/2-EPS;
  if(eren.x>safeX){eren.x=safeX;eren.vx=Math.min(0,eren.vx);logEvent('barrera_gb02_bloquea_paso',{enemyHp:sim.enemyHp});}
 }

 sim.maxSpeed=Math.max(sim.maxSpeed,Math.abs(eren.vx));
 sim.maxHeight=Math.max(sim.maxHeight,eren.y-sim.jumpStartY);

 if(scene==='graybox'){
  if(eren.onGround&&eren.x>=21.5&&sim.checkpoint.id==='R0'){sim.checkpoint={x:22,y:2,id:'R1'};logEvent('anclaje',{id:'R1'});}
  if(sim.coopUnlocked&&eren.onGround&&eren.x>=29.2&&['R0','R1'].includes(sim.checkpoint.id)){sim.checkpoint={x:29.5,y:2,id:'R2'};logEvent('anclaje',{id:'R2'});}
  if(eren.onGround&&eren.x>=34.3&&!['R3','R4'].includes(sim.checkpoint.id)){sim.checkpoint={x:34.5,y:2,id:'R3'};logEvent('anclaje',{id:'R3'});}
  if(!sim.readingCue&&eren.x>=13.7){sim.readingCue=true;logEvent('instruccion_leida',{text:'Scar, activa la placa.'});playAzureSequence(['Scar, activa la placa.']);}
  if(!sim.gb02Cue&&eren.x>=36.5){sim.gb02Cue=true;logEvent('gb02_inicio',{contract:GB02_CONTRACT.id});}
  if(!sim.starCollected&&sim.world.star){
   const star=sim.world.star,dx=eren.x-star.x,dy=(eren.y+eren.h*.55)-star.y;
   if(dx*dx+dy*dy<.8){sim.starCollected=true;toast('Estrella opcional conseguida.');tone('correct');logEvent('estrella');}
  }
  if(!sim.complete&&!sim.goalPending&&actorInGoalZone(eren)){
   sim.goalPending=true;sim.goalWait=0;sim.goalCallIssued=false;
   toast('Meta alcanzada. Espera a Scar.',2);logEvent('meta_espera_scar',{scarX:Number(sim.scar.x.toFixed(2))});
  }
 }

 const hit=sim.world.hazards.find(h=>overlaps(bodyRect(eren),hazardCollider(h)));
 if(hit)damageEren(hit.kind);
 if(eren.y<-2.5)damageEren('caída');
}

function updateScar(dt){
 const scar=sim.scar,eren=sim.eren,world=sim.world;
 scar.recoveryGrace=Math.max(0,(scar.recoveryGrace||0)-dt);
 updateScarSignal(scar,dt);updateActorVisualState(scar,dt);
 if(scar.recoverTimer>0){
  scar.recoverTimer-=dt;
  if(scar.recoverTimer<=0){
   let x=Math.max(world.minX+.9,sim.camera.x-.9),y=surfaceAt(x,eren.y,world.solids);
   if(y===null){x=sim.checkpoint.x-1.7;y=sim.checkpoint.y;}
   scar.x=x;scar.y=y;scar.vx=Math.max(2.2,eren.vx);scar.vy=0;scar.onGround=true;scar.supportRatio=1;scar.lostSupportRatio=null;scar.ignoredSupportId=null;scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.navStuck=0;scar.traversal=null;scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=SCAR_GAP_JUMP.retryCooldown;scar.recoveryGrace=3.5;scar.stuck=0;scar.spikeSafetyWaitLogged=false;clearJumpVisual(scar);
   if(scar.crouched){scar.crouched=false;scar.w=SCAR_LOW_PROFILE.normal.w;scar.h=SCAR_LOW_PROFILE.normal.h;setActorVisualState(scar,null);}
  }
  return;
 }

 updateScarPosture(scar,world);
 let supportState=groundSupportState(scar,world.solids),support=supportState.solid;
 if(scar.onGround)scar.supportRatio=supportState.ratio;
 const wantsLowReturn=scar.mode==='marker'||(scar.mode==='follow'&&eren.x<=SCAR_LOW_RETURN.erenMaxX);
 if(!scar.traversal&&scene==='graybox'&&wantsLowReturn&&!scar.crouched&&scar.onGround&&support?.id==='G2'&&scar.x<=SCAR_LOW_RETURN.takeoffMaxX){
  scar.traversal='g2_g1_low_return';scar.navPhase='retorno_bajo_g2_g1';scar.facing=-1;scar.vx=SCAR_LOW_RETURN.speedX;scar.vy=SCAR_LOW_RETURN.speedY;scar.onGround=false;
  startJumpVisual(scar);
  logEvent('scar_salto_retorno_bajo_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_LOW_RETURN.speedX,vy:SCAR_LOW_RETURN.speedY});
 }
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G2'&&scar.x>=SCAR_LONG_JUMP.takeoffMinX&&eren.x>=SCAR_LONG_JUMP.erenMinX){
  scar.traversal='water_long_jump';scar.navPhase='salto_largo_agua';scar.facing=1;scar.vx=SCAR_LONG_JUMP.speedX;scar.vy=SCAR_LONG_JUMP.speedY;scar.onGround=false;
  startJumpVisual(scar);
  logEvent('scar_salto_largo_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_LONG_JUMP.speedX,vy:SCAR_LONG_JUMP.speedY});
 }
 const spikeJumpReady=sim.goalPending||eren.x>=SCAR_SPIKE_JUMP.erenMinX;
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G3'&&scar.x>=SCAR_SPIKE_JUMP.takeoffMinX&&scar.x<32.5&&spikeJumpReady){
  scar.traversal='spike_jump';scar.navPhase='salto_pinchos';scar.facing=1;scar.vx=SCAR_SPIKE_JUMP.speedX;scar.vy=SCAR_SPIKE_JUMP.speedY;scar.onGround=false;
  scar.spikeSafetyWaitLogged=false;
  startJumpVisual(scar);
  logEvent('scar_salto_pinchos_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_SPIKE_JUMP.speedX,vy:SCAR_SPIKE_JUMP.speedY});
 }
 if(scar.traversal){
  const traversal=scar.traversal,isLowReturn=traversal==='g2_g1_low_return',settings=isLowReturn?SCAR_LOW_RETURN:(traversal==='water_long_jump'?SCAR_LONG_JUMP:SCAR_SPIKE_JUMP);
  scar.facing=isLowReturn?-1:1;scar.vx=settings.speedX;scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);moveBody(scar,dt,world.solids);updateJumpVisual('scar',scar,dt);
  supportState=groundSupportState(scar,world.solids);support=supportState.solid;
  if(scar.onGround&&support?.id===(isLowReturn?'G1':'G3')){
   scar.traversal=null;scar.navPhase=traversal==='water_long_jump'?'aproximacion_pinchos_segura':'follow';scar.navTargetX=null;scar.navTargetY=null;
   if(traversal==='water_long_jump')scar.recoveryGrace=Math.max(scar.recoveryGrace||0,4);
   const successEvent=isLowReturn?'scar_salto_retorno_bajo_exito':(traversal==='water_long_jump'?'scar_salto_largo_exito':'scar_salto_pinchos_exito');
   logEvent(successEvent,{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});
  }
  const longJumpHazard=world.hazards.find(h=>overlaps(bodyRect(scar),hazardCollider(h)));
  if(longJumpHazard||scar.y<-2.5)recoverScar(longJumpHazard?longJumpHazard.kind:'caída');
  return;
 }
 scar.gapJumpCooldown=Math.max(0,(scar.gapJumpCooldown||0)-dt);
 let targetX=eren.x-eren.facing*2;
 if(sim.goalPending&&scar.mode==='follow'&&world.goalZone)targetX=world.goalZone.x+world.goalZone.w/2;
 if(scar.mode==='marker')targetX=scarMarkerTarget(scar,world);
 else if(scar.mode==='bridge_marker')targetX=BRIDGE_COMMAND.plateX;
 else if(scar.mode==='wait')targetX=scar.waitX??scar.x;
 if(scene==='graybox'&&scar.x>=34){
  if(!sim.barrierOpen)targetX=Math.min(targetX,41.55);
  else if(sim.bridgeState!=='solid')targetX=sim.bridgeCommanded&&scar.mode==='bridge_marker'?BRIDGE_COMMAND.plateX:Math.min(targetX,BRIDGE_COMMAND.waitX);
 }
 const protectedSpikeApproach=scene==='graybox'&&scar.mode==='follow'&&scar.onGround&&support?.id==='G3'&&scar.x<32.5;
 if(protectedSpikeApproach&&!spikeJumpReady&&targetX>SCAR_SPIKE_JUMP.safeWaitX)targetX=SCAR_SPIKE_JUMP.safeWaitX;
 const dx=targetX-scar.x;
 const tolerance=protectedSpikeApproach ? .08 : (scar.gapJumpActive ? .16 : (sim.goalPending&&scar.mode==='follow' ? .18 : (scar.mode==='follow'?1.45:.16)));
 let axis=Math.abs(dx)>tolerance?Math.sign(dx):0;
 if(protectedSpikeApproach&&!spikeJumpReady&&scar.x>=SCAR_SPIKE_JUMP.safeWaitX-.08){
  axis=0;scar.navPhase='espera_segura_pinchos';
  if(!scar.spikeSafetyWaitLogged){scar.spikeSafetyWaitLogged=true;logEvent('scar_espera_segura_pinchos',{x:Number(scar.x.toFixed(2)),erenX:Number(eren.x.toFixed(2))});}
 }
 if(scar.mode==='marker'&&scarReachedMarker(scar,world)){
  scar.mode='wait';scar.navPhase='placa_confirmada';scar.navTargetX=world.marker.x+world.marker.w/2;scar.navTargetY=world.marker.y;scar.waitX=scar.navTargetX;
  logEvent('scar_en_huella',{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});
  if(!sim.scarPlateLatched){
   sim.scarPlateLatched=true;
   logEvent('placa_scar_activada',{latched:true,leverArmed:sim.erenSwitchArmed});
   logEvent('placa_scar_enclavada',{leverArmed:sim.erenSwitchArmed});
  }
  axis=0;
  if(!tryOpenCoopGate('placa_scar'))toast('Placa de Scar activada. Busca la palanca de Eren.',2);
 }
 if(axis)scar.facing=axis;
 const speed=scar.crouched?2.4:(Math.abs(dx)>7?6.5:(Math.abs(eren.vx)>tuning.walk+.3?5.5:3));
 scar.vx=approach(scar.vx,axis*speed,(axis?22:28)*dt);

 if(scar.gapJumpActive)scar.gapJumpAirTime=(scar.gapJumpAirTime||0)+dt;
 let shouldJump=false,gapJump=false,gapJumpReason=null,reservedTraversalLink=false;
 if(scar.onGround&&axis&&support&&!scar.crouched){
  const intentionalDrop=scar.mode==='marker'&&scar.navPhase.startsWith('bajar_');
  const reservedWaterLink=scene==='graybox'&&scar.mode==='follow'&&support.id==='G2'&&axis>0&&eren.x>=24.5;
  const reservedLowReturn=scene==='graybox'&&wantsLowReturn&&support.id==='G2'&&axis<0;
  const reservedSpikeLink=scene==='graybox'&&scar.mode==='follow'&&support.id==='G3'&&axis>0&&scar.x<32.5;
  const reservedBridgeLink=scene==='graybox'&&support.id==='G5'&&axis>0&&sim.bridgeState!=='solid';
  const reservedBridgeCommandPath=scene==='graybox'&&scar.mode==='bridge_marker'&&axis>0&&scar.x>=43&&scar.x<=BRIDGE_COMMAND.plateX+.1;
  reservedTraversalLink=reservedWaterLink||reservedLowReturn||reservedSpikeLink||reservedBridgeLink||reservedBridgeCommandPath;
  const edge=axis>0?support.x+support.w:support.x;
  const edgeDistance=axis>0?edge-(scar.x+scar.w/2):(scar.x-scar.w/2)-edge;
  const probeX=edge+axis*.08;
  const aheadSurface=surfaceAt(probeX,scar.y,world.solids);
  if(!intentionalDrop&&!reservedTraversalLink&&edgeDistance<SCAR_GAP_JUMP.anticipationDistance&&aheadSurface===null){shouldJump=true;gapJump=true;gapJumpReason='hueco_anticipado';}
  const higher=world.solids.some(s=>{
   const top=s.y+s.h,front=axis>0?s.x-(scar.x+scar.w/2):(scar.x-scar.w/2)-(s.x+s.w);
   const passableOverhead=s.y>=scar.y+scar.h-EPS;
   return!passableOverhead&&front>=-.05&&front<1.2&&top>scar.y+.25&&top<=scar.y+3.05;
  });
  if(!intentionalDrop&&!reservedTraversalLink&&higher)shouldJump=true;
 }
 const weakSupport=scar.onGround&&supportState.ratio<SCAR_GAP_JUMP.minimumStableSupportRatio-EPS;
 if(weakSupport&&!scar.crouched&&!reservedTraversalLink&&!(scar.mode==='marker'&&scar.navPhase.startsWith('bajar_'))){
  shouldJump=true;gapJump=true;gapJumpReason=supportState.ratio>EPS?'apoyo_insuficiente':'centro_sin_apoyo';
 }
 if(scar.onGround&&scar.hitWall&&axis&&!scar.crouched&&!reservedTraversalLink&&!(scar.mode==='marker'&&scar.navPhase.startsWith('bajar_')))shouldJump=true;
 if(gapJump&&(scar.gapJumpActive||scar.gapJumpCooldown>0)){shouldJump=false;gapJump=false;}
 if(shouldJump){
  const jumpDirection=axis||Math.sign(dx)||scar.facing||1;
  if(gapJump){
   scar.vx=jumpDirection*Math.max(Math.abs(scar.vx),SCAR_GAP_JUMP.speedX);
   if(!scar.gapJumpActive){
    scar.gapJumpActive=true;scar.gapJumpFrom=support?.id||null;scar.gapJumpAirTime=0;scar.ignoredSupportId=support?.id||null;
    logEvent('scar_salto_hueco_inicio',{x:Number(scar.x.toFixed(2)),from:scar.gapJumpFrom,reason:gapJumpReason,supportRatio:Number(supportState.ratio.toFixed(3))});
   }
  }
  scar.facing=jumpDirection;scar.vy=SCAR_GAP_JUMP.speedY;scar.onGround=false;startJumpVisual(scar);logEvent('scar_salto',{x:Number(scar.x.toFixed(2))});
 }
 scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);
 const beforeX=scar.x,beforeY=scar.y;
 moveBody(scar,dt,world.solids);
 updateJumpVisual('scar',scar,dt);

 if(scar.gapJumpActive&&scar.onGround&&scar.gapJumpAirTime>=SCAR_GAP_JUMP.minimumAirTime){
  const landing=groundSupportState(scar,world.solids);
  if(landing.ratio>=SCAR_GAP_JUMP.minimumStableSupportRatio-EPS){
   const crossed=!!landing.solid&&landing.solid.id!==scar.gapJumpFrom;
   logEvent(crossed?'scar_salto_hueco_exito':'scar_salto_hueco_reintento',{from:scar.gapJumpFrom,to:landing.solid?.id||null,x:Number(scar.x.toFixed(2)),supportRatio:Number(landing.ratio.toFixed(3))});
   scar.gapJumpActive=false;scar.gapJumpFrom=null;scar.gapJumpAirTime=0;scar.gapJumpCooldown=SCAR_GAP_JUMP.retryCooldown;
  }
 }

 if((scar.mode==='marker'||scar.mode==='bridge_marker')&&axis&&scar.onGround&&Math.abs(scar.x-beforeX)<.003&&Math.abs(scar.y-beforeY)<.003)scar.navStuck+=dt;else scar.navStuck=0;
 if((scar.mode==='marker'||scar.mode==='bridge_marker')&&scar.navStuck>2.5){logEvent('scar_ruta_bloqueada',{phase:scar.navPhase,x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});scar.navStuck=0;recoverScar('ruta_marcador');}

 const hazard=world.hazards.find(h=>overlaps(bodyRect(scar),hazardCollider(h)));
 if(hazard?.kind==='spikes'&&scene==='graybox'&&!scar.crouched&&scar.y>=2-EPS){
  scar.traversal='spike_jump';scar.navPhase='salto_pinchos_emergencia';scar.facing=1;scar.vx=SCAR_SPIKE_JUMP.speedX;scar.vy=SCAR_SPIKE_JUMP.speedY;scar.onGround=false;scar.gapJumpActive=false;scar.ignoredSupportId=null;startJumpVisual(scar);
  logEvent('scar_salto_pinchos_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_SPIKE_JUMP.speedX,vy:SCAR_SPIKE_JUMP.speedY,emergency:true});
 }else if(hazard||scar.y<-2.5)recoverScar(hazard?hazard.kind:'caída');
 const inheritedRecoveryZone=scar.x<36.5&&eren.x<36.5;
 if(inheritedRecoveryZone&&!sim.goalPending&&scar.mode==='follow'&&scar.recoveryGrace<=0&&Math.abs(scar.x-eren.x)>15)scar.stuck+=dt;else scar.stuck=0;
 if(scar.stuck>.55)recoverScar('fuera_de_camara');
}

function bridgeClearanceOccupied(){
 const zone={x:51.5,y:1.45,w:4,h:2.55};
 return[sim.eren,sim.scar].some(actor=>(actor.recoverTimer||0)<=0&&overlaps(bodyRect(actor),zone));
}

function updateEnemyCombat(dt){
 if(sim.enemyDefeated){sim.enemyDefeatVisualElapsed+=dt;return;}
 const eren=sim.eren,inArena=eren.x>=37.2&&eren.x<=42.35&&eren.y<=3.8;
 if(sim.enemyState==='patrol'){
  sim.enemyX+=sim.enemyFacing*ENEMY_COMBAT.patrolSpeed*dt;
  if(sim.enemyX<=ENEMY_COMBAT.patrolMinX){sim.enemyX=ENEMY_COMBAT.patrolMinX;sim.enemyFacing=1;}
  if(sim.enemyX>=ENEMY_COMBAT.patrolMaxX){sim.enemyX=ENEMY_COMBAT.patrolMaxX;sim.enemyFacing=-1;}
  if(inArena){sim.enemyState='alerting';sim.enemyStateElapsed=0;sim.enemyFacing=eren.x<sim.enemyX?-1:1;logEvent('enemigo_alerta_inicio',{duration:ENEMY_COMBAT.alertSeconds,enemyX:Number(sim.enemyX.toFixed(2))});}
  return;
 }
 if(sim.enemyState==='alerting'){
  sim.enemyStateElapsed+=dt;sim.enemyFacing=eren.x<sim.enemyX?-1:1;
  if(sim.enemyStateElapsed+.0001>=ENEMY_COMBAT.alertSeconds){sim.enemyState='chase';sim.enemyStateElapsed=0;logEvent('enemigo_alerta_completa',{duration:ENEMY_COMBAT.alertSeconds});toast('¡El guardián ataca! Salta la embestida y contraataca.',1.4);}
  return;
 }
 if(sim.enemyState==='hit'){
  sim.enemyStateElapsed+=dt;
  if(sim.enemyStateElapsed+.0001>=ENEMY_COMBAT.enemyHitStunSeconds)setEnemyState('chase',{afterHit:true});
  return;
 }
 if(sim.enemyState==='chase'){
  const dx=eren.x-sim.enemyX;sim.enemyFacing=Math.sign(dx)||sim.enemyFacing||1;
  sim.enemyX=clamp(sim.enemyX+sim.enemyFacing*ENEMY_COMBAT.chaseSpeed*dt,ENEMY_COMBAT.patrolMinX,ENEMY_COMBAT.patrolMaxX);
  if(inArena&&Math.abs(dx)<=ENEMY_COMBAT.attackTriggerDistance){
   sim.enemyAttackFacing=sim.enemyFacing;sim.enemyHitApplied=false;setEnemyState('windup',{duration:ENEMY_COMBAT.windupSeconds,facing:sim.enemyAttackFacing});
   toast('¡Va a embestir! Salta ahora.',.9);
  }
  return;
 }
 if(sim.enemyState==='windup'){
  sim.enemyStateElapsed+=dt;
  if(sim.enemyStateElapsed+.0001>=ENEMY_COMBAT.windupSeconds){sim.enemyState='lunge';sim.enemyStateElapsed=0;sim.enemyHitApplied=false;logEvent('enemigo_ataque_inicio',{duration:ENEMY_COMBAT.lungeSeconds,facing:sim.enemyAttackFacing});}
  return;
 }
 if(sim.enemyState==='lunge'){
  sim.enemyStateElapsed+=dt;sim.enemyX=clamp(sim.enemyX+sim.enemyAttackFacing*ENEMY_COMBAT.lungeSpeed*dt,ENEMY_COMBAT.patrolMinX,ENEMY_COMBAT.patrolMaxX);
  const active=sim.enemyStateElapsed>=ENEMY_COMBAT.activeFrom&&sim.enemyStateElapsed<=ENEMY_COMBAT.activeUntil;
  if(active&&!sim.enemyHitApplied&&overlaps(bodyRect(eren),enemyAttackRect()))sim.enemyHitApplied=damageErenFromEnemy();
  if(sim.enemyStateElapsed+.0001>=ENEMY_COMBAT.lungeSeconds){
   if(!sim.enemyHitApplied)logEvent('enemigo_ataque_esquivado',{erenY:Number(eren.y.toFixed(2)),enemyX:Number(sim.enemyX.toFixed(2))});
   setEnemyState('recover',{hit:sim.enemyHitApplied,duration:ENEMY_COMBAT.recoverySeconds});
  }
  return;
 }
 if(sim.enemyState==='recover'){
  sim.enemyStateElapsed+=dt;
  if(sim.enemyStateElapsed+.0001>=ENEMY_COMBAT.recoverySeconds)setEnemyState('chase',{afterRecovery:true});
 }
}

function updateGb02(dt){
 if(scene!=='graybox')return;
 const eren=sim.eren,scar=sim.scar,world=sim.world;
 updateEnemyCombat(dt);

 const plate=world.bridgePlate,scarSupport=supportingSolid(scar,world.solids);
 if(sim.barrierOpen&&!sim.bridgePlateLatched&&scarSupport?.id==='G5'&&overlaps(bodyRect(scar),plate)&&(!sim.bridgeCommanded||scar.mode!=='bridge_marker')){
  if(!sim.bridgeAutoBlockLogged){sim.bridgeAutoBlockLogged=true;logEvent('placa_puente_sin_orden_bloqueada',{x:Number(scar.x.toFixed(2))});toast('Scar espera la orden de la pata antes de accionar la placa.',1.5);}
 }
 if(sim.barrierOpen&&!sim.bridgePlateLatched&&sim.bridgeCommanded&&scar.mode==='bridge_marker'&&scarSupport?.id==='G5'&&overlaps(bodyRect(scar),plate)){
  sim.bridgePlateLatched=true;sim.bridgeState='pending_empty';scar.bridgeWait=true;scar.mode='wait';scar.waitX=plate.x+plate.w/2;scar.navPhase='placa_puente_enclavada';
  logEvent('placa_puente_scar_enclavada',{latched:true,x:Number(scar.x.toFixed(2)),commandRequired:true,commandCount:sim.bridgeCommandCount});toast('Placa enclavada: esperando zona de despliegue libre.',1.6);
 }
 if(sim.bridgeState==='pending_empty'&&!bridgeClearanceOccupied()){
  sim.bridgeState='deploying';sim.bridgeDeployElapsed=0;sim.bridgeWaitLogged=false;
  logEvent('puente_despliegue_inicio',{duration:.6,collider:false});
 }
 if(sim.bridgeState==='pending_empty'&&!sim.bridgeWaitLogged){sim.bridgeWaitLogged=true;logEvent('puente_espera_zona_libre');}
 if(sim.bridgeState==='deploying'){
  sim.bridgeDeployElapsed+=dt;
  if(sim.bridgeDeployElapsed+.0001>=.6&&!bridgeClearanceOccupied()){
   sim.bridgeState='solid';rebuildWorld();
   logEvent('puente_solido',{latched:true,deploySeconds:.6,collider:true});toast('Puente sólido y permanente. Scar reanuda la ruta segura.',1.8);tone('correct');
   if(scar.bridgeWait){scar.bridgeWait=false;scar.mode='follow';scar.waitX=null;scar.navPhase='follow';scar.recoveryGrace=Math.max(scar.recoveryGrace||0,4);logEvent('scar_reanuda_ruta_segura');}
  }
 }

 const erenSupport=supportingSolid(eren,sim.world.solids),updatedScarSupport=supportingSolid(scar,sim.world.solids);
 if(sim.bridgeState==='solid'&&!sim.r4Unlocked&&erenSupport?.id==='G6'&&updatedScarSupport?.id==='G6'){
  sim.r4Unlocked=true;sim.checkpoint={x:56.5,y:2,id:'R4'};logEvent('anclaje',{id:'R4',requires:['bridge_solid','eren_safe_g6','scar_safe_g6']});toast('R4 activado: ambos a salvo en G6.',1.4);
 }
}

function actorInGoalZone(entity){
 if(scene!=='graybox'||!sim?.world?.goalZone||!entity.onGround)return false;
 const support=supportingSolid(entity,sim.world.solids),zone=sim.world.goalZone;
 return support?.id==='G6'&&pointInRect(entity.x,entity.y,zone);
}

function updateGoalReunion(dt){
 if(scene!=='graybox'||!sim.goalPending||sim.complete)return;
 sim.goalWait+=dt;
 const scar=sim.scar;
 if(scar.recoverTimer<=0&&scar.mode==='follow'&&actorInGoalZone(sim.eren)&&actorInGoalZone(scar)){
  logEvent('meta_reunion_scar',{wait:Number(sim.goalWait.toFixed(2)),erenX:Number(sim.eren.x.toFixed(2)),scarX:Number(scar.x.toFixed(2)),zone:[sim.world.goalZone.x,sim.world.goalZone.x+sim.world.goalZone.w]});finishGraybox();return;
 }
 if(sim.goalWait>=2&&!sim.goalCallIssued&&actorInGoalZone(sim.eren)){
  sim.goalCallIssued=true;
  if(!scar.bridgeWait){scar.mode='follow';scar.waitX=null;scar.navPhase='follow';scar.recoveryGrace=Math.max(scar.recoveryGrace||0,6);}
  toast('¡Scar, ven a la meta!',1.6);playAzureSequence(['Scar, ven a la meta.']);
  logEvent('meta_llamada_scar',{afterSeconds:2,physicalRouteOnly:true,teleport:false});
 }
}

function updateCamera(dt){
 const world=sim.world,eren=sim.eren;
 const viewport=currentViewportWorldSize();sim.camera.viewW=viewport.w;sim.camera.viewH=viewport.h;
 const look=clamp(eren.vx/tuning.run,-1,1)*3;
 const desiredX=clamp(eren.x+look-viewport.w/2,world.minX,Math.max(world.minX,world.maxX-viewport.w));
 const desiredY=clamp(eren.y-3.75,world.minY,Math.max(world.minY,world.maxY-viewport.h));
 sim.camera.x+=(desiredX-sim.camera.x)*(1-Math.exp(-dt/.18));
 sim.camera.y+=(desiredY-sim.camera.y)*(1-Math.exp(-dt/.25));
}

function physicsStep(dt,input){
 if(!sim||!sim.running||sim.paused)return;
 sim.elapsed+=dt;
 for(const control of['left','right','run']){
  if(input[control]&&!sim.prevInput[control])logEvent('control_inicio',{control});
  if(!input[control]&&sim.prevInput[control])logEvent('control_fin',{control});
 }
 updateEren(input,dt);
 updateScar(dt);
 updateGb02(dt);
 updateGoalReunion(dt);
 if(!sim.paused)updateCamera(dt);
 sim.prevInput={...input};
}

function finishGraybox(){
 sim.complete=true;sim.paused=true;logEvent('meta',{elapsed:Number(sim.elapsed.toFixed(2)),star:sim.starCollected,damage:sim.events.filter(e=>e.type==='daño').length});
 const wins=Number(localStorage.getItem('game-wins')||0)+1;localStorage.setItem('game-wins',String(wins));
 localStorage.setItem('graybox-last-playtest',JSON.stringify(playtestBundle()));
 byId('gameRewardStars').textContent=sim.starCollected?'★':'☆';byId('gameReward').classList.remove('hidden');
 tone('correct');setTimeout(()=>tone('correct'),230);playAzureSequence(['¡GB02 completado! Eren y Scar han llegado juntos.']);
}

function playtestAttemptPayload(){
 const events=sim?sim.events:[];
 return{
  runId:sim?.runId||null,startedAt:sim?.startedAt||null,capturedAt:new Date().toISOString(),scene:sim?.scene||scene,station:sim?.station||labStation,
  tuning:{...tuning},summary:sim?{
   elapsed:Number(sim.elapsed.toFixed(2)),maxSpeed:Number(sim.maxSpeed.toFixed(2)),maxJumpHeight:Number(sim.maxHeight.toFixed(2)),
   hearts:sim.eren.hearts,star:sim.starCollected,complete:sim.complete,damageCount:events.filter(e=>e.type==='daño').length,
   edgeThirdFalls:events.filter(e=>e.type==='caida_borde_tercio').length,edgeFootProbeFalls:events.filter(e=>e.type==='caida_borde_sondas_pie').length,
   edgeRecontactEvents:events.filter(e=>e.type==='caida_borde_sondas_pie'||e.type==='caida_borde_tercio').length,
   jumps:events.filter(e=>e.type==='salto').length,runActivations:events.filter(e=>e.type==='control_inicio'&&e.control==='run').length,
   directionActivations:events.filter(e=>e.type==='control_inicio'&&(e.control==='left'||e.control==='right')).length,
   actionPresses:events.filter(e=>e.type==='accion').length,scarRecoveries:events.filter(e=>e.type==='scar_recuperacion').length,
   scarMarkerCommands:events.filter(e=>e.type==='scar_huella').length,scarMarkerSuccesses:events.filter(e=>e.type==='scar_en_huella').length,
   scarPlateActivations:events.filter(e=>e.type==='placa_scar_activada').length,scarPlateLatches:events.filter(e=>e.type==='placa_scar_enclavada').length,leverAttempts:events.filter(e=>e.type==='palanca_eren_activada').length,
   coopUnlocks:events.filter(e=>e.type==='puerta_coop_abierta').length,puzzleBypassBlocks:events.filter(e=>e.type==='bypass_puzle_bloqueado').length,
   scarLowPasses:events.filter(e=>e.type==='scar_paso_bajo_inicio').length,scarRouteBlocks:events.filter(e=>e.type==='scar_ruta_bloqueada').length,
   scarLowReturns:events.filter(e=>e.type==='scar_salto_retorno_bajo_inicio').length,scarLowReturnSuccesses:events.filter(e=>e.type==='scar_salto_retorno_bajo_exito').length,
   scarLongJumps:events.filter(e=>e.type==='scar_salto_largo_inicio').length,scarLongJumpSuccesses:events.filter(e=>e.type==='scar_salto_largo_exito').length,
   scarSpikeJumps:events.filter(e=>e.type==='scar_salto_pinchos_inicio').length,scarSpikeJumpSuccesses:events.filter(e=>e.type==='scar_salto_pinchos_exito').length,
   scarGapJumps:events.filter(e=>e.type==='scar_salto_hueco_inicio').length,scarGapJumpSuccesses:events.filter(e=>e.type==='scar_salto_hueco_exito').length,
   erenAttacks:events.filter(e=>e.type==='eren_golpe_inicio').length,erenAttackHits:events.filter(e=>e.type==='enemigo_golpe'&&e.source==='eren_attack_window').length,
   enemyAttacks:events.filter(e=>e.type==='enemigo_ataque_inicio').length,enemyAttackHits:events.filter(e=>e.type==='enemigo_impacta_eren').length,enemyAttackDodges:events.filter(e=>e.type==='enemigo_ataque_esquivado').length,
   enemyDefeats:events.filter(e=>e.type==='enemigo_derrotado').length,ladderGrabs:events.filter(e=>e.type==='escalera_agarre_inicio').length,ladderTopExits:events.filter(e=>e.type==='escalera_salida_superior_completa').length,
   bridgeCommands:events.filter(e=>e.type==='scar_orden_puente').length,bridgeAutoLatchBlocks:events.filter(e=>e.type==='placa_puente_sin_orden_bloqueada').length,bridgePlateLatches:events.filter(e=>e.type==='placa_puente_scar_enclavada').length,
   bridgeDeployments:events.filter(e=>e.type==='puente_solido').length,goalCalls:events.filter(e=>e.type==='meta_llamada_scar').length,
   scarLowProfileMutations:events.filter(e=>e.type==='scar_paso_bajo_inicio'||e.type==='scar_paso_bajo_fin').length,
   goalReunions:events.filter(e=>e.type==='meta_reunion_scar').length
  }:null,finalState:sim?{
   eren:{x:Number(sim.eren.x.toFixed(2)),y:Number(sim.eren.y.toFixed(2)),vx:Number(sim.eren.vx.toFixed(2)),vy:Number(sim.eren.vy.toFixed(2)),visualState:sim.eren.visualState,ladderState:sim.ladderState,attackState:sim.erenAttackState},
   scar:{x:Number(sim.scar.x.toFixed(2)),y:Number(sim.scar.y.toFixed(2)),mode:sim.scar.mode,crouched:sim.scar.crouched,navPhase:sim.scar.navPhase,traversal:sim.scar.traversal},
   coopPuzzle:{plateActive:scarPlateActive(),plateLatched:sim.scarPlateLatched,leverArmed:sim.erenSwitchArmed,unlocked:sim.coopUnlocked},
   gb02:{enemyHp:sim.enemyHp,enemyState:sim.enemyState,enemyX:Number(sim.enemyX.toFixed(2)),barrierOpen:sim.barrierOpen,ladderEnabled:sim.ladderEnabled,scarReleased:sim.scarReleased,bridgeCommanded:sim.bridgeCommanded,bridgeCommandCount:sim.bridgeCommandCount,bridgePlateLatched:sim.bridgePlateLatched,bridgeState:sim.bridgeState,r4Unlocked:sim.r4Unlocked},
   goal:{pending:sim.goalPending,callIssued:sim.goalCallIssued,erenInZone:actorInGoalZone(sim.eren),scarInZone:actorInGoalZone(sim.scar)},checkpoint:sim.checkpoint.id
  }:null,events
 };
}

function playtestBundle(){
 const attempts=[...attemptHistory];
 if(sim&&!sim.archived&&hasMeaningfulAttempt(sim.events))attempts.push(playtestAttemptPayload());
 const includedAttempts=attempts.slice(-MAX_PLAYTEST_ATTEMPTS);
 return{
  version:LOG_VERSION,appVersion:APP_VERSION,testMode:TEST_MODE,generatedAt:new Date().toISOString(),
  visuals:{
   packageId:`${R16_FUNCTIONAL_ART_PACK.packageId}+${WORLD_ART_PACK.packageId}+${TERRAIN_MOUNT_PACK.packageId}+${UI_ART_PACK.packageId}`,
   packages:{functionalArt:R16_FUNCTIONAL_ART_PACK.packageId,locomotion:LOCOMOTION_PACK.packageId,jump:JUMP_PACK.packageId,worldArt:WORLD_ART_PACK.packageId,terrain:TERRAIN_MOUNT_PACK.packageId,ui:UI_ART_PACK.packageId},status:'GB02_R04_FUNCTIONAL_ART_CANDIDATE_R16_ON_R15_PASS',gameReady:false,functionalValidation:FUNCTIONAL_VALIDATION,gb02Contract:GB02_CONTRACT,ppu:100,rootMotion:false,physicsAuthoritative:true,transformScale:[1,1],
   frameCounts:{totalFunctional:101,eren:48,scar:35,enemy:16,functionalWorld:2,locomotion:{eren:16,scar:16},jump:{eren:6,erenRunning:6,scar:6},erenActions:12,erenLadder:8,scarLow:8,scarSignals:5},
   timingMs:{locomotion:{eren:LOCOMOTION_PACK.eren.timingMs,scar:LOCOMOTION_PACK.scar.timingMs},jump:{eren:JUMP_PACK.eren.timingMs,erenRunning:JUMP_PACK.erenRun.timingMs,scar:JUMP_PACK.scar.timingMs},erenActions:EREN_ACTION_PACK.timingMs,erenLadder:EREN_LADDER_PACK.timingMs,scarLow:SCAR_LOW_PACK.timingMs,scarSignals:SCAR_SIGNAL_PACK.timingMs,enemy:ENEMY_ART_PACK.timingMs},thresholds:LOCOMOTION_THRESHOLDS,
   locomotionReview:{status:'ART_R02_CANDIDATE_INTEGRATED',currentPackageStatus:'R16_VISUAL_CANDIDATE',awaitingPackage:null,integrated:true,erenIdlePlayback:'ANIMATED_4_FRAMES',erenLegAlternation:'INTEGRATED_R16_CANDIDATE',scarIdlePlayback:'ANIMATED_4_FRAMES',contactNormalization:'R10_ACTOR_INSET_PLUS_R16_ALPHA_GAP_FRAME_EREN_RUN_03_30PX'},
   runtimeStateVisuals:R16_RUNTIME_VISUALS,
   jumpArt:JUMP_PACK.packageId,
   worldArt:{status:'FUNCTIONAL_R16_CANDIDATE_PLACEMENT',sourceStatus:WORLD_ART_PACK.sourceStatus,gameReady:false,assetCount:Object.keys(WORLD_ART_PACK.assets).length+2,geometryAuthoritative:true,collidersChanged:false,physicsChanged:false,runtimePlacementRevision:'R16_VISUAL_ONLY_ON_R15_GEOMETRY',canonicalStructures:{S012:{sha256:r16WorldArt.ladder.sha256,modules:[1,3.5],stretched:false},S020:{sha256:r16WorldArt.bridge.sha256,modules:[4.5,1],stretched:false,visualOverhangModules:.25,colliderModules:[4,.5]}},boxFit:WORLD_ART_PACK.assets.boxIntact.fit,boxRemainsFit:WORLD_ART_PACK.assets.boxRemains.fit,plateFit:WORLD_ART_PACK.assets.plateFree.fit,plateVisibleCoverageModules:{free:WORLD_ART_PACK.assets.plateFree.visibleCoverageModules,pressed:WORLD_ART_PACK.assets.platePressed.visibleCoverageModules},visualContactPlane:VISUAL_CONTACT_PLANE,provisionalPlacements:['lever']},
   terrainMount:{packageId:TERRAIN_MOUNT_PACK.packageId,decisionId:TERRAIN_MOUNT_PACK.decisionId,status:TERRAIN_MOUNT_PACK.status,gameReady:TERRAIN_MOUNT_PACK.gameReady,replaces:TERRAIN_MOUNT_PACK.replaces,predecessorStatus:TERRAIN_MOUNT_PACK.predecessorStatus,sourceAssetCount:2,solidRecipeCount:9,ppu:TERRAIN_MOUNT_PACK.ppu,transformScale:TERRAIN_MOUNT_PACK.transformScale,integrationScope:TERRAIN_MOUNT_PACK.integrationScope,renderer:TERRAIN_MOUNT_PACK.renderer,runtimeDrawCallsPerSolid:TERRAIN_MOUNT_PACK.runtimeDrawCallsPerSolid,runtimeHalfTileRepetition:TERRAIN_MOUNT_PACK.runtimeHalfTileRepetition,runtimePrecomposedSolidPng:TERRAIN_MOUNT_PACK.runtimePrecomposedSolidPng,geometryChanged:TERRAIN_MOUNT_PACK.geometryChanged,collidersChanged:TERRAIN_MOUNT_PACK.collidersChanged,physicsChanged:TERRAIN_MOUNT_PACK.physicsChanged,pivotsChanged:TERRAIN_MOUNT_PACK.pivotsChanged,renderOffsets:TERRAIN_MOUNT_PACK.renderOffsets,visualFootAnchor:TERRAIN_MOUNT_PACK.visualFootAnchor,visualContactPlane:TERRAIN_MOUNT_PACK.visualContactPlane,sourceAsset:TERRAIN_MOUNT_PACK.sourceAsset},
   uiArt:{...UI_ART_PACK,runtimePanel:'COLLAPSED_DRAWER_TOP_RIGHT',defaultPanelOpen:false,gameViewport:'PANORAMIC_DYNAMIC_FULL_WIDTH',viewportPolicy:GB02_CONTRACT.viewport,hudHearts:HUD_HEARTS_LAYOUT},
   edgeSupport:{...EDGE_SUPPORT_POLICY,visualContactPlane:VISUAL_CONTACT_PLANE},
   scarGapTraversal:{automaticJump:true,minimumStableSupportRatio:SCAR_GAP_JUMP.minimumStableSupportRatio,anticipationDistance:SCAR_GAP_JUMP.anticipationDistance,retryCooldown:SCAR_GAP_JUMP.retryCooldown,singleActiveJump:true,fallRecovery:true,spikeSafety:'SAFE_WAIT_THEN_FORCED_JUMP'},
   coopPlate:{actor:'scar',type:'latched_switch',physicalSurface:'shared_ground',activationPersists:true,resumeAfterUnlock:true},
   gb02:{enemy:{hp:2,patrol:[ENEMY_COMBAT.patrolMinX,ENEMY_COMBAT.patrolMaxX],patrolSpeed:ENEMY_COMBAT.patrolSpeed,chaseSpeed:ENEMY_COMBAT.chaseSpeed,alertSeconds:ENEMY_COMBAT.alertSeconds,windupSeconds:ENEMY_COMBAT.windupSeconds,lungeSeconds:ENEMY_COMBAT.lungeSeconds,activeWindow:[ENEMY_COMBAT.activeFrom,ENEMY_COMBAT.activeUntil],hitboxHeight:ENEMY_COMBAT.hitboxHeight,passiveContactDamage:false,visualActor:'ARANA_M1',visualPackage:R16_FUNCTIONAL_ART_PACK.packageId,atomicConsequences:['barrier_removed','ladder_enabled','scar_released']},ladder:{states:['agarre','subida','bajada','salida_superior'],visualStates:['ladder_grip','ladder_up','ladder_down','ladder_exit_top','ladder_release'],canonicalAsset:'S012',climbSpeed:LADDER_TRAVERSAL.climbSpeed,topExitSeconds:LADDER_TRAVERSAL.exitSeconds,ignoredSolidOnlyDuringClimb:LADDER_TRAVERSAL.ignoredSolidId},bridge:{plate:'scar_only',commandRequired:true,commandZone:[BRIDGE_COMMAND.erenMinX,BRIDGE_COMMAND.erenMaxX],scarOnlyClearance:.75,erenCrouchedFits:false,latched:true,emptyZoneBeforeDeploy:true,deploySeconds:.6,colliderDuringDeploy:false,solidPermanent:true,canonicalAsset:'S020',nativeVisualModules:[4.5,1],colliderModules:[4,.5]},scarSafeRoute:{surfaceY:2,requiresJumps:false,requiresTeleport:false,hazards:false,requiredLowPass:true},lab:GB02_CONTRACT.lab,tilesetIntegrated:false},
   goalContract:{type:'strict_dual_actor_zone',zone:sim?.world?.goalZone||null,requires:['eren','scar'],simultaneousPresence:true,support:'G6',aloneCallAfterSeconds:2,teleport:false},
   jumpPhysics:{eren:{takeoffVy:tuning.jump,gravityUp:tuning.gravityUp,gravityDown:tuning.gravityDown,terminalFallVy:-16},scar:{ordinaryTakeoffVy:14.7,longWaterTakeoffVy:SCAR_LONG_JUMP.speedY,spikeTakeoffVy:SCAR_SPIKE_JUMP.speedY,lowReturnTakeoffVy:SCAR_LOW_RETURN.speedY,gravityUp:36,gravityDown:44,terminalFallVy:-16}}
  },
  device:{userAgent:navigator.userAgent||'Android WebView',viewport:{width:window.innerWidth||0,height:window.innerHeight||0},viewportWorld:currentViewportWorldSize(),pixelRatio:window.devicePixelRatio||1},
  attemptCount:includedAttempts.length,attempts:includedAttempts
 };
}

function compactPlaytestBundle(){
 const bundle=playtestBundle(),keyTypes=new Set(['caja_rota','caida_borde_sondas_pie','scar_en_huella','placa_scar_activada','placa_scar_enclavada','palanca_eren_activada','puzle_coop_completado','puerta_coop_abierta','scar_reanuda_tras_puzle','bypass_puzle_bloqueado','scar_ruta_bloqueada','scar_salto_hueco_inicio','scar_salto_hueco_exito','scar_salto_hueco_reintento','scar_salto_retorno_bajo_inicio','scar_salto_retorno_bajo_exito','scar_salto_largo_inicio','scar_salto_largo_exito','scar_espera_segura_pinchos','scar_salto_pinchos_inicio','scar_salto_pinchos_exito','scar_recuperacion','enemigo_alerta_completa','enemigo_windup','enemigo_ataque_inicio','enemigo_impacta_eren','enemigo_ataque_esquivado','eren_golpe_inicio','eren_golpe_falla','enemigo_golpe','enemigo_derrotado','barrera_gb02_retirada','escalera_gb02_habilitada','scar_gb02_liberado','escalera_agarre_inicio','escalera_salida_superior_inicio','escalera_salida_superior_completa','eren_tunel_scar_bloqueado','scar_orden_puente','scar_paso_bajo_inicio','scar_paso_bajo_fin','placa_puente_sin_orden_bloqueada','placa_puente_scar_enclavada','puente_despliegue_inicio','puente_solido','scar_reanuda_ruta_segura','meta_llamada_scar','daño','estrella','anclaje','meta_espera_scar','meta_reunion_scar','meta']);
 return{
  version:bundle.version,appVersion:bundle.appVersion,testMode:bundle.testMode,generatedAt:bundle.generatedAt,visuals:bundle.visuals,device:bundle.device,attemptCount:bundle.attemptCount,
  attempts:bundle.attempts.map(attempt=>({runId:attempt.runId,startedAt:attempt.startedAt,scene:attempt.scene,station:attempt.station,tuning:attempt.tuning,summary:attempt.summary,finalState:attempt.finalState,keyEvents:attempt.events.filter(event=>keyTypes.has(event.type))}))
 };
}

function worldToScreen(x,y,draw){return{x:draw.ox+(x-sim.camera.x)*draw.scale,y:draw.oy+(sim.camera.y+draw.viewH-y)*draw.scale};}

function drawStar(ctx,x,y,r,draw){
 const p=worldToScreen(x,y,draw);ctx.save();ctx.translate(p.x,p.y);ctx.beginPath();
 for(let i=0;i<10;i++){const angle=-Math.PI/2+i*Math.PI/5,rad=(i%2?r*.45:r)*draw.scale;const px=Math.cos(angle)*rad,py=Math.sin(angle)*rad;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}
 ctx.closePath();ctx.fillStyle='#ffd34f';ctx.fill();ctx.strokeStyle='#6d5410';ctx.lineWidth=2;ctx.stroke();ctx.restore();
}

function artReady(asset){return!!asset?.image?.complete&&!!asset.image.naturalWidth;}

function drawWorldArt(ctx,asset,x,y,w=asset?.worldSize?.w,h=asset?.worldSize?.h,draw,options={}){
 if(!artReady(asset)||!Number.isFinite(w)||!Number.isFinite(h))return false;
 const surfaceOffset=options.alignSurface?(asset.surfaceTopInsetPx||0)/WORLD_ART_PACK.ppu:0;
 const topLeft=worldToScreen(x,y+h+surfaceOffset,draw);
 if(options.alignBottom)topLeft.y+=(asset.bottomTransparentPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 topLeft.y+=(options.contactInsetPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 ctx.save();
 if(options.alpha!==undefined)ctx.globalAlpha=options.alpha;
 if(options.filter)ctx.filter=options.filter;
 ctx.drawImage(asset.image,topLeft.x,topLeft.y,w*draw.scale,h*draw.scale);
 ctx.restore();
 return true;
}

function drawWorldArtFitBounds(ctx,asset,x,y,w,draw,options={}){
 if(!artReady(asset)||!asset.visibleBoundsPx)return false;
 const [sx,sy,sw,sh]=asset.visibleBoundsPx,destH=w*sh/sw,topLeft=worldToScreen(x,y+destH,draw);
 topLeft.y+=(options.contactInsetPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(options.alpha!==undefined)ctx.globalAlpha=options.alpha;
 ctx.drawImage(asset.image,sx,sy,sw,sh,topLeft.x,topLeft.y,w*draw.scale,destH*draw.scale);
 ctx.restore();return true;
}

function drawWorldArtToCollider(ctx,asset,solid,draw,options={}){
 if(!artReady(asset)||!asset.visibleBoundsPx)return false;
 const [sx,sy,sw,sh]=asset.visibleBoundsPx,topLeft=worldToScreen(solid.x,solid.y+solid.h,draw);
 topLeft.y+=(options.contactInsetPx||0)/WORLD_ART_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(options.alpha!==undefined)ctx.globalAlpha=options.alpha;
 ctx.drawImage(asset.image,sx,sy,sw,sh,topLeft.x,topLeft.y,solid.w*draw.scale,solid.h*draw.scale);
 ctx.restore();return true;
}

function withSolidClip(ctx,solid,draw,callback){
 const topLeft=worldToScreen(solid.x,solid.y+solid.h,draw);
 ctx.save();ctx.beginPath();ctx.rect(topLeft.x,topLeft.y,solid.w*draw.scale,solid.h*draw.scale);ctx.clip();
 callback();ctx.restore();
}

function drawNativePlatform(ctx,solid,draw){
 return drawContinuousTerrain(ctx,solid,draw);
}

function drawContinuousTerrain(ctx,solid,draw){
 const asset=TERRAIN_CONTINUOUS_ASSET;
 if(!artReady(asset))return false;
 const sourceW=Math.round(solid.w*asset.ppu),sourceH=Math.round(solid.h*asset.ppu);
 if(sourceW<=0||sourceH<=0||sourceH>asset.canvasPx[1])return false;
 const requested=asset.sourceOffsetsPx[solid.id]||0,sourceX=clamp(requested,0,asset.canvasPx[0]-sourceW);
 const topLeft=worldToScreen(solid.x,solid.y+solid.h,draw);
 ctx.save();ctx.imageSmoothingEnabled=true;
 ctx.drawImage(asset.image,sourceX,0,sourceW,sourceH,topLeft.x,topLeft.y,solid.w*draw.scale,solid.h*draw.scale);
 ctx.restore();return true;
}

function drawGroundTerrain(ctx,solid,draw){
 return drawContinuousTerrain(ctx,solid,draw);
}

function drawNativeTerrain(ctx,solid,draw){
 if(solid.id==='U0_VERTICAL')return drawWorldArt(ctx,worldArt.ruinColumn,solid.x,solid.y,1,4.5,draw);
 if(Math.abs(solid.h-.5)<EPS)return drawNativePlatform(ctx,solid,draw);
 if(solid.kind==='ground')return drawGroundTerrain(ctx,solid,draw);
 return false;
}

function drawSolidWorldArt(ctx,solid,draw){
 if(scene!=='graybox')return false;
 if(solid.id==='CAJA_ROMPIBLE')return drawWorldArtToCollider(ctx,worldArt.boxIntact,solid,draw,{contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
 if(solid.id==='PUENTE_1')return drawWorldArt(ctx,r16WorldArt.bridge,solid.x-.25,solid.y-.5,4.5,1,draw);
 const inheritedArtSolids=new Set(['G0','G1','G2','G3','U0_VERTICAL','TECHO_BAJO','U1','U2','U3']);
 if(!inheritedArtSolids.has(solid.id))return false;
 if(!['ground','upper','roof'].includes(solid.kind))return false;
 return drawNativeTerrain(ctx,solid,draw);
}

function drawHazard(ctx,h,draw){
 const left=worldToScreen(h.x,h.y+h.h,draw),w=h.w*draw.scale,height=h.h*draw.scale;
 if(h.kind==='water'){
  const useWorldArt=scene==='graybox'&&h.id==='AGUA'&&Math.abs(h.w-4)<EPS&&artReady(worldArt.water);
  ctx.fillStyle=useWorldArt?'#0e6688cc':'#2c99c4bb';ctx.fillRect(left.x,left.y,w,height);
  if(useWorldArt){
   const artH=worldArt.water.worldSize.h;
   drawWorldArt(ctx,worldArt.water,h.x,h.y+h.h-artH,h.w,artH,draw);
  }else{
   ctx.strokeStyle='#7fdbef';ctx.lineWidth=2;ctx.beginPath();
   for(let x=left.x;x<=left.x+w;x+=draw.scale*.5)ctx.lineTo(x,left.y+Math.sin((x-left.x)/draw.scale*Math.PI*2)*3);ctx.stroke();
  }
 }else{
  const count=Math.max(1,Math.round(h.w/.5)),unit=w/count;ctx.fillStyle='#df4b45';ctx.strokeStyle='#6e2422';ctx.lineWidth=1.5;
  for(let i=0;i<count;i++){ctx.beginPath();ctx.moveTo(left.x+i*unit,left.y+height);ctx.lineTo(left.x+(i+.5)*unit,left.y);ctx.lineTo(left.x+(i+1)*unit,left.y+height);ctx.closePath();ctx.fill();ctx.stroke();}
 }
 if(debug){const hit=hazardCollider(h),p=worldToScreen(hit.x,hit.y+hit.h,draw);ctx.save();ctx.strokeStyle='#00e5ff';ctx.setLineDash([4,3]);ctx.strokeRect(p.x,p.y,hit.w*draw.scale,hit.h*draw.scale);ctx.restore();}
}

function timedFrame(frames,durationsMs,elapsedSeconds,loop=true){
 if(!frames?.length)return null;
 const durations=Array.isArray(durationsMs)?durationsMs:Array(frames.length).fill(Number(durationsMs)||100);
 const total=durations.reduce((sum,value)=>sum+value,0)||1;
 let time=Math.max(0,elapsedSeconds*1000);
 time=loop?time%total:Math.min(time,total-.001);
 let index=0,edge=durations[0]||total;
 while(index<frames.length-1&&time>=edge){index++;edge+=durations[index]||0;}
 return{index,timingMs:durations,...frames[index]};
}

function locomotionState(entity){
 if(!entity.onGround||entity.crouched)return null;
 const speed=Math.abs(entity.vx);
 if(speed<LOCOMOTION_THRESHOLDS.idleMaxSpeed)return'idle';
 return speed>=LOCOMOTION_THRESHOLDS.runMinSpeed?'run':'walk';
}

function selectLocomotionFrame(character,entity,elapsed=sim?.elapsed||0){
 const state=locomotionState(entity);
 if(!state)return null;
 const frames=locomotionFrames[character][state],timingMs=LOCOMOTION_PACK[character].timingMs[state];
 return{state,...timedFrame(frames,timingMs,elapsed,true)};
}

function selectJumpFrame(character,entity){
 if(entity.crouched)return null;
 const state=entity.jumpVisualState||(!entity.onGround?(entity.vy>0?'subida':'caida'):null);
 const packKey=character==='eren'&&entity.jumpVisualVariant==='running'?'erenRun':character;
 if(!state||!jumpFrames[packKey][state])return null;
 const frames=jumpFrames[packKey][state],timingMs=JUMP_PACK[packKey].timingMs[state];
 let index=0;
 if(Array.isArray(timingMs)&&frames.length>1){
  const elapsedMs=Math.max(0,(entity.jumpVisualTime||0)*1000);
  index=elapsedMs<timingMs[0]?0:Math.min(frames.length-1,1);
 }
 return{kind:'jump',state,index,timingMs,variant:entity.jumpVisualVariant,worldSize:JUMP_PACK[packKey].worldSize,...frames[index]};
}

function selectScarSignalFrame(entity){
 if(!entity.onGround||entity.crouched)return null;
 const state=entity.signalState||(entity.navPhase==='espera_segura_pinchos'?'danger':(entity.mode==='wait'?'wait':null));
 if(!state||!scarSignalFrames[state])return null;
 const elapsed=entity.signalState?entity.signalTime:(sim?.elapsed||0);
 return{kind:'functional-r16',state:`scar_${state}`,worldSize:SCAR_SIGNAL_PACK.worldSize,...timedFrame(scarSignalFrames[state],SCAR_SIGNAL_PACK.timingMs[state],elapsed,state==='danger')};
}

function selectCharacterFrame(character,entity,elapsed=sim?.elapsed||0){
 if(entity.visualState||entity.crouched)return null;
 if(character==='scar'){
  const signal=selectScarSignalFrame(entity);
  if(signal)return signal;
 }
 const jumpFrame=selectJumpFrame(character,entity);
 if(jumpFrame)return jumpFrame;
 const locomotionFrame=selectLocomotionFrame(character,entity,elapsed);
 return locomotionFrame?{kind:'locomotion',worldSize:LOCOMOTION_PACK[character].worldSize,...locomotionFrame}:null;
}

function selectR16FunctionalStateFrame(character,entity,state){
 if(character==='eren'){
  if(state==='bajo'){
   const moving=Math.abs(entity.vx)>=LOCOMOTION_THRESHOLDS.idleMaxSpeed,clip=moving?'crawl':'crouch';
   return{kind:'functional-r16',state:`eren_${clip}`,worldSize:EREN_ACTION_PACK.worldSize,...timedFrame(erenActionFrames[clip],EREN_ACTION_PACK.timingMs[clip],entity.visualStateTime,moving)};
  }
  if(state==='golpe')return{kind:'functional-r16',state:'eren_attack',worldSize:EREN_ACTION_PACK.worldSize,...timedFrame(erenActionFrames.attack,EREN_ACTION_PACK.timingMs.attack,sim.erenAttackElapsed,false)};
  if(state==='impacto')return{kind:'functional-r16',state:'eren_impact',worldSize:EREN_ACTION_PACK.worldSize,...timedFrame(erenActionFrames.impact,EREN_ACTION_PACK.timingMs.impact,entity.visualStateTime,false)};
  const ladderMap={escalera_agarre:'grip',escalera_subida:'up',escalera_bajada:'down',escalera_salida_superior:'exit',escalera_liberacion:'release'};
  const clip=ladderMap[state];
  if(clip){
   const elapsed=state==='escalera_agarre'||state==='escalera_salida_superior'?sim.ladderStateElapsed:entity.visualStateTime;
   return{kind:'functional-r16',state:`eren_ladder_${clip}`,worldSize:EREN_LADDER_PACK.worldSize,noFlip:true,...timedFrame(erenLadderFrames[clip],EREN_LADDER_PACK.timingMs[clip],elapsed,clip==='up'||clip==='down')};
  }
 }
 if(character==='scar'){
  const lowMap={paso_bajo_entrada:'enter',bajo:'move',paso_bajo_salida:'exit'},clip=lowMap[state];
  if(clip)return{kind:'functional-r16',state:`scar_low_${clip}`,worldSize:SCAR_LOW_PACK.worldSize,...timedFrame(scarLowFrames[clip],SCAR_LOW_PACK.timingMs[clip],entity.visualStateTime,clip==='move')};
 }
 return null;
}

function drawR16FunctionalCharacterFrame(ctx,entity,character,frame,draw){
 if(!frame?.image?.complete||!frame.image.naturalWidth)return false;
 const visual=frame.worldSize,offset=TERRAIN_MOUNT_PACK.renderOffsets[character],contactInsetPx=entity.onGround?offset.groundedInsetPx:offset.airborneInsetPx;
 const renderX=entity.x+(character==='eren'?(entity.visualFootOffsetX||0):0);
 const topLeft=worldToScreen(renderX-visual.w/2,entity.y+visual.h,draw),pivot=worldToScreen(renderX,entity.y,draw),w=visual.w*draw.scale,h=visual.h*draw.scale;
 topLeft.y+=contactInsetPx/TERRAIN_MOUNT_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(!frame.noFlip&&entity.facing<0){ctx.translate(pivot.x,0);ctx.scale(-1,1);ctx.translate(-pivot.x,0);}
 ctx.drawImage(frame.image,topLeft.x,topLeft.y,w,h);
 if(debug){ctx.setLineDash([7,4]);ctx.strokeStyle='#ffd34f';ctx.lineWidth=1.25;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
 if(debug){const collider=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw);ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.strokeRect(collider.x,collider.y,entity.w*draw.scale,entity.h*draw.scale);ctx.restore();}
 return true;
}

function drawFunctionalCharacterState(ctx,entity,character,label,color,draw){
 const state=entity.visualState||(entity.crouched?'bajo':null);
 if(!state)return false;
 const artFrame=selectR16FunctionalStateFrame(character,entity,state);
 if(drawR16FunctionalCharacterFrame(ctx,entity,character,artFrame,draw))return true;
 const groundedInset=(entity.onGround?VISUAL_CONTACT_PLANE.actorInsetPx:0)/VISUAL_CONTACT_PLANE.ppu*draw.scale;
 const foot=worldToScreen(entity.x,entity.y,draw),phase=(entity.visualStateTime||sim.elapsed||0)*12;
 const facing=entity.facing||1,low=state==='bajo',ladder=state.startsWith('escalera_');
 const bodyW=(low?entity.w*.9:entity.w*.72)*draw.scale,bodyH=(low?entity.h*.58:entity.h*.58)*draw.scale;
 const bodyY=foot.y-groundedInset-(low?entity.h*.5:entity.h*.57)*draw.scale;
 ctx.save();ctx.translate(foot.x,bodyY);if(!ladder&&facing<0)ctx.scale(-1,1);
 if(state==='impacto')ctx.rotate(Math.sin(phase)*.12-.18*facing);

 if(character==='scar'){
  const stride=Math.sin(phase)*draw.scale*.08;
  ctx.fillStyle='#f7f8fa';ctx.strokeStyle='#15191d';ctx.lineWidth=Math.max(2,draw.scale*.035);
  ctx.beginPath();ctx.ellipse(0,0,bodyW*.5,bodyH*.46,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#17191c';ctx.beginPath();ctx.ellipse(-bodyW*.16,-bodyH*.08,bodyW*.18,bodyH*.42,-.25,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(bodyW*.38,-bodyH*.18,bodyH*.3,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#17191c';ctx.lineWidth=Math.max(3,draw.scale*.07);ctx.beginPath();ctx.moveTo(-bodyW*.46,-bodyH*.05);ctx.quadraticCurveTo(-bodyW*.75,-bodyH*.45,-bodyW*.62,-bodyH*.72);ctx.stroke();
  ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-bodyW*.2,bodyH*.25);ctx.lineTo(-bodyW*.2-stride,bodyH*.52);ctx.moveTo(bodyW*.16,bodyH*.25);ctx.lineTo(bodyW*.16+stride,bodyH*.52);ctx.stroke();
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(bodyW*.46,-bodyH*.23,Math.max(1.5,draw.scale*.035),0,Math.PI*2);ctx.fill();
 }else if(ladder){
  const climb=Math.sin(phase),torsoY=-bodyH*.08;
  ctx.fillStyle='#e54747';ctx.strokeStyle='#8b1d1d';ctx.lineWidth=Math.max(2,draw.scale*.035);
  ctx.beginPath();if(ctx.roundRect)ctx.roundRect(-bodyW*.34,torsoY-bodyH*.48,bodyW*.68,bodyH*.78,bodyW*.14);else ctx.rect(-bodyW*.34,torsoY-bodyH*.48,bodyW*.68,bodyH*.78);ctx.fill();ctx.stroke();
  ctx.fillStyle='#5a321f';ctx.beginPath();ctx.arc(0,torsoY-bodyH*.72,bodyH*.29,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#f3b184';ctx.lineCap='round';ctx.lineWidth=Math.max(3,draw.scale*.075);
  ctx.beginPath();ctx.moveTo(-bodyW*.25,torsoY-bodyH*.3);ctx.lineTo(-bodyW*.58,torsoY-bodyH*(.45+.15*climb));ctx.moveTo(bodyW*.25,torsoY-bodyH*.3);ctx.lineTo(bodyW*.58,torsoY-bodyH*(.45-.15*climb));ctx.stroke();
  ctx.strokeStyle='#31527b';ctx.beginPath();ctx.moveTo(-bodyW*.17,torsoY+bodyH*.22);ctx.lineTo(-bodyW*.42,torsoY+bodyH*(.58-.16*climb));ctx.moveTo(bodyW*.17,torsoY+bodyH*.22);ctx.lineTo(bodyW*.42,torsoY+bodyH*(.58+.16*climb));ctx.stroke();
 }else{
  const squat=low?.28:0,stride=low?Math.sin(phase)*bodyW*.12:0;
  ctx.fillStyle='#e54747';ctx.strokeStyle='#8b1d1d';ctx.lineWidth=Math.max(2,draw.scale*.035);
  ctx.beginPath();if(ctx.roundRect)ctx.roundRect(-bodyW*.48,-bodyH*.44+bodyH*squat,bodyW*.96,bodyH*(low?.64:1),bodyW*.18);else ctx.rect(-bodyW*.48,-bodyH*.44+bodyH*squat,bodyW*.96,bodyH*(low?.64:1));ctx.fill();ctx.stroke();
  ctx.fillStyle='#5a321f';ctx.beginPath();ctx.arc(bodyW*.12,-bodyH*(low?.34:.64),bodyH*(low?.28:.32),0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#31527b';ctx.lineCap='round';ctx.lineWidth=Math.max(3,draw.scale*.085);
  ctx.beginPath();ctx.moveTo(-bodyW*.2,bodyH*.22);ctx.lineTo(-bodyW*.28-stride,bodyH*.55);ctx.moveTo(bodyW*.18,bodyH*.22);ctx.lineTo(bodyW*.28+stride,bodyH*.55);ctx.stroke();
  if(state==='golpe'){
   const attackProgress=clamp(sim.erenAttackElapsed/ENEMY_COMBAT.erenAttackDurationSeconds,0,1),reach=Math.sin(attackProgress*Math.PI);
   ctx.strokeStyle='#f4bd8f';ctx.lineWidth=Math.max(4,draw.scale*.09);ctx.beginPath();ctx.moveTo(bodyW*.28,-bodyH*.12);ctx.lineTo(bodyW*(.58+.72*reach),-bodyH*(.15+.12*reach));ctx.stroke();
   ctx.strokeStyle='#ffd45c';ctx.lineWidth=Math.max(2,draw.scale*.045);ctx.beginPath();ctx.arc(bodyW*.58,-bodyH*.1,bodyW*(.35+.4*reach),-.7,.65);ctx.stroke();
  }
 }
 ctx.fillStyle='#fff';ctx.font=`900 ${Math.max(9,draw.scale*.17)}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,0,low?0:-bodyH*.08);
 ctx.restore();
 if(debug){const collider=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw);ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.strokeRect(collider.x,collider.y,entity.w*draw.scale,entity.h*draw.scale);ctx.restore();}
 return true;
}

function drawCharacterPlaceholder(ctx,entity,label,color,draw){
 if(entity.recoverTimer>0)return;
 const topLeft=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw),w=entity.w*draw.scale,h=entity.h*draw.scale;
 const character=label==='S'?'scar':'eren',offset=TERRAIN_MOUNT_PACK.renderOffsets[character];
 topLeft.y+=(entity.onGround?offset.groundedInsetPx:offset.airborneInsetPx)/TERRAIN_MOUNT_PACK.ppu*draw.scale;
 ctx.save();ctx.fillStyle=color;ctx.strokeStyle=label==='S'?'#e7edf3':'#8b1d1d';ctx.lineWidth=Math.max(2,draw.scale*.035);
 const radius=Math.min(w,h)*.22;ctx.beginPath();
 if(ctx.roundRect)ctx.roundRect(topLeft.x,topLeft.y,w,h,radius);else ctx.rect(topLeft.x,topLeft.y,w,h);
 ctx.fill();ctx.stroke();
 ctx.fillStyle=label==='S'?'#f6f7f8':'#fff';ctx.font=`900 ${Math.max(11,draw.scale*.32)}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,topLeft.x+w/2,topLeft.y+h/2);
 const faceX=topLeft.x+(entity.facing>0?w*.78:w*.22);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(faceX,topLeft.y+h*.28,Math.max(1.6,draw.scale*.045),0,Math.PI*2);ctx.fill();
 if(debug){ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.lineWidth=1.5;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
}

function drawCharacter(ctx,entity,character,label,color,draw){
 if(entity.recoverTimer>0)return;
 if(label==='E'&&entity.invuln>0&&Math.floor(entity.invuln*12)%2===0)return;
 if(drawFunctionalCharacterState(ctx,entity,character,label,color,draw))return;
 const frame=selectCharacterFrame(character,entity);
 if(!frame||!frame.image.complete||!frame.image.naturalWidth){drawCharacterPlaceholder(ctx,entity,label,color,draw);return;}
 const visual=frame.worldSize,contactGaps=CONTACT_BOTTOM_GAPS_PX[character]?.[frame.state]||[],contactGapPx=frame.kind==='locomotion'?(contactGaps[frame.index]||0):0;
 const offset=TERRAIN_MOUNT_PACK.renderOffsets[character],contactInsetPx=entity.onGround?offset.groundedInsetPx:offset.airborneInsetPx;
 const renderOffsetYPx=contactInsetPx+contactGapPx;
 const renderX=entity.x+(character==='eren'?(entity.visualFootOffsetX||0):0);
 const topLeft=worldToScreen(renderX-visual.w/2,entity.y+visual.h,draw),pivot=worldToScreen(renderX,entity.y,draw),w=visual.w*draw.scale,h=visual.h*draw.scale;
 topLeft.y+=renderOffsetYPx/TERRAIN_MOUNT_PACK.ppu*draw.scale;
 ctx.save();ctx.imageSmoothingEnabled=true;
 if(entity.facing<0){ctx.translate(pivot.x,0);ctx.scale(-1,1);ctx.translate(-pivot.x,0);}
 ctx.drawImage(frame.image,topLeft.x,topLeft.y,w,h);
 if(debug){ctx.setLineDash([7,4]);ctx.strokeStyle='#ffd34f';ctx.lineWidth=1.25;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
 if(debug){
  const collider=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw);
  const requiredRatio=entity.minGroundSupportRatio||0,requiredWidth=entity.w*requiredRatio,foot=worldToScreen(entity.x-requiredWidth/2,entity.y,draw);
  ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.lineWidth=1.5;ctx.strokeRect(collider.x,collider.y,entity.w*draw.scale,entity.h*draw.scale);ctx.setLineDash([]);
  if(requiredRatio>0){ctx.strokeStyle=entity.onGround?'#74f59a':'#ff7b72';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(foot.x,foot.y-2);ctx.lineTo(foot.x+requiredWidth*draw.scale,foot.y-2);ctx.stroke();}
  ctx.fillStyle='#f4fbff';ctx.font='700 9px monospace';ctx.textAlign='center';ctx.fillText(`apoyo ${Math.round((entity.supportRatio||0)*100)}%`,collider.x+entity.w*draw.scale/2,collider.y-4);ctx.restore();
 }
}

function selectEnemyArtFrame(){
 const state=sim.enemyState;
 if(state==='defeated')return timedFrame(enemyArtFrames.defeat,ENEMY_ART_PACK.timingMs.defeat,sim.enemyDefeatVisualElapsed,false);
 if(state==='alerting')return timedFrame(enemyArtFrames.alert,ENEMY_ART_PACK.timingMs.alert,sim.enemyStateElapsed,false);
 if(state==='windup')return timedFrame(enemyArtFrames.windup,ENEMY_ART_PACK.timingMs.windup,sim.enemyStateElapsed,false);
 if(state==='lunge')return timedFrame(enemyArtFrames.lunge,ENEMY_ART_PACK.timingMs.lunge,sim.enemyStateElapsed,false);
 if(state==='hit')return timedFrame(enemyArtFrames.impact,ENEMY_ART_PACK.timingMs.impact,sim.enemyStateElapsed,false);
 if(state==='recover')return timedFrame(enemyArtFrames.recover,ENEMY_ART_PACK.timingMs.recover,sim.enemyStateElapsed,false);
 if(state==='patrol'||state==='chase')return timedFrame(enemyArtFrames.walk,ENEMY_ART_PACK.timingMs.walk,sim.elapsed,true);
 return timedFrame(enemyArtFrames.idle,ENEMY_ART_PACK.timingMs.idle,sim.elapsed,true);
}

function drawEnemyFunctional(ctx,draw){
 if(scene!=='graybox'||!sim.world.enemy)return;
 const enemy=sim.world.enemy,state=sim.enemyState,facing=sim.enemyFacing||1,frame=selectEnemyArtFrame();
 const foot=worldToScreen(sim.enemyX,enemy.y,draw),artW=ENEMY_ART_PACK.worldSize.w*draw.scale,artH=ENEMY_ART_PACK.worldSize.h*draw.scale;
 const artDrawn=!!(frame?.image?.complete&&frame.image.naturalWidth);
 if(artDrawn){
  ctx.save();ctx.imageSmoothingEnabled=true;ctx.translate(foot.x,0);if(facing<0)ctx.scale(-1,1);ctx.translate(-foot.x,0);
  ctx.drawImage(frame.image,foot.x-artW/2,foot.y-artH,artW,artH);ctx.restore();
 }else{
  const moving=state==='patrol'||state==='chase'||state==='lunge',stride=moving?Math.sin(sim.elapsed*(state==='lunge'?30:12))*.13:0;
  const fallbackFoot=worldToScreen(sim.enemyX+(state==='hit'?Math.sin(sim.enemyStateElapsed*70)*.08:0),enemy.y,draw),w=enemy.w*draw.scale,h=enemy.h*draw.scale;
  ctx.save();ctx.translate(fallbackFoot.x,fallbackFoot.y);if(facing<0)ctx.scale(-1,1);
  ctx.fillStyle='#704687';ctx.strokeStyle='#f4d3d7';ctx.lineWidth=Math.max(2,draw.scale*.035);
  ctx.beginPath();if(ctx.roundRect)ctx.roundRect(-w*.42,-h*.78,w*.84,h*.55,w*.18);else ctx.rect(-w*.42,-h*.78,w*.84,h*.55);ctx.fill();ctx.stroke();
  ctx.strokeStyle='#34303f';ctx.lineCap='round';ctx.lineWidth=Math.max(3,draw.scale*.075);ctx.beginPath();ctx.moveTo(-w*.2,-h*.25);ctx.lineTo(-w*.24-stride*w,0);ctx.moveTo(w*.18,-h*.25);ctx.lineTo(w*.24+stride*w,0);ctx.stroke();ctx.restore();
 }
 if(state==='alerting'||state==='windup'){
  const radius=(.68+.12*Math.sin(sim.elapsed*16))*draw.scale;
  ctx.save();ctx.strokeStyle=state==='windup'?'#ff4a45':'#ffc857';ctx.lineWidth=Math.max(2,draw.scale*.05);ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(foot.x,foot.y-artH*.62,radius,0,Math.PI*2);ctx.stroke();ctx.restore();
 }
 if(state==='windup'||state==='lunge'){
  const hit=enemyAttackRect(),p=worldToScreen(hit.x,hit.y+hit.h,draw);
  ctx.save();ctx.fillStyle=state==='lunge'?'#ff3b3044':'#ffb02028';ctx.strokeStyle=state==='lunge'?'#ff665c':'#ffcf66';ctx.setLineDash(state==='lunge'?[]:[6,4]);ctx.fillRect(p.x,p.y,hit.w*draw.scale,hit.h*draw.scale);ctx.strokeRect(p.x,p.y,hit.w*draw.scale,hit.h*draw.scale);ctx.restore();
 }
 if(state!=='defeated'){
  ctx.fillStyle='#fff';ctx.font=`900 ${Math.max(10,draw.scale*.19)}px Arial`;ctx.textAlign='center';
  ctx.fillText(state==='alerting'?'!':state==='windup'?'¡SALTA!':`HP ${sim.enemyHp}`,foot.x,foot.y-artH-5);
 }
 if(debug){const hit=enemyBodyRect(),p=worldToScreen(hit.x,hit.y+hit.h,draw);ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#ff8ea1';ctx.strokeRect(p.x,p.y,hit.w*draw.scale,hit.h*draw.scale);ctx.restore();}
}

function render(){
 if(!sim)return;
 const canvas=byId('gameCanvas'),bounds=canvas.getBoundingClientRect();
 if(!bounds.width||!bounds.height)return;
 const dpr=Math.min(2,window.devicePixelRatio||1),pixelW=Math.round(bounds.width*dpr),pixelH=Math.round(bounds.height*dpr);
 if(canvas.width!==pixelW||canvas.height!==pixelH){canvas.width=pixelW;canvas.height=pixelH;}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,bounds.width,bounds.height);
 const viewport=viewportWorldSize(bounds.width,bounds.height),scale=bounds.width/viewport.w;
 const draw={scale,ox:0,oy:(bounds.height-viewport.h*scale)/2,viewW:viewport.w,viewH:viewport.h};
 sim.camera.viewW=viewport.w;sim.camera.viewH=viewport.h;
 ctx.fillStyle='#0b0f14';ctx.fillRect(0,0,bounds.width,bounds.height);
 const gradient=ctx.createLinearGradient(0,draw.oy,0,draw.oy+draw.viewH*scale);gradient.addColorStop(0,'#19222b');gradient.addColorStop(1,'#10151b');ctx.fillStyle=gradient;ctx.fillRect(draw.ox,draw.oy,draw.viewW*scale,draw.viewH*scale);

 ctx.save();ctx.beginPath();ctx.rect(draw.ox,draw.oy,draw.viewW*scale,draw.viewH*scale);ctx.clip();
 const firstX=Math.floor(sim.camera.x*2)/2,lastX=sim.camera.x+draw.viewW;
 for(let x=firstX;x<=lastX+.5;x+=.5){const p=worldToScreen(x,0,draw),major=Math.abs(x-Math.round(x/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(p.x,draw.oy);ctx.lineTo(p.x,draw.oy+draw.viewH*scale);ctx.stroke();}
 for(let y=Math.floor(sim.camera.y*2)/2;y<=sim.camera.y+draw.viewH+.5;y+=.5){const p=worldToScreen(0,y,draw),major=Math.abs(y-Math.round(y/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(draw.ox,p.y);ctx.lineTo(draw.ox+draw.viewW*scale,p.y);ctx.stroke();}

 if(scene==='lab'){
  for(let x=0;x<80;x+=16){const a=worldToScreen(x,sim.camera.y+draw.viewH,draw);ctx.fillStyle=(x/16)%2?'#ffffff08':'#00000010';ctx.fillRect(a.x,draw.oy,16*scale,draw.viewH*scale);}
 }

 for(const solid of sim.world.solids){
  const p=worldToScreen(solid.x,solid.y+solid.h,draw),w=solid.w*scale,h=solid.h*scale;
  const artDrawn=drawSolidWorldArt(ctx,solid,draw);
  if(!artDrawn){
   ctx.fillStyle=solid.kind==='box'?'#98683e':solid.kind==='gate'?'#34445c':solid.kind==='roof'?'#777f87':solid.kind==='upper'?'#626d78':'#59636c';ctx.fillRect(p.x,p.y,w,h);
   ctx.fillStyle=solid.kind==='box'?'#c58a51':solid.kind==='gate'?'#76a5c8':'#88939d';ctx.fillRect(p.x,p.y,w,Math.min(5,h*.15));ctx.strokeStyle='#2a3036';ctx.lineWidth=1.2;ctx.strokeRect(p.x,p.y,w,h);
   if(solid.id==='CAJA_ROMPIBLE'){
    ctx.strokeStyle='#5f3d24';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+w,p.y+h);ctx.moveTo(p.x+w,p.y);ctx.lineTo(p.x,p.y+h);ctx.stroke();
   }
  }
  if(solid.id==='PUERTA_COOP'||solid.id==='BARRERA_GB02'||solid.id==='E_BARRERA'){
   ctx.strokeStyle='#9dc7e4';ctx.lineWidth=Math.max(2,scale*.06);for(let y=p.y+scale*.45;y<p.y+h;y+=scale*.65){ctx.beginPath();ctx.moveTo(p.x,y);ctx.lineTo(p.x+w,y);ctx.stroke();}
   ctx.fillStyle=solid.id==='BARRERA_GB02'?'#ffb84d':'#ef5b5b';ctx.beginPath();ctx.arc(p.x+w/2,p.y+h*.56,Math.max(4,scale*.12),0,Math.PI*2);ctx.fill();
  }
  if(debug&&solid.id){
   if(artDrawn){ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#9be8ff';ctx.lineWidth=1.2;ctx.strokeRect(p.x,p.y,w,h);ctx.restore();}
   ctx.fillStyle='#e3e8ee';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(solid.id,p.x+3,p.y+12);
  }
 }
 if(scene==='graybox'&&sim.boxBroken)drawWorldArt(ctx,worldArt.boxRemains,6.5,2,1,1,draw,{alpha:.92,alignBottom:true,contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
 sim.world.hazards.forEach(h=>drawHazard(ctx,h,draw));

 drawEnemyFunctional(ctx,draw);
 if(scene==='graybox'&&sim.world.ladder){
  const ladder=sim.world.ladder,p=worldToScreen(ladder.art.x,ladder.art.y+ladder.art.h,draw),w=ladder.art.w*scale,h=ladder.art.h*scale;
  const ladderDrawn=drawWorldArt(ctx,r16WorldArt.ladder,ladder.art.x,ladder.art.y,1,3.5,draw,{alpha:sim.ladderEnabled?1:.24,filter:sim.ladderEnabled?'none':'grayscale(1)'});
  if(!ladderDrawn){ctx.save();ctx.globalAlpha=sim.ladderEnabled?1:.24;ctx.strokeStyle=sim.ladderEnabled?'#d5b36a':'#64707c';ctx.lineWidth=Math.max(2,scale*.055);
   ctx.strokeRect(p.x,p.y,w,h);for(let y=p.y+scale*.35;y<p.y+h;y+=scale*.45){ctx.beginPath();ctx.moveTo(p.x,y);ctx.lineTo(p.x+w,y);ctx.stroke();}ctx.restore();}
  if(debug){const grip=sim.world.ladder.grip,g=worldToScreen(grip.x,grip.y+grip.h,draw),exit=sim.world.ladder.topExit,e=worldToScreen(exit.x,exit.y+exit.h,draw);ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#8df7bb';ctx.strokeRect(g.x,g.y,grip.w*scale,grip.h*scale);ctx.strokeStyle='#ffd45c';ctx.strokeRect(e.x,e.y,exit.w*scale,exit.h*scale);ctx.restore();}
 }
 if(scene==='graybox'&&sim.world.bridge&&sim.bridgeState!=='solid'){
  const bridge=sim.world.bridge,p=worldToScreen(bridge.x,bridge.y+bridge.h,draw),progress=sim.bridgeState==='deploying'?clamp(sim.bridgeDeployElapsed/.6,0,1):0;
  let deploymentArt=false;
  if(sim.bridgeState==='deploying'&&artReady(r16WorldArt.bridge)){
   const visualX=bridge.x-.25,visualY=bridge.y-.5,visual=worldToScreen(visualX,visualY+1,draw);
   ctx.save();ctx.beginPath();ctx.rect(visual.x,visual.y,4.5*scale*progress,scale);ctx.clip();deploymentArt=drawWorldArt(ctx,r16WorldArt.bridge,visualX,visualY,4.5,1,draw,{alpha:.4+.6*progress});ctx.restore();
  }
  if(!deploymentArt){ctx.save();ctx.globalAlpha=sim.bridgeState==='deploying'?.28+.45*progress:.16;ctx.fillStyle='#72b7cd';ctx.fillRect(p.x,p.y,bridge.w*scale*progress,bridge.h*scale);ctx.restore();}
  ctx.save();ctx.strokeStyle='#aee9f8';ctx.setLineDash([6,4]);ctx.strokeRect(p.x,p.y,bridge.w*scale,bridge.h*scale);ctx.restore();
 }

 if(sim.world.marker){
  const m=sim.world.marker,p=worldToScreen(m.x,m.y+m.h,draw),active=scarPlateActive(),plateAsset=active?worldArt.platePressed:worldArt.plateFree;
  if(scene==='graybox')drawNativePlatform(ctx,{id:'PLACA_BASE',x:m.x,y:m.y-.5,w:m.w,h:.5},draw);
  const plateDrawn=scene==='graybox'&&drawWorldArtFitBounds(ctx,plateAsset,m.x,m.y,m.w,draw,{contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
  if(!plateDrawn){const contactY=p.y+VISUAL_CONTACT_PLANE.propInsetPx/VISUAL_CONTACT_PLANE.ppu*scale;ctx.fillStyle=active?'#4ed58a':'#f3c83b';ctx.fillRect(p.x,contactY,m.w*scale,Math.max(4,m.h*scale));ctx.strokeStyle=active?'#174d31':'#4f4214';ctx.strokeRect(p.x,contactY,m.w*scale,Math.max(4,m.h*scale));}
  ctx.fillStyle=active?'#dfffee':'#f7f1cf';ctx.font=`900 ${Math.max(10,scale*.2)}px Arial`;ctx.textAlign='center';ctx.fillText(active?'ACTIVA':'SCAR',p.x+m.w*scale/2,p.y-4);
 }
 if(scene==='graybox'&&sim.world.bridgePlate){
  const m=sim.world.bridgePlate,p=worldToScreen(m.x,m.y+m.h,draw),active=sim.bridgePlateLatched,plateAsset=active?worldArt.platePressed:worldArt.plateFree;
  const plateDrawn=drawWorldArtFitBounds(ctx,plateAsset,m.x,m.y,m.w,draw,{contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
  if(!plateDrawn){ctx.fillStyle=active?'#4ed58a':'#f3c83b';ctx.fillRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));ctx.strokeStyle=active?'#174d31':'#4f4214';ctx.strokeRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));}
  ctx.fillStyle=active?'#dfffee':'#f7f1cf';ctx.font=`900 ${Math.max(10,scale*.18)}px Arial`;ctx.textAlign='center';ctx.fillText(active?'ENCLAVADA':sim.bridgeCommanded?'SCAR · EN CAMINO':'ORDENA A SCAR',p.x+m.w*scale/2,p.y-4);
 }
 if(sim.world.lever){
  const lever=sim.world.lever,p=worldToScreen(lever.x,lever.y+lever.h,draw),w=lever.w*scale,h=lever.h*scale,active=sim.erenSwitchArmed;
  const leverDrawn=scene==='graybox'&&drawWorldArt(ctx,worldArt.lever,lever.x,lever.y,1.5,2,draw,{alpha:active?1:.72,filter:active?'none':'saturate(.65)',contactInsetPx:VISUAL_CONTACT_PLANE.propInsetPx});
  if(!leverDrawn){
   ctx.fillStyle=active?'#2d9d65':'#7c8794';ctx.fillRect(p.x+w*.2,p.y+h*.45,w*.6,h*.55);ctx.strokeStyle='#252b32';ctx.lineWidth=1.5;ctx.strokeRect(p.x+w*.2,p.y+h*.45,w*.6,h*.55);
   ctx.strokeStyle=active?'#65efaa':'#ef6262';ctx.lineWidth=Math.max(3,scale*.08);ctx.beginPath();ctx.moveTo(p.x+w*.5,p.y+h*.5);ctx.lineTo(p.x+w*(active?.78:.3),p.y+h*.15);ctx.stroke();
  }
  ctx.fillStyle='#f7fbff';ctx.font=`900 ${Math.max(10,scale*.2)}px Arial`;ctx.textAlign='center';ctx.fillText(sim.coopUnlocked?'ABIERTA':active?'LISTA':'EREN',p.x+w*.5,p.y-4);
 }
 if(sim.world.star&&!sim.starCollected){
  const star=sim.world.star;
  if(!(scene==='graybox'&&drawWorldArt(ctx,worldArt.star,star.x-.5,star.y-.5,1,1,draw)))drawStar(ctx,star.x,star.y,star.r,draw);
 }
 if(sim.world.goal){const g=sim.world.goal,p=worldToScreen(g.x,g.y+g.h,draw);ctx.strokeStyle='#e6edf3';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x,p.y+g.h*scale);ctx.stroke();ctx.fillStyle='#ef4a4a';ctx.fillRect(p.x,p.y,g.w*scale*.72,g.h*scale*.42);}
 for(const checkpoint of sim.world.checkpoints){const p=worldToScreen(checkpoint.x,checkpoint.y+.2,draw);ctx.fillStyle=checkpoint.id===sim.checkpoint.id?'#62d6ff':'#3f6d7d';ctx.beginPath();ctx.moveTo(p.x,p.y-7);ctx.lineTo(p.x+7,p.y);ctx.lineTo(p.x,p.y+7);ctx.lineTo(p.x-7,p.y);ctx.closePath();ctx.fill();}
 for(const label of sim.world.labels){const p=worldToScreen(label.x,10.15,draw);ctx.fillStyle='#dce4ec';ctx.font=`900 ${Math.max(10,scale*.25)}px Arial`;ctx.textAlign='center';ctx.fillText(label.text,p.x,p.y);}

 drawCharacter(ctx,sim.scar,'scar','S','#17191c',draw);drawCharacter(ctx,sim.eren,'eren','E','#e54747',draw);
 if(debug){
  if(Number.isFinite(sim.scar.navTargetX)&&Number.isFinite(sim.scar.navTargetY)){
   const from=worldToScreen(sim.scar.x,sim.scar.y+sim.scar.h*.5,draw),to=worldToScreen(sim.scar.navTargetX,sim.scar.navTargetY+.2,draw);
   ctx.strokeStyle='#62d6ff';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(to.x,to.y);ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle='#bdefff';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(sim.scar.navPhase,to.x+5,to.y-5);
  }
  const deadW=3*scale,deadH=1.5*scale;ctx.strokeStyle='#ffd34faa';ctx.setLineDash([7,5]);ctx.strokeRect(draw.ox+(draw.viewW*scale-deadW)/2,draw.oy+(draw.viewH*scale-deadH)/2,deadW,deadH);ctx.setLineDash([]);
  ctx.fillStyle='#fff';ctx.font='700 11px monospace';ctx.textAlign='left';ctx.fillText(`cam ${sim.camera.x.toFixed(2)}, ${sim.camera.y.toFixed(2)} · 60 Hz`,draw.ox+8,draw.oy+16);
 }
 ctx.restore();
}

function updateHud(){
 if(!sim)return;
 updateHeartHud(sim.eren.hearts);
 byId('gameStars').textContent=sim.starCollected?'1':'0';
 byId('metricSpeed').textContent=`${format(Math.abs(sim.eren.vx))} m/s`;
 byId('metricHeight').textContent=`${format(Math.max(0,sim.eren.y-2))} m`;
 byId('metricScar').textContent=sim.scar.recoverTimer>0?'RETORNO':sim.scar.bridgeWait?'PLACA PUENTE':sim.scar.mode==='bridge_marker'?(sim.scar.crouched?'PASO BAJO':'VA AL PUENTE'):sim.scar.mode==='follow'?'SIGUE':sim.scar.mode==='marker'?'VA A PLACA':'ESPERA';
 byId('metricState').textContent=sim.ladderState?'ESCALERA':sim.erenAttackState?'GOLPE':sim.eren.recover>0?'RETORNO':sim.eren.crouched?'AGACHADO':sim.eren.onGround?'SUELO':'AIRE';
 byId('gamePrompt').textContent=setMessageFromProgress();
}

function updateHeartHud(currentHearts){
 const target=byId('gameHearts'),count=clamp(Math.trunc(currentHearts),0,HUD_HEARTS_LAYOUT.slots);
 target.style.display='inline-grid';
 target.style.gridTemplateColumns=`repeat(${HUD_HEARTS_LAYOUT.slots}, ${HUD_HEARTS_LAYOUT.slotWidthEm}em)`;
 target.style.width=`${HUD_HEARTS_LAYOUT.containerWidthEm}em`;
 target.style.justifyItems='center';
 target.style.alignItems='center';
 target.style.whiteSpace='nowrap';
 target.style.textAlign='center';
 target.setAttribute('role','img');
 target.setAttribute('aria-label',`${count} de ${HUD_HEARTS_LAYOUT.slots} corazones`);
 target.innerHTML=Array.from({length:HUD_HEARTS_LAYOUT.slots},(_,index)=>
  `<span aria-hidden="true" data-heart-slot="${index+1}">${index<count?HUD_HEARTS_LAYOUT.filledGlyph:HUD_HEARTS_LAYOUT.emptyGlyph}</span>`
 ).join('');
}

function gameLoop(time){
 if(!sim||!sim.running)return;
 if(!previousTime)previousTime=time;
 const delta=Math.min(.05,(time-previousTime)/1000);previousTime=time;accumulator+=delta;
 const input=currentInput();
 while(accumulator>=FIXED_DT){physicsStep(FIXED_DT,input);accumulator-=FIXED_DT;}
 render();
 if(time-lastHudUpdate>90){updateHud();lastHudUpdate=time;}
 frameHandle=requestAnimationFrame(gameLoop);
}

function resetSimulation(reason='reinicio_manual'){
 const wasRunning=!!(sim&&sim.running);if(reason)archiveCurrentAttempt(reason);sim=createSimulation();accumulator=0;previousTime=0;
 byId('gameReward').classList.add('hidden');updateHud();render();
 if(!wasRunning&&!frameHandle)frameHandle=requestAnimationFrame(gameLoop);
}

function updateLabObjective(){
 const target=byId('labObjective');if(target)target.textContent=LAB_OBJECTIVES[labStation]||'';
}

function configureQaOnlyUi(){
 const labButton=byId('playLab');
 labButton.classList.toggle('hidden',!TEST_MODE);labButton.disabled=!TEST_MODE;labButton.setAttribute('aria-hidden',TEST_MODE?'false':'true');
 if(!TEST_MODE&&scene==='lab')scene='graybox';
}

function setScene(next,reason=`cambio_escena_${scene}_a_${next}`){
 if(next==='lab'&&!TEST_MODE)return;
 archiveCurrentAttempt(reason);scene=next;labStation='A';
 byId('playGraybox').classList.toggle('active',scene==='graybox');byId('playLab').classList.toggle('active',scene==='lab');
 byId('labControls').classList.toggle('hidden',scene!=='lab');
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===labStation));
 updateLabObjective();
 resetSimulation(null);
}

function teleportStation(station){
 if(!TEST_MODE||scene!=='lab'||!LAB_STATIONS.includes(station))return;archiveCurrentAttempt(`cambio_estacion_${labStation}_a_${station}`);labStation=station;
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===station));
 updateLabObjective();resetSimulation(null);logEvent('estacion',{station,objective:LAB_OBJECTIVES[station]});
}

function setControllerMode(enabled){
 document.body.classList.toggle('controller-mode',enabled);byId('controllerStatus').classList.toggle('hidden',!enabled);
}

function setGamePanel(open){
 const game=byId('game'),panel=byId('gamePanel'),toggle=byId('toggleGamePanel');
 game.classList.toggle('panel-open',!!open);
 panel.setAttribute('aria-hidden',open?'false':'true');
 toggle.setAttribute('aria-expanded',open?'true':'false');
}

function startGame(){
 if(!TEST_MODE&&scene==='lab')scene='graybox';
 stopNarration();show('game');byId('appTitle').textContent='Eren y Scar · GB02 R04 · R16 visual';
 archiveCurrentAttempt('nuevo_inicio');cancelAnimationFrame(frameHandle);frameHandle=0;sim=createSimulation();previousTime=0;accumulator=0;lastHudUpdate=0;
 byId('gameReward').classList.add('hidden');setControllerMode(false);setGamePanel(false);updateHud();frameHandle=requestAnimationFrame(gameLoop);
}

function openLandscapeGame(){
 if(!TEST_MODE&&!Number(localStorage.getItem('game-tokens')||0)&&!completedStories().size){byId('gameStatus').textContent='Primero completa un cuento nuevo';tone('wrong');return;}
 document.body.classList.add('game-mode');if(window.AndroidLayout)AndroidLayout.landscape();startGame();
}

function closeLandscapeGame(){
 archiveCurrentAttempt('salir_juego');if(sim)sim.running=false;cancelAnimationFrame(frameHandle);frameHandle=0;stopNarration();setControllerMode(false);document.body.classList.remove('game-mode');
 setGamePanel(false);
 if(window.AndroidLayout)AndroidLayout.portrait();renderMenu();
}

function savePlaytestLog(){
 if(!sim)return'';
 const json=JSON.stringify(playtestBundle(),null,2);localStorage.setItem('graybox-last-playtest',json);byId('playtestLogText').value=json;return json;
}

function openPlaytestDialog(recordEvent=true){
 if(!sim)return;
 if(recordEvent)logEvent('ver_registro');
 savePlaytestLog();logDialogWasPaused=sim.paused;sim.paused=true;byId('playtestLogDialog').classList.remove('hidden');
}

function closePlaytestDialog(){
 byId('playtestLogDialog').classList.add('hidden');if(sim&&!sim.complete)sim.paused=logDialogWasPaused;
}

function sharePlaytest(){
 if(!sim)return;
 logEvent('compartir_registro');const json=savePlaytestLog();
 if(window.AndroidShare&&typeof window.AndroidShare.shareText==='function'){
  window.AndroidShare.shareText('Registro playtest · Eren y Scar',json);toast('Elige dónde enviar el registro.');
 }else{
  openPlaytestDialog(false);toast('Registro guardado. Puedes copiarlo.');
 }
}

async function copyPlaytest(){
 if(!sim)return;
 logEvent('copiar_registro');const json=savePlaytestLog(),area=byId('playtestLogText');let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Registro copiado.':'Mantén pulsado el texto para copiarlo.');
}

async function copyPlaytestSummary(){
 if(!sim)return;
 logEvent('copiar_resumen');const json=JSON.stringify(compactPlaytestBundle(),null,2),area=byId('playtestLogText');area.value=json;localStorage.setItem('graybox-last-playtest-summary',json);let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Resumen copiado.':'Resumen mostrado: mantén pulsado para copiarlo.');
}

function bindPointerHold(element){
 const names=(element.dataset.controls||'').split(/\s+/).filter(Boolean);
 const release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,names);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

function bindPointerPress(id,name){
 const element=byId(id),release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,[name]);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

document.querySelectorAll('[data-controls]').forEach(bindPointerHold);
bindPointerPress('jump','jump');bindPointerPress('action','action');bindPointerPress('scarAction','scar');
configureQaOnlyUi();updateLabObjective();

window.addEventListener('keydown',event=>{
 if(!document.body.classList.contains('game-mode'))return;
 if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(event.code))event.preventDefault();
 keyControls.add(event.code);
});
window.addEventListener('keyup',event=>keyControls.delete(event.code));
window.addEventListener('blur',()=>{keyControls.clear();pointerControls.clear();Object.keys(nativeControls).forEach(key=>nativeControls[key]=false);});

window.androidGameKey=(control,pressed)=>{if(!sim||!sim.running)return;setControllerMode(true);if(control in nativeControls)nativeControls[control]=pressed;};
window.androidGameAxis=(x,y)=>{if(!sim||!sim.running)return;setControllerMode(true);nativeControls.left=x<-.35;nativeControls.right=x>.35;nativeControls.up=y<-.55;nativeControls.crouch=y>.55;};
window.addEventListener('gamepadconnected',()=>setControllerMode(true));window.addEventListener('gamepaddisconnected',()=>setControllerMode(false));
byId('gameViewport').addEventListener('pointerdown',event=>{if(!event.target.closest?.('button'))setControllerMode(false);});

byId('directGame').onclick=openLandscapeGame;byId('openGame').onclick=openLandscapeGame;byId('playReward').onclick=openLandscapeGame;byId('exitGame').onclick=closeLandscapeGame;
byId('toggleGamePanel').onclick=()=>setGamePanel(!byId('game').classList.contains('panel-open'));byId('closeGamePanel').onclick=()=>setGamePanel(false);
byId('gameRewardOk').onclick=closeLandscapeGame;byId('gameRewardAgain').onclick=()=>setScene('graybox','probar_otra_vez');
byId('playGraybox').onclick=()=>setScene('graybox','seleccion_graybox');byId('playLab').onclick=()=>setScene('lab','seleccion_laboratorio');
byId('resetGame').onclick=()=>resetSimulation('reinicio_manual');
byId('labReset').onclick=()=>resetSimulation('reinicio_estacion_qa');
byId('labNext').onclick=()=>teleportStation(LAB_STATIONS[(LAB_STATIONS.indexOf(labStation)+1)%LAB_STATIONS.length]);
byId('labExit').onclick=()=>setScene('graybox','salir_laboratorio_qa');
byId('toggleDebug').onclick=()=>{debug=!debug;byId('toggleDebug').textContent=`Colliders: ${debug?'sí':'no'}`;render();};
byId('exportPlaytest').onclick=sharePlaytest;byId('showPlaytest').onclick=()=>openPlaytestDialog(true);
byId('copyPlaytest').onclick=copyPlaytest;byId('copyPlaytestSummary').onclick=copyPlaytestSummary;byId('sharePlaytest').onclick=sharePlaytest;byId('closePlaytest').onclick=closePlaytestDialog;
document.querySelectorAll('[data-station]').forEach(button=>button.onclick=()=>teleportStation(button.dataset.station));

function bindRange(id,key,output,suffix=''){
 const input=byId(id),target=byId(output);
 input.addEventListener('input',()=>{tuning[key]=Number(input.value);target.textContent=`${format(input.value)}${suffix}`;});
 input.addEventListener('change',()=>{logEvent('ajuste_metrica',{key,value:tuning[key]});if(key==='labHeight'||key==='labGap')resetSimulation(`ajuste_${key}`);});
}
bindRange('walkTuning','walk','walkOutput');bindRange('runTuning','run','runOutput');bindRange('jumpTuning','jump','jumpOutput');
byId('gravityTuning').addEventListener('input',event=>{tuning.gravityDown=Number(event.target.value);byId('gravityOutput').textContent=event.target.value;});
byId('gravityTuning').addEventListener('change',()=>logEvent('ajuste_metrica',{key:'gravityDown',value:tuning.gravityDown}));

})();
