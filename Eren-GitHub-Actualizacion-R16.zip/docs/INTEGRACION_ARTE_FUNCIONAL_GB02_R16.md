# Integración de arte funcional GB02 R16

## Resultado

La entrega `ARTE_GB02_R16_ASSETS_FUNCIONALES_R01_CANDIDATE_PLAYTEST` queda integrada sobre la mecánica R15 validada en dispositivo. La revisión es visual y permanece como `CANDIDATE_PLAYTEST`; no se declara `gameReady` hasta completar el playtest visual Android R16.

## Fuente integrada

- ZIP fuente: `ARTE_GB02_R16_ASSETS_FUNCIONALES_R01_CANDIDATE_PLAYTEST.zip`
- SHA-256: `9839aed8faf4f3412e9ec7b99fd14a54bfc319ba7014299910c329f3868d0e90`
- PNG funcionales RGBA: 101
- Manifiestos de familia: 11
- Escala de autoría: 100 px por módulo
- Root motion: desactivado
- Física autoritativa: sí

## Contenido montado

| Actor/objeto | Estados visuales integrados |
|---|---|
| Eren | reposo, caminar, correr, salto normal, salto en carrera, agacharse/arrastrarse, golpe, impacto/recuperación y escalera completa |
| Scar | reposo, caminar, correr, salto, entrada/avance/salida de paso bajo y señales esperar/confirmar/peligro |
| Araña | reposo, patrulla/persecución, alerta, preparación, embestida, impacto, recuperación y derrota |
| Escalera | S012 canónico, 100×350 px, 1×3,5 módulos |
| Pasarela | S020 canónico, 450×100 px, 4,5×1 módulos |

## Decisiones de montaje

- S012 y S020 se usan directamente desde el atlas autorizado. No se ha diseñado ni derivado ninguna sustitución.
- S012 se dibuja a su tamaño nativo de 1×3,5 módulos sobre el volumen de escalera R15.
- S020 se dibuja a su tamaño nativo de 4,5×1 módulos, centrado sobre el collider R15 de 4×0,5 módulos. El voladizo de 0,25 módulos por lado es solo visual; el collider, la zona vacía durante el despliegue y los 0,6 s de despliegue no cambian.
- El fotograma `eren-correr-r02-03-candidate.png` contiene 30 px transparentes bajo los pies. Se compensa únicamente en el dibujo de ese fotograma; no se mueve actor, pivot físico, collider ni terreno.
- Tres imágenes generadas después del ZIP se conservan solo como referencia porque tienen el fondo ajedrezado incrustado y carecen de recortes RGBA/manifiesto: `Eren: atlas 4×4 de movimiento.png`, `Eren cae con pies separados.png` y `Atlas de animación de Scar.png`.

## Contrato mecánico preservado

- Contrato: `GB02_R04_PLAYTEST_CORRECTION`
- SHA contractual R15: `02692ced658695b7e5ce95d9b1709448835b16427812e8393c61bc67466e6055`
- Contacto visual: R10, actores 10 px y utilería 6 px
- Física, gravedad, velocidad, salto, geometría, colliders, controles, daño y ventanas de combate: sin cambios
- R12 y R13: preservados y no aplicados

## Validación automatizada

- Sintaxis JavaScript: PASS
- Inventario de arte: 101/101 PNG RGBA, 11 manifiestos de familia y 1 manifiesto runtime: PASS
- Hash S012: PASS
- Hash S020: PASS
- Escalera: 20/20 completadas, 0 bloqueos: PASS
- Ruta baja de Scar: 20/20 completadas, 0 saltos, 0 recuperaciones: PASS
- Puente: 20/20 órdenes y despliegues, 0 enclavamientos sin orden: PASS
- Combate: ataque, esquiva, dos impactos y consecuencias atómicas: PASS
- HUD fijo de tres corazones y catálogo de locuciones: PASS

## Pendiente imprescindible

Este entorno no contiene Gradle ni Android SDK, por lo que aquí no se puede compilar honestamente una APK. El workflow `.github/workflows/build-apk.yml` ya está actualizado para ejecutar las pruebas R16, compilar y publicar el APK y las evidencias.

Después de aplicar el paquete al repositorio, ejecutar manualmente **Actions → Compilar APK → Run workflow**. Instalar `app-debug.apk` en el dispositivo y revisar únicamente contacto visual, continuidad de bucles, legibilidad de estados y montaje S012/S020. Si esa revisión pasa, se podrá promover R16; no se deben retocar mecánicas durante ese playtest.
