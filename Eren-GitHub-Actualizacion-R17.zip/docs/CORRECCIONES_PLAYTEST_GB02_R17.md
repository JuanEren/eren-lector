# Correcciones de playtest GB02 R17

## Resultado

R17 corrige los defectos observados en el playtest Android de R16 y conserva la física de movimiento validada en R15. La revisión queda como candidata de playtest; no se declara `gameReady` hasta repetir la prueba en el dispositivo.

## Cambios aplicados

| Área | Corrección R17 | Verificación |
|---|---|---|
| Inicio | Eren aparece centrado, Scar queda visible y el espacio a la izquierda se representa como roca inaccesible. | Encuadre calculado en 4:3, 16:9, 21:9 y 32:9. |
| Caja | La caja requiere dos impactos y conserva collider tras el primero. | Estados intacta → dañada → restos. |
| Táctil | Cada puntero conserva su acción; correr y saltar admiten dos dedos, huella ancha o deslizamiento de un pulgar. | Casos automatizados independientes y de un solo puntero. |
| Zonas táctiles | Solo el disco real de cada botón redondo activa su acción; el contenedor y los huecos no capturan. | Prueba negativa sobre una esquina transparente. |
| Acceso | El botón de juego abre temporalmente GB02 sin exigir un cuento previo. | Build normal iniciada sin progreso de cuentos. |
| Lectura | Se bloquean selección, arrastre, menú contextual y pinza. | Contrato CSS, eventos de selección y multitáctil comprobados. |
| Respuestas | Un fallo marca solo la opción elegida y permite volver a intentar sin revelar la correcta. | Flujo de error separado del cierre por acierto. |
| Postura | ABAJO agacha en cualquier suelo válido; con horizontal arrastra; al soltar se levanta si hay altura. | Postura voluntaria y restricción real bajo techo comprobadas. |
| Escalera | Solo ARRIBA/ABAJO vertical inicia, exige al menos 50 % de solape, permite bajar desde U4 y bloquea el reagarre por fotograma. | 20/20 ascensos, bajada superior y casos negativos de diagonal/solape. |
| Escalera visual | S012 usa una variante RGBA transparente de 100×350 px. | SHA-256 fijado en el manifiesto R17. |
| Mundo | Todo suelo, plataforma y techo funcional recibe arte; las dos aguas usan su recurso funcional. | Cobertura runtime `ALL_GROUND_UPPER_ROOF_SOLIDS`. |
| Pilares | Las barreras son columnas de piedra y al abrirse desaparecen los 1,5 módulos inferiores. | Estado cerrado y abierto trazados sin cambiar sólidos base. |
| Eren | Marcha y carrera vuelven al ciclo completo con piernas alternas; reposo queda anclado. | Secuencias estables de 4+4 fotogramas y reposo de 1 fotograma. |
| Scar | Reposo, marcha y carrera usan fotogramas completos sin huecos alfa internos. | Secuencias estables de 2+4+4 fotogramas. |
| Trepa | La subida alterna brazos y la bajada conserva su ciclo alterno. | Dos poses alternas por dirección. |

## Contratos preservados

- Contacto visual R10: actores 10 px y utilería 6 px.
- HUD R11: tres casillas estables.
- Movimiento R15: velocidades, gravedad, salto y caída terminal.
- Contrato `GB02_R04_PLAYTEST_CORRECTION` y sus consecuencias atómicas.
- R12 y R13 permanecen preservados y no aplicados.

## Estado de entrega

- Fuente y pruebas automatizadas: `PASS`.
- Compilación y playtest Android R17: pendientes en el ramal aislado.
- Merge, release y promoción a `gameReady`: fuera de alcance.
