# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 41.0.0 · candidata GB02 R04 · revisión R18

R18 aplica las correcciones del playtest Android R17 sobre el contrato `GB02_R04_PLAYTEST_CORRECTION`. Mantiene R15 como base física, conserva el contacto visual R10 y preserva sin aplicar R12/R13. Sigue siendo una candidata: requiere compilación y playtest en dispositivo antes de aprobarse.

Incluye:

- límite oeste infranqueable para Eren y Scar, manteniendo a ambos visibles al comenzar;
- caja de dos impactos con puño visible y estados intacta → dañada → transición → restos;
- repetición de SALTAR mientras CORRER continúa mantenido, con dos dedos o gesto de un pulgar;
- ciclos completos de marcha/carrera de Eren, reposo anclado y trepa con brazos alternos;
- escalera con eliminación alfa del panel blanco y entrada/salida estable heredada de R17;
- pinchos del tileset funcional y puerta de piedra sin resto visual al abrirse;
- guardián con exclamación amarilla/roja, contacto corporal y superior dañino, y bloqueo físico;
- reacción de alerta inmóvil de Scar durante el combate;
- llave soltada por el guardián que causa la apertura total y las consecuencias atómicas;
- Laboratorio `QA_ONLY`, cuentos desbloqueados temporalmente, HUD R11 y meta dual preservados.

La validación automatizada se ejecuta con `node tests/azure-catalogue-smoke.mjs`, `node tests/hud-hearts-r11-smoke.mjs`, `node tests/r16-functional-art-smoke.mjs` y `node tests/gb02-r04-smoke.mjs`.

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
