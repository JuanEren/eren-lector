# Correcciones de playtest GB02 R18

## Resultado

R18 corrige los defectos observados en el playtest Android de R17 y conserva la física de movimiento validada en R15 y el contacto visual R10. La revisión queda como candidata de playtest; no se declara `gameReady` hasta compilarla y repetir la prueba en el dispositivo.

## Cambios aplicados

| Área | Corrección R18 | Verificación fuente |
|---|---|---|
| Inicio | Se añade un límite oeste invisible y sólido para Eren y Scar. El encuadre inicial conserva a ambos visibles. | Prueba de avance continuo hacia la izquierda sin caída ni recuperación de Scar. |
| Caja | ACCIÓN inicia el golpe visible. El primer impacto deja O024; el segundo reproduce O025 durante 0,34 s y termina en O026 sin collider. | Secuencia y eventos diferenciados comprobados. |
| Táctil | Cada nueva presión de SALTAR se encola como flanco independiente aunque CORRER continúe mantenido. El acorde se rearma al retirar y volver a apoyar la falange. | Dos contactos y gesto repetido de un único pulgar comprobados. |
| Eren | Marcha de 4 fotogramas, carrera de 8, reposo con base anclada, respiración mínima y parpadeo. | Todos los fotogramas del ciclo se seleccionan; R10 conserva el contacto. |
| Salto corriendo | La salida visual mantiene impulso/subida un mínimo coherente antes de mostrar caída. | Transición impulso → subida → caída comprobada sin tocar la física. |
| Escalera | La subida usa las dos poses correctas de subida. El personaje conserva el anclaje y la mecánica bidireccional R17. | 20/20 ascensos y brazos alternos. |
| Fondo de escalera | Los píxeles neutros del panel blanco de S012 se convierten a alfa en tiempo de carga. | Montaje `S012_R18_RUNTIME_ALPHA` comprobado. |
| Puerta de piedra | La puerta sube 5,25 módulos y se retira por completo; no queda un pilar decorativo sin colisión. | Estado abierto sin `BARRERA_GB02`. |
| Pinchos | El collider R15 conserva su geometría y se dibuja con `hazards/pincho-1x1_5.png`. | Recurso del tileset trazado en runtime. |
| Guardián | Aviso amarillo al detectar y rojo durante la preparación; el rectángulo de ataque queda solo en depuración. | Estados de aviso comprobados. |
| Contacto enemigo | El cuerpo bloquea lateralmente. Caer encima causa daño y rebote; no se puede atravesar ni usar como plataforma. | Contacto lateral y superior comprobados. |
| Scar en combate | Scar se queda inmóvil, orientada hacia el peligro y reproduce la señal de alerta hasta la derrota o alejamiento de Eren. | Entrada y salida únicas del estado de combate comprobadas. |
| Causalidad | La araña derrotada suelta una llave. Recogerla eleva la puerta; al terminar se habilitan escalera, paso de Scar y retirada de barrera en el mismo instante. | Cadena y marcas temporales atómicas comprobadas. |

## Contratos preservados

- Contacto visual R10: actores 10 px y utilería 6 px.
- HUD R11: tres casillas estables.
- Movimiento R15: velocidades, gravedad, impulso y caída terminal.
- Agachado voluntario, escalera bidireccional, puente ordenado y meta dual aprobados en R17.
- Acceso directo temporal, texto no seleccionable, pinza bloqueada y reintento sin revelar la respuesta.
- R12 y R13 permanecen preservados y no aplicados.

## Fuera de alcance

- Decoración final, fondos y paralaje.
- Sonidos de personajes, ambiente y enemigos.
- Música.
- Merge a `main`, release o promoción a `gameReady`.

## Estado de entrega

- Fuente y pruebas automáticas: `PASS`.
- Compilación CI y playtest Android R18: pendientes.
- Aprobación gráfica final: pendiente.
