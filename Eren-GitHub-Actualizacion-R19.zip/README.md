# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 42.0.0 · candidata GB02 R04 · revisión R19

R19 aplica las correcciones imprescindibles del playtest Android R18 sobre el contrato `GB02_R04_PLAYTEST_CORRECTION`. Mantiene R15 como base física, conserva el contacto visual R10 y preserva sin aplicar R12/R13. Sigue siendo una candidata: requiere compilación y playtest en dispositivo antes de aprobarse.

Incluye:

- límite oeste infranqueable para Eren y Scar, manteniendo a ambos visibles al comenzar;
- puño universal en cada pulsación de ACCIÓN —también en el aire, agachado y en escalera— y caja de dos impactos sin giro al romperse;
- repetición de SALTAR mientras CORRER continúa mantenido, con dos dedos o gesto de un pulgar;
- ciclos completos de marcha/carrera de Eren, reposo anclado y trepa de cuatro pasos con brazos alternos;
- escalera dibujada directamente desde PNG RGBA, desplazada fuera del pilar y con entrada/salida estable heredada de R17;
- pinchos del tileset funcional, llave canónica y puerta de piedra cerrada/abierta con pilar superior permanente;
- guardián con exclamación amarilla/roja, contacto corporal y superior dañino, y bloqueo físico;
- reacción de alerta inmóvil de Scar durante el combate;
- Scar detenida antes del agua hasta recibir la orden del puente, sin bypass ni bucles de recuperación;
- llave soltada por el guardián que causa la apertura total y las consecuencias atómicas;
- Laboratorio `QA_ONLY`, cuentos desbloqueados temporalmente, HUD R11 y meta dual preservados.

La validación automatizada se ejecuta con `node tests/azure-catalogue-smoke.mjs`, `node tests/hud-hearts-r11-smoke.mjs`, `node tests/r16-functional-art-smoke.mjs` y `node tests/gb02-r04-smoke.mjs`.

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK R19** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
