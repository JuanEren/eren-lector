# Correcciones imprescindibles de playtest GB02 R19

## Resultado

R19 corrige los bloqueos observados en el playtest Android R18. Conserva la física de movimiento R15, el contacto visual R10, el HUD R11 y las interacciones validadas en R17. Es una candidata de playtest: `gameReady` continúa en `false` hasta compilar y superar la prueba en el dispositivo.

## Cambios aplicados

| Área | Corrección R19 | Verificación |
|---|---|---|
| ACCIÓN | Toda pulsación nueva inicia un puño visible y un hitbox frontal, sin exigir una caja o enemigo preseleccionado. Funciona quieto, andando, corriendo, saltando, agachado y en escalera; las pulsaciones durante otro golpe se encolan. | Casos libre, aéreo, agachado, escalera, cola y alcance dinámico: `PASS`. |
| Caja | O023 → O024 → O025 → O026 se conserva, pero O025 ya no rota ni el sprite ni sus restos. | Dos impactos y transición fija comprobados. |
| Escalera | S012 se dibuja directamente desde su PNG RGBA; no hay clave blanca en runtime. La secuencia de subida y bajada usa cuatro pasos, con pose intermedia y alternancia izquierda/derecha. | Alfa real y secuencias visuales revisadas; 20/20 ascensos. |
| Locomoción | Eren usa reloj local de animación: reposo de cuatro pasos anclado al pie, marcha de cuatro y carrera de ocho. | Los ciclos recorren todos sus fotogramas sin desplazar la física. |
| Recompensa | La esfera amarilla provisional se sustituye por la llave O014 canónica. | SHA-256 `d52497cb5b0b6fa4d39d6f433b9aaab8e6dbaa146e3e0c05e00e1a30df360f17`. |
| Puerta del guardián | Se integran O020 cerrada y O019 abierta. La colisión inferior desaparece solo al finalizar la apertura; el pilar superior permanece visible y sólido. | Assets y geometría comprobados; apertura causal tras recoger la llave. |
| Escalera/puerta | La escalera se desplaza a `x=44,5…45,5`, fuera del pilar y alineada con U4. | Entrada, salida superior y apoyo U4: 20/20. |
| Pilar del puzle inicial | Solo la mitad inferior se retrae durante 0,60 s; la parte superior permanece y conserva colisión. | Estado cerrado, transición y estado abierto comprobados. |
| Ruta de Scar | Scar se detiene en `x=43,75` antes del túnel y del agua hasta recibir la orden del puente. Se bloquean avance bajo, salto y recuperación de bypass. | 20/20 rutas con orden; antes de la orden: 0 cruces, 0 saltos y 0 recuperaciones. |
| Pilar continuo | Se recortan los 17 px transparentes superiores del asset únicamente al repetirlo como columna, evitando una junta vacía sin modificar su collider. | Render determinista de puerta cerrada/abierta revisado. |

## Assets canónicos integrados

| Uso | Archivo | SHA-256 |
|---|---|---|
| Llave del guardián | `llave-1_5x1.png` | `d52497cb5b0b6fa4d39d6f433b9aaab8e6dbaa146e3e0c05e00e1a30df360f17` |
| Puerta cerrada | `puerta-cerrada-2x2_5.png` | `d38c748780e0d640da6ff31873cf921b0b88f544c785e9141cc4825511c7176e` |
| Puerta abierta | `puerta-abierta-2x2_5.png` | `1d6533e067bd029886ff692b49be39c040f889ab7ad8f935a8fa37d080780704` |
| Escalera RGBA | `S012-escalera-madera-1x3_5-r19-rgba.png` | `cdf8ef053ace7551c74c77ab3ea7ff63f156df7466d76fa0a4bf0813f9024f30` |

## Preservado

- Límite oeste dual y encuadre inicial de R18.
- CORRER + SALTAR repetible, ABAJO y diagonal agachada.
- Salto corriendo, pincho del tileset, señales amarilla/roja y contacto sólido del guardián.
- Scar inmóvil y erizada durante el combate.
- Cuentos y protecciones de interfaz de R17.
- Contacto visual R10; tres corazones R11; velocidades, gravedad, salto y apoyo R15.
- R12 y R13 permanecen preservados y no aplicados.

## Fuera de alcance

- Decoración, fondos y paralaje.
- Sonidos y música.
- Merge a `main`, release o promoción a `gameReady`.

## Estado

- Sintaxis, catálogo, arte funcional y contrato GB02 R04: `PASS`.
- Ruta de Scar: 20/20; bypass antes de orden: 0/20.
- Escalera: 20/20.
- Render determinista de escenas y secuencias: `PASS`.
- Compilación CI y playtest Android R19: pendientes.
