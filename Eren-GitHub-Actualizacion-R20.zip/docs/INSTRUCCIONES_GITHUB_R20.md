# Cómo subir R20 a GitHub

## Dónde debe ir

- Repositorio: `JuanEren/eren-lector`.
- Rama de partida: `codex/gb02-r16-visual-integration-20260827`.
- Rama nueva: `codex/gb02-r20-a05-integration-20260828`.
- No subir directamente a `main`.
- No crear una release y no activar merge automático.

El nombre antiguo de la rama de partida contiene “R16”, pero su `HEAD` correcto ya incluye R19. Antes de seguir, confirma que el commit mostrado es `711c33841824a713964691be8b33268eed1db48e`.

## Qué se sube realmente

Este repositorio conserva una base y una cadena de ZIP incrementales en su raíz. **No descomprimas** `Eren-GitHub-Actualizacion-R20.zip` dentro del repositorio: ese ZIP es el parche que GitHub Actions aplicará después de R19.

La rama R20 debe contener únicamente estos tres cambios respecto de R19:

- `.github/workflows/build-apk.yml`
- `Eren-GitHub-Actualizacion-R20.zip`
- `Eren-GitHub-Actualizacion-R20.zip.sha256`

El archivo de entrega `SUBIR_A_GITHUB_R20.zip` es solo un contenedor cómodo con esos tres elementos. Descomprime ese contenedor antes de subirlo, pero deja intacto `Eren-GitHub-Actualizacion-R20.zip`.

## Método recomendado: GitHub Desktop

1. En GitHub abre `JuanEren/eren-lector`.
2. En el selector de ramas elige `codex/gb02-r16-visual-integration-20260827`.
3. Comprueba en la lista de commits que el último commit es `711c33841824a713964691be8b33268eed1db48e`.
4. Pulsa el selector de ramas otra vez.
5. Escribe `codex/gb02-r20-a05-integration-20260828`.
6. Pulsa **Create branch: codex/gb02-r20-a05-integration-20260828 from codex/gb02-r16-visual-integration-20260827**.
7. En GitHub Desktop, clona o abre `JuanEren/eren-lector` y selecciona la rama nueva.
8. Descarga y descomprime `SUBIR_A_GITHUB_R20.zip` en una carpeta temporal.
9. Copia sus tres elementos a la raíz local del repositorio, aceptando solo el reemplazo de `.github/workflows/build-apk.yml`.
10. Comprueba que GitHub Desktop muestra exactamente tres cambios: el workflow, el ZIP R20 y su `.sha256`.
11. En **Summary** escribe: `R20: integrar A05 R02 sobre HEAD exacto de R19`.
12. Pulsa **Commit to codex/gb02-r20-a05-integration-20260828** y después **Push origin**.

## Alternativa: terminal

Desde una copia local del repositorio:

```bash
git fetch origin
git switch -c codex/gb02-r20-a05-integration-20260828 711c33841824a713964691be8b33268eed1db48e
unzip SUBIR_A_GITHUB_R20.zip -d /ruta/a/eren-lector
git status --short
git add .github/workflows/build-apk.yml Eren-GitHub-Actualizacion-R20.zip Eren-GitHub-Actualizacion-R20.zip.sha256
git commit -m "R20: integrar A05 R02 sobre HEAD exacto de R19"
git push -u origin codex/gb02-r20-a05-integration-20260828
```

Antes del `git add`, `git status --short` debe mostrar solo esos tres archivos. Sustituye `/ruta/a/eren-lector` por la ruta real de tu clon.

La web de GitHub no es la opción preferida porque el navegador puede dificultar el reemplazo de la ruta oculta `.github/`. Si se usa, deben quedar exactamente los mismos tres cambios; nunca se sube `SUBIR_A_GITHUB_R20.zip` como archivo del repositorio.

## Compilar la APK en GitHub Actions

1. Abre la pestaña **Actions**.
2. Selecciona **Compilar APK R20**.
3. Pulsa **Run workflow**.
4. En **Use workflow from** elige `codex/gb02-r20-a05-integration-20260828`.
5. Pulsa el botón verde **Run workflow**.
6. Espera a que el workflow termine en verde.
7. Abre la ejecución terminada.
8. En **Artifacts** descarga `Eren-GB02-R04-R20-APK-CANDIDATE`.
9. Descomprime el artifact para obtener `app-debug.apk`.

## Comprobaciones antes del playtest

- La ejecución debe indicar `Compilar APK R20`.
- La APK debe mostrar `versionName 43.0.0-visual-integration-gb02-r04-candidate-r20` y `versionCode 44`.
- No debe existir ningún commit nuevo en `main` como consecuencia de esta subida.
- No debe existir una release automática.
- Conserva el SHA-256 del artifact de GitHub; puede diferir del APK local si la firma/build environment cambia.

## Qué no subir

- `Plano_Nivel_1_150x50.png`.
- Fuentes R12 o R13.
- Los 16 cuadros Ludo gratuitos con fondo morado o marcas de agua.
- Carpetas locales `build/`, `.gradle/`, toolchains o caches.
- Credenciales, claves de Azure o archivos de firma.

## Estado permitido

Tras subir y compilar, el estado sigue siendo `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`. No declarar `GITHUB_VERIFICADO` hasta comprobar manualmente rama, commit y artifact; no declarar `GAME_READY` hasta completar el playtest Android.
