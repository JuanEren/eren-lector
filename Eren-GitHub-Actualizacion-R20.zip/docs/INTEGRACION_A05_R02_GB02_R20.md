# Integración A05 R02 · GB02 R04 · R20

## Resultado

R20 integra el cierre visual A05 R02 sobre el `HEAD` exacto de R19, manteniendo R15 como contrato físico. La APK local compila, pero continúa pendiente de playtest en un dispositivo Android real.

## Montaje visual

- FAR, MID y NEAR se cargan como tres imágenes independientes con factores 0,12, 0,30 y 0,52.
- Ninguna capa se declara seamless ni recibe collider.
- El fondo se renderiza con menor brillo, contraste y saturación que el plano jugable.
- El terreno usa recortes nativos a 100 px/M, sin `Transform.scale` ni estiramiento de piezas.
- Se conservan únicamente cuatro acentos: musgo `x=12,50`, grietas `x=17,05`, piedras `x=29,55` y raíces `x=37,70`.
- No hay decoración bajo la estrella.
- Agua, puente, escalera, rejas, columnas, pincho, placas, estrella y bandera se montan en el plano jugable.

## Geometría autorizada

| Elemento | Geometría R20 |
|---|---|
| Prolongación U0 | `x=6,5 · y=7,5 · w=1 · h=4,5` |
| Columna reja 1 | `x=23,75 · y=4,5 · w=1 · h=7,5` |
| Reja móvil 1 | `x=24 · y=2 · w=0,5 · h=2,5` |
| Columna reja 2 | `x=42,5 · y=5 · w=1 · h=7` |
| Reja móvil 2 | `x=42,75 · y=2 · w=0,5 · h=2,5` |
| Escalera arte/agarre | `x=43,5 · y=1,5 · w=1 · h=3,5`; centro `x=44` |
| U4 | `x=42,5 · y=4,5 · w=3 · h=0,5` |
| Paso bajo Scar | `x=45,5 · y=2,75 · w=4 · h=0,5` |

Las rejas conservan collider durante la subida y se eliminan del conjunto de sólidos únicamente cuando su borde inferior ha liberado el paso. Las columnas receptoras permanecen sólidas.

## Correcciones posteriores a R19

- ACCIÓN queda deshabilitada durante la trepa.
- El golpe bajo conserva postura y collider hasta finalizar.
- El alcance del golpe se reduce a 0,92 M.
- Las pulsaciones rápidas se encolan de forma acotada y el estado siempre termina.
- Recoger la llave solo habilita la segunda reja; ACCIÓN junto a la reja inicia su subida.
- La salida superior termina exactamente en `Eren.x=44`.
- La ruta física para agacharse bajo la escalera permanece disponible.
- Scar se queda en la placa del puente y no retrocede tras enclavarla.
- El despliegue dura exactamente 0,600 s sin collider.
- Se bloquea el salto automático de Scar contra la columna inicial.

## Personajes

No existe una exportación Ludo de pago limpia, RGBA, sin marca de agua y con cuerpo completo. Los 16 cuadros gratuitos con fondo morado/marcas no se modifican ni se integran. Solo la sustitución de `walk` queda bloqueada; R20 conserva el caminar funcional de R19. Las demás animaciones de Eren, Scar, araña y guardián también se preservan.

## Estado

`GAME_READY=false`

`APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`
