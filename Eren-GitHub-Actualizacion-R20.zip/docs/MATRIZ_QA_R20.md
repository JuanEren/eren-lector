# Matriz QA · GB02 R04 · R20

Fecha: 2026-08-28  
APK: `43.0.0-visual-integration-gb02-r04-candidate-r20` (`versionCode 44`)  
Estado máximo: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`

`PASS` significa comprobado en fuente, simulación determinista, render local o compilación según indica la columna Evidencia. `PENDING_DEVICE` no significa fallo observado: significa que todavía debe ejecutarse físicamente en Android.

| Caso | Resultado | Evidencia / observación |
|---|---|---|
| Compilación Android | PASS | Gradle 8.9 `assembleDebug`; APK local generada. |
| Arranque Android real | PENDING_DEVICE | Requiere instalación manual de la APK candidata. |
| Pantalla completa 16:9 | PASS_LOCAL / PENDING_DEVICE | Render 1280×720: `01_EREN_CAMINAR_16x9.png`; recorte físico pendiente. |
| Pantalla completa 19.5:9 | PASS_LOCAL / PENDING_DEVICE | Render 1300×600: `08_VIEWPORT_19_5x9.png`; recorte físico pendiente. |
| Pantalla completa 21:9 | PASS_LOCAL / PENDING_DEVICE | Render 1400×600: `09_VIEWPORT_21x9.png`; recorte físico pendiente. |
| Recorrido inicio–meta con Eren y Scar | PASS_SIMULATION / PENDING_DEVICE | Ruta y meta dual simuladas; recorrido manual completo pendiente. |
| Caja: dos golpes, cuatro estados, sin rotación | PASS | O023→O024→O025→O026; una transición; collider retirado tras rotura. |
| Caminar 3,5 m/s | PASS | Tuning congelado y ciclo de 4 frames; `01_EREN_CAMINAR_16x9.png`. |
| Correr 6 m/s + salto, salto vertical | PASS | Física/tuning R15 y acorde multitáctil preservados. |
| Ataque de pie y aéreo | PASS | Ventana universal y hitbox dinámico comprobados. |
| Ataque bajo conserva postura | PASS | Collider 1,5×1 y variante `crouched` bloqueados hasta terminar. |
| Repetición rápida de ataque | PASS | Cola acotada; finalización sin estado enganchado. |
| ACCIÓN durante escalera | PASS | Bloqueada y trazada con `accion_bloqueada_escalera`. |
| Paso agachado de Eren | PASS | Postura voluntaria y restricción baja heredadas. |
| Paso bajo exclusivo de Scar | PASS | Eren de pie/agachado no cabe; Scar a 0,65 M sí; `05_PASO_BAJO_SCAR_16x9.png`. |
| Primera reja | PASS | Placa + activador, subida completa, collider presente durante transición y retirado solo al final; `02_PRIMERA_REJA_16x9.png`. |
| Segunda reja | PASS | Llave solo habilita; ACCIÓN inicia; subida completa; columna fija anti-salto; `03_SEGUNDA_REJA_16x9.png`. |
| Escalera desplazada y salida superior | PASS | Arte/agarre `x=43,5`, centro/salida `x=44`; 20/20 sin atasco; `04_ESCALERA_16x9.png`. |
| Guardián: daño esquivable y dos golpes | PASS | Ataque con daño, esquiva, contacto lateral/superior y consecuencias atómicas. |
| Scar: orden, túnel y placa del puente | PASS | Antes de orden: 0 cruces, 0 saltos, 0 recuperaciones; con orden: 20/20. |
| Puente 0,6 s sin collider y cruce estable | PASS | 20/20; diferencia de eventos exactamente 0,600 s; `06_PUENTE_DESPLIEGUE_16x9.png`. |
| Pincho y daño | PASS | Hazard R15 preservado; arte hundido 0,28 M. |
| Placas, estrella, bandera/meta y checkpoints | PASS | Lógica preservada; contacto visual −0,22 M/−0,38 M; `07_META_DUAL_16x9.png`. |
| Scar y araña: sprites, ciclos y contacto | PASS_AUTOMATED / PENDING_DEVICE | Fuentes/hashes preservados; 20 rutas sin flotación/penetración; revisión visual física pendiente. |
| FAR/MID/NEAR independientes | PASS_CODE_RENDER | Tres recursos separados, factores 0,12/0,30/0,52, sin colliders ni declaración seamless. |
| Fondo no tapa plano jugable | PASS_RENDER | Filtros de contraste/saturación y montaje revisados en las nueve capturas. |
| Laboratorio QA_ONLY oculto | PASS | Oculto y no activable en build normal. |
| HUD compacto y tres corazones | PASS | Tres slots R11 fijos; cruceta y cuatro botones preservados. |

## Resultados repetidos

- Escalera: 20 completadas, 0 atascos, 0 penetraciones residuales.
- Ruta baja de Scar: 20 completadas, 20 órdenes, 20 pasos bajos, 0 saltos, 0 recuperaciones.
- Puente: 20 despliegues, 0 autoenclavados sin orden, collider ausente durante 0,600 s.

## Bloqueos antes de promover

1. Instalar en un dispositivo Android.
2. Ejecutar recorrido manual inicio–meta.
3. Comprobar recortes y controles en 16:9, 19.5:9 y 21:9 reales.
4. Revisar a tamaño de móvil el contraste, el ciclo de Eren y las animaciones preservadas de Scar/araña.

Hasta completar esos puntos no se permite declarar `GAME_READY`, aprobación final, merge a `main` ni release.
