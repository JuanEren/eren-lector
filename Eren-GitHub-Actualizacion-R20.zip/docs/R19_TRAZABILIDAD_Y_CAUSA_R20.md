# Por qué parecía que R19 no se tenía en cuenta

## Diagnóstico

R19 sí estaba aplicado al código. El `HEAD` funcional utilizado para R20 es:

`711c33841824a713964691be8b33268eed1db48e`

Ese commit contiene la cadena incremental R15 + R16 + R17 + R18 + R19 y supera las pruebas de R19 antes de aplicar A05 R02.

La confusión procede de tres desfases de trazabilidad:

1. La rama remota siguió llamándose `codex/gb02-r16-visual-integration-20260827`, aunque su `HEAD` ya incorporaba R17, R18 y R19.
2. El snapshot, el handoff y parte del inventario de Drive quedaron cerrados alrededor de R15/R16.
3. El prompt A05 aún identificaba R15 como baseline funcional, porque A05 describe el contrato físico, no el último paquete de correcciones de playtest.

Por tanto, leer solo el nombre de la rama o esos documentos daba la impresión de que se estaba reconstruyendo desde R15 y omitiendo R19. No era correcto sustituir R19 por memoria ni volver a R15 sin reaplicar la cadena.

## Decisión aplicada en R20

- Se reconstruyó y compiló R15 como preflight de la fuente contractual.
- Se reconstruyó y compiló el `HEAD` exacto de R19.
- R20 se creó sobre ese `HEAD` exacto.
- A05 R02 se integró después, junto con el feedback posterior al playtest R19.
- R12 y R13 siguen preservados y no aplicados.

La rama propuesta para eliminar la ambigüedad es:

`codex/gb02-r20-a05-integration-20260828`

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`. No implica merge, release, `GAME_READY` ni verificación final de GitHub.
