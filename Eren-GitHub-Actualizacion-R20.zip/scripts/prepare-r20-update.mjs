import { createHash } from 'node:crypto';
import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { dirname, relative, resolve, sep } from 'node:path';
import { spawnSync } from 'node:child_process';

const args = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  args.set(process.argv[index], process.argv[index + 1]);
}

const baseRoot = resolve(args.get('--base') || '');
const candidateRoot = resolve(args.get('--candidate') || '.');
const outputZip = resolve(args.get('--output') || 'SUBIR_A_GITHUB_R20.zip');
const aliasZip = args.has('--alias') ? resolve(args.get('--alias')) : null;
const checksumRelative = 'docs/updates/R20/SHA256SUMS_UPDATE_R20.txt';

if (!existsSync(baseRoot) || !existsSync(candidateRoot)) {
  throw new Error('Debes indicar --base y --candidate existentes.');
}

const ignoredSegments = new Set(['.git', '.gradle', 'build', 'node_modules']);

function isIgnored(relativePath) {
  return relativePath.split('/').some((segment) => ignoredSegments.has(segment));
}

function walk(root, current = root, output = []) {
  for (const entry of readdirSync(current, { withFileTypes: true })) {
    const absolute = resolve(current, entry.name);
    const relativePath = relative(root, absolute).split(sep).join('/');
    if (isIgnored(relativePath)) continue;
    if (entry.isDirectory()) walk(root, absolute, output);
    else if (entry.isFile()) output.push(relativePath);
  }
  return output;
}

function sha256(file) {
  return createHash('sha256').update(readFileSync(file)).digest('hex');
}

function filesDiffer(relativePath) {
  const candidateFile = resolve(candidateRoot, relativePath);
  const baseFile = resolve(baseRoot, relativePath);
  if (!existsSync(baseFile) || !lstatSync(baseFile).isFile()) return true;
  return sha256(candidateFile) !== sha256(baseFile);
}

let changedFiles = walk(candidateRoot).filter(filesDiffer).sort();

const checksumEntries = changedFiles
  .filter((file) => file !== checksumRelative)
  .map((file) => `${sha256(resolve(candidateRoot, file))}  ${file}`);
const checksumPath = resolve(candidateRoot, checksumRelative);
mkdirSync(dirname(checksumPath), { recursive: true });
writeFileSync(
  checksumPath,
  [
    '# SHA-256 de los archivos nuevos o modificados por R20.',
    '# Verificar desde la raiz del repositorio con: sha256sum -c docs/updates/R20/SHA256SUMS_UPDATE_R20.txt',
    ...checksumEntries,
    '',
  ].join('\n'),
  'utf8',
);

changedFiles = walk(candidateRoot).filter(filesDiffer).sort();
if (!changedFiles.includes(checksumRelative)) changedFiles.push(checksumRelative);
changedFiles.sort();

mkdirSync(dirname(outputZip), { recursive: true });
rmSync(outputZip, { force: true });
const zipResult = spawnSync('zip', ['-q', '-X', outputZip, ...changedFiles], {
  cwd: candidateRoot,
  encoding: 'utf8',
});
if (zipResult.status !== 0) {
  throw new Error(zipResult.stderr || zipResult.stdout || 'No se pudo crear el ZIP incremental.');
}

if (aliasZip) {
  mkdirSync(dirname(aliasZip), { recursive: true });
  copyFileSync(outputZip, aliasZip);
}

process.stdout.write(`${JSON.stringify({
  baseRoot,
  candidateRoot,
  changedFileCount: changedFiles.length,
  checksumEntryCount: checksumEntries.length,
  outputZip,
  aliasZip,
  outputZipSha256: sha256(outputZip),
  changedFiles,
}, null, 2)}\n`);
