# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 44.0.0 · candidata GB02 R04 · revisión R21

R21 parte de R20, cuya prueba física completó dos recorridos de principio a meta, y aplica únicamente las correcciones menores observadas en ese dispositivo. Conserva el cierre visual A05 R02, la base física R15, el contacto R10 y mantiene R12/R13 sin aplicar. No es una versión final: el estado máximo es `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST` y `gameReady` continúa en `false`.

Incluye:

- FAR, MID y NEAR como capas de paralaje independientes, sin declaración seamless ni colliders;
- escalera S012 siempre visible, sin atenuación previa, con alfa real en los huecos y delante de U4;
- U4 compuesta con tres recortes nativos de 100 px, continua hasta la columna y sin el recorte residual;
- despegue de Scar tras la primera reja retrasado hasta `x=24,35`, con 20/20 cruces sin choque ni recuperación en agua;
- look-ahead horizontal de cámara amortiguado al frenar, sin salto inverso al detenerse;
- terreno continuo a 100 px por módulo, agua, puente, columnas, rejas, escalera y cuatro acentos decorativos A05 R02;
- prolongación sólida de U0 hasta `y=12`, primera reja en `x=24` y segunda reja en `x=42,75` con sus columnas receptoras fijas;
- escalera completa en `x=43,5`, centro `x=44`, y salida superior centrada 20/20;
- puño universal en suelo y aire; el golpe bajo conserva postura/collider y ACCIÓN queda deshabilitada durante la trepa;
- repetición de SALTAR mientras CORRER continúa mantenido, con dos dedos o gesto de un pulgar;
- ciclos funcionales R19 de Eren, Scar, araña y guardián preservados; no se usa el walk Ludo con fondo morado o marcas de agua;
- pincho hundido visualmente 0,28 M, placas 0,22 M y bandera 0,38 M sin mover sus colliders/triggers;
- guardián con exclamación amarilla/roja, contacto corporal y superior dañino, y bloqueo físico;
- reacción de alerta inmóvil de Scar durante el combate;
- Scar detenida antes del agua hasta recibir la orden del puente, sin bypass ni bucles de recuperación;
- llave soltada por el guardián que solo habilita la segunda reja; ACCIÓN junto a ella inicia la elevación y las consecuencias se aplican al final;
- puente desplegado exactamente durante 0,600 s sin collider y sólido de forma permanente después;
- Laboratorio `QA_ONLY`, cuentos desbloqueados temporalmente, HUD R11 y meta dual preservados.

La validación automatizada se ejecuta con `node tests/azure-catalogue-smoke.mjs`, `node tests/hud-hearts-r11-smoke.mjs`, `node tests/r16-functional-art-smoke.mjs`, `node tests/ladder-alpha-r21-smoke.mjs` y `node tests/gb02-r04-smoke.mjs`. Las capturas reproducibles se generan con `node tests/r21-render-evidence.mjs` cuando está disponible `@napi-rs/canvas`.

## Prueba rápida en dispositivo

1. Abre el juego con tres corazones y toma como referencia su centro.
2. Recibe daño hasta mostrar dos, uno y cero corazones.
3. Confirma que las tres casillas conservan exactamente la misma posición y separación.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK R21** y descarga **Eren-GB02-R04-R21-APK-CANDIDATE**. Ejecuta el workflow únicamente en la rama candidata R21; no hagas merge a `main` ni crees una release.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
