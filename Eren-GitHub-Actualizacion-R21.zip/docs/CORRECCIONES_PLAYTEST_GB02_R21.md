# Correcciones del playtest físico · GB02 R04 · R21

R21 parte de la APK R20 probada el 28/08/2026 en un Samsung SM-S928B con Android 16 y viewport 891×411. Los dos intentos completaron el nivel, la estrella y la meta dual. Esta revisión no rediseña el nivel ni modifica las velocidades, gravedad, contacto R10, combate, controles, puente o geometría contractual.

## Alcance aplicado

1. **Escalera S012**: permanece visible al 100 % antes y después de abrir la segunda reja. El PNG R21 conserva 100×350 px y sustituye el matte blanco por alfa real.
2. **U4**: se monta con tres recortes nativos de 100×50 px —izquierda, centro y derecha—. La plataforma ocupa visualmente los 3 m completos detrás de la escalera, sin estirar PNG. Se elimina el recorte residual de 0,1 m.
3. **Segunda reja**: el arte móvil se oculta cuando `gateUnlockState=open`, evitando que quede un poste residual tras completar la apertura.
4. **Scar tras la primera reja**: el despegue sobre G2 se retrasa de `x=23,10` a `x=24,35`. Se preservan `vx=8,5 m/s` y `vy=13,5 m/s`; la columna y todos los colliders permanecen intactos.
5. **Cámara**: el look-ahead máximo continúa siendo 3 m, pero acelera y vuelve a cero mediante amortiguación exponencial. Al soltar la dirección no cambia bruscamente el objetivo ni invierte el movimiento.

## Exclusiones

- No se integran ni modifican los sprites Ludo con marca de agua.
- No se añaden partículas, decoración nueva ni animaciones finales.
- No se aplican R12 ni R13.
- No se usa `Plano_Nivel_1_150x50.png`.
- No hay merge a `main`, release ni declaración `GAME_READY`.

Estado máximo: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`.
