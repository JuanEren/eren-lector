# Cómo subir R20 + R21 a GitHub

R20 no se ha subido. El paquete final `SUBIR_A_GITHUB_R20_R21.zip` contendrá los dos incrementales y el workflow R21. No subas la APK ni descomprimas los ZIP incrementales dentro del repositorio.

## Rama

Usa exclusivamente:

`codex/gb02-r21-playtest-correction-20260828`

No uses `main`, no hagas merge y no crees una release.

## Archivos que deben quedar en la raíz del repositorio

- `.github/workflows/build-apk.yml`
- `Eren-GitHub-Actualizacion-R20.zip`
- `Eren-GitHub-Actualizacion-R20.zip.sha256`
- `Eren-GitHub-Actualizacion-R21.zip`
- `Eren-GitHub-Actualizacion-R21.zip.sha256`

`SUBIR_A_GITHUB_R20_R21.zip` es únicamente el contenedor para transportar esos cinco archivos; se descomprime antes de copiarlos al repositorio.

## GitHub Desktop

1. Abre el repositorio `JuanEren/eren-lector`.
2. Actualiza el repositorio con **Fetch origin**.
3. Crea la rama `codex/gb02-r21-playtest-correction-20260828` desde la revisión que ya contiene R19.
4. Descomprime `SUBIR_A_GITHUB_R20_R21.zip` en una carpeta temporal.
5. Copia sus cinco elementos a la raíz del repositorio, respetando la carpeta oculta `.github`.
6. Comprueba que GitHub Desktop muestra únicamente esos cinco archivos nuevos/modificados.
7. Usa el mensaje: `R20 + R21: integrar A05 y corregir playtest físico`.
8. Pulsa **Commit to codex/gb02-r21-playtest-correction-20260828**.
9. Pulsa **Publish branch** o **Push origin**.

## Actions

1. En GitHub abre **Actions**.
2. Selecciona **Compilar candidata GB02 R04 R21**.
3. Ejecuta el workflow desde la rama R21 si no se inicia automáticamente.
4. Espera a que todos los pasos queden verdes.
5. Descarga el artifact `Eren-GB02-R04-R21-APK-CANDIDATE`.

El cierre seguirá siendo `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`. No declarar `GITHUB_VERIFICADO` hasta comprobar rama, commit y artifact, ni `GAME_READY` hasta terminar el playtest Android R21.
