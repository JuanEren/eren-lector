# Entrega GB02 R04 · R21

Esta entrega corrige únicamente las incidencias menores observadas en el playtest físico R20:

- escalera visible siempre y con transparencia alfa real;
- plataforma U4 continua encima de la escalera;
- eliminación del resto visual de la segunda reja abierta;
- salida segura de Scar tras la primera verja;
- amortiguación del objetivo de cámara al parar.

## APK local

Archivo: `EREN_GB02_R21_APK_CANDIDATE.apk`  
SHA-256: `ae1e8daffeb24ce4944fcfbf9b969bee4030ac567f889debea4b22e55d3ecb4c`

La APK está compilada y firmada como `debug`, con:

- versión `44.0.0-playtest-correction-gb02-r04-candidate-r21`;
- `versionCode 45`;
- registro `GB02-R04-PLAYTEST-R21-v1`.

## Orden recomendado

1. Instalar la APK R21 y comprobar escalera, primera verja y frenada de cámara.
2. Si el resultado es correcto, seguir `INSTRUCCIONES_GITHUB_R21.md`.
3. Subir R20 y R21 juntos mediante `SUBIR_A_GITHUB_R20_R21.zip`, sin subir la APK.
4. Descargar y contrastar el artifact generado por GitHub Actions.

No fusionar a `main`, no crear release y no declarar `GAME_READY` ni `GITHUB_VERIFICADO` todavía.

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`.
