# Matriz QA · GB02 R04 · R21

Aplicación: `44.0.0-playtest-correction-gb02-r04-candidate-r21` (`versionCode 45`)  
Estado máximo: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`

| Caso | Resultado local | Evidencia |
|---|---|---|
| Sintaxis JS y versionado Android | PASS | `node --check`; pruebas HUD/GB02 |
| Escalera visible antes de abrir | PASS | Captura `03_SEGUNDA_REJA_16x9.png` |
| Escalera RGBA 100×350 con huecos transparentes | PASS | 18.904 píxeles alfa 0; 0 blancos opacos; 8/8 muestras transparentes |
| U4 continua 3 m detrás de la escalera | PASS | Tres recortes nativos de 100×50 px; captura `04_ESCALERA_16x9.png` |
| Reja sin resto después de abrir | PASS | Estado abierto exige `barrierOpen=true` y `gateUnlockState=open` |
| Scar sale de la primera verja sin colisión/agua | PASS | 20/20; 0 recuperaciones; `SCAR_SALIDA_PRIMERA_REJA_R21_20_REPETICIONES.json` |
| Escalera: salida superior centrada | PASS | 20/20, `x=44`, soporte U4 |
| Puente: orden, placa y despliegue | PASS | 20/20; 0,600 s sin collider |
| Cámara al detenerse | PASS | Look-ahead positivo, monótono y sin inversión hasta cero |
| Viewports 16:9, 19.5:9 y 21:9 | PASS local | 9 capturas reproducibles |
| Física R15 y contacto R10 | PASS preservado | Velocidades, gravedad, colliders y perfiles sin cambios |
| Recorrido físico completo R21 | PENDING | Requiere APK instalada en dispositivo |

Los dos recorridos físicos R20 constan como `PASS_WITH_MINOR_CORRECTIONS`; R21 necesita una comprobación corta en el mismo dispositivo antes de cerrar el pase.
