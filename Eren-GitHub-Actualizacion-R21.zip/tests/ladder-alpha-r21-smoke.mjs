import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { inflateSync } from 'node:zlib';

const file = new URL('../app/src/main/assets/www/assets/playtest/arte-gb02-r16-r01/04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r21-alpha-real.png', import.meta.url);
const bytes = await readFile(file);
const signature = '89504e470d0a1a0a';
if (bytes.subarray(0, 8).toString('hex') !== signature) throw new Error('S012 R21 no es un PNG válido.');

let offset = 8;
let width = 0;
let height = 0;
let bitDepth = 0;
let colorType = 0;
let interlace = 0;
const idat = [];
while (offset < bytes.length) {
  const length = bytes.readUInt32BE(offset);
  const type = bytes.subarray(offset + 4, offset + 8).toString('ascii');
  const data = bytes.subarray(offset + 8, offset + 8 + length);
  if (type === 'IHDR') {
    width = data.readUInt32BE(0); height = data.readUInt32BE(4); bitDepth = data[8]; colorType = data[9]; interlace = data[12];
  } else if (type === 'IDAT') idat.push(data);
  else if (type === 'IEND') break;
  offset += length + 12;
}

if (width !== 100 || height !== 350 || bitDepth !== 8 || colorType !== 6 || interlace !== 0) throw new Error(`S012 R21 debe ser RGBA 100x350 sin entrelazado: ${JSON.stringify({ width, height, bitDepth, colorType, interlace })}`);

const raw = inflateSync(Buffer.concat(idat));
const stride = width * 4;
const rgba = Buffer.alloc(stride * height);
const paeth = (a, b, c) => {
  const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
};
let source = 0;
for (let y = 0; y < height; y++) {
  const filter = raw[source++];
  const row = y * stride;
  for (let x = 0; x < stride; x++) {
    const value = raw[source++], left = x >= 4 ? rgba[row + x - 4] : 0, up = y ? rgba[row - stride + x] : 0, upperLeft = y && x >= 4 ? rgba[row - stride + x - 4] : 0;
    if (filter === 0) rgba[row + x] = value;
    else if (filter === 1) rgba[row + x] = (value + left) & 255;
    else if (filter === 2) rgba[row + x] = (value + up) & 255;
    else if (filter === 3) rgba[row + x] = (value + Math.floor((left + up) / 2)) & 255;
    else if (filter === 4) rgba[row + x] = (value + paeth(left, up, upperLeft)) & 255;
    else throw new Error(`Filtro PNG no compatible: ${filter}.`);
  }
}

const pixel = (x, y) => {
  const index = (y * width + x) * 4;
  return { r: rgba[index], g: rgba[index + 1], b: rgba[index + 2], a: rgba[index + 3] };
};
const holeSeeds = [[50, 75], [50, 104], [50, 133], [50, 162], [50, 191], [50, 220], [50, 249], [50, 278]];
for (const [x, y] of holeSeeds) if (pixel(x, y).a !== 0) throw new Error(`El hueco de S012 R21 en ${x},${y} conserva fondo opaco.`);

let transparent = 0;
let visible = 0;
let opaqueNearWhite = 0;
for (let index = 0; index < rgba.length; index += 4) {
  const r = rgba[index], g = rgba[index + 1], b = rgba[index + 2], a = rgba[index + 3];
  if (a === 0) transparent++;
  if (a >= 200) visible++;
  if (a >= 250 && r >= 235 && g >= 235 && b >= 235) opaqueNearWhite++;
}
if (transparent < 18000 || visible < 14000 || opaqueNearWhite !== 0) throw new Error(`Alfa de S012 R21 incorrecto: ${JSON.stringify({ transparent, visible, opaqueNearWhite })}`);

console.log(JSON.stringify({
  result: 'PASS', asset: 'S012-escalera-madera-1x3_5-r21-alpha-real.png', width, height,
  sha256: createHash('sha256').update(bytes).digest('hex'), transparentPixels: transparent,
  visiblePixels: visible, opaqueNearWhitePixels: opaqueNearWhite, transparentHoleSamples: holeSeeds.length,
}));
