import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';

const artRoot = new URL('../app/src/main/assets/www/assets/playtest/arte-gb02-r16-r01/', import.meta.url);
const runtimeSource = await readFile(new URL('../app/src/main/assets/www/graybox-game.js', import.meta.url), 'utf8');

async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const url = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) files.push(...await walk(url));
    else files.push(url);
  }
  return files;
}

const files = await walk(artRoot);
const pngFiles = files.filter(file => file.pathname.endsWith('.png'));
const manifests = files.filter(file => file.pathname.endsWith('.json'));
const familyManifests = manifests.filter(file => !file.pathname.endsWith('/runtime-manifest.json'));
if (pngFiles.length !== 104) throw new Error(`Se esperaban 101 PNG fuente y las tres variantes S012 preservadas R17/R19/R21; hay ${pngFiles.length}.`);
if (familyManifests.length !== 11 || manifests.length !== 12) throw new Error(`Se esperaban 11 manifiestos de familia más el manifiesto runtime y hay ${familyManifests.length}+${manifests.length - familyManifests.length}.`);

const dimensions = new Map();
for (const file of pngFiles) {
  const data = await readFile(file);
  if (data.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a') throw new Error(`Firma PNG inválida: ${file.pathname}`);
  const width = data.readUInt32BE(16);
  const height = data.readUInt32BE(20);
  const colorType = data[25];
  if (!width || !height || colorType !== 6) throw new Error(`PNG no RGBA o sin dimensiones: ${file.pathname}`);
  dimensions.set(file.pathname.slice(artRoot.pathname.length), [width, height]);
}

const expectedDimensions = {
  '01_EREN/LOCOMOTION_R02/frames/eren-correr-r02-03-candidate.png': [300, 200],
  '01_EREN/ESCALERA_R01_EXTRACT/frames/eren-escalera-subida-00-candidate.png': [300, 200],
  '02_SCAR/PASO_BAJO_R01/frames/scar-paso-bajo-avance-00-candidate.png': [200, 150],
  '03_ARANA/ARANA_R01_REUSE/frames/attack/arana-attack-02.png': [200, 150],
  '04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5.png': [100, 350],
  '04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r17-transparent.png': [100, 350],
  '04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r19-rgba.png': [100, 350],
  '04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r21-alpha-real.png': [100, 350],
  '04_ESTRUCTURAS_CANONICAS/S020-puente-madera-4_5x1.png': [450, 100],
};
for (const [file, expected] of Object.entries(expectedDimensions)) {
  if (dimensions.get(file)?.join('x') !== expected.join('x')) throw new Error(`Dimensiones inesperadas: ${file}.`);
}

async function sha256(relativePath) {
  return createHash('sha256').update(await readFile(new URL(relativePath, artRoot))).digest('hex');
}
const s012Sha = await sha256('04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5.png');
const s012TransparentSha = await sha256('04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r17-transparent.png');
const s012R19Sha = await sha256('04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r19-rgba.png');
const s012R21Sha = await sha256('04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r21-alpha-real.png');
const s020Sha = await sha256('04_ESTRUCTURAS_CANONICAS/S020-puente-madera-4_5x1.png');
if (s012Sha !== '49e685f14bca4de1de28b3564f49c1ec06713b38bd763a3eff964e6e6064c667') throw new Error('S012 no coincide con el canónico del catálogo.');
if (s012TransparentSha !== 'cdf8ef053ace7551c74c77ab3ea7ff63f156df7466d76fa0a4bf0813f9024f30') throw new Error('El S012 transparente de R17 no coincide con el recurso corregido.');
if (s012R19Sha !== s012TransparentSha) throw new Error('El S012 RGBA directo R19 no conserva exactamente el alfa corregido.');
if (s012R21Sha !== '29a53dd1a3a6429093f6f526ac00a54ad3f6a0482f9ef9033211ff7da9bf4f33') throw new Error('El S012 R21 no coincide con la limpieza de matte validada.');
if (s020Sha !== '0afd0d11f231b8a6239033fd7552d0155e66c776b1a2fdb5af51194ccce9316e') throw new Error('S020 no coincide con el canónico del catálogo.');

const requiredRuntimeDeclarations = [
  "sourceZipSha256:'9839aed8faf4f3412e9ec7b99fd14a54bfc319ba7014299910c329f3868d0e90'",
  "mechanicsModified:false,geometryChanged:false,collidersChanged:false,physicsChanged:false",
  "referenceOnlyExcluded:['Eren: atlas 4×4 de movimiento.png','Eren cae con pies separados.png','Atlas de animación de Scar.png']",
  "const visualX=bridge.x-.25,visualY=bridge.y-.5",
  "drawWorldArt(ctx,r16WorldArt.bridge,visualX,visualY,4.5,1",
  "drawWorldArt(ctx,r16WorldArt.ladder,ladder.art.x,ladder.art.y,1,3.5",
  "alphaMode:'R21_TRUE_ALPHA_MATTE_REMOVED'",
  "S012-escalera-madera-1x3_5-r21-alpha-real.png",
];
for (const declaration of requiredRuntimeDeclarations) {
  if (!runtimeSource.includes(declaration)) throw new Error(`Falta declaración runtime R16: ${declaration}`);
}

console.log(JSON.stringify({
  result: 'PASS', package: 'ARTE_GB02_R16_ASSETS_FUNCIONALES_R01_CANDIDATE_PLAYTEST',
  pngRgba: pngFiles.length, familyManifests: familyManifests.length, runtimeManifests: manifests.length - familyManifests.length,
  canonical: { S012: s012Sha, S020: s020Sha }, correctionR17: { S012Transparent: s012TransparentSha }, correctionR19: { S012SourceRgbaDirect: s012R19Sha }, correctionR21: { S012TrueAlpha: s012R21Sha },
  nativeMount: { S012: '1x3.5', S020: '4.5x1', bridgeColliderPreserved: '4x0.5' },
  mechanicsModified: false, gameReady: false,
}));
