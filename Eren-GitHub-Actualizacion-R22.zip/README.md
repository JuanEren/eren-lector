# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 45.0.0 · candidata GB02 R04 · revisión R22

R22 parte del R21 validado físicamente el 28/08/2026 en un Samsung SM-S928B con Android 16. Es un pase exclusivamente visual: conserva sin cambios la geometría, colliders, física, cámara R21, controles, actores y contrato GB02 R04. El estado máximo continúa siendo `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`; `gameReady` permanece en `false`.

Incluye:

- límite oeste del comienzo sustituido por una composición única de árbol, raíces y ruinas con alfa real, sin collider;
- doce acentos estáticos colocados manualmente y nueve grupos de flora tenue, sin repetición automática ni decoración bajo la estrella;
- luciérnagas, hojas, lianas y helechos con movimiento ambiental lento;
- destellos de agua, polvo de elevación de rejas, niebla durante el despliegue del puente y chispas de estrella;
- checkpoints funcionales preservados, con sus rombos azules ocultos en la build normal y visibles solo en QA;
- FAR, MID y NEAR independientes, terreno A05 R02, escalera S012 R21, rejas laterales, puente S020 y contactos visuales preservados;
- ciclos funcionales R19 de Eren, Scar, araña y guardián sin cambios;
- HUD R11, controles simultáneos, Laboratorio `QA_ONLY`, tres corazones y meta dual preservados.

La validación automatizada se ejecuta con:

```text
node tests/azure-catalogue-smoke.mjs
node tests/hud-hearts-r11-smoke.mjs
node tests/r16-functional-art-smoke.mjs
node tests/ladder-alpha-r21-smoke.mjs
node tests/r22-decoration-smoke.mjs
node tests/gb02-r04-smoke.mjs
```

Las capturas reproducibles se generan con `node tests/r22-render-evidence.mjs` cuando está disponible `@napi-rs/canvas`.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK R22** y descarga **Eren-GB02-R04-R22-APK-CANDIDATE**. Ejecuta el workflow únicamente en la rama candidata R22; no hagas merge a `main` ni crees una release.

## Siguiente orden de trabajo

1. Validación visual breve de R22 en Android.
2. Personajes y animaciones definitivos con fuentes limpias y sin marcas de agua.
3. Sonido.
4. Cierre del tutorial tras QA final.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
