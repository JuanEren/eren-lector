plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 46
        versionName = "45.0.0-decoration-vfx-gb02-r04-candidate-r22"
    }
}
