# Decoración y VFX · GB02 R04 · R22

R22 parte de la APK R21 validada físicamente el 28/08/2026. No modifica el nivel funcional: el bloque `buildGraybox` conserva exactamente el mismo SHA-256 estructural que R21 (`e7c80acfd88ddff0caf091abfb72af7db6950e4cea6c8986c913f5b350aabd0b`).

## Cambios aplicados

- Se elimina el relleno visual cuadriculado situado a la izquierda de `x=0`.
- Se monta en `x=-8,5 · y=0 · w=8,5 · h=12 M` una composición única de árbol, raíces y ruinas con alfa real. Es fondo visual y no recibe collider.
- Se mantienen los cuatro acentos A05 R02 y se amplía el acabado mediante doce colocaciones manuales y nueve grupos de flora tenue; no existe repetición automática ni decoración bajo la estrella.
- Se añaden luciérnagas, hojas descendentes, lianas y helechos con oscilación lenta.
- Se añaden destellos de agua, polvo de reja, niebla del puente y chispas alrededor de la estrella.
- Los rombos azules de checkpoints quedan ocultos en la build normal. Los checkpoints, respawns y eventos `anclaje` permanecen intactos; el dibujo solo se conserva en modo QA.

## Elementos congelados

Geometría, colliders, hazards, checkpoints, física, cámara R21, controles, HUD, personajes, animaciones, combate, rejas, escalera, puente, estrella, meta y lógica de Scar.

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST` · `gameReady=false`.
