# Cómo subir R20 + R21 + R22 a GitHub

No subas la APK al repositorio. Usa el contenedor `SUBIR_A_GITHUB_R20_R21_R22.zip`, descomprímelo primero y sube solamente sus siete archivos.

## Rama

`codex/gb02-r22-decoration-vfx-20260829`

## Antes de subir

Comprueba que el repositorio ya contiene la cadena BASE + R05 + R07 + R08 + R09 + R10 + R11 + R14 + R15 + R16 + R17 + R18 + R19. R12 y R13 deben permanecer archivados, pero fuera de la cadena aplicada. Si falta cualquiera de esos archivos, no ejecutes el workflow.

## Archivos que se copian a la raíz

- `.github/workflows/build-apk.yml`
- `Eren-GitHub-Actualizacion-R20.zip`
- `Eren-GitHub-Actualizacion-R20.zip.sha256`
- `Eren-GitHub-Actualizacion-R21.zip`
- `Eren-GitHub-Actualizacion-R21.zip.sha256`
- `Eren-GitHub-Actualizacion-R22.zip`
- `Eren-GitHub-Actualizacion-R22.zip.sha256`

## Pasos en github.com

1. Abre el repositorio y cambia a la revisión que ya contiene R19.
2. Crea la rama `codex/gb02-r22-decoration-vfx-20260829`; no trabajes en `main`.
3. Descomprime `SUBIR_A_GITHUB_R20_R21_R22.zip` en tu ordenador.
4. En la rama R22, pulsa **Add file → Upload files**.
5. Arrastra los siete archivos respetando exactamente nombres y ruta del workflow.
6. Usa el mensaje `R20 + R21 + R22: integrar arte, correcciones y decoración ambiental`.
7. Confirma **Commit directly to codex/gb02-r22-decoration-vfx-20260829**.
8. Abre **Actions → Compilar candidata GB02 R04 R22** y ejecuta la rama R22 si no arrancó automáticamente.
9. Cuando termine en verde, descarga `Eren-GB02-R04-R22-APK-CANDIDATE`.

No hagas merge a `main` ni crees una release. `GITHUB_VERIFICADO` solo podrá declararse después de comprobar el commit y el artifact en GitHub.
