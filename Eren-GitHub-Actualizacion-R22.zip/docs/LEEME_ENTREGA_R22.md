# Entrega GB02 R04 · R22

## APK

Archivo: `EREN_GB02_R22_APK_CANDIDATE.apk`

- Tamaño: 30.875.117 bytes
- SHA-256: `db98e4593c7b3412a83fd4f4772e5628464151c2750538852c7c3263cf2b1559`
- Paquete: `com.juaneren.lector`
- VersionCode: `46`
- Firma: debug Android, APK Signature Scheme v2 verificado

## Qué comprobar en el móvil

1. Inicio: árbol/ruina integrado, sin pared de baldosas y sin rombo azul.
2. Recorrido: ningún checkpoint azul visible y respawns conservados al recibir daño.
3. Ambiente: hojas, luciérnagas, lianas y helechos discretos, sin tapar rutas.
4. Rejas y puente: polvo y niebla breves, sin afectar el momento del collider.
5. Estrella y agua: destellos legibles pero secundarios.
6. Recorrido completo hasta la meta dual.

Si la instalación intenta actualizar una APK firmada con otra clave, desinstala la candidata anterior y vuelve a instalar R22. Esto elimina datos locales de prueba, no archivos del proyecto.

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST` · `gameReady=false`.
