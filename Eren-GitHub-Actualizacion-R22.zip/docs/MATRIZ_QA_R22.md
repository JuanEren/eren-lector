# Matriz QA · GB02 R04 · R22

Aplicación: `45.0.0-decoration-vfx-gb02-r04-candidate-r22` (`versionCode 46`)

| Caso | Estado | Evidencia |
| --- | --- | --- |
| Playtest físico R21 en Android | PASS | Samsung SM-S928B; recorrido completo; estrella y meta dual; Scar 0 recuperaciones |
| PNG del límite oeste | PASS | RGBA 850×1200; 100 PPU; SHA-256 registrado |
| Zona izquierda sin mosaico repetido | PASS | `00_INICIO_DECORADO_891x411.png` |
| Checkpoints funcionales sin rombos azules | PASS técnico | Dibujo solo con `debug`; bloque funcional R21 idéntico |
| Decoración manual, sin repetición ni elemento bajo estrella | PASS | 12 acentos + 9 grupos de flora |
| Decoración animada | PASS técnico | luciérnagas, hojas, lianas y helechos |
| Partículas | PASS técnico | agua, rejas, puente y estrella |
| Colliders/física/geometría modificados por R22 | PASS: ninguno | hash estructural R21/R22 idéntico |
| Escalera | PASS | alfa R21 preservado + regresión 20/20 |
| Scar tras primera verja | PASS | 20/20; 0 agua; 0 choque de columna |
| Ruta baja y puente | PASS | 20/20; 0 bypass; despliegue 0,6 s |
| HUD y controles | PASS | HUD R11 y gesto correr+saltar preservados |
| Render 16:9, 19.5:9 y 21:9 | PASS técnico | 10 capturas reproducibles |
| Compilación APK, integridad y firma v2 | PASS | APK debug verificada |
| Playtest visual R22 en Android | PENDING | comprobar movimiento ambiental y ausencia de rombos azules |

El pase no declara `GAME_READY` ni `GITHUB_VERIFICADO`. Cierre: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`.
