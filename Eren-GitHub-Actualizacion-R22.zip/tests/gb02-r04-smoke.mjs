import vm from 'node:vm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('game.css', root), 'utf8');
const styles = await readFile(new URL('styles.css', root), 'utf8');
const appSource = await readFile(new URL('app.js', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');

const PARENT_CONTRACT_SHA = 'dd349b6e4c0eb05855be5b25c49bbc2e0f0047cf53ab71dce9a70ab182dc99a4';
const R15_CONTRACT_SHA = '02692ced658695b7e5ce95d9b1709448835b16427812e8393c61bc67466e6055';
const idleInput = { left: false, right: false, up: false, crouch: false, run: false, jump: false, action: false, scar: false };

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id; this.dataset = {}; this.classList = new ClassList(); this.listeners = new Map();
    this.style = {}; this.textContent = ''; this.innerHTML = ''; this.value = ''; this.offsetWidth = 10;
    this.attributes = new Map(); this.disabled = false; this.width = 0; this.height = 0;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, stopPropagation() {}, pointerId: 1, clientX: 0, clientY: 0, width: 1, height: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  getBoundingClientRect() { return this.rect || { left: 0, top: 0, width: 64, height: 64 }; }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  closest(selector) { return selector === 'button' || selector === `#${this.id}` ? this : null; }
}

function createHarness({ qaOnly, width = 1920, height = 1080 }) {
  const exportedSource = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={
 getSim:()=>sim,
 reset:reason=>resetSimulation(reason),
 step:(input={},dt=FIXED_DT)=>physicsStep(dt,{...${JSON.stringify(idleInput)},...input}),
 buildGraybox,
 rebuildWorld,
 viewportWorldSize,
 currentViewportWorldSize,
 currentInput,
 lowClearanceConstraint,
 scarLowClearanceConstraint,
 canFit,
 bodyRect,
 overlaps,
 supportingSolid,
 ladderBodyOverlapRatio,
 commandScar,
 updateGb02,
 updateCoopGate,
 updateCamera,
 enemyAttackRect,
 erenAttackRect,
 requestErenAttack,
 enforceScarBridgeCommandGate,
 resolveEnemyBodyContact,
 selectLocomotionFrame,
 updateLocomotionClock,
 selectJumpFrame,
 updateJumpVisual,
 actorInGoalZone,
 getQueuedJumpPresses:()=>queuedJumpPresses,
 getTuning:()=>({...tuning}),
 getContract:()=>JSON.parse(JSON.stringify(GB02_CONTRACT)),
 getContact:()=>JSON.parse(JSON.stringify(VISUAL_CONTACT_PLANE)),
 getTestMode:()=>TEST_MODE,
 setScene,
 render
};
})();`);

  const elements = new Map();
  for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
  const get = id => elements.get(id);
  const controlMap = {
    moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
    moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
  };
  for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
  get('run').rect = { left: 680, top: 100, width: 64, height: 64 };
  get('jump').rect = { left: 740, top: 190, width: 64, height: 64 };
  for (const [id, value] of Object.entries({ walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;
  const stations = [...html.matchAll(/data-station="([A-Z])"/g)].map(match => { const element = new Element(); element.dataset.station = match[1]; return element; });
  const body = new Element('body');
  const document = {
    body,
    getElementById: id => get(id),
    querySelectorAll: selector => (selector === '[data-controls]' || selector === '.game-dpad [data-controls]') ? [...elements.values()].filter(element => element.dataset.controls && element.id !== 'run') : selector === '[data-station]' ? stations : [],
    createElement: () => new Element(),
    addEventListener() {},
    elementFromPoint: () => null,
    execCommand: () => true,
  };
  const gradient = { addColorStop() {} };
  const context2d = new Proxy({ createLinearGradient: () => gradient }, {
    get(target, key) { if (key in target) return target[key]; return () => {}; },
    set(target, key, value) { target[key] = value; return true; },
  });
  get('gameCanvas').getContext = () => context2d;
  get('gameCanvas').getBoundingClientRect = () => ({ width, height });
  const storage = new Map();
  const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
  const listeners = new Map();
  const window = {
    document, devicePixelRatio: 1, innerWidth: width, innerHeight: height, __EREN_QA_ONLY__: qaOnly,
    addEventListener(type, callback) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(callback); },
    dispatchEvent(event) { for (const callback of listeners.get(event.type) || []) callback(event); },
    requestAnimationFrame() { return 1; }, cancelAnimationFrame() {},
  };
  class Image {
    constructor() { this.complete = false; this.naturalWidth = 0; this.naturalHeight = 0; this.decoding = ''; this._src = ''; }
    set src(value) { this._src = value; }
    get src() { return this._src; }
  }
  const sandbox = {
    window, document, navigator: { getGamepads: () => [], userAgent: 'GB02-QA' }, localStorage,
    requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
    setTimeout: callback => { callback(); return 1; }, clearTimeout() {}, console, Image,
    completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
    tone() {}, playAzureSequence() {}, renderMenu() {},
  };
  window.localStorage = localStorage;
  vm.createContext(sandbox);
  vm.runInContext(exportedSource, sandbox, { filename: 'graybox-game.js' });
  return { window, get, stations, body };
}


const stepFrames = (api, frames, input = {}) => { for (let frame = 0; frame < frames; frame++) api.step(input); };
const openGb02 = (api, sim) => {
  Object.assign(sim, {
    coopUnlocked: true, enemyHp: 0, enemyState: 'defeated', enemyDefeated: true,
    keyState: 'collected', gateUnlockState: 'open', gateLiftProgress: 1,
    barrierOpen: true, ladderEnabled: true, scarReleased: true,
  });
  api.rebuildWorld();
};

const normalR15 = createHarness({ qaOnly: false });
if (normalR15.window.__grayboxTest.getTestMode() !== false) throw new Error('La build normal quedó en modo QA.');
if (!normalR15.get('playLab').classList.contains('hidden') || !normalR15.get('playLab').disabled || normalR15.get('playLab').getAttribute('aria-hidden') !== 'true') throw new Error('Laboratorio QA_ONLY visible o activable en build normal.');
normalR15.get('playLab').click();
if (normalR15.get('playLab').classList.contains('active')) throw new Error('La build normal permitió entrar al Laboratorio QA_ONLY.');
normalR15.get('directGame').click();
if (!normalR15.window.__grayboxTest.getSim()) throw new Error('El acceso directo al juego sigue dependiendo de completar un cuento.');

const qaR15 = createHarness({ qaOnly: true });
const apiR15 = qaR15.window.__grayboxTest;
qaR15.get('directGame').click();
if (!apiR15.getSim()) throw new Error('No se inició la simulación QA de GB02 R04.');
const initialSimR17 = apiR15.getSim();
if (initialSimR17.camera.x >= 0 || Math.abs((initialSimR17.eren.x - initialSimR17.camera.x) - initialSimR17.camera.viewW / 2) > .001 || initialSimR17.scar.x <= initialSimR17.camera.x) throw new Error('El encuadre inicial no mantiene visibles y fuera de la cruceta a Eren y Scar.');

qaR15.get('run').dispatch('pointerdown', { pointerId: 10, clientX: 680, clientY: 100 });
let touchInput = apiR15.currentInput();
if (touchInput.run || touchInput.jump) throw new Error('Una esquina transparente fuera del círculo activó un botón de acción.');
qaR15.get('run').dispatch('pointerdown', { pointerId: 11, clientX: 712, clientY: 132 });
qaR15.get('jump').dispatch('pointerdown', { pointerId: 12, clientX: 772, clientY: 222 });
touchInput = apiR15.currentInput();
if (!touchInput.run || !touchInput.jump) throw new Error('Dos contactos independientes no mantienen CORRER + SALTAR.');
qaR15.get('run').dispatch('pointerup', { pointerId: 11 });
touchInput = apiR15.currentInput();
if (touchInput.run || !touchInput.jump) throw new Error('Soltar CORRER canceló indebidamente el contacto independiente de SALTAR.');
qaR15.get('jump').dispatch('pointerup', { pointerId: 12 });
qaR15.get('run').dispatch('pointerdown', { pointerId: 14, clientX: 712, clientY: 132 });
qaR15.get('run').dispatch('pointermove', { pointerId: 14, clientX: 772, clientY: 222 });
touchInput = apiR15.currentInput();
if (!touchInput.run || !touchInput.jump) throw new Error('El deslizamiento de un único pulgar desde CORRER hasta SALTAR no conserva el acorde.');
qaR15.get('run').dispatch('pointerup', { pointerId: 14 });
qaR15.get('run').dispatch('pointerdown', { pointerId: 13, clientX: 712, clientY: 132, width: 150, height: 150 });
touchInput = apiR15.currentInput();
if (!touchInput.run || !touchInput.jump) throw new Error('La huella amplia de un pulgar no activa el acorde Mario CORRER + SALTAR.');
qaR15.get('run').dispatch('pointerup', { pointerId: 13 });
touchInput = apiR15.currentInput();
if (touchInput.run || touchInput.jump) throw new Error('Soltar el pulgar dejó bloqueado el acorde CORRER + SALTAR.');
apiR15.reset('qa_repetir_salto_manteniendo_correr_r19');
const repeatedTouchSim = apiR15.getSim();
qaR15.get('run').dispatch('pointerdown', { pointerId: 20, clientX: 712, clientY: 132 });
qaR15.get('jump').dispatch('pointerdown', { pointerId: 21, clientX: 772, clientY: 222 });
apiR15.step(apiR15.currentInput());
qaR15.get('jump').dispatch('pointerup', { pointerId: 21 });
for (let frame = 0; frame < 180 && (!repeatedTouchSim.eren.onGround || repeatedTouchSim.events.filter(event => event.type === 'salto').length < 1); frame++) apiR15.step(apiR15.currentInput());
if (!apiR15.currentInput().run || repeatedTouchSim.events.filter(event => event.type === 'salto').length !== 1) throw new Error('El primer salto no conservó CORRER mantenido.');
qaR15.get('jump').dispatch('pointerdown', { pointerId: 22, clientX: 772, clientY: 222 });
apiR15.step(apiR15.currentInput());
qaR15.get('jump').dispatch('pointerup', { pointerId: 22 });
if (!apiR15.currentInput().run || repeatedTouchSim.events.filter(event => event.type === 'salto').length !== 2) throw new Error('El segundo flanco de SALTAR se perdió mientras CORRER seguía mantenido.');
qaR15.get('run').dispatch('pointerup', { pointerId: 20 });
apiR15.reset('qa_repetir_salto_un_pulgar_r19');
const thumbTouchSim = apiR15.getSim();
qaR15.get('run').dispatch('pointerdown', { pointerId: 23, clientX: 712, clientY: 132, width: 150, height: 150 });
apiR15.step(apiR15.currentInput());
qaR15.get('run').dispatch('pointermove', { pointerId: 23, clientX: 712, clientY: 132, width: 1, height: 1 });
for (let frame = 0; frame < 180 && !thumbTouchSim.eren.onGround; frame++) apiR15.step(apiR15.currentInput());
qaR15.get('run').dispatch('pointermove', { pointerId: 23, clientX: 712, clientY: 132, width: 150, height: 150 });
apiR15.step(apiR15.currentInput());
if (!apiR15.currentInput().run || thumbTouchSim.events.filter(event => event.type === 'salto').length !== 2) throw new Error('El gesto repetido de un solo pulgar perdió SALTAR sin soltar CORRER.');
qaR15.get('run').dispatch('pointerup', { pointerId: 23 });
if (qaR15.get('playLab').classList.contains('hidden') || qaR15.get('playLab').disabled || qaR15.get('playLab').getAttribute('aria-hidden') !== 'false') throw new Error('La build QA no habilitó el Laboratorio QA_ONLY.');
if (qaR15.stations.map(item => item.dataset.station).join('') !== 'ABCDE') throw new Error('El laboratorio no contiene exactamente las estaciones A–E.');

const contractR15 = apiR15.getContract();
if (contractR15.id !== 'GB02_R04_PLAYTEST_CORRECTION' || contractR15.sha256 !== R15_CONTRACT_SHA || contractR15.parentId !== 'GB02_R03_APPROVED' || contractR15.parentSha256 !== PARENT_CONTRACT_SHA || contractR15.baseline !== 'R14_ANDROID_PASS_WITH_CONDITIONS' || contractR15.functionalBaseline !== 'R11') throw new Error('Identidad o cadena contractual R15 incorrecta.');
if (contractR15.preservedNotApplied.join(',') !== 'R12,R13' || contractR15.frozenContactRevision !== 'R10' || !contractR15.scarRoute.requiredLowPass || !contractR15.scarRoute.bridgeRequiresCommand) throw new Error('R15 no preserva exclusiones, contacto o ruta contractual.');
if (!sourceText.includes("APP_VERSION='45.0.0-decoration-vfx-gb02-r04-candidate-r22'") || !sourceText.includes("LOG_VERSION='GB02-R04-PLAYTEST-R22-v1'") || !gradle.includes('versionCode = 46') || !gradle.includes('versionName = "45.0.0-decoration-vfx-gb02-r04-candidate-r22"')) throw new Error('Versionado R22 desalineado.');

const tuningR15 = apiR15.getTuning();
const contactR15 = apiR15.getContact();
if (tuningR15.walk !== 3.5 || tuningR15.run !== 6 || tuningR15.jump !== 15.9 || tuningR15.gravityUp !== 36 || tuningR15.gravityDown !== 44) throw new Error('La locomoción, salto o física congelada R10 cambió.');
if (contactR15.actorInsetPx !== 10 || contactR15.propInsetPx !== 6 || contactR15.collidersChanged !== false || contactR15.physicsChanged !== false) throw new Error('El contacto visual R10 cambió.');

const worldR15 = apiR15.getSim().world;
const solidsR15 = {
  G4: [36.5, 0, 9, 2], U4: [42.5, 4.5, 3, .5], G5: [45.5, 0, 6, 2],
  TUNEL_BAJO_SCAR: [45.5, 2.75, 4, .5], G6: [55.5, 0, 9, 2],
};
for (const [id, expected] of Object.entries(solidsR15)) {
  const solid = worldR15.solids.find(item => item.id === id);
  if (!solid || [solid.x, solid.y, solid.w, solid.h].some((value, index) => value !== expected[index])) throw new Error(`Geometría R15 incorrecta: ${id}.`);
}
if (worldR15.ladder.art.x !== 43.5 || worldR15.ladder.art.y !== 1.5 || worldR15.ladder.art.w !== 1 || worldR15.ladder.art.h !== 3.5 || worldR15.ladder.topExit.x !== 43.5 || worldR15.bridgePlate.x !== 49.5 || worldR15.goalZone.x !== 62.5 || worldR15.goalZone.w !== 2) throw new Error('Escalera R21, placa o meta desalineadas.');
const initialGate = worldR15.solids.find(item => item.id === 'REJA_COOP_MOVIL');
const initialColumn = worldR15.solids.find(item => item.id === 'COLUMNA_REJA_COOP');
const guardianDoorCollider = worldR15.solids.find(item => item.id === 'REJA_GB02_MOVIL');
const guardianColumn = worldR15.solids.find(item => item.id === 'COLUMNA_REJA_GB02');
const u0Extension = worldR15.solids.find(item => item.id === 'U0_VERTICAL_EXTENSION');
if (!u0Extension || [u0Extension.x, u0Extension.y, u0Extension.w, u0Extension.h].join(',') !== '6.5,7.5,1,4.5') throw new Error('Falta la prolongación sólida de U0 hasta y=12.');
if (!initialGate || [initialGate.x, initialGate.y, initialGate.w, initialGate.h].join(',') !== '24,2,0.5,2.5' || !initialColumn || [initialColumn.x, initialColumn.y, initialColumn.w, initialColumn.h].join(',') !== '23.75,4.5,1,7.5') throw new Error('La primera reja lateral o su columna receptora no tienen geometría R20.');
if (!guardianDoorCollider || [guardianDoorCollider.x, guardianDoorCollider.y, guardianDoorCollider.w, guardianDoorCollider.h].join(',') !== '42.75,2,0.5,2.5' || !guardianColumn || [guardianColumn.x, guardianColumn.y, guardianColumn.w, guardianColumn.h].join(',') !== '42.5,5,1,7') throw new Error('La segunda reja lateral o su columna receptora no tienen geometría R20.');
const westBoundary = worldR15.solids.find(item => item.id === 'LIMITE_OESTE');
if (!westBoundary || westBoundary.x !== -.5 || westBoundary.w !== .5 || westBoundary.kind !== 'boundary') throw new Error('Falta la barrera oeste infranqueable compartida por Eren y Scar.');
if (!worldR15.lowClearanceVolumes.some(volume => volume.id === 'LOW_SCAR_BRIDGE' && volume.tag === 'SCAR_ONLY_LOW_CLEARANCE' && volume.h === .75)) throw new Error('Falta el paso bajo exclusivo de Scar.');
if (!sourceText.includes('drawA05Ground') || !sourceText.includes('drawA05Platform') || !sourceText.includes('drawA05Column') || !sourceText.includes('drawA05MovingGates') || !sourceText.includes("if(!['ground','upper','roof'].includes(solid.kind))return false") || !sourceText.includes("drawNativeCrop(ctx,a05Art.tiles.ruinPlatformLeft,50,0,100,50,solid.x,solid.y,draw)") || !sourceText.includes("drawNativeCrop(ctx,a05Art.tiles.ruinPlatformCenter,50,0,100,50,solid.x+1,solid.y,draw)") || !sourceText.includes("drawNativeCrop(ctx,a05Art.tiles.ruinPlatformRight,50,0,100,50,solid.x+2,solid.y,draw)")) throw new Error('El montaje modular A05 R02 o la continuidad nativa de U4 no están conectados al runtime.');

for (const [width, height, expectedW] of [[1200, 900, 19.2], [1920, 1080, 19.2], [2520, 1080, 25.2], [3840, 1080, 38.4]]) {
  const view = apiR15.viewportWorldSize(width, height);
  if (Math.abs(view.w - expectedW) > 1e-9 || view.h !== 10.8) throw new Error(`Viewport incorrecto para ${width}:${height}.`);
}
if (!sourceText.includes('scale=bounds.width/viewport.w') || !sourceText.includes('const draw={scale,ox:0') || sourceText.includes('bounds.width-VIEW.w*scale')) throw new Error('El render no ocupa todo el ancho con escala uniforme.');

apiR15.reset('qa_limite_oeste_dual_r19');
const westSim = apiR15.getSim();
Object.assign(westSim.eren, { x: .55, y: 2, vx: -6, vy: 0, onGround: true });
Object.assign(westSim.scar, { x: .8, y: 2, vx: -6, vy: 0, onGround: true, mode: 'wait', waitX: -10, recoverTimer: 0 });
stepFrames(apiR15, 60, { left: true, run: true });
if (westSim.eren.x < .5 - 1e-6 || westSim.scar.x < .75 - 1e-6 || westSim.events.some(event => event.type === 'scar_recuperacion')) throw new Error('Eren o Scar todavía atraviesan o mueren por el límite inicial.');

apiR15.reset('qa_caja_dos_golpes_r19');
let boxSimR17 = apiR15.getSim();
Object.assign(boxSimR17.eren, { x: 6, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
apiR15.step({ action: true }); stepFrames(apiR15, 8);
if (boxSimR17.boxHp !== 1 || boxSimR17.boxBroken || boxSimR17.boxBreakState !== 'damaged' || !boxSimR17.world.solids.some(item => item.id === 'CAJA_ROMPIBLE') || boxSimR17.events.filter(event => event.type === 'caja_danada').length !== 1 || !boxSimR17.events.some(event => event.type === 'eren_golpe_inicio' && event.target === 'dynamic')) throw new Error('El primer golpe universal no mostró el puño ni dejó la caja O024 dañada y sólida.');
stepFrames(apiR15, 14); apiR15.step({ action: true }); stepFrames(apiR15, 8);
if (boxSimR17.boxHp !== 0 || !boxSimR17.boxBroken || boxSimR17.boxBreakState !== 'transition' || boxSimR17.world.solids.some(item => item.id === 'CAJA_ROMPIBLE') || boxSimR17.events.filter(event => event.type === 'caja_rotura_transicion').length !== 1) throw new Error('El segundo golpe no inició O025 antes de los restos.');
stepFrames(apiR15, 22);
if (boxSimR17.boxBreakState !== 'remains' || boxSimR17.events.filter(event => event.type === 'caja_restos').length !== 1) throw new Error('La caja no completó O025 → O026 con restos sin collider.');
if (sourceText.includes('ctx.rotate(progress*1.12)') || sourceText.includes('ctx.rotate(angle+progress*2)')) throw new Error('La transición O025 todavía gira la caja o sus restos.');

apiR15.reset('qa_golpe_universal_r19');
let universalAttackSim = apiR15.getSim();
Object.assign(universalAttackSim.eren, { x: 10, y: 4, vx: 0, vy: -1, onGround: false, crouched: false, w: 1, h: 1.5, facing: 1 });
apiR15.step({ action: true });
if (!universalAttackSim.erenAttackState || !universalAttackSim.events.some(event => event.type === 'eren_golpe_inicio' && event.airborne && !event.crouched) || apiR15.erenAttackRect().w <= 0) throw new Error('ACCIÓN no crea puño e hitbox en el aire.');
apiR15.step({}); apiR15.step({ action: true });
if (universalAttackSim.erenAttackQueued !== 1 || !universalAttackSim.events.some(event => event.type === 'eren_golpe_encolado')) throw new Error('Una pulsación durante otro golpe no queda en cola.');

apiR15.reset('qa_golpe_agachado_r19'); universalAttackSim = apiR15.getSim();
Object.assign(universalAttackSim.eren, { x: 5.7, y: 2, vx: 0, vy: 0, onGround: true, crouched: true, w: 1.5, h: 1, facing: 1 });
apiR15.step({ action: true }); stepFrames(apiR15, 8);
if (universalAttackSim.boxHp !== 1 || !universalAttackSim.eren.crouched || universalAttackSim.eren.h !== 1 || !universalAttackSim.events.some(event => event.type === 'eren_golpe_inicio' && event.crouched && event.variant === 'crouched')) throw new Error('El golpe bajo no conserva postura/collider o no aplica su hitbox a la caja.');

apiR15.reset('qa_golpe_escalera_bloqueado_r20'); universalAttackSim = apiR15.getSim(); openGb02(apiR15, universalAttackSim);
Object.assign(universalAttackSim.eren, { x: 44, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
apiR15.step({ up: true }); apiR15.step({ up: true, action: true });
if (!universalAttackSim.ladderState || universalAttackSim.erenAttackState || !universalAttackSim.events.some(event => event.type === 'accion_bloqueada_escalera')) throw new Error('ACCIÓN no queda deshabilitada durante la trepa.');

apiR15.reset('qa_posturas_r15');
let simR15 = apiR15.getSim();
Object.assign(simR15.eren, { x: 4.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
apiR15.step({ crouch: true });
if (!simR15.eren.crouched || simR15.eren.w !== 1.5 || simR15.eren.h !== 1 || !simR15.events.some(event => event.type === 'agacharse' && event.reason === 'USER_DOWN')) throw new Error('ABAJO no activó la postura voluntaria de Eren.');
apiR15.step({});
if (simR15.eren.crouched || simR15.eren.w !== 1 || simR15.eren.h !== 1.5) throw new Error('Eren no volvió a ponerse de pie al soltar ABAJO en una zona libre.');
simR15.boxBroken = true; apiR15.rebuildWorld();
Object.assign(simR15.eren, { x: 5.55, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5 });
apiR15.step({ right: true, crouch: true });
if (!simR15.eren.crouched || simR15.eren.w !== 1.5 || simR15.eren.h !== 1 || simR15.eren.visualState !== 'bajo') throw new Error('La restricción real heredada no activa el estado bajo de Eren.');
openGb02(apiR15, simR15);
const tunnelProbe = { x: 47, y: 2, w: 1, h: 1.5 };
if (apiR15.canFit(tunnelProbe, 1, 1.5, simR15.world.solids) || apiR15.canFit(tunnelProbe, 1.5, 1, simR15.world.solids) || !apiR15.canFit(tunnelProbe, 1.5, .65, simR15.world.solids)) throw new Error('La luz de 0,75 m no discrimina Eren de pie/agachado y Scar bajo.');

apiR15.reset('qa_pilar_coop_retractil_r19'); simR15 = apiR15.getSim();
simR15.scarPlateLatched = true;
Object.assign(simR15.eren, { x: 22, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
apiR15.step({ action: true });
if (simR15.coopGateState !== 'opening' || simR15.coopUnlocked || !simR15.world.solids.some(item => item.id === 'REJA_COOP_MOVIL')) throw new Error('El puzle inicial no inicia la elevación visible de la reja lateral.');
stepFrames(apiR15, 18);
if (!simR15.world.solids.some(item => item.id === 'REJA_COOP_MOVIL') || simR15.coopGateProgress <= 0 || simR15.coopGateProgress >= 1) throw new Error('El collider de la primera reja se desactiva antes de liberar por completo el paso.');
stepFrames(apiR15, 22);
if (!simR15.coopUnlocked || simR15.coopGateState !== 'open' || simR15.coopGateProgress !== 1 || simR15.world.solids.some(item => item.id === 'REJA_COOP_MOVIL') || !simR15.world.solids.some(item => item.id === 'COLUMNA_REJA_COOP')) throw new Error('La reja inicial no libera el paso conservando sólida la columna receptora.');
if (!simR15.events.some(event => event.type === 'puerta_coop_abierta' && event.grateRetracted && event.fixedColumnCollision && event.bottomEdgeCleared)) throw new Error('La apertura completa de la primera reja no queda trazada.');

const scarFirstGateRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  apiR15.reset(`qa_scar_salida_primera_reja_r21_${repetition}`);
  const run = apiR15.getSim();
  run.coopUnlocked = true; run.coopGateState = 'open'; run.coopGateProgress = 1; apiR15.rebuildWorld();
  Object.assign(run.eren, { x: 29.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 20.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', waitX: null, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1 });
  for (let frame = 0; frame < 360 && !run.events.some(event => event.type === 'scar_salto_largo_exito'); frame++) apiR15.step({});
  const start = run.events.find(event => event.type === 'scar_salto_largo_inicio');
  const success = run.events.find(event => event.type === 'scar_salto_largo_exito');
  const recoveries = run.events.filter(event => event.type === 'scar_recuperacion');
  if (!start || start.x < 24.35 || !success || recoveries.length || apiR15.supportingSolid(run.scar, run.world.solids)?.id !== 'G3') throw new Error(`Scar choca con la columna o cae al agua tras la primera reja en repetición ${repetition}: ${JSON.stringify({start,success,recoveries,scar:{x:run.scar.x,y:run.scar.y,vx:run.scar.vx,vy:run.scar.vy,onGround:run.scar.onGround,support:apiR15.supportingSolid(run.scar,run.world.solids)?.id},last:run.events.slice(-12)})}`);
  scarFirstGateRuns.push({ repetition, takeoffX: start.x, landingX: success.x, recoveries: 0, result: 'PASS' });
}

const ladderRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  apiR15.reset(`qa_escalera_r15_${repetition}`);
  const run = apiR15.getSim(); openGb02(apiR15, run);
  Object.assign(run.eren, { x: 44, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 38, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 38, recoverTimer: 0 });
  stepFrames(apiR15, 100, { up: true });
  const exits = run.events.filter(event => event.type === 'escalera_salida_superior_completa');
  const support = apiR15.supportingSolid(run.eren, run.world.solids);
  if (exits.length !== 1 || run.ladderState !== null || Math.abs(run.eren.x - 44) > .001 || Math.abs(run.eren.y - 5) > .001 || support?.id !== 'U4' || run.eren.ignoredSupportId !== null || run.events.some(event => event.type === 'escalera_suelta')) throw new Error(`Salida de escalera falló en repetición ${repetition}.`);
  ladderRuns.push({ repetition, exits: exits.length, x: run.eren.x, y: run.eren.y, support: support.id, ignoredSupportRestored: true });
}

apiR15.reset('qa_escalera_solape_y_diagonal_r17');
let ladderProbeR17 = apiR15.getSim(); openGb02(apiR15, ladderProbeR17);
Object.assign(ladderProbeR17.eren, { x: 43.4, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, recover: 0, invuln: 0 });
apiR15.step({ up: true });
if (ladderProbeR17.ladderState !== null || ladderProbeR17.events.some(event => event.type === 'escalera_agarre_inicio')) throw new Error('La escalera se agarró con menos del 50 % del cuerpo solapado.');
apiR15.step({});Object.assign(ladderProbeR17.eren, { x: 44, y: 2, vx: 0, vy: 0, onGround: true });
apiR15.step({ up: true, right: true });
if (ladderProbeR17.ladderState !== null) throw new Error('Una diagonal inició la escalera.');
apiR15.step({});apiR15.step({ up: true });stepFrames(apiR15, 20, { up: true, right: true });
if (!ladderProbeR17.ladderState || ladderProbeR17.events.some(event => event.type === 'escalera_suelta')) throw new Error('La diagonal durante la trepa provocó suelta o bucle de reagarre.');

apiR15.reset('qa_escalera_bajada_superior_r17');
ladderProbeR17 = apiR15.getSim(); openGb02(apiR15, ladderProbeR17);
Object.assign(ladderProbeR17.eren, { x: 44, y: 5, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, recover: 0, invuln: 0 });
apiR15.step({ crouch: true });stepFrames(apiR15, 90, { crouch: true });
if (ladderProbeR17.ladderState !== null || Math.abs(ladderProbeR17.eren.y - 2) > .001 || ladderProbeR17.events.filter(event => event.type === 'escalera_entrada_superior_inicio').length !== 1 || ladderProbeR17.events.filter(event => event.type === 'escalera_salida_inferior').length !== 1 || ladderProbeR17.events.some(event => event.type === 'escalera_suelta')) throw new Error('ABAJO desde U4 no completó una única bajada estable.');

apiR15.reset('qa_guardian_impacto'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'windup', enemyStateElapsed: 0, enemyX: 40.5, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 39.3, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
stepFrames(apiR15, 70);
if (simR15.eren.hearts !== 2 || !simR15.events.some(event => event.type === 'enemigo_ataque_inicio') || !simR15.events.some(event => event.type === 'enemigo_impacta_eren')) throw new Error('El guardián no ejecutó una ofensiva con daño.');

apiR15.reset('qa_guardian_esquiva'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'windup', enemyStateElapsed: 0, enemyX: 40.5, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 39.3, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
stepFrames(apiR15, 35, { jump: true, left: true }); stepFrames(apiR15, 35, { left: true });
if (simR15.eren.hearts !== 3 || !simR15.events.some(event => event.type === 'enemigo_ataque_esquivado') || simR15.events.some(event => event.type === 'enemigo_impacta_eren')) throw new Error(`El salto no esquivó la ventana baja del guardián: ${JSON.stringify({hearts:simR15.eren.hearts,y:simR15.eren.y,state:simR15.enemyState,events:simR15.events.filter(event=>event.type.startsWith('enemigo_')||event.type==='salto')})}`);

apiR15.reset('qa_guardian_contacto_superior_r19'); simR15 = apiR15.getSim();
Object.assign(simR15, { enemyState: 'patrol', enemyX: 40, enemyDefeated: false });
Object.assign(simR15.eren, { x: 40, y: 3.5, vx: 0, vy: -2, onGround: false, hearts: 3, recover: 0, invuln: 0 });
if (!apiR15.resolveEnemyBodyContact() || simR15.eren.hearts !== 2 || simR15.eren.onGround || simR15.eren.vy <= 0 || !simR15.events.some(event => event.type === 'enemigo_contacto_superior')) throw new Error('Caer sobre la araña todavía permite atravesarla o usarla como plataforma.');

apiR15.reset('qa_guardian_contacto_cuerpo_r19'); simR15 = apiR15.getSim();
Object.assign(simR15, { enemyState: 'patrol', enemyX: 40, enemyDefeated: false });
Object.assign(simR15.eren, { x: 39.35, y: 2, vx: 4, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0 });
if (!apiR15.resolveEnemyBodyContact() || simR15.eren.x > 39.001 || simR15.eren.hearts !== 2 || !simR15.events.some(event => event.type === 'enemigo_contacto_cuerpo')) throw new Error('El cuerpo de la araña todavía se puede atravesar lateralmente.');

apiR15.reset('qa_scar_reaccion_combate_r19'); simR15 = apiR15.getSim();
Object.assign(simR15, { coopUnlocked: true, enemyState: 'chase', enemyX: 40, enemyDefeated: false }); apiR15.rebuildWorld();
Object.assign(simR15.eren, { x: 39, y: 2, vx: 0, vy: 0, onGround: true, recover: 0, invuln: 0 });
Object.assign(simR15.scar, { x: 36.5, y: 2, vx: 3, vy: 0, onGround: true, mode: 'follow', waitX: null, recoverTimer: 0 });
stepFrames(apiR15, 12);
if (!simR15.scar.combatHold || simR15.scar.mode !== 'combat_wait' || simR15.scar.signalState !== 'danger' || Math.abs(simR15.scar.vx) > .01 || simR15.events.filter(event => event.type === 'scar_alerta_combate').length !== 1) throw new Error(`Scar no se queda quieta y erizada durante el combate: ${JSON.stringify({scar:simR15.scar,enemyState:simR15.enemyState,events:simR15.events.slice(-10)})}`);
simR15.eren.x = 34.5; apiR15.step({});
if (simR15.scar.combatHold || !simR15.events.some(event => event.type === 'scar_fin_alerta_combate')) throw new Error('Scar no reanuda su estado al alejarse Eren del enemigo.');

apiR15.reset('qa_guardian_derrota'); simR15 = apiR15.getSim();
simR15.coopUnlocked = true; apiR15.rebuildWorld();
Object.assign(simR15, { enemyState: 'recover', enemyStateElapsed: 0, enemyX: 40.2, enemyFacing: -1, enemyAttackFacing: -1 });
Object.assign(simR15.eren, { x: 38.9, y: 2, vx: 0, vy: 0, onGround: true, hearts: 3, recover: 0, invuln: 0, facing: 1 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, mode: 'wait', waitX: 36.8 });
apiR15.step({ action: true }); stepFrames(apiR15, 22);
Object.assign(simR15.eren, { x: simR15.enemyX - 1.25, y: 2, vx: 0, vy: 0, onGround: true, recover: 0, invuln: 0, facing: 1 });
apiR15.step({ action: true }); stepFrames(apiR15, 22);
if (!simR15.enemyDefeated || simR15.enemyHp !== 0 || simR15.keyState !== 'dropped' || simR15.barrierOpen || simR15.ladderEnabled || simR15.scarReleased || !simR15.world.solids.some(item => item.id === 'REJA_GB02_MOVIL')) throw new Error(`La derrota no dejó una llave pendiente sin abrir mágicamente la barrera: ${JSON.stringify({enemyDefeated:simR15.enemyDefeated,enemyHp:simR15.enemyHp,keyState:simR15.keyState,barrierOpen:simR15.barrierOpen,ladderEnabled:simR15.ladderEnabled,scarReleased:simR15.scarReleased,events:simR15.events.slice(-20)})}`);
Object.assign(simR15.eren, { x: simR15.keyX, y: 2, vx: 0, vy: 0, onGround: true, recover: 0, invuln: 0 });
stepFrames(apiR15, 80);
if (simR15.keyState !== 'collected' || simR15.gateUnlockState !== 'ready' || simR15.gateLiftProgress !== 0 || simR15.barrierOpen || simR15.ladderEnabled || simR15.scarReleased || !simR15.world.solids.some(item => item.id === 'REJA_GB02_MOVIL') || !simR15.events.some(event => event.type === 'puerta_llave_habilitada' && event.requiresAction)) throw new Error('Recoger la llave debe habilitar, pero no abrir, la segunda reja.');
Object.assign(simR15.eren, { x: 42, y: 2, vx: 0, vy: 0, onGround: true, recover: 0, invuln: 0, facing: 1 });
apiR15.step({ action: true });
if (simR15.gateUnlockState !== 'opening' || !simR15.events.some(event => event.type === 'puerta_llave_apertura_inicio' && event.requiresAction)) throw new Error('ACCIÓN junto a la segunda reja no inicia su elevación.');
stepFrames(apiR15, 20);
if (!simR15.world.solids.some(item => item.id === 'REJA_GB02_MOVIL') || simR15.gateLiftProgress <= 0 || simR15.gateLiftProgress >= 1) throw new Error('El collider de la segunda reja se desactiva antes de liberar por completo el paso.');
stepFrames(apiR15, 25);
if (simR15.gateUnlockState !== 'open' || simR15.gateLiftProgress !== 1 || !simR15.barrierOpen || !simR15.ladderEnabled || !simR15.scarReleased || simR15.world.solids.some(item => item.id === 'REJA_GB02_MOVIL') || !simR15.world.solids.some(item => item.id === 'COLUMNA_REJA_GB02')) throw new Error('La segunda reja no completó la elevación manteniendo sólida su columna.');
const atomicR15 = ['puerta_llave_abierta', 'barrera_gb02_retirada', 'escalera_gb02_habilitada', 'scar_gb02_liberado'].map(type => simR15.events.find(event => event.type === type));
if (atomicR15.some(event => !event) || new Set(atomicR15.map(event => event.time)).size !== 1 || new Set(atomicR15.map(event => event.atomicTime)).size !== 1) throw new Error('Las consecuencias de la llave no fueron atómicas al terminar de subir la puerta.');

apiR15.reset('qa_scar_no_cruza_puente_sin_orden_r19'); simR15 = apiR15.getSim(); openGb02(apiR15, simR15);
Object.assign(simR15.eren, { x: 50, y: 3.25, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
Object.assign(simR15.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', waitX: null, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1 });
stepFrames(apiR15, 600);
const noCommandEvents = simR15.events.filter(event => event.type === 'scar_paso_bajo_inicio' || event.type === 'scar_recuperacion' || event.type.startsWith('scar_salto'));
if (simR15.bridgeCommanded || simR15.bridgeState !== 'stowed' || simR15.scar.x > 44.08 + 1e-6 || simR15.scar.crouched || noCommandEvents.length || !simR15.events.some(event => event.type === 'scar_puente_espera_segura')) throw new Error(`Scar todavía atraviesa el túnel o el agua antes de recibir la orden: ${JSON.stringify({x:simR15.scar.x,crouched:simR15.scar.crouched,bridge:simR15.bridgeState,events:simR15.events.slice(-20)})}`);

const scarRouteRuns = [];
for (let repetition = 1; repetition <= 20; repetition++) {
  apiR15.reset(`qa_scar_paso_bajo_r15_${repetition}`);
  const run = apiR15.getSim(); openGb02(apiR15, run);
  Object.assign(run.eren, { x: 44, y: 5, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  Object.assign(run.scar, { x: 50.25, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'wait', waitX: 50.25, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0 });
  apiR15.updateGb02(1 / 60);
  if (run.bridgePlateLatched || run.bridgeState !== 'stowed' || run.bridgeCommanded || !run.events.some(event => event.type === 'placa_puente_sin_orden_bloqueada')) throw new Error(`La placa se enclavó sin orden en repetición ${repetition}: ${JSON.stringify({latched:run.bridgePlateLatched,state:run.bridgeState,commanded:run.bridgeCommanded,scar:{x:run.scar.x,y:run.scar.y,mode:run.scar.mode,support:apiR15.supportingSolid(run.scar,run.world.solids)?.id},events:run.events.slice(-5)})}`);
  Object.assign(run.scar, { x: 36.8, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', waitX: null, bridgeWait: false, recoverTimer: 0, recoveryGrace: 0, traversal: null, gapJumpActive: false, gapJumpCooldown: 0, ignoredSupportId: null, facing: 1 });
  const routeStart = run.events.length;
  apiR15.step({ scar: true }); apiR15.step({});
  for (let frame = 0; frame < 600 && run.bridgeState !== 'solid'; frame++) apiR15.step({});
  if (run.bridgeState !== 'solid' || !run.bridgePlateLatched || run.bridgeCommandCount !== 1 || !run.world.solids.some(item => item.id === 'PUENTE_1')) throw new Error(`Orden, placa o puente falló en repetición ${repetition}.`);
  const deploymentStart = run.events.find(event => event.type === 'puente_despliegue_inicio');
  const deploymentEnd = run.events.find(event => event.type === 'puente_solido');
  if (!deploymentStart || !deploymentEnd || Math.abs((deploymentEnd.time - deploymentStart.time) - .6) > .001 || deploymentStart.collider !== false || deploymentEnd.collider !== true) throw new Error(`El despliegue del puente no duró exactamente 0,6 s sin collider en repetición ${repetition}.`);
  Object.assign(run.eren, { x: 63.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1, recover: 0, invuln: 0 });
  for (let frame = 0; frame < 720 && !run.complete; frame++) apiR15.step({});
  const routeEvents = run.events.slice(routeStart);
  const lowStarts = routeEvents.filter(event => event.type === 'scar_paso_bajo_inicio');
  const lowEnds = routeEvents.filter(event => event.type === 'scar_paso_bajo_fin');
  const forbidden = routeEvents.filter(event => event.type.startsWith('scar_salto') || event.type === 'scar_recuperacion');
  if (!run.complete || lowStarts.length !== 1 || lowEnds.length !== 1 || forbidden.length || run.scar.crouched || routeEvents.filter(event => event.type === 'scar_orden_puente').length !== 1 || routeEvents.filter(event => event.type === 'placa_puente_scar_enclavada').length !== 1) throw new Error(`Ruta baja segura de Scar falló en repetición ${repetition}: ${JSON.stringify({complete:run.complete,bridge:run.bridgeState,scar:{x:run.scar.x,y:run.scar.y,mode:run.scar.mode,crouched:run.scar.crouched,recover:run.scar.recoverTimer},lowStarts,lowEnds,forbidden,commands:routeEvents.filter(event=>event.type==='scar_orden_puente'),latches:routeEvents.filter(event=>event.type==='placa_puente_scar_enclavada'),last:routeEvents.slice(-20)})}`);
  scarRouteRuns.push({ repetition, complete: true, commands: 1, lowPasses: 1, lowRestores: 1, latches: 1, jumps: 0, recoveries: 0 });
}

qaR15.get('playLab').click();
if (apiR15.getSim().scene !== 'lab' || qaR15.get('labControls').classList.contains('hidden')) throw new Error('Laboratorio QA_ONLY no abrió en modo QA.');
qaR15.stations.find(item => item.dataset.station === 'D').click();
if (apiR15.getSim().station !== 'D' || !qaR15.get('labObjective').textContent.includes('paso bajo')) throw new Error('La estación D no expone escalera y paso bajo.');
qaR15.stations.find(item => item.dataset.station === 'E').click();
if (apiR15.getSim().station !== 'E' || !qaR15.get('labObjective').textContent.includes('guardián')) throw new Error('La estación E no expone combate y orden cooperativa.');
qaR15.get('labNext').click();
if (apiR15.getSim().station !== 'A') throw new Error('Siguiente no recorre A–E de forma cíclica.');
qaR15.get('labExit').click();
if (apiR15.getSim().scene !== 'graybox') throw new Error('Salir no vuelve a GB02.');
const locomotionProbe = { onGround: true, crouched: false, vx: 3.5 };
const walkCycle = [0, .12, .24, .36].map(time => apiR15.selectLocomotionFrame('eren', locomotionProbe, time).src);
locomotionProbe.vx = 6;
const runCycle = [0, .09, .18, .27, .36, .45, .54, .63].map(time => apiR15.selectLocomotionFrame('eren', locomotionProbe, time).src);
if (new Set(walkCycle).size !== 4 || new Set(runCycle).size !== 8) throw new Error('Eren no alterna las piernas en los ciclos completos de andar y correr.');
locomotionProbe.vx = 0;
const idleCycle = [0, .32, .64, .96].map(time => apiR15.selectLocomotionFrame('eren', locomotionProbe, time).src);
if (new Set(idleCycle).size !== 4) throw new Error('El reposo de Eren no reproduce sus cuatro fotogramas de respiración/parpadeo.');
locomotionProbe.locomotionStateKey = 'idle'; locomotionProbe.locomotionTime = 0; apiR15.updateLocomotionClock(locomotionProbe, .33);
if (locomotionProbe.locomotionTime !== .33 || !apiR15.selectLocomotionFrame('eren', locomotionProbe).src.includes('eren-reposo-r02-01')) throw new Error('El reloj local de locomoción no avanza de forma visible y estable.');
const runningJumpProbe = { onGround: false, crouched: false, vy: -1, jumpVisualState: 'impulso', jumpVisualTime: .2, jumpVisualAirTime: .2, jumpVisualVariant: 'running' };
apiR15.updateJumpVisual('eren', runningJumpProbe, .02);
if (runningJumpProbe.jumpVisualState !== 'subida') throw new Error('El salto corriendo salta visualmente de impulso a caída demasiado pronto.');
runningJumpProbe.jumpVisualAirTime = .31; apiR15.updateJumpVisual('eren', runningJumpProbe, .01);
if (runningJumpProbe.jumpVisualState !== 'caida') throw new Error('El salto corriendo no entra en caída tras la transición suavizada.');

apiR15.reset('qa_camara_parada_sin_rebote_r21');
const cameraSim = apiR15.getSim();
Object.assign(cameraSim.eren, { x: 34.5, y: 2, vx: 6, vy: 0, onGround: true });
for (let frame = 0; frame < 90; frame++) apiR15.updateCamera(1 / 60);
const lookBeforeStop = cameraSim.camera.lookAhead;
cameraSim.eren.vx = 0;
const lookAfterStop = [];
for (let frame = 0; frame < 120; frame++) { apiR15.updateCamera(1 / 60); lookAfterStop.push(cameraSim.camera.lookAhead); }
if (lookBeforeStop < 2.9 || lookAfterStop[0] <= 0 || lookAfterStop[0] >= lookBeforeStop || lookAfterStop.some((value, index) => value < -1e-9 || index > 0 && value > lookAfterStop[index - 1] + 1e-9) || lookAfterStop.at(-1) > .02) throw new Error(`El look-ahead de cámara todavía salta, rebota o no vuelve suavemente a cero: ${JSON.stringify({lookBeforeStop,first:lookAfterStop[0],last:lookAfterStop.at(-1)})}`);
if (!css.includes('.station-buttons{display:grid;grid-template-columns:repeat(5,1fr)') || !css.includes('.qa-only.hidden{display:none!important}')) throw new Error('La UI QA A–E o su ocultación normal no está fijada.');
if (!sourceText.includes('R16_FUNCTIONAL_ART_PACK') || !sourceText.includes('R16_RUNTIME_VISUALS') || !sourceText.includes('drawFunctionalCharacterState') || !sourceText.includes('drawEnemyFunctional') || !sourceText.includes("erenLegAlternation:'VISIBLE_WALK_4_RUN_8_FRAME_CYCLES_WITH_LOCAL_CLOCK'")) throw new Error('Los actores funcionales heredados de R19 no están trazados.');
if (!sourceText.includes('A05_VISUAL_PACK') || !sourceText.includes("runtimeBaseline:'R19_HEAD_711c33841824a713964691be8b33268eed1db48e'") || !sourceText.includes("cleanLudoWalkPresent:false") || !sourceText.includes("walkFallback:'R19_FUNCTIONAL_WALK_RETAINED'") || !sourceText.includes("S012:{sha256:r16WorldArt.ladder.sha256") || !sourceText.includes("S020:{sha256:r16WorldArt.bridge.sha256") || !sourceText.includes("eren:{idle:[0,0,0,0],walk:[0,0,0,0],run:[0,0,0,30,0,0,0,0]}")) throw new Error('La autoridad A05 R02, el fallback de walk o las estructuras canónicas no están declarados.');
if (!css.includes('.game-actions{position:relative') || !css.includes('pointer-events:none}.round-button{') || !css.includes('pointer-events:auto}.round-button span')) throw new Error('Los huecos del rombo táctil siguen capturando contactos.');
if (!sourceText.includes("document.querySelectorAll('.game-dpad [data-controls]')") || !sourceText.includes("bindPointerPress('run','run',true)") || !sourceText.includes('updateRunJumpChord')) throw new Error('El multitáctil independiente y el acorde de pulgar no están enlazados solo a controles visibles.');
if (!html.includes('maximum-scale=1,user-scalable=no') || !styles.includes('body,body *{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}') || !appSource.includes("document.addEventListener('selectstart'") || !appSource.includes("event.touches.length>1")) throw new Error('Selección de texto, menú contextual o zoom por pinza siguen habilitados.');
if (appSource.includes('feedback.textContent=`La respuesta es: ${correct}.`') || !appSource.includes("feedback.textContent='No es esa. Vuelve a mirar el texto y prueba otra vez.'") || !appSource.includes('if(choice!==correct)')) throw new Error('Una respuesta errónea sigue revelando la correcta o impide reintentar.');
if (sourceText.includes('Primero completa un cuento nuevo') || !html.includes('Modo de pruebas · acceso directo')) throw new Error('El cuento sigue bloqueando temporalmente el acceso al juego.');
if (!sourceText.includes("idle:['eren-reposo-r02-00-candidate.png','eren-reposo-r02-01-candidate.png','eren-reposo-r02-02-candidate.png','eren-reposo-r02-03-candidate.png']") || !sourceText.includes("eren-caminar-r02-03-candidate.png") || !sourceText.includes("eren-correr-r02-07-candidate.png") || !sourceText.includes("scar-andar-03-candidate.png") || !sourceText.includes("up:['eren-escalera-subida-00-candidate.png','eren-escalera-agarre-01-candidate.png','eren-escalera-bajada-00-candidate.png','eren-escalera-agarre-01-candidate.png']") || !sourceText.includes("down:['eren-escalera-bajada-00-candidate.png','eren-escalera-agarre-01-candidate.png','eren-escalera-bajada-01-candidate.png','eren-escalera-agarre-01-candidate.png']") || !sourceText.includes('drawAnchoredErenIdle')) throw new Error('El fallback funcional R19 de Eren/Scar no quedó preservado.');
const ladderR21 = await readFile(new URL('assets/playtest/arte-gb02-r16-r01/04_ESTRUCTURAS_CANONICAS/S012-escalera-madera-1x3_5-r21-alpha-real.png', root));
if (createHash('sha256').update(ladderR21).digest('hex') !== '29a53dd1a3a6429093f6f526ac00a54ad3f6a0482f9ef9033211ff7da9bf4f33' || ladderR21[25] !== 6 || !sourceText.includes('S012-escalera-madera-1x3_5-r21-alpha-real.png') || !sourceText.includes("alphaMode:'R21_TRUE_ALPHA_MATTE_REMOVED'") || sourceText.includes("alpha:sim.ladderEnabled?1:.24") || sourceText.includes("filter:sim.ladderEnabled?'none':'grayscale(1)'") || sourceText.includes('foregroundLip,0,0,10,50') || !sourceText.includes("if(!sim.barrierOpen&&sim.gateUnlockState!=='open')")) throw new Error('La escalera R21 no tiene alfa real permanente, U4 conserva el recorte residual o la reja deja un resto al abrirse.');
const canonicalAssets = [
  ['objects/llave-1_5x1.png', 'd52497cb5b0b6fa4d39d6f433b9aaab8e6dbaa146e3e0c05e00e1a30df360f17'],
  ['objects/puerta-cerrada-2x2_5.png', 'd38c748780e0d640da6ff31873cf921b0b88f544c785e9141cc4825511c7176e'],
  ['objects/puerta-abierta-2x2_5.png', '1d6533e067bd029886ff692b49be39c040f889ab7ad8f935a8fa37d080780704'],
];
for (const [path, sha] of canonicalAssets) {
  const bytes = await readFile(new URL(`assets/playtest/mundo1-functional/${path}`, root));
  if (createHash('sha256').update(bytes).digest('hex') !== sha) throw new Error(`Asset canónico alterado: ${path}.`);
}
const a05Assets = [
  ['background/parallax-far-891x411.png', '4b3e1e780074a99f912427ee04b050c36f04e78fa8d6d702559a40262494991f'],
  ['background/parallax-mid-891x411.png', '11ecd420bf6cd15a749c3393ff9211811ec6a975c69a7c67eec0b7d4ebe4cc47'],
  ['background/parallax-near-891x411.png', '4a1fe2de7b3f7260a0017ee45bb64693dc15d089ac67befa607e9d139bce772c'],
  ['objects/door/reja-lateral-cerrada-0_5x2_5.png', '0e5550a4a9416c7e9022ebc4b3d02363236c3ceb8e66f9c3f12fffaacdd56d15'],
  ['objects/hazards/pinchos-suelo-1x1_5.png', '59d6a3a242f2f1f6ad28b891762988a634265bffc1ca04390351a7b9010b14b7'],
  ['objects/signage/bandera-meta-1_5x2.png', 'c7ac81d452d9b7788bc4bf10d03680194057e085f270ec01d0c05718ec9760a8'],
];
for (const [path, sha] of a05Assets) {
  const bytes = await readFile(new URL(`assets/playtest/a05-r02/${path}`, root));
  if (createHash('sha256').update(bytes).digest('hex') !== sha || bytes[25] !== 6) throw new Error(`Asset A05 R02 ausente, alterado o sin RGBA: ${path}.`);
}
if (!sourceText.includes('worldArt.guardianKey') || !sourceText.includes("requiresKeyAndAction:true") || !sourceText.includes("action_at_gate") || !sourceText.includes("mode:'LATERAL_GRATE_RISE'")) throw new Error('La llave y la apertura contextual ascendente no están conectadas al runtime R20.');
if (!sourceText.includes("if(!['ground','upper','roof'].includes(solid.kind))return false") || !sourceText.includes("functionalTerrainCoverage:'ALL_GROUND_UPPER_ROOF_SOLIDS'") || !sourceText.includes('drawStartCliff(ctx,draw)') || !sourceText.includes("rect('LIMITE_OESTE'") || !sourceText.includes("platesSinkModules:.22") || !sourceText.includes("spikeSinkModules:.28") || !sourceText.includes("flagSinkModules:.38")) throw new Error('Faltan suelo, límite dual o contactos visuales A05 R02.');
if (!sourceText.includes("layers:['FAR','MID','NEAR']") || !sourceText.includes('seamlessDeclared:false') || !sourceText.includes('automaticDecorationRepeat:false') || !sourceText.includes('underStar:false') || !sourceText.includes('checkpointVisuals:R22_DECORATION_PACK.checkpointVisuals') || !sourceText.includes("telegraph:'YELLOW_ALERT_RED_WINDUP_EXCLAMATION'") || !sourceText.includes("ctx.fillText('!'") || !sourceText.includes("reward:'GUARDIAN_KEY_O014'") || !sourceText.includes("scarCombatReaction:{state:'DANGER_BRISTLED_WAIT'")) throw new Error('Paralaje, decoración R22 o lectura funcional no están trazados.');

const resultR15 = {
  result: 'PASS', contract: contractR15.id, parentContractSha256: contractR15.parentSha256,
  baseline: contractR15.baseline, functionalBaseline: contractR15.functionalBaseline,
  preservedNotApplied: contractR15.preservedNotApplied, frozen: { locomotion: true, jump: true, contactR10: true },
  viewport: ['4:3', '16:9', '19.5:9', '21:9', '32:9'], erenTunnelBlockedStandingAndCrouched: true,
  enemy: { offensiveAttackHit: true, jumpDodge: true, bodySolid: true, topContactDamage: true, erenHitsToDefeat: 2, keyThenActionCausal: true, canonicalKeyAsset: true, ascendingGateAsset: true, consequencesAtomic: true, exclamationTelegraph: true },
  universalAttack: { free: true, airborne: true, crouched: true, crouchColliderLocked: true, ladderDisabled: true, queued: true, dynamicHitbox: true, reachModules: .92 },
  ladder: { repetitions: ladderRuns.length, failures: 0, onlyIgnoredSolid: 'U4', sourceRgba: true, intermediateFrames: true, armsAlternateUpAndDown: true },
  scarSafeRoute: { repetitions: scarRouteRuns.length, failures: 0, commands: 20, lowPasses: 20, jumps: 0, recoveries: 0, preCommandCrossings: 0 },
  bridge: { autoLatchesWithoutCommand: 0, deployments: 20, colliderDuringDeploy: false },
  qaOnlyLab: { normalBuildHidden: true, stations: 'A-E' },
  visualIntegrationR22: { a05R02: true, parallaxLayers: 3, independentParallax: true, seamlessDeclared: false, staticDecorationAccents: 12, proceduralFlora: 9, animatedDecoration: true, particles: true, checkpointsVisuallyHidden: true, startBoundaryDecorated: true, s012TrueAlphaAlwaysVisible: true, u4ContinuousBehindLadder: true, orphanLipRemoved: true, s020Canonical: true, erenWalkFallbackR19: true, cleanLudoWalkPresent: false, spikeBuriedModules: .28, platesBuriedModules: .22, flagBuriedModules: .38 },
  firstGateScarRoute: { repetitions: scarFirstGateRuns.length, failures: 0, recoveries: 0, takeoffMinX: 24.35 },
  camera: { lookAheadSmoothed: true, abruptStopSnap: false, reverseBounce: false },
  touch: { repeatedJumpWhileRunHeld: true }, initialBoundary: { erenBlocked: true, scarBlocked: true },
  gates: { firstGateRises: true, firstFixedColumnCollision: true, secondGateRequiresKeyAndAction: true, secondGateRises: true, secondFixedColumnCollision: true, colliderReleasedOnlyAtEnd: true, ladderMovedToX43_5: true, ladderCenterX44: true },
  playtestMechanicsCorrected: true,
  tilesetIntegrated: true, gameReady: false,
};

const evidenceDirR15 = process.env.GB02_EVIDENCE_DIR;
if (evidenceDirR15) {
  await mkdir(evidenceDirR15, { recursive: true });
  const generatedAt = new Date().toISOString();
  await writeFile(`${evidenceDirR15}/GB02_R04_QA_MATRIX.json`, `${JSON.stringify({ schema: 'EREN_GB02_R04_QA_MATRIX_R22_V1', generatedAt, appVersion: '45.0.0-decoration-vfx-gb02-r04-candidate-r22', contract: contractR15, result: 'PASS', status: 'APK_CANDIDATE_PENDING_DEVICE_PLAYTEST', checks: resultR15 }, null, 2)}\n`);
  await writeFile(`${evidenceDirR15}/SCAR_SALIDA_PRIMERA_REJA_R21_20_REPETICIONES.json`, `${JSON.stringify({ schema: 'SCAR_FIRST_GATE_EXIT_R21_V1', generatedAt, repetitions: scarFirstGateRuns.length, results: scarFirstGateRuns, summary: { completions: 20, waterRecoveries: 0, columnCollisions: 0, failures: 0, result: 'PASS' } }, null, 2)}\n`);
  await writeFile(`${evidenceDirR15}/LADDER_GB02_R04_20_REPETICIONES.json`, `${JSON.stringify({ schema: 'EREN_LADDER_GB02_R04_V1', generatedAt, repetitions: ladderRuns.length, results: ladderRuns, summary: { completions: 20, stuck: 0, residualPenetrations: 0, failures: 0, result: 'PASS' } }, null, 2)}\n`);
  await writeFile(`${evidenceDirR15}/SCAR_RUTA_BAJA_GB02_R04_20_REPETICIONES.json`, `${JSON.stringify({ schema: 'SCAR_LOW_ROUTE_GB02_R04_V1', generatedAt, repetitions: scarRouteRuns.length, results: scarRouteRuns, summary: { completions: 20, commands: 20, lowPasses: 20, autoLatches: 0, jumps: 0, recoveries: 0, failures: 0, result: 'PASS' } }, null, 2)}\n`);
}

console.log(JSON.stringify(resultR15));
