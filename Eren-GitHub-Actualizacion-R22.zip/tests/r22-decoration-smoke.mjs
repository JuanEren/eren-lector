import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { inflateSync } from 'node:zlib';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const source = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');
const assetPath = 'assets/playtest/r22-decoration/start-boundary-tree-ruins-8_5x12-r22.png';
const bytes = await readFile(new URL(assetPath, root));
const expectedAssetSha = 'f9110297a68f6640e13b698bd69d37d36e4a96701d0b3a110a0b1f08c8d4a25c';

if (!source.includes("APP_VERSION='45.0.0-decoration-vfx-gb02-r04-candidate-r22'") || !source.includes("LOG_VERSION='GB02-R04-PLAYTEST-R22-v1'") || !gradle.includes('versionCode = 46') || !gradle.includes('versionName = "45.0.0-decoration-vfx-gb02-r04-candidate-r22"')) throw new Error('Versionado R22 desalineado.');
if (createHash('sha256').update(bytes).digest('hex') !== expectedAssetSha) throw new Error('El límite oeste R22 no coincide con el asset aprobado para esta candidata.');
if (bytes.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a') throw new Error('El límite oeste R22 no es PNG.');

let offset = 8, width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
const idat = [];
while (offset < bytes.length) {
  const length = bytes.readUInt32BE(offset), type = bytes.subarray(offset + 4, offset + 8).toString('ascii'), data = bytes.subarray(offset + 8, offset + 8 + length);
  if (type === 'IHDR') { width = data.readUInt32BE(0); height = data.readUInt32BE(4); bitDepth = data[8]; colorType = data[9]; interlace = data[12]; }
  else if (type === 'IDAT') idat.push(data);
  else if (type === 'IEND') break;
  offset += length + 12;
}
if (width !== 850 || height !== 1200 || bitDepth !== 8 || colorType !== 6 || interlace !== 0) throw new Error(`El límite oeste debe ser RGBA 850×1200: ${JSON.stringify({ width, height, bitDepth, colorType, interlace })}`);

const raw = inflateSync(Buffer.concat(idat)), stride = width * 4, rgba = Buffer.alloc(stride * height);
const paeth = (a, b, c) => { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); return pa <= pb && pa <= pc ? a : pb <= pc ? b : c; };
let sourceOffset = 0;
for (let y = 0; y < height; y++) {
  const filter = raw[sourceOffset++], row = y * stride;
  for (let x = 0; x < stride; x++) {
    const value = raw[sourceOffset++], left = x >= 4 ? rgba[row + x - 4] : 0, up = y ? rgba[row - stride + x] : 0, upperLeft = y && x >= 4 ? rgba[row - stride + x - 4] : 0;
    if (filter === 0) rgba[row + x] = value;
    else if (filter === 1) rgba[row + x] = (value + left) & 255;
    else if (filter === 2) rgba[row + x] = (value + up) & 255;
    else if (filter === 3) rgba[row + x] = (value + Math.floor((left + up) / 2)) & 255;
    else if (filter === 4) rgba[row + x] = (value + paeth(left, up, upperLeft)) & 255;
    else throw new Error(`Filtro PNG no compatible: ${filter}.`);
  }
}
let transparent = 0, opaque = 0;
for (let index = 3; index < rgba.length; index += 4) { if (rgba[index] === 0) transparent++; if (rgba[index] === 255) opaque++; }
if (transparent < 400000 || opaque < 300000) throw new Error(`El límite oeste no conserva alfa real suficiente: ${JSON.stringify({ transparent, opaque })}`);

const buildGraybox = source.match(/function buildGraybox\([\s\S]*?\n}\n\nfunction buildLab/)?.[0];
if (!buildGraybox || createHash('sha256').update(buildGraybox).digest('hex') !== 'e7c80acfd88ddff0caf091abfb72af7db6950e4cea6c8986c913f5b350aabd0b') throw new Error('La geometría, hazards, triggers o checkpoints R21 cambiaron durante el pase visual R22.');
if (!source.includes('if(debug)for(const checkpoint of sim.world.checkpoints)') || source.includes('checkpointLogicChanged:true')) throw new Error('Los checkpoints no están ocultos solo a nivel visual.');
if (source.includes('for(let x=start;x<0;x++)') || !source.includes("drawWorldArt(ctx,r22Art.startBoundary,-8.5,0,8.5,12")) throw new Error('El relleno cuadriculado izquierdo no fue sustituido por el límite decorado R22.');
if (!source.includes('automaticDecorationRepeat:false') || !source.includes('underStar:false') || !source.includes('staticAccentCount:12') || !source.includes('proceduralFloraCount:9')) throw new Error('La decoración R22 no respeta el montaje manual o la exclusión bajo la estrella.');
for (const token of ['drawR22AmbientAnimation(ctx,draw)', 'drawR22HangingVines(ctx,draw)', 'drawR22Flora(ctx,draw)', 'drawR22WaterGlints(ctx,draw)', 'drawR22ActionParticles(ctx,draw)', "particleTypes:['ambient_motes','water_glints','gate_dust','bridge_mist','star_sparkles']"]) if (!source.includes(token)) throw new Error(`Falta el componente visual R22: ${token}`);
if (!source.includes('r22ColliderChanges:false') || !source.includes('geometryChanged:false,collidersChanged:false,physicsChanged:false,checkpointLogicChanged:false')) throw new Error('El pase R22 no declara de forma verificable su alcance exclusivamente visual.');

console.log(JSON.stringify({ result: 'PASS', revision: 'R22', version: '45.0.0-decoration-vfx-gb02-r04-candidate-r22', asset: { path: assetPath, width, height, sha256: expectedAssetSha, transparentPixels: transparent, opaquePixels: opaque }, decoration: { staticAccents: 12, proceduralFlora: 9, motes: 16, leaves: 9, vines: 4, checkpointVisuals: 'HIDDEN_NORMAL_QA_ONLY' }, geometryR21Preserved: true, collidersChangedR22: false, physicsChangedR22: false, gameReady: false }));
