import vm from 'node:vm';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';

const require = createRequire(import.meta.url);
const { createCanvas, Image: CanvasImage } = require('@napi-rs/canvas');
const wwwRoot = fileURLToPath(new URL('../app/src/main/assets/www/', import.meta.url));
const html = await readFile(resolve(wwwRoot, 'index.html'), 'utf8');
const source = await readFile(resolve(wwwRoot, 'graybox-game.js'), 'utf8');
const evidenceRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../docs/evidencias-r22/capturas');
const runtimeImages = [];

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id; this.dataset = {}; this.classList = new ClassList(); this.listeners = new Map();
    this.style = {}; this.textContent = ''; this.innerHTML = ''; this.value = ''; this.offsetWidth = 10;
    this.attributes = new Map(); this.disabled = false; this.width = 0; this.height = 0;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, stopPropagation() {}, pointerId: 1, clientX: 0, clientY: 0, width: 1, height: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  getBoundingClientRect() { return this.rect || { left: 0, top: 0, width: 64, height: 64 }; }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  closest(selector) { return selector === 'button' || selector === `#${this.id}` ? this : null; }
}

class RuntimeImage extends CanvasImage {
  constructor() { super(); runtimeImages.push(this); }
  set src(value) {
    this.runtimeSource = String(value);
    super.src = readFileSync(resolve(wwwRoot, this.runtimeSource));
  }
  get src() { return this.runtimeSource || ''; }
}

async function createHarness(width, height) {
  const canvas = createCanvas(width, height);
  canvas.id = 'gameCanvas'; canvas.dataset = {}; canvas.classList = new ClassList(); canvas.listeners = new Map();
  canvas.addEventListener = Element.prototype.addEventListener;
  canvas.getBoundingClientRect = () => ({ left: 0, top: 0, width, height });
  canvas.closest = () => null;

  const elements = new Map();
  for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
  elements.set('gameCanvas', canvas);
  const get = id => elements.get(id);
  const controlMap = {
    moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
    moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
  };
  for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
  for (const [id, value] of Object.entries({ walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;
  const stations = [...html.matchAll(/data-station="([A-Z])"/g)].map(match => { const element = new Element(); element.dataset.station = match[1]; return element; });
  const body = new Element('body');
  const document = {
    body,
    getElementById: id => get(id),
    querySelectorAll: selector => (selector === '[data-controls]' || selector === '.game-dpad [data-controls]') ? [...elements.values()].filter(element => element.dataset?.controls && element.id !== 'run') : selector === '[data-station]' ? stations : [],
    createElement: () => new Element(),
    addEventListener() {}, elementFromPoint: () => null, execCommand: () => true,
  };
  const storage = new Map();
  const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
  const listeners = new Map();
  const window = {
    document, devicePixelRatio: 1, innerWidth: width, innerHeight: height, __EREN_QA_ONLY__: true,
    addEventListener(type, callback) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(callback); },
    dispatchEvent(event) { for (const callback of listeners.get(event.type) || []) callback(event); },
    requestAnimationFrame() { return 1; }, cancelAnimationFrame() {},
  };
  const sandbox = {
    window, document, navigator: { getGamepads: () => [], userAgent: 'R22-OFFSCREEN-QA' }, localStorage,
    requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
    setTimeout: callback => { callback(); return 1; }, clearTimeout() {}, console, Image: RuntimeImage,
    completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
    tone() {}, playAzureSequence() {}, renderMenu() {},
  };
  window.localStorage = localStorage;
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 'graybox-game.js' });
  await Promise.all(runtimeImages.splice(0).map(image => image.decode()));
  get('directGame').click();
  window.__grayboxQa.pause(true);
  return { canvas, api: window.__grayboxQa };
}

function placeActor(actor, values) {
  Object.assign(actor, { vx: 0, vy: 0, onGround: true, crouched: false, recoverTimer: 0, recover: 0, invuln: 0, visualState: null, visualStateTime: 0, jumpVisualState: null }, values);
}

function configureStage(api, stage) {
  const sim = api.getSim();
  sim.paused = true; sim.complete = false; sim.boxBroken = stage !== 'walk' && stage !== 'start'; sim.boxBreakState = sim.boxBroken ? 'remains' : 'intact';
  Object.assign(sim, { coopUnlocked: true, coopGateState: 'open', coopGateProgress: 1, enemyDefeated: true, enemyState: 'defeated', enemyHp: 0, keyState: 'collected', gateUnlockState: 'open', gateLiftProgress: 1, barrierOpen: true, ladderEnabled: true, scarReleased: true, bridgeCommanded: false, bridgePlateLatched: false, bridgeState: 'stowed', bridgeDeployElapsed: 0, starCollected: false });
  placeActor(sim.eren, { x: 10.5, y: 2, w: 1, h: 1.5, facing: 1 });
  placeActor(sim.scar, { x: 8.5, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 8.5 });
  let focus = 10;
  if (stage === 'walk' || stage === 'start') {
    Object.assign(sim, { coopUnlocked: false, coopGateState: 'closed', coopGateProgress: 0, enemyDefeated: false, enemyState: 'patrol', enemyHp: 2, keyState: 'hidden', gateUnlockState: 'locked', gateLiftProgress: 0, barrierOpen: false, ladderEnabled: false, scarReleased: false });
    placeActor(sim.eren, { x: stage === 'start' ? 4.5 : 10.5, y: 2, w: 1, h: 1.5, vx: stage === 'start' ? 0 : 3.5, facing: 1, locomotionStateKey: stage === 'start' ? 'idle' : 'walk', locomotionTime: .24 });
    placeActor(sim.scar, { x: stage === 'start' ? 3.3 : 8.5, y: 2, w: 1.5, h: 1, facing: 1, mode: 'follow' });
    focus = stage === 'start' ? 4.5 : 10;
  } else if (stage === 'gate1') {
    Object.assign(sim, { coopUnlocked: false, coopGateState: 'opening', coopGateProgress: .55 });
    placeActor(sim.eren, { x: 22.2, y: 2, w: 1, h: 1.5, facing: 1 });
    placeActor(sim.scar, { x: 16.2, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 16.2 });
    focus = 23.5;
  } else if (stage === 'gate2') {
    Object.assign(sim, { gateUnlockState: 'opening', gateLiftProgress: .55, barrierOpen: false, ladderEnabled: false, scarReleased: false });
    placeActor(sim.eren, { x: 41.2, y: 2, w: 1, h: 1.5, facing: 1 });
    placeActor(sim.scar, { x: 38, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 38 });
    focus = 43.5;
  } else if (stage === 'ladder') {
    placeActor(sim.eren, { x: 44, y: 3.2, w: 1, h: 1.5, onGround: false, facing: 1, visualState: 'escalera_subida', visualStateTime: .23 });
    placeActor(sim.scar, { x: 40, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 40 });
    sim.ladderState = 'subida'; sim.ladderStateElapsed = .23; focus = 44;
  } else if (stage === 'lowpass') {
    sim.bridgeCommanded = true;
    placeActor(sim.eren, { x: 44, y: 5, w: 1, h: 1.5, facing: 1 });
    placeActor(sim.scar, { x: 47.4, y: 2, w: 1.5, h: .65, crouched: true, facing: 1, mode: 'bridge_marker', visualState: 'bajo', visualStateTime: .22 });
    focus = 48;
  } else if (stage === 'bridge') {
    Object.assign(sim, { bridgeCommanded: true, bridgePlateLatched: true, bridgeState: 'deploying', bridgeDeployElapsed: .3 });
    placeActor(sim.eren, { x: 49.5, y: 2, w: 1, h: 1.5, facing: 1 });
    placeActor(sim.scar, { x: 50.25, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 50.25 });
    focus = 52.5;
  } else if (stage === 'goal') {
    Object.assign(sim, { bridgeCommanded: true, bridgePlateLatched: true, bridgeState: 'solid', r4Unlocked: true });
    placeActor(sim.eren, { x: 62.8, y: 2, w: 1, h: 1.5, facing: 1 });
    placeActor(sim.scar, { x: 63.5, y: 2, w: 1.5, h: 1, facing: 1, mode: 'wait', waitX: 63.5 });
    focus = 59.5;
  }
  api.rebuild(); api.focus(focus); api.render();
}

async function capture(name, width, height, stage) {
  const { canvas, api } = await createHarness(width, height);
  configureStage(api, stage);
  const sim = api.getSim();
  const target = resolve(evidenceRoot, name);
  await writeFile(target, canvas.toBuffer('image/png'));
  return { file: name, width, height, stage, barrierOpen: sim.barrierOpen, ladderEnabled: sim.ladderEnabled, gateLiftProgress: sim.gateLiftProgress };
}

await mkdir(evidenceRoot, { recursive: true });
const captures = [];
captures.push(await capture('00_INICIO_DECORADO_891x411.png', 891, 411, 'start'));
captures.push(await capture('01_EREN_CAMINAR_16x9.png', 1280, 720, 'walk'));
captures.push(await capture('02_PRIMERA_REJA_16x9.png', 1280, 720, 'gate1'));
captures.push(await capture('03_SEGUNDA_REJA_16x9.png', 1280, 720, 'gate2'));
captures.push(await capture('04_ESCALERA_16x9.png', 1280, 720, 'ladder'));
captures.push(await capture('05_PASO_BAJO_SCAR_16x9.png', 1280, 720, 'lowpass'));
captures.push(await capture('06_PUENTE_DESPLIEGUE_16x9.png', 1280, 720, 'bridge'));
captures.push(await capture('07_META_DUAL_16x9.png', 1280, 720, 'goal'));
captures.push(await capture('08_VIEWPORT_19_5x9.png', 1300, 600, 'walk'));
captures.push(await capture('09_VIEWPORT_21x9.png', 1400, 600, 'walk'));
await writeFile(resolve(evidenceRoot, 'CAPTURAS_R22.json'), `${JSON.stringify({ schema: 'EREN_GB02_R22_RENDER_EVIDENCE_V1', generatedAt: new Date().toISOString(), renderer: '@napi-rs/canvas', runtimeSource: 'graybox-game.js', debugOverlays: false, checkpointVisuals: 'HIDDEN', captures }, null, 2)}\n`);
console.log(JSON.stringify({ result: 'PASS', captures: captures.length, evidenceRoot, formats: ['16:9', '19.5:9', '21:9'] }));
