# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 46.0.0 · candidata GB02 R04 · revisión R23

R23 parte de R22 y del R21 validado físicamente el 28/08/2026 en un Samsung SM-S928B con Android 16. Es un pase audiovisual y conserva sin cambios la geometría, colliders, física, cámara R21, controles, actores y contrato GB02 R04. El estado máximo continúa siendo `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`; `gameReady` permanece en `false`.

Incluye:

- límite oeste del comienzo integrado con el terreno mediante raíces, musgo y vegetación, sin collider;
- doce acentos estáticos colocados manualmente y nueve grupos de flora tenue, sin repetición automática ni decoración bajo la estrella;
- FAR, MID, NEAR y un cuarto plano FOREGROUND oscuro con velocidades independientes;
- luciérnagas, hojas, lianas, helechos, aves lejanas, mariposas, ranas, peces y burbujas con movimiento ambiental lento;
- agua Canvas con gradiente, reflejo, ondas, caústicas, espuma y vida subacuática, sin modificar el hazard;
- destellos de agua, polvo de elevación de rejas, niebla durante el despliegue del puente y chispas de estrella;
- ambiente procedural original de bosque, viento, agua y aves, música generativa tenue y efectos esenciales; no incluye archivos de audio de terceros;
- botón de silencio y opción de efectos reducidos;
- checkpoints funcionales preservados, con sus rombos azules ocultos en la build normal y visibles solo en QA;
- FAR, MID y NEAR independientes, terreno A05 R02, escalera S012 R21, rejas laterales, puente S020 y contactos visuales preservados;
- ciclos funcionales R19 de Eren, Scar, araña y guardián sin cambios;
- HUD R11, controles simultáneos, Laboratorio `QA_ONLY`, tres corazones y meta dual preservados.

La validación automatizada se ejecuta con:

```text
node tests/azure-catalogue-smoke.mjs
node tests/hud-hearts-r11-smoke.mjs
node tests/r16-functional-art-smoke.mjs
node tests/ladder-alpha-r21-smoke.mjs
node tests/r22-decoration-smoke.mjs
node tests/r23-atmosphere-audio-smoke.mjs
node tests/gb02-r04-smoke.mjs
```

Las capturas reproducibles se generan con `node tests/r23-render-evidence.mjs` cuando está disponible `@napi-rs/canvas`.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar candidata GB02 R04 R23** y descarga **Eren-GB02-R04-R23-APK-CANDIDATE**. Ejecuta el workflow únicamente en la rama candidata R23; no hagas merge a `main` ni crees una release.

## Siguiente orden de trabajo

1. Validación audiovisual breve de R23 en Android.
2. Personajes y animaciones definitivos con exportaciones Ludo de pago limpias.
3. Sustitución opcional del audio procedural por una biblioteca curada con licencias registradas.
4. Sonido final, QA y cierre del tutorial.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
