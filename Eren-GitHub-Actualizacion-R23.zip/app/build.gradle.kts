plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 47
        versionName = "46.0.0-atmosphere-audio-gb02-r04-candidate-r23"
    }
}
