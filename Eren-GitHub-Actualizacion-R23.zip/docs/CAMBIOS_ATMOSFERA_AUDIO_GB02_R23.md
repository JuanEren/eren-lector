# Pase audiovisual GB02 R04 · R23

## Resultado

R23 convierte el montaje R22 en una escena más viva sin rediseñar el nivel. La geometría, colliders, física, IA, cámara R21, controles y contrato funcional permanecen idénticos.

## Criterios de dirección artística

Se estudiaron principios de dos referentes, sin copiar personajes, fondos ni composiciones:

- *Planet of Lana*: siluetas oscuras próximas a cámara, profundidad 2.5D, viento/movimiento que conecta las capas y coordinación entre arte, animación, música y sonido.
- *Hollow Knight*: lectura lateral limpia, fondos y primeros planos que amplían profundidad, color controlado y animación 2D eficiente al servicio de la silueta.

Fuentes:

- <https://www.gamedeveloper.com/business/exploring-the-art-and-animation-behind-hand-painted-odyssey-i-planet-of-lana-i->
- <https://www.teamcherry.com.au/blog/introducing-hollow-knight>
- <https://www.teamcherry.com.au/blog/hollow-knight-then-and-now>

La aplicación concreta en GB02 mantiene el plano jugable como el de mayor contraste. El primer plano solo enmarca; la niebla, la fauna y la luz nunca ocultan peligros, mecanismos o apoyos.

## Cambios visuales

- Cuatro capas independientes: FAR 0,12; MID 0,30; NEAR 0,52; FOREGROUND 0,82.
- Primer plano procedural con ramas, hojas y viñeta tenue; sin collider.
- Uno o dos haces de luz ambiental según el modo de efectos.
- Aves lejanas, mariposas, ranas y peces con ciclos independientes y baja densidad.
- Árbol/ruina del límite oeste unido visualmente al césped mediante raíces, musgo, pequeñas piedras y helechos; no corta el terreno ni añade superficie jugable.
- Agua renderizada en Canvas con gradiente de profundidad, reflejo superficial, varias ondas, caústicas, espuma, burbujas y peces.
- Movimiento ambiental R22 preservado: hojas, luciérnagas, lianas y helechos.
- Polvo de rejas, niebla de puente, brillo de estrella y contacto visual de pulsadores/pincho/meta preservados.
- Rombos azules de checkpoint ocultos en la build normal; siguen disponibles únicamente con `debug` QA.
- Opción `FX: reducidos` que disminuye haces, fauna, ondas, caústicas, burbujas y primer plano.

No se integraron los dos PNG generados durante una prueba de raíces porque incluían un damero dibujado y no tenían alfa real.

## Cambios de sonido

- Bosque/viento procedural mediante ruido filtrado.
- Agua procedural sensible a la proximidad de cámara.
- Llamadas de aves espaciadas.
- Pad armónico original de baja presencia.
- SFX procedurales para salto, daño, caja, rejas, puente, estrella y meta.
- Botón superior de silencio persistente.
- Suspensión del audio al abandonar el juego o dejar la aplicación en segundo plano.
- Cero archivos de audio de terceros.

## Límites preservados

- `buildGraybox` SHA-256 estructural: `e7c80acfd88ddff0caf091abfb72af7db6950e4cea6c8986c913f5b350aabd0b`.
- Geometría modificada por R23: no.
- Collider modificado por R23: no.
- Física o navegación modificada por R23: no.
- PNG estirado con `Transform.scale`: no.
- Decoración con collider: no.
- Arte bajo la estrella: no.
- Personajes R19/R21, escalera R21 y puente S020: preservados.

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST` · `gameReady=false`.
