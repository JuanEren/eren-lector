# Guía de producción Ludo · personajes definitivos

## Regla de licencia y exportación

- Compra cualquier plan de pago antes de descargar material para integrar.
- Las exportaciones gratuitas llevan marca de agua en cada fotograma. No se borran, tapan, recortan ni reconstruyen.
- Tras suscribirte, vuelve a descargar también las generaciones útiles que ya estén en tu historial: Ludo indica que el plan de pago elimina la marca de las exportaciones nuevas y de las existentes del historial.
- Entrega siempre: ZIP de fotogramas individuales, sprite sheet PNG, JSON si está disponible y GIF/MP4 de previsualización.

Referencia oficial: <https://ludo.ai/docs/sprite-generator>

## Ajustes que no deben cambiar entre animaciones

| Actor | Lienzo final | Pivote | Línea de suelo | Orientación maestra |
| --- | ---: | ---: | ---: | --- |
| Eren | 300×200 px | (150, 200) | y=200 | derecha |
| Scar | 200×150 px | (100, 150) | y=150 | derecha |
| Araña/guardián | 200×150 px | (100, 150) | y=150 | derecha |

- Escala: 100 px = 1 m. No usar `trim whitespace`; el lienzo debe permanecer fijo.
- Alfa real RGBA, cuerpo completo, sin sombra proyectada, suelo, fondo, texto ni marca.
- Misma identidad, vestuario, proporciones, luz y paleta en todos los packs.
- Sin root motion: el cuerpo vuelve al mismo punto del lienzo; el juego produce el desplazamiento.
- Pies o patas apoyados en la misma línea en todos los ciclos terrestres.
- Generar mirando a la derecha; la izquierda se crea mediante volteo controlado en runtime.
- Usar 16 fotogramas cuando Ludo lo permita. Los holds muy simples pueden exportarse en 9, pero deben normalizarse al mismo lienzo.
- En **Animation Pack**, usar el mismo maestro limpio para homogeneizar tamaño y línea de suelo.

## Maestro de identidad de Eren

Antes de animar, crea y aprueba una imagen maestra limpia de cuerpo completo:

- niño de perfil, camiseta roja lisa;
- pantalón corto azul;
- calcetines blancos;
- zapatillas rojas y blancas;
- cabello oscuro sin reflejos violetas;
- proporción infantil constante y lectura clara a tamaño de móvil;
- fondo transparente, pose neutra, pies completos.

No mezcles packs de maestros distintos. Si cambia la cara, el cabello, el calzado o la proporción, regenera el pack antes de continuar.

## Eren · lista completa

### P0 · imprescindible para sustituir el personaje del tutorial

| # | Pack | Fotogramas | Requisito visual |
| ---: | --- | ---: | --- |
| E01 | Reposo, respiración y parpadeo | 16 | pies clavados; respiración leve; un parpadeo limpio |
| E02 | Caminar | 16 | alternancia real de piernas; sin deslizar pies |
| E03 | Correr | 16 | zancada más amplia; bucle continuo |
| E04 | Agacharse: entrada, hold y salida | 16 | cuerpo dentro de 1,5×1 m; sin crecer al final |
| E05 | Arrastrarse/agachado en movimiento | 16 | altura baja constante; manos y piernas alternan |
| E06 | Salto vertical | 16 | impulso, subida, ápice, caída y aterrizaje; sin desplazamiento horizontal interno |
| E07 | Salto hacia delante | 16 | lectura de inercia moderada; la trayectoria sigue siendo física |
| E08 | Salto corriendo | 16 | continuidad exacta desde E03; sin cambio de identidad |
| E09 | Patada de pie | 16 | sustituye visualmente el golpe; misma ventana mecánica actual |
| E10 | Patada baja agachado | 16 | nunca se levanta durante el golpe |
| E11 | Patada aérea | 16 | no incluye aterrizaje falso ni root motion |
| E12 | Impacto y recuperación | 16 | daño legible, retorno rápido al control |
| E13 | Derrota y reincorporación | 16 | caída y recuperación sin mover el pivote |
| E14 | Agarre de escalera | 9 | Eren de espaldas; manos preparadas; cuerpo centrado |
| E15 | Subir escalera | 16 | brazos y piernas alternan; de espaldas |
| E16 | Bajar escalera | 16 | ciclo distinto o reversible validado; de espaldas |
| E17 | Salida superior de escalera | 16 | termina de pie sobre el centro de la escalera |
| E18 | Soltarse de escalera y comenzar caída | 9 | transición limpia; no incorpora la escalera en el sprite |

### P1 · cierre expresivo e interacción

| # | Pack | Fotogramas | Uso |
| ---: | --- | ---: | --- |
| E19 | Interactuar/empujar/accionar | 16 | palancas, interruptores y mecanismos |
| E20 | Recoger objeto | 16 | llave o pieza funcional; manos legibles |
| E21 | Recoger estrella/premio | 16 | gesto corto que no bloquea el recorrido |
| E22 | Celebración | 16 | meta y refuerzo positivo |
| E23 | Acariciar a Scar | 16 | agacharse y acariciar; ambos apoyados y sin desplazarse |
| E24 | Reaccionar cuando Scar se arrima | 16 | mirar abajo y sonreír; interrumpible |

## Scar · lista completa

| # | Pack | Fotogramas | Requisito visual |
| ---: | --- | ---: | --- |
| S01 | Reposo, respiración, orejas y cola | 16 | patas apoyadas; cola completa en todo momento |
| S02 | Andar | 16 | apoyo felino creíble, sin patinar |
| S03 | Correr | 16 | cuerpo bajo y elástico; bucle limpio |
| S04 | Salto vertical | 16 | impulso, ápice, caída y aterrizaje |
| S05 | Salto hacia delante | 16 | sin root motion dentro del lienzo |
| S06 | Salto largo corriendo | 16 | continuidad con S03 |
| S07 | Caída y aterrizaje | 16 | no flota ni cambia de tamaño |
| S08 | Entrada a postura baja | 9 | reduce altura sin desplazar patas |
| S09 | Paso bajo/arrastre | 16 | altura baja estable; avance y retroceso válidos |
| S10 | Salida de postura baja | 9 | solo se levanta con espacio físico |
| S11 | Esperar/quedarse | 16 | postura atenta, sin bloquear interfaz |
| S12 | Confirmar una orden | 9 | gesto breve y claro |
| S13 | Aviso de peligro | 16 | sobresalto + alerta; icono `!` sigue siendo externo |
| S14 | Observar/localizar | 16 | buscar con cabeza, orejas y olfato |
| S15 | Indicar dirección | 16 | mirada y pata señalan una ruta |
| S16 | Dar pista/interrogación | 16 | gesto de atención; icono `?` externo |
| S17 | Golpe de pata | 16 | golpe corto, cuerpo no se traslada |
| S18 | Activar placa por apoyo | 16 | peso visible y hold estable |
| S19 | Activar mecanismo con salto | 16 | salto/apoyo legible, sin mover la física |
| S20 | Acudir a un punto/confirmar llegada | 9 | usa locomoción y finaliza con respuesta visual |
| S21 | Recibir caricia | 16 | animación coordinable con E23 |
| S22 | Arrimarse a la pierna de Eren | 16 | bucle afectivo interrumpible |
| S23 | Entrar en hueco felino | 16 | cuerpo y cola desaparecen progresivamente por la salida visible |
| S24 | Salir de hueco felino | 16 | inversa específica, sin aparición brusca |
| S25 | Trepar escalera de espaldas | 16 | patas alternas y cola equilibrando |
| S26 | Bajar escalera de espaldas | 16 | descenso controlado |
| S27 | Alerta/bufido/ahuyentar | 16 | silueta erizada, sin ataque automático |
| S28 | Daño/sobresalto | 9 | reacción breve; Scar no pierde corazones |
| S29 | Recuperación/reentrada segura | 16 | termina caminando, nunca aparece dentro de un sólido |

## Araña/guardián actual · lista completa

| # | Pack | Fotogramas | Uso |
| ---: | --- | ---: | --- |
| G01 | Reposo | 16 | espera del guardián |
| G02 | Patrulla | 16 | ciclo horizontal estable |
| G03 | Alerta | 9 | anticipación amarilla; exclamación externa |
| G04 | Preparación de ataque | 16 | telegraph inequívoco |
| G05 | Embestida/ataque | 16 | ventana ofensiva visible; sin mover el collider por arte |
| G06 | Recibir golpe | 9 | impacto claro, recuperación enlazable |
| G07 | Recuperarse | 16 | retorno a patrulla/persecución |
| G08 | Derrota | 16 | termina inmóvil; deja caer la llave mediante lógica externa |

## Fauna ambiental opcional para una segunda pasada

R23 ya incluye fauna procedural funcional, por lo que estos packs no bloquean el tutorial. Si quieres reemplazarla por arte final, produce ciclos de 4–8 fotogramas, sin collider:

- rana: reposo, parpadeo y salto corto;
- mariposa: aleteo;
- luciérnaga: pulso luminoso;
- caracol: avance lento;
- insecto pequeño: vuelo irregular;
- ave lejana: aleteo y posado;
- ardilla: reposo y carrera corta;
- conejo: reposo y salto;
- pez: nado y giro.

## Nombres y estructura de entrega

```text
LUDO_PERSONAJES_M1_R01/
  01_EREN/E01_IDLE/frames/eren-idle-000.png
  02_SCAR/S01_IDLE/frames/scar-idle-000.png
  03_GUARDIAN/G01_IDLE/frames/guardian-idle-000.png
  04_FAUNA_OPCIONAL/
  PREVIEWS/
  MANIFEST.json
  SHA256SUMS.txt
```

El manifiesto debe incluir por pack: maestro usado, prompt, modelo/estilo de Ludo, número de fotogramas, dimensiones, pivote, línea de suelo, fps recomendado, orientación, alfa y SHA-256.

## Control antes de pasarme los archivos

- ningún fotograma conserva marca de agua, fondo negro o damero;
- cabeza, pies, patas y cola completos en todos los frames;
- identidad idéntica entre reposo, locomoción, salto, golpes y escalera;
- no hay desplazamiento del pivote ni suelo variable;
- ninguna escalera, icono, polvo o fondo está pintado dentro del personaje;
- los loops de caminar y correr alternan piernas/patas de verdad;
- los ZIP se abren y contienen los PNG, no accesos directos vacíos.

Estado de estos assets hasta validarlos: `CANDIDATE_NO_INTEGRAR_PENDIENTE_APROBACION_VISUAL_Y_QA_TECNICO`.
