# Cómo subir R20 + R21 + R22 + R23 a GitHub

No tienes que crear ni compilar la APK manualmente. La APK adjunta sirve para el playtest directo. GitHub se usa para guardar la candidata y producir una segunda APK reproducible mediante Actions.

No subas la APK al repositorio. Usa el contenedor `SUBIR_A_GITHUB_R20_R21_R22_R23.zip`, descomprímelo primero y sube solamente sus nueve archivos.

## Rama

`codex/gb02-r23-atmosphere-audio-20260829`

## Punto de partida

Como no subiste R20, R21 ni R22, parte de la revisión del repositorio que ya contiene la cadena exacta hasta R19:

`BASE + R05 + R07 + R08 + R09 + R10 + R11 + R14 + R15 + R16 + R17 + R18 + R19`

R12 y R13 deben seguir archivados y fuera de la cadena aplicada. Si el repositorio no llega exactamente a R19, detente antes de ejecutar el workflow.

## Archivos del contenedor

- `.github/workflows/build-apk.yml`
- `Eren-GitHub-Actualizacion-R20.zip`
- `Eren-GitHub-Actualizacion-R20.zip.sha256`
- `Eren-GitHub-Actualizacion-R21.zip`
- `Eren-GitHub-Actualizacion-R21.zip.sha256`
- `Eren-GitHub-Actualizacion-R22.zip`
- `Eren-GitHub-Actualizacion-R22.zip.sha256`
- `Eren-GitHub-Actualizacion-R23.zip`
- `Eren-GitHub-Actualizacion-R23.zip.sha256`

## Pasos en github.com

1. Descarga `SUBIR_A_GITHUB_R20_R21_R22_R23.zip` y descomprímelo en tu ordenador. No intentes abrir o subir el contenedor sin extraerlo.
2. Abre tu repositorio en GitHub y selecciona la rama o commit que contiene R19.
3. Abre el selector de ramas, escribe `codex/gb02-r23-atmosphere-audio-20260829` y pulsa **Create branch**.
4. Ya dentro de esa rama, pulsa **Add file → Upload files**.
5. Arrastra los nueve elementos. La carpeta `.github` debe conservar la ruta `.github/workflows/build-apk.yml`.
6. Mensaje de commit: `R20-R23: arte, correcciones, decoración, atmósfera y audio`.
7. Selecciona **Commit directly to codex/gb02-r23-atmosphere-audio-20260829**.
8. Abre **Actions → Compilar candidata GB02 R04 R23**.
9. Si no se ejecutó automáticamente, pulsa **Run workflow**, selecciona la rama R23 y confirma.
10. Cuando termine en verde, abre la ejecución y descarga el artifact `Eren-GB02-R04-R23-APK-CANDIDATE`.

## Qué no hacer

- No hagas merge a `main`.
- No crees una release.
- No subas `EREN_GB02_R23_APK_CANDIDATE.apk` al repositorio.
- No extraigas ni combines manualmente los ZIP incrementales.
- No declares `GITHUB_VERIFICADO` hasta comprobar el commit, los tests verdes y el artifact descargado.

Si Android rechaza la APK descargada de Actions al actualizar la candidata local, desinstala primero la candidata anterior. Los builds debug de entornos distintos pueden usar certificados distintos; desinstalar borra únicamente los datos locales de prueba de la aplicación.
