# Entrega GB02 R04 · R23

## APK directa

Archivo: `EREN_GB02_R23_APK_CANDIDATE.apk`

- Tamaño: 30.866.356 bytes.
- SHA-256: `c3e32d0312a59601e08ec613995a1ecb4350d4b5b3f02af465230af4d831ce15`.
- Paquete: `com.juaneren.lector`.
- VersionCode: `47`.
- VersionName: `46.0.0-atmosphere-audio-gb02-r04-candidate-r23`.
- Firma: APK Signature Scheme v2, certificado debug temporal, firma y digest verificados.

La APK local reutiliza la envoltura Android R22 verificada porque R23 solo cambia el contenido WebView. Se han sustituido los assets R23 exactos, actualizado el manifiesto y firmado de nuevo. GitHub Actions compilará el mismo código fuente con Gradle.

## Antes de instalar

Si aparece **“problema con el paquete”** o **“la aplicación no se instaló”**, desinstala la candidata R22/R21 que ya tengas y vuelve a instalar R23. La firma debug temporal puede ser distinta. Esto elimina el progreso/log local de prueba, no los archivos descargados.

## Qué probar en el móvil

1. Recorre el inicio y comprueba que el árbol/ruina entra en el terreno mediante raíces y musgo, sin una pared de baldosas.
2. Verifica que no se ven rombos azules de checkpoint.
3. Observa que FAR, MID, NEAR y el primer plano frontal se mueven a velocidades distintas sin tapar la ruta.
4. Mira el agua: ondas, reflejo, caústicas, espuma, burbujas y peces.
5. Comprueba aves, mariposas, ranas, luciérnagas, hojas y vegetación en movimiento.
6. Escucha bosque, viento, agua, aves, música tenue y eventos. Prueba el botón 🔊/🔇.
7. Abre el panel QA y compara `FX: completos` con `FX: reducidos`.
8. Recorre ambas verjas, escalera, paso bajo, puente y meta para confirmar que nada funcional cambió.
9. Comparte el log R23 al terminar.

## Archivos auxiliares

- `GUIA_LUDO_PERSONAJES_R23.md`: lista completa de animaciones limpias a producir.
- `PLAN_AUDIO_Y_LICENCIAS_R23.md`: sonidos, música, fuentes y registro de licencias.
- `MATRIZ_QA_R23.md`: PASS/PENDING y evidencias.
- `INSTRUCCIONES_GITHUB_R23.md`: subida desde R19 sin tocar `main`.
- `PREVIA_R23.png`: hoja de contacto de la escena.

Estado: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST` · `gameReady=false` · `githubVerified=false`.
