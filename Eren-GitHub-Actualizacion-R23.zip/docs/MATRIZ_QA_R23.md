# Matriz QA · GB02 R04 · R23

Aplicación: `46.0.0-atmosphere-audio-gb02-r04-candidate-r23` (`versionCode 47`)

| Caso | Estado | Evidencia |
| --- | --- | --- |
| Fuente exacta R22 recuperada | PASS | cadena incremental y APK R22 verificadas antes de editar |
| Contrato GB02 R04 completo | PASS | `docs/evidencias-r23/GB02_R04_QA_MATRIX.json` |
| Geometría, colliders, física y navegación modificados por R23 | PASS: ninguno | hash estructural `e7c80a…bd0b` |
| Rombos azules de checkpoint ocultos | PASS técnico | dibujo encerrado en `if(debug)`; lógica de respawn preservada |
| Inicio/árbol unido al terreno | PASS técnico | `00_INICIO_ARBOL_INTEGRADO_891x411.png` |
| FAR/MID/NEAR/FOREGROUND independientes | PASS técnico | 4 capas, velocidades 0,12/0,30/0,52/0,82; sin collider |
| Agua viva | PASS técnico | ondas, reflejo, caústicas, espuma, peces y burbujas; `01_AGUA_VIVA_21x9.png` |
| Fauna animada | PASS técnico | aves, mariposas, ranas y peces; activación puntual |
| Vegetación y partículas R22 | PASS | preservadas sin repetición automática ni elemento bajo estrella |
| Modo de efectos reducidos | PASS técnico | ajuste persistente y respeto a `prefers-reduced-motion` |
| Audio ambiental y música procedural | PASS técnico | Web Audio original, 0 archivos externos, mute persistente |
| Audio al segundo plano/salida | PASS técnico | se detiene y se reanuda bajo condición segura |
| Caminar, correr+saltar y salto vertical | PASS automatizado | regresión GB02 |
| Caja: dos golpes, cuatro estados, sin rotación | PASS automatizado | regresión GB02 |
| Ataque de pie, agachado y aéreo | PASS automatizado | regresión GB02 |
| Primera verja y salida segura de Scar | PASS 20/20 | 0 fallos, 0 recuperaciones |
| Segunda verja, llave + acción y columna | PASS automatizado | collider liberado al final; no bypass |
| Escalera x=43,5, salida x=44 | PASS 20/20 | 0 fallos; solo U4 ignorado durante trepa |
| Paso bajo exclusivo de Scar | PASS 20/20 | 20 órdenes; 20 pasos bajos; 0 saltos/recuperaciones |
| Guardián, dos golpes y consecuencias atómicas | PASS automatizado | llave → acción → verja/escalera/Scar |
| Puente 0,6 s sin collider y sólido permanente | PASS 20/20 | 20 despliegues; 0 autoactivaciones |
| Pincho, estrella, meta dual y checkpoints | PASS automatizado | funciones R21/R22 preservadas |
| Escalera con alfa real | PASS | `ladder-alpha-r21-smoke.mjs`; SHA R21 preservado |
| Capturas 16:9, 19.5:9 y 21:9 | PASS técnico | 11 capturas + hoja de contacto |
| Integridad ZIP de APK | PASS | 370 entradas; `unzip -t` sin errores |
| APK Signature Scheme v2 | PASS criptográfico | firma RSA/SHA-256, certificado y digest de contenido verificados |
| `versionCode`/`versionName` del manifiesto | PASS | 47 / R23 verificados en XML binario |
| Instalación y escucha en Samsung SM-S928B | PENDING | requiere desinstalar candidata previa si la firma debug difiere |
| Playtest visual y de rendimiento R23 | PENDING | comprobar agua, foreground, fauna, audio y FX reducidos en dispositivo |
| Build limpia de GitHub Actions | PENDING | no declarar `GITHUB_VERIFICADO` hasta revisar workflow y artifact |

El test `tests/graybox-smoke.mjs` pertenece a una revisión antigua anterior al contrato GB02 R04 y espera campos de laboratorio eliminados. La regresión autoritativa actual es `tests/gb02-r04-smoke.mjs`, que da PASS.

El pase no declara `GAME_READY` ni `GITHUB_VERIFICADO`. Cierre: `APK_CANDIDATE_PENDING_DEVICE_PLAYTEST`.
