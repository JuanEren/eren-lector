# Plan de música, ambiente y sonido · GB02

## Qué incluye ya R23

R23 incorpora audio original generado en tiempo real con Web Audio:

- cama de bosque y viento filtrado;
- agua cuya presencia aumenta al acercarse la cámara;
- llamadas de aves espaciadas;
- pad musical ambiental muy tenue;
- salto, daño, golpes y rotura de caja, apertura de rejas, anclaje del puente, estrella y meta;
- botón de silencio y modo de efectos reducidos.

No hay archivos musicales ni efectos de terceros dentro de la APK R23. Por tanto, este pase no añade obligaciones de atribución ni redistribuye bibliotecas externas.

## Fuentes recomendadas para el pase de sonido final

| Fuente | Uso recomendado | Regla antes de integrar |
| --- | --- | --- |
| Kenney | UI, impactos, pasos y mecanismos | Preferir paquetes indicados como CC0; guardar página y versión del pack |
| Sonniss GDC Bundle | ambiente, agua, bosque, mecanismos, fauna | Se permite sincronizar en un juego; no redistribuir los WAV sueltos |
| Pixabay | música ambiental o stingers concretos | Guardar URL, autor, fecha y copia de la licencia aplicable al descargar |
| Freesound | sonidos muy específicos que falten | Comprobar la licencia de cada archivo; priorizar CC0 o CC BY |

Fuentes oficiales:

- Kenney: <https://kenney.nl/support>
- Sonniss GDC License: <https://sonniss.com/gdc-bundle-license/>
- Sonniss Free GDC Bundle: <https://gdc.sonniss.com/>
- Pixabay License Summary: <https://pixabay.com/service/license-summary/>
- Freesound FAQ: <https://freesound.org/help/faq/>

No usar material CC BY-NC, licencias no comerciales, material sin autor identificable ni audio extraído de otros juegos o vídeos. CC BY solo se integra si se prepara la atribución exigida. No aceptar una etiqueta genérica de “royalty free” sin leer la licencia concreta.

## Lista completa a buscar

### Ambientes y música

- bosque fantástico diurno, loop de 2–3 minutos;
- viento suave entre copas, loop separado;
- agua/arroyo, loop separado y sin golpes periódicos dominantes;
- aves e insectos en one-shots espaciados;
- música de exploración calmada, sin melodía infantil invasiva;
- capa de tensión breve para el guardián;
- stinger de estrella;
- stinger de meta/reunión con Scar;
- transición musical opcional hacia la continuación del nivel.

### Eren

- pasos sobre hierba/tierra;
- pasos sobre piedra/ruina;
- pasos sobre madera/puente;
- carrera para cada superficie o variaciones de paso;
- salto, caída y aterrizaje;
- agacharse y arrastrarse;
- patada: whoosh y contacto;
- daño, recuperación y derrota;
- agarre, subida, bajada y salida de escalera;
- recoger llave, estrella y premio;
- interacción con mecanismo;
- celebración.

### Scar

- pasos suaves y carrera;
- salto y aterrizaje;
- paso bajo/roce;
- maullido de confirmar;
- maullido de esperar;
- maullido de pista;
- alerta/bufido;
- sobresalto y recuperación;
- golpe de pata;
- activación de placa;
- entrada/salida de hueco;
- trepa de escalera;
- ronroneo o respuesta durante caricia.

### Enemigo, mundo y UI

- araña: patrulla, alerta, wind-up, embestida, golpe recibido y derrota;
- caja: primer golpe, segundo golpe, rotura y restos;
- placas e interruptores: pulsar, enclavar y liberar;
- reja: inicio, deslizamiento en piedra y cierre superior;
- puente: despliegue, polvo/piedra y anclaje sólido;
- pincho, caída, agua y salpicadura;
- checkpoint funcional sin señal azul visible;
- llave: aparición y recogida;
- botones principales, panel, respuesta correcta/incorrecta y cierre;
- iconos contextuales de Scar;
- recompensa y meta dual.

## Especificación técnica

- Maestro: WAV, 48 kHz, 24 bit cuando la fuente lo permita.
- Runtime WebView: OGG Vorbis y un respaldo AAC/MP3 solo si la matriz Android lo exige.
- Ambientes y música: loops realmente continuos; comprobar inicio y fin con auriculares.
- Pico máximo recomendado: −1 dBFS.
- Punto de partida de mezcla: música alrededor de −18 LUFS, ambiente alrededor de −22 LUFS y efectos de primer plano alrededor de −16 LUFS; ajustar en dispositivo, no normalizar todo al mismo volumen.
- Voz educativa siempre domina; música y ambiente deben atenuarse durante narración e instrucciones importantes.
- Mantener buses independientes: `music`, `ambience`, `sfx`, `voice` y `scar`.
- Limitar la simultaneidad de fauna y partículas sonoras para no crear ruido continuo.

## Registro de licencia obligatorio

Crear una fila por archivo final con:

```text
id, archivo_original, archivo_runtime, autor, fuente_url, fecha_descarga,
licencia, version_licencia, atribucion_requerida, uso_previsto, sha256
```

Guardar además una copia PDF o HTML de la página/licencia vigente el día de descarga. El ZIP de entrega al programador contiene únicamente los archivos integrables y el registro; nunca incluye una biblioteca completa de terceros.
