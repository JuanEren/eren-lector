# Hoja de ruta tras R23 · cierre del tutorial y continuación

La prioridad es terminar bien el tutorial actual antes de ampliar geometría. El orden evita diseñar nuevas salas sobre personajes o sonido todavía provisionales.

## R24 · personajes definitivos

- integrar únicamente exportaciones Ludo de pago, limpias y aprobadas;
- normalizar lienzo, pivote, suelo y escala;
- sustituir Eren completo, después Scar y finalmente guardián;
- validar todos los enlaces entre estados a tamaño real de móvil;
- no cambiar hitboxes, velocidades, saltos ni navegación para esconder fallos de arte.

## R25 · sonido final

- seleccionar y registrar música/ambientes/efectos con licencia;
- sustituir o complementar el audio procedural por stems curados;
- implementar buses de música, ambiente, SFX, voz y Scar;
- ducking durante narración e instrucciones;
- mezcla y rendimiento en Android.

## R26 · cierre del tutorial

- recorrido completo repetido con personajes y sonido final;
- accesibilidad: FX reducidos, mute/volumen, legibilidad de HUD y señales;
- evidencias 16:9, 19.5:9 y 21:9;
- corrección de regresiones sin rediseñar el nivel;
- solo después del playtest final se estudia pasar de candidata a cierre del tutorial.

## R27 · continuación del nivel

Diseñar primero en documento y graybox, sin contaminar el tutorial validado. Introducir una mecánica principal por tramo:

1. cooperación vertical: Eren habilita una ruta física para Scar;
2. hueco felino visible con entrada y salida conectadas;
3. caja o plataforma móvil como herramienta, no como decoración;
4. pista contextual de Scar que señale una ruta opcional;
5. variación ambiental de agua o lluvia con la misma regla de daño ya conocida;
6. cámara y checkpoint propios del nuevo tramo;
7. cierre con una combinación de dos mecánicas ya enseñadas, no una tercera mecánica nueva.

Cada ampliación necesita contrato de geometría, ruta segura de Scar, puntos de retorno, prueba de cámara y criterios de lectura antes de producir arte final.
