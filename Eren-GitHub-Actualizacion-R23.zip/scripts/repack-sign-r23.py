#!/usr/bin/env python3
"""Repackage the R23 WebView assets over the verified R22 APK and sign with APK v2.

This is an offline fallback for the local candidate. GitHub remains authoritative and
builds the same source with Gradle. The generated certificate is intentionally a
temporary debug certificate; it is never included in the source update ZIP.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import os
import struct
import tempfile
import zipfile
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.oid import NameOID


APK_SIG_MAGIC = b"APK Sig Block 42"
APK_SIG_V2_ID = 0x7109871A
RSA_PKCS1_SHA256_ID = 0x0103
EOCD_SIGNATURE = b"PK\x05\x06"
CHUNK_BYTES = 1024 * 1024


def u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def lp(data: bytes) -> bytes:
    return struct.pack("<I", len(data)) + data


def read_utf16_length(data: bytes, offset: int) -> tuple[int, int]:
    first = u16(data, offset)
    if first & 0x8000:
        second = u16(data, offset + 2)
        return ((first & 0x7FFF) << 16) | second, 4
    return first, 2


def encode_utf16_string(value: str) -> bytes:
    encoded = value.encode("utf-16le")
    length = len(encoded) // 2
    if length > 0x7FFF:
        prefix = struct.pack("<HH", 0x8000 | (length >> 16), length & 0xFFFF)
    else:
        prefix = struct.pack("<H", length)
    return prefix + encoded + b"\x00\x00"


def patch_binary_manifest(data: bytes, old_version: str, new_version: str, version_code: int) -> bytes:
    if u16(data, 0) != 0x0003:
        raise ValueError("AndroidManifest.xml no es un XML binario Android.")
    xml_size = u32(data, 4)
    pool_offset = 8
    if u16(data, pool_offset) != 0x0001:
        raise ValueError("No se encontró el string pool del manifiesto.")
    pool_header_size = u16(data, pool_offset + 2)
    pool_size = u32(data, pool_offset + 4)
    string_count = u32(data, pool_offset + 8)
    style_count = u32(data, pool_offset + 12)
    flags = u32(data, pool_offset + 16)
    strings_start = u32(data, pool_offset + 20)
    styles_start = u32(data, pool_offset + 24)
    if flags & 0x100:
        raise ValueError("El manifiesto usa UTF-8; este candidato esperaba UTF-16.")

    offsets_start = pool_offset + pool_header_size
    string_offsets = [u32(data, offsets_start + i * 4) for i in range(string_count)]
    string_data_start = pool_offset + strings_start
    string_data_end = pool_offset + (styles_start if styles_start else pool_size)
    strings: list[str] = []
    for offset in string_offsets:
        absolute = string_data_start + offset
        length, prefix_size = read_utf16_length(data, absolute)
        begin = absolute + prefix_size
        strings.append(data[begin : begin + length * 2].decode("utf-16le"))

    try:
        version_index = strings.index(old_version)
        version_code_name_index = strings.index("versionCode")
    except ValueError as exc:
        raise ValueError("No se encontraron versionName/versionCode esperados.") from exc
    strings[version_index] = new_version

    rebuilt_offsets: list[int] = []
    rebuilt_strings = bytearray()
    for value in strings:
        rebuilt_offsets.append(len(rebuilt_strings))
        rebuilt_strings.extend(encode_utf16_string(value))
    while len(rebuilt_strings) % 4:
        rebuilt_strings.append(0)

    style_offsets_start = offsets_start + string_count * 4
    style_offsets_end = style_offsets_start + style_count * 4
    styles_data = data[pool_offset + styles_start : pool_offset + pool_size] if styles_start else b""
    new_strings_start = pool_header_size + string_count * 4 + style_count * 4
    new_styles_start = new_strings_start + len(rebuilt_strings) if styles_start else 0
    new_pool_size = new_strings_start + len(rebuilt_strings) + len(styles_data)

    pool = bytearray()
    pool.extend(struct.pack("<HHI", 0x0001, pool_header_size, new_pool_size))
    pool.extend(struct.pack("<IIIII", string_count, style_count, flags, new_strings_start, new_styles_start))
    pool.extend(b"".join(struct.pack("<I", value) for value in rebuilt_offsets))
    pool.extend(data[style_offsets_start:style_offsets_end])
    pool.extend(rebuilt_strings)
    pool.extend(styles_data)

    remainder = bytearray(data[pool_offset + pool_size : xml_size])
    cursor = 0
    version_code_patched = False
    while cursor + 8 <= len(remainder):
        chunk_type = u16(remainder, cursor)
        chunk_header_size = u16(remainder, cursor + 2)
        chunk_size = u32(remainder, cursor + 4)
        if chunk_size < chunk_header_size or cursor + chunk_size > len(remainder):
            raise ValueError("Chunk XML binario inválido.")
        if chunk_type == 0x0102:
            attribute_start = u16(remainder, cursor + 24)
            attribute_size = u16(remainder, cursor + 26)
            attribute_count = u16(remainder, cursor + 28)
            base = cursor + chunk_header_size + attribute_start
            for index in range(attribute_count):
                attr = base + index * attribute_size
                name_index = u32(remainder, attr + 4)
                if name_index == version_code_name_index:
                    data_type = remainder[attr + 15]
                    if data_type not in (0x10, 0x11):
                        raise ValueError("versionCode no tiene tipo entero.")
                    struct.pack_into("<I", remainder, attr + 16, version_code)
                    version_code_patched = True
        cursor += chunk_size
    if not version_code_patched:
        raise ValueError("No se pudo actualizar versionCode.")

    output = bytearray(data[:8])
    output.extend(pool)
    output.extend(remainder)
    struct.pack_into("<I", output, 4, len(output))
    return bytes(output)


def find_eocd(data: bytes) -> int:
    start = max(0, len(data) - 22 - 0xFFFF)
    offset = data.rfind(EOCD_SIGNATURE, start)
    if offset < 0 or offset + 22 > len(data):
        raise ValueError("EOCD ZIP no encontrado.")
    comment_len = u16(data, offset + 20)
    if offset + 22 + comment_len != len(data):
        raise ValueError("EOCD ZIP ambiguo.")
    return offset


def apk_content_digest(section1: bytes, section2: bytes, eocd: bytes) -> bytes:
    chunk_digests: list[bytes] = []
    for section in (section1, section2, eocd):
        for begin in range(0, len(section), CHUNK_BYTES):
            chunk = section[begin : begin + CHUNK_BYTES]
            chunk_digests.append(hashlib.sha256(b"\xA5" + struct.pack("<I", len(chunk)) + chunk).digest())
    return hashlib.sha256(
        b"\x5A" + struct.pack("<I", len(chunk_digests)) + b"".join(chunk_digests)
    ).digest()


def create_debug_identity() -> tuple[rsa.RSAPrivateKey, bytes, bytes]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Eren R23 Debug Candidate")])
    now = dt.datetime.now(dt.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(now + dt.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    public_der = key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return key, cert_der, public_der


def sign_apk_v2(unsigned: bytes) -> tuple[bytes, str]:
    eocd_offset = find_eocd(unsigned)
    central_dir_offset = u32(unsigned, eocd_offset + 16)
    central_dir_size = u32(unsigned, eocd_offset + 12)
    if central_dir_offset + central_dir_size != eocd_offset:
        raise ValueError("ZIP64 o directorio central no estándar no soportado.")

    section1 = unsigned[:central_dir_offset]
    section2 = unsigned[central_dir_offset:eocd_offset]
    digest_eocd = bytearray(unsigned[eocd_offset:])
    struct.pack_into("<I", digest_eocd, 16, len(section1))
    content_digest = apk_content_digest(section1, section2, bytes(digest_eocd))

    key, cert_der, public_der = create_debug_identity()
    digest_record = struct.pack("<I", RSA_PKCS1_SHA256_ID) + lp(content_digest)
    signed_data = lp(lp(digest_record)) + lp(lp(cert_der)) + lp(b"")
    signature = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    signature_record = struct.pack("<I", RSA_PKCS1_SHA256_ID) + lp(signature)
    signer = lp(signed_data) + lp(lp(signature_record)) + lp(public_der)
    v2_value = lp(signer)
    pair = struct.pack("<Q", 4 + len(v2_value)) + struct.pack("<I", APK_SIG_V2_ID) + v2_value
    block_size = len(pair) + 24
    signing_block = struct.pack("<Q", block_size) + pair + struct.pack("<Q", block_size) + APK_SIG_MAGIC

    final_eocd = bytearray(unsigned[eocd_offset:])
    struct.pack_into("<I", final_eocd, 16, central_dir_offset + len(signing_block))
    signed = section1 + signing_block + section2 + bytes(final_eocd)
    cert_sha256 = hashlib.sha256(cert_der).hexdigest()
    return signed, cert_sha256


def read_lp(data: bytes, offset: int) -> tuple[bytes, int]:
    if offset + 4 > len(data):
        raise ValueError("Campo length-prefixed truncado.")
    length = u32(data, offset)
    begin = offset + 4
    end = begin + length
    if end > len(data):
        raise ValueError("Campo length-prefixed fuera de rango.")
    return data[begin:end], end


def verify_apk_v2(apk: bytes) -> tuple[str, str]:
    eocd_offset = find_eocd(apk)
    central_dir_offset = u32(apk, eocd_offset + 16)
    central_dir_size = u32(apk, eocd_offset + 12)
    if central_dir_offset + central_dir_size != eocd_offset:
        raise ValueError("Directorio central APK inválido.")
    if apk[central_dir_offset - 16 : central_dir_offset] != APK_SIG_MAGIC:
        raise ValueError("No se encontró APK Signing Block.")
    block_size = struct.unpack_from("<Q", apk, central_dir_offset - 24)[0]
    block_start = central_dir_offset - block_size - 8
    if block_start < 0 or struct.unpack_from("<Q", apk, block_start)[0] != block_size:
        raise ValueError("Tamaños del APK Signing Block no coinciden.")

    pairs = apk[block_start + 8 : central_dir_offset - 24]
    cursor = 0
    v2_value: bytes | None = None
    while cursor < len(pairs):
        if cursor + 8 > len(pairs):
            raise ValueError("Par de firma truncado.")
        pair_size = struct.unpack_from("<Q", pairs, cursor)[0]
        begin = cursor + 8
        end = begin + pair_size
        if pair_size < 4 or end > len(pairs):
            raise ValueError("Par de firma inválido.")
        pair_id = u32(pairs, begin)
        if pair_id == APK_SIG_V2_ID:
            v2_value = pairs[begin + 4 : end]
        cursor = end
    if v2_value is None:
        raise ValueError("Bloque de firma APK v2 ausente.")

    signer, signer_end = read_lp(v2_value, 0)
    if signer_end != len(v2_value):
        raise ValueError("Se esperaba un único firmante v2.")
    signed_data, offset = read_lp(signer, 0)
    signatures, offset = read_lp(signer, offset)
    public_key_der, offset = read_lp(signer, offset)
    if offset != len(signer):
        raise ValueError("Datos sobrantes en el firmante v2.")

    digests, sd_offset = read_lp(signed_data, 0)
    certificates, sd_offset = read_lp(signed_data, sd_offset)
    _, sd_offset = read_lp(signed_data, sd_offset)
    if sd_offset != len(signed_data):
        raise ValueError("Datos firmados v2 inválidos.")
    digest_record, end = read_lp(digests, 0)
    if end != len(digests) or u32(digest_record, 0) != RSA_PKCS1_SHA256_ID:
        raise ValueError("Algoritmo de digest v2 inesperado.")
    expected_digest, end = read_lp(digest_record, 4)
    if end != len(digest_record):
        raise ValueError("Registro de digest v2 inválido.")
    cert_der, end = read_lp(certificates, 0)
    if end != len(certificates):
        raise ValueError("Cadena de certificados v2 inesperada.")
    signature_record, end = read_lp(signatures, 0)
    if end != len(signatures) or u32(signature_record, 0) != RSA_PKCS1_SHA256_ID:
        raise ValueError("Algoritmo de firma v2 inesperado.")
    signature, end = read_lp(signature_record, 4)
    if end != len(signature_record):
        raise ValueError("Registro de firma v2 inválido.")

    cert = x509.load_der_x509_certificate(cert_der)
    cert_public_der = cert.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if cert_public_der != public_key_der:
        raise ValueError("Clave pública y certificado v2 no coinciden.")
    cert.public_key().verify(signature, signed_data, padding.PKCS1v15(), hashes.SHA256())

    digest_eocd = bytearray(apk[eocd_offset:])
    struct.pack_into("<I", digest_eocd, 16, block_start)
    actual_digest = apk_content_digest(
        apk[:block_start],
        apk[central_dir_offset:eocd_offset],
        bytes(digest_eocd),
    )
    if actual_digest != expected_digest:
        raise ValueError("Digest de contenido APK v2 inválido.")
    return hashlib.sha256(cert_der).hexdigest(), hashlib.sha256(apk).hexdigest()


def aligned_zipinfo(source: zipfile.ZipInfo, current_offset: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(source.filename, date_time=source.date_time)
    info.compress_type = source.compress_type
    info.comment = source.comment
    info.internal_attr = source.internal_attr
    info.external_attr = source.external_attr
    info.create_system = source.create_system
    info.flag_bits = source.flag_bits & ~0x08
    info.extra = b""
    if info.compress_type == zipfile.ZIP_STORED:
        name_len = len(info.filename.encode("utf-8"))
        pad_len = (-((current_offset + 30 + name_len + 4) % 4)) % 4
        info.extra = struct.pack("<HH", 0xFFFF, pad_len) + b"\x00" * pad_len
    return info


def build_unsigned(base_apk: Path, web_root: Path, output: Path, old_version: str, new_version: str, version_code: int) -> None:
    current_files = {
        path.relative_to(web_root).as_posix(): path
        for path in web_root.rglob("*")
        if path.is_file()
    }
    seen: set[str] = set()
    with zipfile.ZipFile(base_apk, "r") as source, output.open("wb") as raw:
        with zipfile.ZipFile(raw, "w", allowZip64=False) as target:
            for source_info in source.infolist():
                name = source_info.filename
                data = source.read(name)
                if name == "AndroidManifest.xml":
                    data = patch_binary_manifest(data, old_version, new_version, version_code)
                elif name.startswith("assets/www/"):
                    relative_name = name.removeprefix("assets/www/")
                    replacement = current_files.get(relative_name)
                    if replacement:
                        data = replacement.read_bytes()
                        seen.add(relative_name)
                info = aligned_zipinfo(source_info, raw.tell())
                target.writestr(info, data, compress_type=info.compress_type, compresslevel=9)
            for relative_name, path in sorted(current_files.items()):
                if relative_name in seen:
                    continue
                name = f"assets/www/{relative_name}"
                source_info = zipfile.ZipInfo(name, date_time=(2026, 8, 29, 1, 1, 0))
                source_info.compress_type = zipfile.ZIP_DEFLATED
                info = aligned_zipinfo(source_info, raw.tell())
                target.writestr(info, path.read_bytes(), compress_type=info.compress_type, compresslevel=9)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-apk", required=True, type=Path)
    parser.add_argument("--web-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--old-version", required=True)
    parser.add_argument("--new-version", required=True)
    parser.add_argument("--version-code", required=True, type=int)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="eren-r23-apk-") as temp_dir:
        unsigned_path = Path(temp_dir) / "unsigned.apk"
        build_unsigned(
            args.base_apk,
            args.web_root,
            unsigned_path,
            args.old_version,
            args.new_version,
            args.version_code,
        )
        signed, cert_sha256 = sign_apk_v2(unsigned_path.read_bytes())
        args.output.write_bytes(signed)
    verified_cert_sha256, verified_apk_sha256 = verify_apk_v2(args.output.read_bytes())
    if verified_cert_sha256 != cert_sha256:
        raise ValueError("El certificado verificado no coincide con el generado.")
    with zipfile.ZipFile(args.output, "r") as archive:
        corrupt_entry = archive.testzip()
        if corrupt_entry:
            raise ValueError(f"Entrada ZIP corrupta: {corrupt_entry}")
    print(
        f"APK={args.output}\n"
        f"SIZE={args.output.stat().st_size}\n"
        f"SHA256={verified_apk_sha256}\n"
        f"CERT_SHA256={cert_sha256}\n"
        "SIGNATURE=APK_SIGNATURE_SCHEME_V2_DEBUG_VERIFIED\n"
        "ZIP_INTEGRITY=PASS\n"
    )


if __name__ == "__main__":
    main()
