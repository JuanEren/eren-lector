import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../app/src/main/assets/www/graybox-game.js', import.meta.url), 'utf8');
const html = await readFile(new URL('../app/src/main/assets/www/index.html', import.meta.url), 'utf8');
const css = await readFile(new URL('../app/src/main/assets/www/game.css', import.meta.url), 'utf8');
const gradle = await readFile(new URL('../app/build.gradle.kts', import.meta.url), 'utf8');

if (!source.includes("APP_VERSION='46.0.0-atmosphere-audio-gb02-r04-candidate-r23'") ||
    !source.includes("LOG_VERSION='GB02-R04-PLAYTEST-R23-v1'") ||
    !gradle.includes('versionCode = 47') ||
    !gradle.includes('versionName = "46.0.0-atmosphere-audio-gb02-r04-candidate-r23"')) {
  throw new Error('Versionado R23 desalineado.');
}

const buildGraybox = source.match(/function buildGraybox\([\s\S]*?\n}\n\nfunction buildLab/)?.[0];
const geometrySha = buildGraybox && createHash('sha256').update(buildGraybox).digest('hex');
if (geometrySha !== 'e7c80acfd88ddff0caf091abfb72af7db6950e4cea6c8986c913f5b350aabd0b') {
  throw new Error(`La geometría funcional cambió en R23: ${geometrySha}.`);
}

const requiredTokens = [
  "packageId:'ATMOSFERA_VIVA_GB02_R23_CANDIDATE'",
  "scope:'VISUAL_AND_AUDIO_ONLY'",
  'geometryChanged:false,collidersChanged:false,physicsChanged:false,navigationChanged:false',
  "layers:['FAR','MID','NEAR','FOREGROUND']",
  "waterRenderer:'CANVAS_GRADIENT_WAVES_CAUSTICS_FOAM_BUBBLES'",
  "animatedFauna:['background_birds','butterflies','frogs','fish']",
  "audio:{source:'ORIGINAL_PROCEDURAL_WEB_AUDIO',thirdPartyFiles:0",
  'function drawR23AtmosphericLight(ctx,draw)',
  'function drawR23BackgroundFauna(ctx,draw)',
  'function drawR23StartTreeBlend(ctx,draw)',
  'function drawR23DecorativeFauna(ctx,draw)',
  'function drawR23ForegroundParallax(ctx,draw)',
  'function drawR23Water(ctx,h,draw)',
  'drawR23Water(ctx,h,draw)',
  'function startGameAudio()',
  'function stopGameAudio()',
  'function playGameEventSound(type)',
  'function toggleReducedEffects()',
  "if(debug)for(const checkpoint of sim.world.checkpoints)",
];
for (const token of requiredTokens) if (!source.includes(token)) throw new Error(`Falta componente R23: ${token}`);

if (!html.includes('id="toggleGameAudio"') || !html.includes('id="toggleEffects"') || !css.includes('.audio-toggle')) {
  throw new Error('Faltan controles accesibles de audio o efectos R23.');
}
if (source.includes('checkpointLogicChanged:true') || source.includes('r23ColliderChanges:true')) {
  throw new Error('R23 altera checkpoints o colliders.');
}

const render = source.match(/function render\(\)\{[\s\S]*?\n}\n\nfunction updateHud/)?.[0] || '';
const order = [
  'drawA05Parallax(ctx,draw)',
  'drawR23AtmosphericLight(ctx,draw)',
  'drawStartCliff(ctx,draw)',
  'drawR23StartTreeBlend(ctx,draw)',
  'drawR23DecorativeFauna(ctx,draw)',
  "drawCharacter(ctx,sim.scar,'scar'",
  'drawR23ForegroundParallax(ctx,draw)',
].map(token => render.indexOf(token));
if (order.some(index => index < 0) || order.some((index, position) => position && index <= order[position - 1])) {
  throw new Error(`Orden de profundidad R23 incorrecto: ${order.join(',')}.`);
}

console.log(JSON.stringify({
  result: 'PASS', revision: 'R23', version: '46.0.0-atmosphere-audio-gb02-r04-candidate-r23',
  geometrySha256: geometrySha, geometryChanged: false, collidersChanged: false, physicsChanged: false,
  parallaxLayers: 4, fauna: ['birds', 'butterflies', 'frogs', 'fish'], water: 'CANVAS_SHADER_LIKE',
  audio: 'ORIGINAL_PROCEDURAL_WEB_AUDIO', thirdPartyAudioFiles: 0, reducedEffectsOption: true,
  checkpointsNormalBuild: 'HIDDEN', gameReady: false,
}));
