# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 23 · Graybox funcional 01 · cooperación sin orden fijo y retorno bajo de Scar

El premio de lectura incorpora dos escenas de validación en horizontal:

- `GB_M1_01_UMBRAL`: tramo corto con caja inferior obligatoria, pilar vertical `U0`, salto, paso agachado, puzle cooperativo de Scar y Eren, ruta opcional con estrella, agua, daño, retorno y meta.
- `LAB_MOV_01`: seis estaciones para medir velocidad, salto vertical, hueco horizontal, colliders, seguimiento de Scar y daño/retorno.
- Física fija a 60 Hz, posiciones en módulos, aceleración/frenada, salto variable, *coyote time* y búfer de salto.
- La entrada distingue una caja marrón rompible de `1 × 1` abajo y un pilar gris permanente `U0_VERTICAL` arriba. Tras romper la caja, el hueco de 1 módulo solo se atraviesa agachado; el pilar no parece ni actúa como caja.
- La ruta inferior G1→G2 tiene ahora un hueco de 1,5 módulos: ya no se cruza andando y exige un salto corto desde un apoyo completo. U1 conserva 1,5 módulos libres en el borde de salida; la ruta alta sigue siendo opcional y el canal U1→U2 mantiene 2 módulos.
- La huella deja de ser decorativa: solo Scar puede mantenerla activa. La palanca de Eren puede activarse antes o después de la placa; queda visiblemente lista y la compuerta solo se retira cuando coinciden ambas condiciones. La apertura queda enclavada para poder llamar a Scar y continuar juntos.
- El agua mide `4` módulos y exige `CORRER + SALTAR`; los pinchos muestran dos puntas en `1` módulo, pero su collider interior deja margen para superarlos andando.
- Scar tiene movimiento, salto, descenso y recuperación propios; no copia la coordenada vertical de Eren. Además del enlace largo sobre el agua, incorpora un retorno físico bajo G2→G1 y vuelve por debajo de U1/`TECHO_BAJO` en lugar de rebotar hacia la ruta superior.
- La orden de placa comprueba posición horizontal, altura y apoyo correctos. Eren sobre la placa no la activa; la palanca sí se arma de forma independiente, pero la compuerta espera a Scar. Scar adopta automáticamente su postura baja al atravesar el túnel en ambos sentidos.
- Controles táctiles simultáneos, teclado y mando Android. La botonera táctil forma un rombo: Scar azul arriba, Correr verde a la izquierda, Acción roja a la derecha y Saltar amarillo abajo. `A` salta, `X/B` actúa, `R1/R2` corre y `Y/L1` ordena a Scar.
- Acceso directo desde la primera pantalla: durante el playtest no hace falta completar un cuento ni gastar una pieza.
- Ajuste vivo de andar, correr, impulso, gravedad, desnivel y hueco.
- Registro local del playtest con métricas y eventos. Conserva hasta diez intentos con actividad, excluye aperturas vacías y registra el orden de resolución, activación/liberación de placa, palanca, apertura de compuerta y retorno bajo de Scar, además de permitir copiar el JSON completo o un resumen compacto.

La lectura y los menús siguen en vertical. El juego cambia a horizontal al entrar y restaura vertical al salir. El progreso de lectura no se modifica ni se consume durante el playtest.

En la primera pantalla, pulsa **Probar juego**. Dentro del panel lateral, **Compartir registro** abre el menú de Android y **Ver registro** permite copiar el registro completo o **Copiar resumen** para enviar solo las métricas y anomalías relevantes. La velocidad inicial de Eren al correr permanece fijada en **6,0 módulos/s**.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
