# Eren: Leo y entiendo

Aplicación Android de lectura y comprensión lectora paso a paso.

## Versión 20 · Graybox funcional 01 · entrada obligatoria y margen de salto

El premio de lectura incorpora dos escenas de validación en horizontal:

- `GB_M1_01_UMBRAL`: tramo corto con barrera de caja vertical obligatoria, salto, paso agachado, orden a Scar, ruta opcional con estrella, agua, daño, retorno y meta.
- `LAB_MOV_01`: seis estaciones para medir velocidad, salto vertical, hueco horizontal, colliders, seguimiento de Scar y daño/retorno.
- Física fija a 60 Hz, posiciones en módulos, aceleración/frenada, salto variable, *coyote time* y búfer de salto.
- La barrera vertical de la entrada no se puede saltar ni usar como plataforma: desaparece al romperla con `ACCIÓN` y deja 2,5 módulos de preparación antes del primer hueco.
- El agua mide `4` módulos y exige `CORRER + SALTAR`; los pinchos miden `0,5` y permiten un salto normal andando con margen.
- Scar tiene movimiento, salto, descenso y recuperación propios; no copia la coordenada vertical de Eren. El agua usa un enlace contextual de salto largo y la meta espera una reunión física real antes de recurrir a una recuperación de seguridad.
- La orden de placa comprueba posición horizontal, altura y apoyo correctos. Scar adopta automáticamente su postura baja al atravesar el túnel.
- Controles táctiles simultáneos, teclado y mando Android. La botonera táctil forma un rombo: Scar azul arriba, Correr verde a la izquierda, Acción roja a la derecha y Saltar amarillo abajo. `A` salta, `X/B` actúa, `R1/R2` corre y `Y/L1` ordena a Scar.
- Acceso directo desde la primera pantalla: durante el playtest no hace falta completar un cuento ni gastar una pieza.
- Ajuste vivo de andar, correr, impulso, gravedad, desnivel y hueco.
- Registro local del playtest con métricas y eventos. Conserva hasta diez intentos con actividad, excluye aperturas vacías y permite copiar el JSON completo o un resumen compacto.

La lectura y los menús siguen en vertical. El juego cambia a horizontal al entrar y restaura vertical al salir. El progreso de lectura no se modifica ni se consume durante el playtest.

En la primera pantalla, pulsa **Probar juego**. Dentro del panel lateral, **Compartir registro** abre el menú de Android y **Ver registro** permite copiar el registro completo o **Copiar resumen** para enviar solo las métricas y anomalías relevantes. La velocidad inicial de Eren al correr permanece fijada en **6,0 módulos/s**.

## Descargar la APK

Abre **Actions**, selecciona la ejecución más reciente de **Compilar APK** y descarga **Eren-Leo-y-entiendo-APK**.

## Características

- Lectura por frases con voz española lenta.
- Resaltado durante la lectura y modo silábico.
- Preguntas de comprensión con dos opciones.
- Refuerzo positivo mediante estrellas.
- Sin publicidad, cuentas, analítica ni transmisión de datos.
