plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }
}
