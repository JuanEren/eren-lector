plugins { id("com.android.application") }
android {
    namespace = "com.juaneren.lector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.juaneren.lector"
        minSdk = 24
        targetSdk = 35
        versionCode = 20
        versionName = "20.0.0-graybox-gate-hazard-margin"
    }
}
