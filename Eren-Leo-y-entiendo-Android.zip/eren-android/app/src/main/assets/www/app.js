const activities=[
 {text:'Nico lleva su coche rojo hasta la línea de salida.',syll:'Ni-co lle-va su co-che ro-jo has-ta la lí-ne-a de sa-li-da.',q:'¿De qué color es el coche de Nico?',a:['Rojo','Azul'],ok:0},
 {text:'Antes de arrancar, Nico se pone el casco para estar seguro.',syll:'An-tes de a-rran-car, Ni-co se po-ne el cas-co pa-ra es-tar se-gu-ro.',q:'¿Por qué se pone el casco?',a:['Para estar seguro','Para dormir'],ok:0},
 {text:'Una tortuga cruza la pista y Nico frena con cuidado.',syll:'U-na tor-tu-ga cru-za la pis-ta y Ni-co fre-na con cui-da-do.',q:'¿Qué hace Nico al ver la tortuga?',a:['Acelera','Frena'],ok:1},
 {text:'La tortuga llega al jardín y Nico continúa contento la carrera.',syll:'La tor-tu-ga lle-ga al jar-dín y Ni-co con-ti-nú-a con-ten-to la ca-rre-ra.',q:'¿Cuándo continúa Nico la carrera?',a:['Cuando la tortuga está a salvo','Antes de que cruce'],ok:0}
];
let index=0,stars=0,syllableMode=false,answered=false;
const $=id=>document.getElementById(id),sections=['welcome','lesson','finish'];
function show(id){sections.forEach(s=>$(s).classList.toggle('hidden',s!==id))}
function renderSentence(text){$('sentence').innerHTML=text.split(' ').map((w,i)=>`<span class="word" data-i="${i}">${w}</span>`).join(' ')}
function currentText(){return syllableMode?activities[index].syll:activities[index].text}
function load(){answered=false;syllableMode=false;$('syllables').setAttribute('aria-pressed','false');$('questionArea').classList.add('hidden');$('ready').classList.remove('hidden');$('next').classList.add('hidden');$('feedback').textContent='';$('stepLabel').textContent=`FRASE ${index+1} DE ${activities.length}`;$('progressBar').style.width=`${index/activities.length*100}%`;renderSentence(activities[index].text)}
function clearHighlight(){document.querySelectorAll('.word').forEach(w=>w.classList.remove('active'))}
function highlightRange(charIndex){const prior=currentText().slice(0,charIndex).trim();const n=prior?prior.split(/\s+/).length:0;document.querySelectorAll('.word').forEach((w,i)=>w.classList.toggle('active',i===n))}
function stopSpeech(){if(window.AndroidVoice)AndroidVoice.stop();else if(window.speechSynthesis)speechSynthesis.cancel()}
function speak(){stopSpeech();clearHighlight();if(window.AndroidVoice){AndroidVoice.speak(currentText());return}const u=new SpeechSynthesisUtterance(currentText());u.lang='es-ES';u.rate=.68;u.onboundary=e=>highlightRange(e.charIndex);u.onend=clearHighlight;speechSynthesis.speak(u)}
window.nativeSpeechRange=(start)=>highlightRange(start);window.nativeSpeechEnd=clearHighlight;
function ask(){stopSpeech();$('ready').classList.add('hidden');$('questionArea').classList.remove('hidden');$('question').textContent=activities[index].q;$('answers').innerHTML='';activities[index].a.forEach((answer,i)=>{const b=document.createElement('button');b.className='answer';b.textContent=answer;b.onclick=()=>check(i,b);$('answers').appendChild(b)})}
function check(choice,button){if(answered)return;answered=true;const ok=activities[index].ok,buttons=[...document.querySelectorAll('.answer')];buttons[ok].classList.add('correct');if(choice===ok){stars++;$('stars').textContent=stars;$('feedback').textContent='¡Muy bien! Has entendido la frase. ⭐';speakText('Muy bien. Has entendido la frase.')}else{button.classList.add('wrong');$('feedback').textContent=`Vamos a mirarlo juntos: ${activities[index].a[ok]}.`;speakText(`Vamos a mirarlo juntos. La respuesta es ${activities[index].a[ok]}.`)}$('next').classList.remove('hidden')}
function speakText(t){stopSpeech();if(window.AndroidVoice){AndroidVoice.speak(t);return}const u=new SpeechSynthesisUtterance(t);u.lang='es-ES';u.rate=.72;speechSynthesis.speak(u)}
$('start').onclick=()=>{show('lesson');load()};
$('listen').onclick=speak;
$('syllables').onclick=()=>{syllableMode=!syllableMode;$('syllables').setAttribute('aria-pressed',String(syllableMode));renderSentence(currentText());speak()};
$('ready').onclick=ask;
$('next').onclick=()=>{index++;if(index<activities.length)load();else{$('finalStars').textContent=stars;show('finish');speakText('Misión cumplida. Has leído y entendido la historia.')}};
$('again').onclick=()=>{index=0;stars=0;$('stars').textContent='0';show('lesson');load()};
