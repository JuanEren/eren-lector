const stories=[
 {title:'Eren y la tortuga',cover:'assets/car.png',friend:'assets/eren-avatar.jpg',items:[
  {text:'Eren lleva su coche rojo hasta la línea de salida.',syll:'E-ren lle-va su co-che ro-jo has-ta la lí-ne-a de sa-li-da.',img:'assets/car.png',q:'¿Quién lleva el coche rojo?',a:['Eren','La tortuga'],ok:0},
  {text:'Antes de arrancar, Eren se pone el casco.',syll:'An-tes de a-rran-car, E-ren se po-ne el cas-co.',img:'assets/helmet.png',q:'¿Qué se pone Eren?',a:['El casco','Los guantes'],ok:0},
  {text:'Una tortuga cruza la pista y Eren frena.',syll:'U-na tor-tu-ga cru-za la pis-ta y E-ren fre-na.',img:'assets/tortoise.png',q:'¿Qué hace Eren?',a:['Frena','Acelera'],ok:0},
  {text:'La tortuga llega al jardín y Eren continúa la carrera.',syll:'La tor-tu-ga lle-ga al jar-dín y E-ren con-ti-nú-a la ca-rre-ra.',img:'assets/tortoise.png',q:'¿Cuándo continúa Eren la carrera?',a:['Cuando la tortuga llega al jardín','Cuando la tortuga cruza la pista'],ok:0}
 ]},
 {title:'Scar en la piscina',cover:'assets/scar.png',friend:'assets/scar.png',items:[
  {text:'Scar camina despacio por el borde de la piscina.',syll:'Scar ca-mi-na des-pa-cio por el bor-de de la pis-ci-na.',img:'assets/scar.png',q:'¿Dónde camina Scar?',a:['En la piscina','En el jardín'],ok:0},
  {text:'Scar mira el agua con los ojos muy abiertos.',syll:'Scar mi-ra el a-gua con los o-jos muy a-bier-tos.',img:'assets/scar.png',q:'¿Cómo tiene Scar los ojos?',a:['Muy abiertos','Cerrados'],ok:0},
  {text:'Una hoja cae al agua y Scar se queda sorprendida.',syll:'U-na ho-ja ca-e al a-gua y Scar se que-da sor-pren-di-da.',img:'assets/scar.png',q:'¿Cómo está Scar?',a:['Sorprendida','Dormida'],ok:0},
  {text:'Scar se aleja del agua y mueve su larga cola.',syll:'Scar se a-le-ja del a-gua y mue-ve su lar-ga co-la.',img:'assets/scar.png',q:'¿Qué mueve Scar?',a:['Su cola','Una pelota'],ok:0}
 ]},
 {title:'Totoro bajo la lluvia',cover:'assets/totoro.png',friend:'assets/totoro.png',items:[
  {text:'Totoro espera tranquilo bajo la lluvia.',syll:'To-to-ro es-pe-ra tran-qui-lo ba-jo la llu-via.',img:'assets/totoro.png',q:'¿Quién espera bajo la lluvia?',a:['Totoro','Scar'],ok:0},
  {text:'Totoro sostiene una hoja verde sobre su cabeza.',syll:'To-to-ro sos-tie-ne u-na ho-ja ver-de so-bre su ca-be-za.',img:'assets/totoro.png',q:'¿Qué sostiene Totoro?',a:['Una hoja verde','Una estrella'],ok:0},
  {text:'Una gota grande cae sobre la hoja y Totoro se sorprende.',syll:'U-na go-ta gran-de ca-e so-bre la ho-ja y To-to-ro se sor-pren-de.',img:'assets/totoro.png',q:'¿Cómo está Totoro?',a:['Sorprendido','Enfadado'],ok:0},
  {text:'Totoro sonríe y sigue esperando bajo la lluvia.',syll:'To-to-ro son-rí-e y si-gue es-pe-ran-do ba-jo la llu-via.',img:'assets/totoro.png',q:'¿Qué hace Totoro?',a:['Sonríe','Llora'],ok:0}
 ]}
];
let story=null,index=0,stars=0,syllableMode=false,answered=false;
const $=id=>document.getElementById(id),sections=['welcome','menu','lesson','finish'];
function show(id){sections.forEach(s=>$(s).classList.toggle('hidden',s!==id))}
function speakText(text){if(window.AndroidVoice){AndroidVoice.stop();AndroidVoice.speak(text);return}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='es-ES';u.rate=.7;speechSynthesis.speak(u)}
function renderMenu(){$('appTitle').textContent='Elige un cuento';$('storyGrid').innerHTML='';stories.forEach((s,i)=>{const b=document.createElement('button');b.className='story-card';b.innerHTML=`<img src="${s.cover}" alt=""><span>${s.title}</span>`;b.onclick=()=>startStory(i);$('storyGrid').appendChild(b)});show('menu')}
function startStory(i){story=stories[i];index=0;stars=0;$('stars').textContent='0';$('appTitle').textContent=story.title;$('storyFriend').src=story.friend;show('lesson');load()}
function current(){return story.items[index]}
function renderSentence(text){$('sentence').innerHTML=text.split(' ').map(w=>`<span class="word" tabindex="0">${w}</span>`).join(' ');document.querySelectorAll('.word').forEach(w=>{w.onclick=()=>speakText(w.textContent.replace(/[-.,¿?¡!]/g,''));w.onkeydown=e=>{if(e.key==='Enter')w.click()}})}
function load(){answered=false;syllableMode=false;$('syllables').setAttribute('aria-pressed','false');$('questionArea').classList.add('hidden');$('ready').classList.remove('hidden');$('next').classList.add('hidden');$('feedback').textContent='';$('stepLabel').textContent=`FRASE ${index+1} DE ${story.items.length}`;$('progressBar').style.width=`${index/story.items.length*100}%`;$('sceneObject').src=current().img;renderSentence(current().text)}
function speak(){speakText(current().text)}
function ask(){$('ready').classList.add('hidden');$('questionArea').classList.remove('hidden');$('question').textContent=current().q;$('answers').innerHTML='';current().a.forEach((answer,i)=>{const b=document.createElement('button');b.className='answer';b.textContent=answer;b.onclick=()=>check(i,b);$('answers').appendChild(b)})}
function check(choice,button){if(answered)return;answered=true;const ok=current().ok,buttons=[...document.querySelectorAll('.answer')];buttons[ok].classList.add('correct');if(choice===ok){stars++;$('stars').textContent=stars;$('feedback').textContent='¡Muy bien! Has entendido la frase. ⭐';speakText('Muy bien. Has entendido la frase.')}else{button.classList.add('wrong');$('feedback').textContent=`La respuesta es: ${current().a[ok]}.`;speakText(`Vamos a mirarlo juntos. La respuesta es ${current().a[ok]}.`)}$('next').classList.remove('hidden')}
$('start').onclick=renderMenu;$('listen').onclick=speak;
$('syllables').onclick=()=>{syllableMode=!syllableMode;$('syllables').setAttribute('aria-pressed',String(syllableMode));renderSentence(syllableMode?current().syll:current().text)};
$('ready').onclick=ask;$('next').onclick=()=>{index++;if(index<story.items.length)load();else{$('finalStars').textContent=stars;show('finish');speakText('Misión cumplida. Has leído y entendido la historia.')}};
$('again').onclick=()=>startStory(stories.indexOf(story));$('menuButton').onclick=renderMenu;
