/* Graybox funcional 01 · Eren y Scar
 * Física a 60 Hz. Unidades del mundo en módulos (1 módulo = 100 px de autoría).
 * El arte final queda fuera deliberadamente: aquí se validan sensaciones y reglas.
 */
(()=>{
'use strict';

const byId=id=>document.getElementById(id);
const VIEW={w:19.2,h:10.8};
const FIXED_DT=1/60;
const TEST_MODE=true;
const APP_VERSION='19.0.0-graybox-layout-scar-jump';
const LOG_VERSION='GB01-v4';
const PLAYTEST_HISTORY_KEY='graybox-playtest-attempts-v4';
const MAX_PLAYTEST_ATTEMPTS=10;
const BOX_CENTER_X=7;
const SCAR_LONG_JUMP={takeoffMinX:22.5,erenMinX:27.5,speedX:7.5,speedY:13.5};
const SCAR_SPIKE_JUMP={takeoffMinX:30.5,erenMinX:33.5,speedX:5.5,speedY:14.7};
const EPS=.001;
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const approach=(value,target,amount)=>value<target?Math.min(value+amount,target):Math.max(value-amount,target);
const format=value=>Number(value).toFixed(1).replace('.',',');
const rect=(id,x,y,w,h,kind='ground')=>({id,x,y,w,h,kind});

const tuning={walk:3.5,run:6,jump:15.9,gravityUp:36,gravityDown:44,labHeight:3,labGap:4};
const controls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const nativeControls={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
const keyControls=new Set();
const pointerControls=new Map();
let scene='graybox';
let labStation='A';
let debug=false;
let sim=null;
let frameHandle=0;
let previousTime=0;
let accumulator=0;
let lastHudUpdate=0;
let logDialogWasPaused=false;
let attemptHistory=loadAttemptHistory();

function loadAttemptHistory(){
 try{const value=JSON.parse(localStorage.getItem(PLAYTEST_HISTORY_KEY)||'[]');return Array.isArray(value)?value.slice(-MAX_PLAYTEST_ATTEMPTS):[];}
 catch(error){return[];}
}

function storeAttemptHistory(){
 try{localStorage.setItem(PLAYTEST_HISTORY_KEY,JSON.stringify(attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS)));}
 catch(error){}
}

function body(x,y,w,h){
 return{x,y,w,h,vx:0,vy:0,onGround:true,facing:1,crouched:false,coyote:.12,jumpBuffer:0,invuln:0,recover:0,hitWall:false};
}

function buildGraybox(boxBroken=false){
 const solids=[
  rect('G0',0,0,10,2),rect('G1',11,0,7,2),rect('G2',19.5,0,5,2),rect('G3',28,0,8,2),
  rect('TECHO_CAJA',6,3.5,2,.5,'roof'),rect('TECHO_BAJO',12,3,2,.5,'roof'),
  rect('U1',14,4,4,.5,'upper'),rect('U2',19.5,6,1.5,.5,'upper'),rect('U3',21,4.5,1.5,.5,'upper')
 ];
 if(!boxBroken)solids.push(rect('CAJA',6.5,2,1,1,'box'));
 return{
  minX:0,maxX:36,minY:0,maxY:12,solids,
  hazards:[rect('AGUA',24.5,-2,3.5,3.5,'water'),rect('PINCHOS',32,2,1.5,.5,'spikes')],
  star:{x:20.5,y:7,r:.34},marker:{x:15,y:2,w:1.5,h:.5},goal:{x:35,y:2,w:.5,h:2},
  checkpoints:[{id:'R0',x:4.5,y:2},{id:'R1',x:22,y:2},{id:'R2',x:29,y:2}],labels:[]
 };
}

function buildLab(){
 const landingTop=2+tuning.labHeight;
 const landingX=39+tuning.labGap;
 const solids=[
  rect('A_SUELO',0,0,16,2),
  rect('B_SALIDA',16,0,7,2),rect('B_LLEGADA',25,landingTop-2,7,2,'upper'),
  rect('C_SALIDA',32,0,7,2),rect('C_LLEGADA',landingX,0,Math.max(4,48-landingX),2),
  rect('D_SUELO',48,0,16,2),rect('D_CAJA',50,2,1,1,'box'),rect('D_TECHO_15',52.5,3.5,3,.5,'roof'),rect('D_TECHO_10',57.5,3,3,.5,'roof'),
  rect('E0',64,0,6,2),rect('E1',70.8,2,4,2,'upper'),rect('E2',75.5,1,3,2,'upper'),rect('E3',79,0,1,2),
  rect('F0',80,0,6,2),rect('F1',89.5,0,6.5,2)
 ];
 return{
  minX:0,maxX:96,minY:0,maxY:12,solids,
  hazards:[rect('B_FOSO',23,-2,2,3.5,'water'),rect('C_FOSO',39,-2,tuning.labGap,3.5,'water'),rect('F_AGUA',86,-2,3.5,3.5,'water'),rect('F_PINCHOS',92,2,1.5,.5,'spikes')],
  star:null,marker:{x:72,y:4,w:1.5,h:.5},goal:null,checkpoints:[],
  labels:[
   {x:8,text:'A · VELOCIDAD'},{x:24,text:'B · SALTO VERTICAL'},{x:40,text:'C · HUECO'},
   {x:56,text:'D · COLLIDERS'},{x:72,text:'E · SCAR'},{x:88,text:'F · DAÑO Y RETORNO'}
  ]
 };
}

const stationSpawns={A:{x:2,y:2},B:{x:18,y:2},C:{x:34,y:2},D:{x:49,y:2},E:{x:65.5,y:2},F:{x:82,y:2}};
const stationScarSpawns={A:{x:3.5,y:2},B:{x:19.5,y:2},C:{x:35.5,y:2},D:{x:51.8,y:2},E:{x:67,y:2},F:{x:83.5,y:2}};

function createSimulation(){
 const spawn=scene==='graybox'?{x:4.5,y:2}:stationSpawns[labStation];
 const eren=body(spawn.x,spawn.y,1,1.5);
 eren.hearts=3;
 const scarSpawn=scene==='graybox'?{x:spawn.x-1.7,y:spawn.y}:stationScarSpawns[labStation];
 const scar=body(scarSpawn.x,scarSpawn.y,1.5,1);
 scar.mode='follow';scar.recoverTimer=0;scar.recoveryGrace=0;scar.stuck=0;scar.navStuck=0;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.traversal=null;
 const world=scene==='graybox'?buildGraybox(false):buildLab();
 const cameraX=clamp(spawn.x-VIEW.w*.36,world.minX,Math.max(world.minX,world.maxX-VIEW.w));
 const now=new Date().toISOString();
 return{
  runId:`run-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,startedAt:now,archived:false,
  running:true,paused:false,scene,station:labStation,world,eren,scar,camera:{x:cameraX,y:0},
  boxBroken:false,starCollected:false,checkpoint:{x:spawn.x,y:spawn.y,id:scene==='graybox'?'R0':labStation},
  complete:false,elapsed:0,readingCue:false,toast:'',toastUntil:0,damageFlash:false,goalPending:false,goalWait:0,goalRecoveryIssued:false,
  maxHeight:0,maxSpeed:0,jumpStartY:spawn.y,prevInput:{...controls},
  events:[{time:0,type:'inicio',scene,station:labStation,createdAt:now}]
 };
}

function rebuildWorld(){
 if(!sim)return;
 sim.world=scene==='graybox'?buildGraybox(sim.boxBroken):buildLab();
}

function logEvent(type,data={}){
 if(!sim)return;
 sim.events.push({time:Number(sim.elapsed.toFixed(3)),type,...data});
}

function archiveCurrentAttempt(reason){
 if(!sim||sim.archived)return;
 logEvent('fin_intento',{reason});
 if(!hasMeaningfulAttempt(sim.events)){sim.archived=true;return;}
 const attempt=playtestAttemptPayload();attempt.endedAt=new Date().toISOString();attempt.endedReason=reason;
 attemptHistory.push(JSON.parse(JSON.stringify(attempt)));attemptHistory=attemptHistory.slice(-MAX_PLAYTEST_ATTEMPTS);storeAttemptHistory();sim.archived=true;
}

function hasMeaningfulAttempt(events=[]){
 const passive=new Set(['inicio','fin_intento','ver_registro','compartir_registro','copiar_registro','copiar_resumen','estacion']);
 return events.some(event=>!passive.has(event.type));
}

function toast(message,seconds=1.6){
 if(!sim)return;
 sim.toast=message;sim.toastUntil=sim.elapsed+seconds;
}

function bodyRect(entity,w=entity.w,h=entity.h){return{x:entity.x-w/2,y:entity.y,w,h};}
function overlaps(a,b){return a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;}
function pointInRect(x,y,r){return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}

function canFit(entity,w,h,solids){
 const box=bodyRect(entity,w,h);
 return !solids.some(s=>overlaps(box,s));
}

function moveBody(entity,dt,solids){
 entity.hitWall=false;
 entity.x+=entity.vx*dt;
 let box=bodyRect(entity);
 for(const solid of solids){
  if(!overlaps(box,solid))continue;
  if(entity.vx>0)entity.x=solid.x-entity.w/2;
  else if(entity.vx<0)entity.x=solid.x+solid.w+entity.w/2;
  entity.vx=0;entity.hitWall=true;box=bodyRect(entity);
 }
 entity.onGround=false;
 entity.y+=entity.vy*dt;
 box=bodyRect(entity);
 for(const solid of solids){
  if(!overlaps(box,solid))continue;
  if(entity.vy<=0){entity.y=solid.y+solid.h;entity.onGround=true;}
  else entity.y=solid.y-entity.h;
  entity.vy=0;box=bodyRect(entity);
 }
 if(!entity.onGround&&entity.vy<=0){
  for(const solid of solids){
   const top=solid.y+solid.h;
   if(Math.abs(entity.y-top)<.035&&entity.x+entity.w/2>solid.x+.03&&entity.x-entity.w/2<solid.x+solid.w-.03){entity.y=top;entity.onGround=true;entity.vy=0;break;}
  }
 }
}

function supportingSolid(entity,solids){
 return solids.find(s=>Math.abs(entity.y-(s.y+s.h))<.08&&entity.x+entity.w/2>s.x+.02&&entity.x-entity.w/2<s.x+s.w-.02);
}

function surfaceAt(x,nearY,solids){
 let best=null;
 for(const solid of solids){
  const top=solid.y+solid.h;
  if(x>=solid.x&&x<=solid.x+solid.w&&top<=nearY+.35&&top>=nearY-2.2&&(!best||top>best))best=top;
 }
 return best;
}

function currentInput(){
 const merged={left:false,right:false,up:false,crouch:false,run:false,jump:false,action:false,scar:false};
 const activate=name=>{if(name in merged)merged[name]=true;};
 const keyMap={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'up',KeyW:'up',ArrowDown:'crouch',KeyS:'crouch',ShiftLeft:'run',ShiftRight:'run',KeyR:'run',Space:'jump',KeyZ:'jump',KeyK:'jump',KeyX:'action',KeyE:'action',KeyJ:'action',KeyC:'scar',KeyQ:'scar',KeyL:'scar'};
 keyControls.forEach(code=>activate(keyMap[code]));
 pointerControls.forEach(values=>values.forEach(activate));
 Object.keys(nativeControls).forEach(name=>{if(nativeControls[name])activate(name);});
 const pads=navigator.getGamepads?navigator.getGamepads():[];
 for(const pad of pads){
  if(!pad)continue;
  if(pad.axes[0]<-.35||pad.buttons[14]?.pressed)merged.left=true;
  if(pad.axes[0]>.35||pad.buttons[15]?.pressed)merged.right=true;
  if(pad.axes[1]<-.55||pad.buttons[12]?.pressed)merged.up=true;
  if(pad.axes[1]>.55||pad.buttons[13]?.pressed)merged.crouch=true;
  if(pad.buttons[0]?.pressed)merged.jump=true;
  if(pad.buttons[2]?.pressed)merged.action=true;
  if(pad.buttons[1]?.pressed||pad.buttons[7]?.pressed)merged.run=true;
  if(pad.buttons[3]?.pressed||pad.buttons[4]?.pressed)merged.scar=true;
 }
 Object.assign(controls,merged);
 return merged;
}

function setMessageFromProgress(){
 if(!sim)return'';
 if(sim.toastUntil>sim.elapsed)return sim.toast;
 if(scene==='lab'){
  const messages={
   A:'A · Compara arranque, frenada, giro y andar/correr.',
   B:'B · Salta desde la marca y comprueba el desnivel seleccionado.',
   C:'C · Cruza el hueco; cambia su anchura para hallar el límite seguro.',
   D:'D · Rompe la caja y prueba de pie/agachado bajo los dos techos.',
   E:'E · Observa cómo Scar resuelve alturas con física propia.',
   F:'F · Toca agua o pinchos y mide cuánto tarda en volver el control.'
  };
  return messages[labStation];
 }
 const x=sim.eren.x;
 if(sim.goalPending)return sim.scar.mode==='follow'?'Espera junto a la meta: Scar está llegando.':'Pulsa SCAR para llamar a Scar y terminar juntos.';
 if(x<5.85)return'Muévete: ¿arranca y frena con claridad, sin patinar?';
 if(!sim.boxBroken&&x<9.7)return'Acércate a la caja y pulsa ACCIÓN para abrir el paso.';
 if(x<11.3)return'Salta el hueco corto. Puedes pulsar salto un instante o mantenerlo.';
 if(x<14.1)return'Mantén ABAJO para cambiar al collider agachado y pasar.';
 if(x<17.6&&sim.scar.mode==='follow')return'Lee: «Scar, espera sobre la huella». Pulsa SCAR para darle la orden.';
 if(x<19.2)return'Puedes tomar la ruta alta para buscar la estrella.';
 if(x<24.3)return'La estrella es opcional. La ruta principal continúa abajo.';
 if(x<28.2)return'Mantén CORRER + SALTAR para cruzar el agua.';
 if(x<33.8)return'Los pinchos quitan un corazón y devuelven al último anclaje.';
 return'Llega a la bandera para cerrar el contrato funcional.';
}

function commandScar(){
 if(!sim||sim.paused)return;
 const scar=sim.scar;
 if(scene==='graybox'&&Math.abs(sim.eren.x-(sim.world.marker.x+.75))<4.2){
  if(scar.mode==='marker'||scar.mode==='wait'){scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;toast('Scar vuelve a seguir a Eren.');logEvent('scar_seguir');}
  else{scar.mode='marker';scar.navPhase='buscar_placa';scar.navTargetX=null;scar.navTargetY=null;scar.navStuck=0;toast('Orden recibida: Scar va a la huella.');logEvent('scar_huella',{fromX:Number(scar.x.toFixed(2)),fromY:Number(scar.y.toFixed(2))});}
 }else if(scar.mode==='wait'||scar.mode==='marker'){
  scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;toast('Scar vuelve contigo.');logEvent('scar_seguir');
 }else{
  scar.mode='wait';scar.navPhase='wait';scar.navTargetX=scar.x;scar.navTargetY=scar.y;scar.waitX=scar.x;toast('Scar espera aquí.');logEvent('scar_esperar',{x:Number(scar.x.toFixed(2))});
 }
}

function damageEren(kind){
 const eren=sim.eren;
 if(eren.invuln>0||eren.recover>0)return;
 eren.hearts--;
 logEvent('daño',{kind,hearts:eren.hearts,checkpoint:sim.checkpoint.id});
 const flash=byId('damageFlash');flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');
 eren.x=sim.checkpoint.x;eren.y=sim.checkpoint.y;eren.vx=0;eren.vy=0;eren.recover=.55;eren.invuln=1.25;eren.crouched=false;eren.w=1;eren.h=1.5;
 if(eren.hearts<=0){eren.hearts=3;logEvent('corazones_repuestos');}
 toast('Daño: retorno al último anclaje.',1.1);tone('wrong');
}

function recoverScar(reason){
 const scar=sim.scar;
 if(scar.recoverTimer>0)return;
 scar.recoverTimer=.65;scar.vx=0;scar.vy=0;logEvent('scar_recuperacion',{reason});
}

function setScarNavigation(scar,phase,targetX,targetY){
 if(scar.navPhase!==phase){scar.navPhase=phase;logEvent('scar_ruta',{phase,targetX:Number(targetX.toFixed(2)),targetY:Number(targetY.toFixed(2))});}
 scar.navTargetX=targetX;scar.navTargetY=targetY;return targetX;
}

function scarMarkerTarget(scar,world){
 if(!scar.onGround&&Number.isFinite(scar.navTargetX))return scar.navTargetX;
 const support=supportingSolid(scar,world.solids),marker=world.marker,markerX=marker.x+marker.w/2;
 if(support?.id==='U2')return setScarNavigation(scar,'bajar_u2_a_u1',17.5,4.5);
 if(support?.id==='U3')return setScarNavigation(scar,'bajar_u3_a_g2',22.5,2);
 if(support?.id==='U1')return setScarNavigation(scar,'bajar_u1_a_techo',13,3.5);
 if(support?.id==='TECHO_BAJO')return setScarNavigation(scar,'bajar_techo_a_g1',11,2);
 if(scar.y>marker.y+.2)return setScarNavigation(scar,'buscar_descenso',markerX,marker.y);
 return setScarNavigation(scar,'ir_a_placa',markerX,marker.y);
}

function scarReachedMarker(scar,world){
 const marker=world.marker,support=supportingSolid(scar,world.solids);
 return!!marker&&support?.id==='G1'&&Math.abs(scar.y-marker.y)<=.1&&Math.abs(scar.x-(marker.x+marker.w/2))<=.5;
}

function updateScarPosture(scar,world){
 const inLowPass=scene==='graybox'&&scar.y<=2.12&&scar.x>=10.7&&scar.x<=14.65;
 if(inLowPass&&!scar.crouched){scar.crouched=true;scar.h=.5;logEvent('scar_paso_bajo_inicio',{x:Number(scar.x.toFixed(2))});}
 else if(!inLowPass&&scar.crouched&&canFit(scar,1.5,1,world.solids)){scar.crouched=false;scar.h=1;logEvent('scar_paso_bajo_fin',{x:Number(scar.x.toFixed(2))});}
}

function updateEren(input,dt){
 const eren=sim.eren;
 eren.invuln=Math.max(0,eren.invuln-dt);
 if(eren.recover>0){eren.recover=Math.max(0,eren.recover-dt);return;}

 if(eren.onGround)eren.coyote=.12;else eren.coyote=Math.max(0,eren.coyote-dt);
 eren.jumpBuffer=Math.max(0,eren.jumpBuffer-dt);
 if(input.jump&&!sim.prevInput.jump)eren.jumpBuffer=.12;

 if(input.crouch&&eren.onGround){
  if(!eren.crouched){eren.crouched=true;eren.w=1.5;eren.h=1;logEvent('agacharse');}
 }else if(eren.crouched&&canFit(eren,1,1.5,sim.world.solids)){
  eren.crouched=false;eren.w=1;eren.h=1.5;
 }

 if(eren.jumpBuffer>0&&eren.coyote>0&&!eren.crouched){
  eren.vy=tuning.jump;eren.onGround=false;eren.coyote=0;eren.jumpBuffer=0;sim.jumpStartY=eren.y;
  logEvent('salto',{x:Number(eren.x.toFixed(2)),speed:Number(Math.abs(eren.vx).toFixed(2))});
 }
 if(!input.jump&&sim.prevInput.jump&&eren.vy>0)eren.vy*=.45;

 const axis=(input.right?1:0)-(input.left?1:0);
 if(axis)eren.facing=axis;
 const maxSpeed=eren.crouched?2.2:(input.run?tuning.run:tuning.walk);
 const target=axis*maxSpeed;
 const accel=!axis?28:(eren.vx*axis<0?36:(eren.onGround?20:14));
 eren.vx=approach(eren.vx,target,accel*dt);

 if(input.action&&!sim.prevInput.action){
  logEvent('accion',{x:Number(eren.x.toFixed(2))});
  if(scene==='graybox'&&!sim.boxBroken&&Math.abs(eren.x-BOX_CENTER_X)<1.8&&eren.y<3.7){
   sim.boxBroken=true;rebuildWorld();toast('Caja rota. El camino ya está abierto.');tone('correct');logEvent('caja_rota');
  }else if(scene==='lab'&&Math.abs(eren.x-50.5)<1.8){
   sim.world.solids=sim.world.solids.filter(s=>s.id!=='D_CAJA');toast('Collider de caja retirado.');tone('correct');
  }
 }
 if(input.scar&&!sim.prevInput.scar)commandScar();

 const gravity=eren.vy>0?tuning.gravityUp:tuning.gravityDown;
 eren.vy=Math.max(-16,eren.vy-gravity*dt);
 moveBody(eren,dt,sim.world.solids);
 eren.x=clamp(eren.x+0,sim.world.minX+eren.w/2,sim.world.maxX-eren.w/2);

 sim.maxSpeed=Math.max(sim.maxSpeed,Math.abs(eren.vx));
 sim.maxHeight=Math.max(sim.maxHeight,eren.y-sim.jumpStartY);

 if(scene==='graybox'){
  if(eren.onGround&&eren.x>=21.5&&sim.checkpoint.id==='R0'){sim.checkpoint={x:22,y:2,id:'R1'};logEvent('anclaje',{id:'R1'});}
  if(eren.onGround&&eren.x>=28.7&&sim.checkpoint.id!=='R2'){sim.checkpoint={x:29,y:2,id:'R2'};logEvent('anclaje',{id:'R2'});}
  if(!sim.readingCue&&eren.x>=13.7){sim.readingCue=true;logEvent('instruccion_leida',{text:'Scar, espera sobre la huella.'});playAzureSequence(['Scar, espera sobre la huella.']);}
  if(!sim.starCollected&&sim.world.star){
   const star=sim.world.star,dx=eren.x-star.x,dy=(eren.y+eren.h*.55)-star.y;
   if(dx*dx+dy*dy<.8){sim.starCollected=true;toast('Estrella opcional conseguida.');tone('correct');logEvent('estrella');}
  }
  if(!sim.complete&&!sim.goalPending&&sim.world.goal&&overlaps(bodyRect(eren),sim.world.goal)){
   sim.goalPending=true;sim.goalWait=0;sim.goalRecoveryIssued=false;
   toast('Meta alcanzada. Espera a Scar.',2);logEvent('meta_espera_scar',{scarX:Number(sim.scar.x.toFixed(2))});
  }
 }

 const hit=sim.world.hazards.find(h=>overlaps(bodyRect(eren),h));
 if(hit)damageEren(hit.kind);
 if(eren.y<-2.5)damageEren('caída');
}

function updateScar(dt){
 const scar=sim.scar,eren=sim.eren,world=sim.world;
 scar.recoveryGrace=Math.max(0,(scar.recoveryGrace||0)-dt);
 if(scar.recoverTimer>0){
  scar.recoverTimer-=dt;
  if(scar.recoverTimer<=0){
   let x=Math.max(world.minX+.9,sim.camera.x-.9),y=surfaceAt(x,eren.y,world.solids);
   if(y===null){x=sim.checkpoint.x-1.7;y=sim.checkpoint.y;}
   scar.x=x;scar.y=y;scar.vx=Math.max(2.2,eren.vx);scar.vy=0;scar.mode='follow';scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;scar.navStuck=0;scar.traversal=null;scar.recoveryGrace=3.5;scar.stuck=0;
   if(scar.crouched){scar.crouched=false;scar.h=1;}
  }
  return;
 }

 updateScarPosture(scar,world);
 let support=supportingSolid(scar,world.solids);
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G2'&&scar.x>=SCAR_LONG_JUMP.takeoffMinX&&eren.x>=SCAR_LONG_JUMP.erenMinX){
  scar.traversal='water_long_jump';scar.navPhase='salto_largo_agua';scar.facing=1;scar.vx=SCAR_LONG_JUMP.speedX;scar.vy=SCAR_LONG_JUMP.speedY;scar.onGround=false;
  logEvent('scar_salto_largo_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_LONG_JUMP.speedX,vy:SCAR_LONG_JUMP.speedY});
 }
 if(!scar.traversal&&scene==='graybox'&&scar.mode==='follow'&&!scar.crouched&&scar.onGround&&support?.id==='G3'&&scar.x>=SCAR_SPIKE_JUMP.takeoffMinX&&scar.x<32&&eren.x>=SCAR_SPIKE_JUMP.erenMinX){
  scar.traversal='spike_jump';scar.navPhase='salto_pinchos';scar.facing=1;scar.vx=SCAR_SPIKE_JUMP.speedX;scar.vy=SCAR_SPIKE_JUMP.speedY;scar.onGround=false;
  logEvent('scar_salto_pinchos_inicio',{x:Number(scar.x.toFixed(2)),vx:SCAR_SPIKE_JUMP.speedX,vy:SCAR_SPIKE_JUMP.speedY});
 }
 if(scar.traversal){
  const traversal=scar.traversal,settings=traversal==='water_long_jump'?SCAR_LONG_JUMP:SCAR_SPIKE_JUMP;
  scar.facing=1;scar.vx=settings.speedX;scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);moveBody(scar,dt,world.solids);
  support=supportingSolid(scar,world.solids);
  if(scar.onGround&&support?.id==='G3'){
   scar.traversal=null;scar.navPhase='follow';scar.navTargetX=null;scar.navTargetY=null;
   logEvent(traversal==='water_long_jump'?'scar_salto_largo_exito':'scar_salto_pinchos_exito',{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});
  }
  const longJumpHazard=world.hazards.find(h=>overlaps(bodyRect(scar),h));
  if(longJumpHazard||scar.y<-2.5)recoverScar(longJumpHazard?longJumpHazard.kind:'caída');
  return;
 }
 let targetX=eren.x-eren.facing*2;
 if(scar.mode==='marker')targetX=scarMarkerTarget(scar,world);
 else if(scar.mode==='wait')targetX=scar.waitX??scar.x;
 const dx=targetX-scar.x;
 const tolerance=scar.mode==='follow'?1.45:.16;
 let axis=Math.abs(dx)>tolerance?Math.sign(dx):0;
 if(scar.mode==='marker'&&scarReachedMarker(scar,world)){scar.mode='wait';scar.navPhase='placa_confirmada';scar.navTargetX=world.marker.x+world.marker.w/2;scar.navTargetY=world.marker.y;scar.waitX=scar.navTargetX;toast('Scar espera sobre la huella.');logEvent('scar_en_huella',{x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});axis=0;}
 if(axis)scar.facing=axis;
 const speed=scar.crouched?2.4:(Math.abs(dx)>7?6.5:(Math.abs(eren.vx)>tuning.walk+.3?5.5:3));
 scar.vx=approach(scar.vx,axis*speed,(axis?22:28)*dt);

 let shouldJump=false;
 if(scar.onGround&&axis&&support&&!scar.crouched){
  const intentionalDrop=scar.mode==='marker'&&scar.navPhase.startsWith('bajar_');
  const edge=axis>0?support.x+support.w:support.x;
  const edgeDistance=axis>0?edge-(scar.x+scar.w/2):(scar.x-scar.w/2)-edge;
  const probeX=scar.x+axis*(scar.w/2+.55);
  const aheadSurface=surfaceAt(probeX,scar.y,world.solids);
  if(!intentionalDrop&&edgeDistance<.85&&aheadSurface===null)shouldJump=true;
  const higher=world.solids.some(s=>{
   const top=s.y+s.h,front=axis>0?s.x-(scar.x+scar.w/2):(scar.x-scar.w/2)-(s.x+s.w);
   const passableRoof=s.kind==='roof'&&s.y>=scar.y+scar.h-EPS;
   return!passableRoof&&front>=-.05&&front<1.2&&top>scar.y+.25&&top<=scar.y+3.05;
  });
  if(!intentionalDrop&&higher)shouldJump=true;
 }
 if(scar.onGround&&scar.hitWall&&axis&&!scar.crouched&&!(scar.mode==='marker'&&scar.navPhase.startsWith('bajar_')))shouldJump=true;
 if(shouldJump){scar.vy=14.7;scar.onGround=false;logEvent('scar_salto',{x:Number(scar.x.toFixed(2))});}
 scar.vy=Math.max(-16,scar.vy-(scar.vy>0?36:44)*dt);
 const beforeX=scar.x,beforeY=scar.y;
 moveBody(scar,dt,world.solids);

 if(scar.mode==='marker'&&axis&&scar.onGround&&Math.abs(scar.x-beforeX)<.003&&Math.abs(scar.y-beforeY)<.003)scar.navStuck+=dt;else scar.navStuck=0;
 if(scar.mode==='marker'&&scar.navStuck>2.5){logEvent('scar_ruta_bloqueada',{phase:scar.navPhase,x:Number(scar.x.toFixed(2)),y:Number(scar.y.toFixed(2))});scar.navStuck=0;recoverScar('ruta_marcador');}

 const hazard=world.hazards.find(h=>overlaps(bodyRect(scar),h));
 if(hazard||scar.y<-2.5)recoverScar(hazard?hazard.kind:'caída');
 if(scar.mode==='follow'&&scar.recoveryGrace<=0&&Math.abs(scar.x-eren.x)>15)scar.stuck+=dt;else scar.stuck=0;
 if(scar.stuck>.55)recoverScar('fuera_de_camara');
}

function updateGoalReunion(dt){
 if(scene!=='graybox'||!sim.goalPending||sim.complete)return;
 sim.goalWait+=dt;
 const scar=sim.scar,support=supportingSolid(scar,sim.world.solids);
 if(scar.recoverTimer<=0&&scar.mode==='follow'&&support?.id==='G3'&&Math.abs(scar.x-sim.eren.x)<=3.5){
  logEvent('meta_reunion_scar',{wait:Number(sim.goalWait.toFixed(2)),scarX:Number(scar.x.toFixed(2))});finishGraybox();return;
 }
 if(sim.goalWait>=4&&!sim.goalRecoveryIssued&&scar.mode==='follow'&&!scar.traversal&&scar.recoverTimer<=0&&support?.id!=='G3'){
  sim.goalRecoveryIssued=true;recoverScar('reunion_meta');
 }
}

function updateCamera(dt){
 const world=sim.world,eren=sim.eren;
 const look=clamp(eren.vx/tuning.run,-1,1)*3;
 const desiredX=clamp(eren.x+look-VIEW.w/2,world.minX,Math.max(world.minX,world.maxX-VIEW.w));
 const desiredY=clamp(eren.y-3.75,world.minY,Math.max(world.minY,world.maxY-VIEW.h));
 sim.camera.x+=(desiredX-sim.camera.x)*(1-Math.exp(-dt/.18));
 sim.camera.y+=(desiredY-sim.camera.y)*(1-Math.exp(-dt/.25));
}

function physicsStep(dt,input){
 if(!sim||!sim.running||sim.paused)return;
 sim.elapsed+=dt;
 for(const control of['left','right','run']){
  if(input[control]&&!sim.prevInput[control])logEvent('control_inicio',{control});
  if(!input[control]&&sim.prevInput[control])logEvent('control_fin',{control});
 }
 updateEren(input,dt);
 updateScar(dt);
 updateGoalReunion(dt);
 if(!sim.paused)updateCamera(dt);
 sim.prevInput={...input};
}

function finishGraybox(){
 sim.complete=true;sim.paused=true;logEvent('meta',{elapsed:Number(sim.elapsed.toFixed(2)),star:sim.starCollected,damage:sim.events.filter(e=>e.type==='daño').length});
 const wins=Number(localStorage.getItem('game-wins')||0)+1;localStorage.setItem('game-wins',String(wins));
 localStorage.setItem('graybox-last-playtest',JSON.stringify(playtestBundle()));
 byId('gameRewardStars').textContent=sim.starCollected?'★':'☆';byId('gameReward').classList.remove('hidden');
 tone('correct');setTimeout(()=>tone('correct'),230);playAzureSequence(['¡Graybox completado! Eren y Scar han llegado juntos.']);
}

function playtestAttemptPayload(){
 const events=sim?sim.events:[];
 return{
  runId:sim?.runId||null,startedAt:sim?.startedAt||null,capturedAt:new Date().toISOString(),scene:sim?.scene||scene,station:sim?.station||labStation,
  tuning:{...tuning},summary:sim?{
   elapsed:Number(sim.elapsed.toFixed(2)),maxSpeed:Number(sim.maxSpeed.toFixed(2)),maxJumpHeight:Number(sim.maxHeight.toFixed(2)),
   hearts:sim.eren.hearts,star:sim.starCollected,complete:sim.complete,damageCount:events.filter(e=>e.type==='daño').length,
   jumps:events.filter(e=>e.type==='salto').length,runActivations:events.filter(e=>e.type==='control_inicio'&&e.control==='run').length,
   directionActivations:events.filter(e=>e.type==='control_inicio'&&(e.control==='left'||e.control==='right')).length,
   actionPresses:events.filter(e=>e.type==='accion').length,scarRecoveries:events.filter(e=>e.type==='scar_recuperacion').length,
   scarMarkerCommands:events.filter(e=>e.type==='scar_huella').length,scarMarkerSuccesses:events.filter(e=>e.type==='scar_en_huella').length,
   scarLowPasses:events.filter(e=>e.type==='scar_paso_bajo_inicio').length,scarRouteBlocks:events.filter(e=>e.type==='scar_ruta_bloqueada').length,
   scarLongJumps:events.filter(e=>e.type==='scar_salto_largo_inicio').length,scarLongJumpSuccesses:events.filter(e=>e.type==='scar_salto_largo_exito').length,
   scarSpikeJumps:events.filter(e=>e.type==='scar_salto_pinchos_inicio').length,scarSpikeJumpSuccesses:events.filter(e=>e.type==='scar_salto_pinchos_exito').length,
   goalReunions:events.filter(e=>e.type==='meta_reunion_scar').length
  }:null,finalState:sim?{
   eren:{x:Number(sim.eren.x.toFixed(2)),y:Number(sim.eren.y.toFixed(2)),vx:Number(sim.eren.vx.toFixed(2)),vy:Number(sim.eren.vy.toFixed(2))},
   scar:{x:Number(sim.scar.x.toFixed(2)),y:Number(sim.scar.y.toFixed(2)),mode:sim.scar.mode,crouched:sim.scar.crouched,navPhase:sim.scar.navPhase,traversal:sim.scar.traversal},checkpoint:sim.checkpoint.id
  }:null,events
 };
}

function playtestBundle(){
 const attempts=[...attemptHistory];
 if(sim&&!sim.archived&&hasMeaningfulAttempt(sim.events))attempts.push(playtestAttemptPayload());
 const includedAttempts=attempts.slice(-MAX_PLAYTEST_ATTEMPTS);
 return{
  version:LOG_VERSION,appVersion:APP_VERSION,testMode:TEST_MODE,generatedAt:new Date().toISOString(),
  device:{userAgent:navigator.userAgent||'Android WebView',viewport:{width:window.innerWidth||0,height:window.innerHeight||0},pixelRatio:window.devicePixelRatio||1},
  attemptCount:includedAttempts.length,attempts:includedAttempts
 };
}

function compactPlaytestBundle(){
 const bundle=playtestBundle(),keyTypes=new Set(['caja_rota','scar_en_huella','scar_ruta_bloqueada','scar_salto_largo_inicio','scar_salto_largo_exito','scar_salto_pinchos_inicio','scar_salto_pinchos_exito','scar_recuperacion','daño','estrella','anclaje','meta_espera_scar','meta_reunion_scar','meta']);
 return{
  version:bundle.version,appVersion:bundle.appVersion,testMode:bundle.testMode,generatedAt:bundle.generatedAt,device:bundle.device,attemptCount:bundle.attemptCount,
  attempts:bundle.attempts.map(attempt=>({runId:attempt.runId,startedAt:attempt.startedAt,scene:attempt.scene,station:attempt.station,tuning:attempt.tuning,summary:attempt.summary,finalState:attempt.finalState,keyEvents:attempt.events.filter(event=>keyTypes.has(event.type))}))
 };
}

function worldToScreen(x,y,draw){return{x:draw.ox+(x-sim.camera.x)*draw.scale,y:draw.oy+(sim.camera.y+VIEW.h-y)*draw.scale};}

function drawStar(ctx,x,y,r,draw){
 const p=worldToScreen(x,y,draw);ctx.save();ctx.translate(p.x,p.y);ctx.beginPath();
 for(let i=0;i<10;i++){const angle=-Math.PI/2+i*Math.PI/5,rad=(i%2?r*.45:r)*draw.scale;const px=Math.cos(angle)*rad,py=Math.sin(angle)*rad;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}
 ctx.closePath();ctx.fillStyle='#ffd34f';ctx.fill();ctx.strokeStyle='#6d5410';ctx.lineWidth=2;ctx.stroke();ctx.restore();
}

function drawHazard(ctx,h,draw){
 const left=worldToScreen(h.x,h.y+h.h,draw),w=h.w*draw.scale,height=h.h*draw.scale;
 if(h.kind==='water'){
  ctx.fillStyle='#2c99c4bb';ctx.fillRect(left.x,left.y,w,height);ctx.strokeStyle='#7fdbef';ctx.lineWidth=2;ctx.beginPath();
  for(let x=left.x;x<=left.x+w;x+=draw.scale*.5)ctx.lineTo(x,left.y+Math.sin((x-left.x)/draw.scale*Math.PI*2)*3);ctx.stroke();
 }else{
  const count=Math.max(1,Math.round(h.w/.5)),unit=w/count;ctx.fillStyle='#df4b45';ctx.strokeStyle='#6e2422';ctx.lineWidth=1.5;
  for(let i=0;i<count;i++){ctx.beginPath();ctx.moveTo(left.x+i*unit,left.y+height);ctx.lineTo(left.x+(i+.5)*unit,left.y);ctx.lineTo(left.x+(i+1)*unit,left.y+height);ctx.closePath();ctx.fill();ctx.stroke();}
 }
}

function drawCharacter(ctx,entity,label,color,draw){
 if(entity.recoverTimer>0)return;
 if(label==='E'&&entity.invuln>0&&Math.floor(entity.invuln*12)%2===0)return;
 const topLeft=worldToScreen(entity.x-entity.w/2,entity.y+entity.h,draw),w=entity.w*draw.scale,h=entity.h*draw.scale;
 ctx.save();ctx.fillStyle=color;ctx.strokeStyle=label==='S'?'#e7edf3':'#8b1d1d';ctx.lineWidth=Math.max(2,draw.scale*.035);
 const radius=Math.min(w,h)*.22;ctx.beginPath();
 if(ctx.roundRect)ctx.roundRect(topLeft.x,topLeft.y,w,h,radius);else ctx.rect(topLeft.x,topLeft.y,w,h);
 ctx.fill();ctx.stroke();
 ctx.fillStyle=label==='S'?'#f6f7f8':'#fff';ctx.font=`900 ${Math.max(11,draw.scale*.32)}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,topLeft.x+w/2,topLeft.y+h/2);
 const faceX=topLeft.x+(entity.facing>0?w*.78:w*.22);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(faceX,topLeft.y+h*.28,Math.max(1.6,draw.scale*.045),0,Math.PI*2);ctx.fill();
 if(debug){ctx.setLineDash([5,4]);ctx.strokeStyle='#00e5ff';ctx.lineWidth=1.5;ctx.strokeRect(topLeft.x,topLeft.y,w,h);ctx.setLineDash([]);}
 ctx.restore();
}

function render(){
 if(!sim)return;
 const canvas=byId('gameCanvas'),bounds=canvas.getBoundingClientRect();
 if(!bounds.width||!bounds.height)return;
 const dpr=Math.min(2,window.devicePixelRatio||1),pixelW=Math.round(bounds.width*dpr),pixelH=Math.round(bounds.height*dpr);
 if(canvas.width!==pixelW||canvas.height!==pixelH){canvas.width=pixelW;canvas.height=pixelH;}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,bounds.width,bounds.height);
 const scale=Math.min(bounds.width/VIEW.w,bounds.height/VIEW.h),draw={scale,ox:(bounds.width-VIEW.w*scale)/2,oy:(bounds.height-VIEW.h*scale)/2};
 ctx.fillStyle='#0b0f14';ctx.fillRect(0,0,bounds.width,bounds.height);
 const gradient=ctx.createLinearGradient(0,draw.oy,0,draw.oy+VIEW.h*scale);gradient.addColorStop(0,'#19222b');gradient.addColorStop(1,'#10151b');ctx.fillStyle=gradient;ctx.fillRect(draw.ox,draw.oy,VIEW.w*scale,VIEW.h*scale);

 ctx.save();ctx.beginPath();ctx.rect(draw.ox,draw.oy,VIEW.w*scale,VIEW.h*scale);ctx.clip();
 const firstX=Math.floor(sim.camera.x*2)/2,lastX=sim.camera.x+VIEW.w;
 for(let x=firstX;x<=lastX+.5;x+=.5){const p=worldToScreen(x,0,draw),major=Math.abs(x-Math.round(x/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(p.x,draw.oy);ctx.lineTo(p.x,draw.oy+VIEW.h*scale);ctx.stroke();}
 for(let y=Math.floor(sim.camera.y*2)/2;y<=sim.camera.y+VIEW.h+.5;y+=.5){const p=worldToScreen(0,y,draw),major=Math.abs(y-Math.round(y/5)*5)<.01;ctx.strokeStyle=major?'#73808d42':'#7180911d';ctx.lineWidth=major?1.2:.65;ctx.beginPath();ctx.moveTo(draw.ox,p.y);ctx.lineTo(draw.ox+VIEW.w*scale,p.y);ctx.stroke();}

 if(scene==='lab'){
  for(let x=0;x<96;x+=16){const a=worldToScreen(x,sim.camera.y+VIEW.h,draw);ctx.fillStyle=(x/16)%2?'#ffffff08':'#00000010';ctx.fillRect(a.x,draw.oy,16*scale,VIEW.h*scale);}
 }

 for(const solid of sim.world.solids){
  const p=worldToScreen(solid.x,solid.y+solid.h,draw),w=solid.w*scale,h=solid.h*scale;
  ctx.fillStyle=solid.kind==='box'?'#98683e':solid.kind==='roof'?'#777f87':solid.kind==='upper'?'#626d78':'#59636c';ctx.fillRect(p.x,p.y,w,h);
  ctx.fillStyle=solid.kind==='box'?'#c58a51':'#88939d';ctx.fillRect(p.x,p.y,w,Math.min(5,h*.15));ctx.strokeStyle='#2a3036';ctx.lineWidth=1.2;ctx.strokeRect(p.x,p.y,w,h);
  if(debug&&solid.id){ctx.fillStyle='#e3e8ee';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(solid.id,p.x+3,p.y+12);}
 }
 sim.world.hazards.forEach(h=>drawHazard(ctx,h,draw));

 if(sim.world.marker){
  const m=sim.world.marker,p=worldToScreen(m.x,m.y+m.h,draw);ctx.fillStyle='#f3c83b';ctx.fillRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));ctx.strokeStyle='#4f4214';ctx.strokeRect(p.x,p.y,m.w*scale,Math.max(4,m.h*scale));ctx.fillStyle='#201d11';ctx.font=`900 ${Math.max(10,scale*.22)}px Arial`;ctx.textAlign='center';ctx.fillText('SCAR',p.x+m.w*scale/2,p.y-4);
 }
 if(sim.world.star&&!sim.starCollected)drawStar(ctx,sim.world.star.x,sim.world.star.y,sim.world.star.r,draw);
 if(sim.world.goal){const g=sim.world.goal,p=worldToScreen(g.x,g.y+g.h,draw);ctx.strokeStyle='#e6edf3';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x,p.y+g.h*scale);ctx.stroke();ctx.fillStyle='#ef4a4a';ctx.fillRect(p.x,p.y,g.w*scale*.72,g.h*scale*.42);}
 for(const checkpoint of sim.world.checkpoints){const p=worldToScreen(checkpoint.x,checkpoint.y+.2,draw);ctx.fillStyle=checkpoint.id===sim.checkpoint.id?'#62d6ff':'#3f6d7d';ctx.beginPath();ctx.moveTo(p.x,p.y-7);ctx.lineTo(p.x+7,p.y);ctx.lineTo(p.x,p.y+7);ctx.lineTo(p.x-7,p.y);ctx.closePath();ctx.fill();}
 for(const label of sim.world.labels){const p=worldToScreen(label.x,10.15,draw);ctx.fillStyle='#dce4ec';ctx.font=`900 ${Math.max(10,scale*.25)}px Arial`;ctx.textAlign='center';ctx.fillText(label.text,p.x,p.y);}

 drawCharacter(ctx,sim.scar,'S','#17191c',draw);drawCharacter(ctx,sim.eren,'E','#e54747',draw);
 if(debug){
  if(Number.isFinite(sim.scar.navTargetX)&&Number.isFinite(sim.scar.navTargetY)){
   const from=worldToScreen(sim.scar.x,sim.scar.y+sim.scar.h*.5,draw),to=worldToScreen(sim.scar.navTargetX,sim.scar.navTargetY+.2,draw);
   ctx.strokeStyle='#62d6ff';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(to.x,to.y);ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle='#bdefff';ctx.font='700 10px monospace';ctx.textAlign='left';ctx.fillText(sim.scar.navPhase,to.x+5,to.y-5);
  }
  const deadW=3*scale,deadH=1.5*scale;ctx.strokeStyle='#ffd34faa';ctx.setLineDash([7,5]);ctx.strokeRect(draw.ox+(VIEW.w*scale-deadW)/2,draw.oy+(VIEW.h*scale-deadH)/2,deadW,deadH);ctx.setLineDash([]);
  ctx.fillStyle='#fff';ctx.font='700 11px monospace';ctx.textAlign='left';ctx.fillText(`cam ${sim.camera.x.toFixed(2)}, ${sim.camera.y.toFixed(2)} · 60 Hz`,draw.ox+8,draw.oy+16);
 }
 ctx.restore();
}

function updateHud(){
 if(!sim)return;
 byId('gameHearts').textContent='♥ '.repeat(sim.eren.hearts).trim()+' ♡ '.repeat(3-sim.eren.hearts).trim();
 byId('gameStars').textContent=sim.starCollected?'1':'0';
 byId('metricSpeed').textContent=`${format(Math.abs(sim.eren.vx))} m/s`;
 byId('metricHeight').textContent=`${format(Math.max(0,sim.eren.y-2))} m`;
 byId('metricScar').textContent=sim.scar.recoverTimer>0?'RETORNO':sim.scar.crouched?'PASO BAJO':sim.scar.mode==='follow'?'SIGUE':sim.scar.mode==='marker'?'VA A HUELLA':'ESPERA';
 byId('metricState').textContent=sim.eren.recover>0?'RETORNO':sim.eren.crouched?'AGACHADO':sim.eren.onGround?'SUELO':'AIRE';
 byId('gamePrompt').textContent=setMessageFromProgress();
}

function gameLoop(time){
 if(!sim||!sim.running)return;
 if(!previousTime)previousTime=time;
 const delta=Math.min(.05,(time-previousTime)/1000);previousTime=time;accumulator+=delta;
 const input=currentInput();
 while(accumulator>=FIXED_DT){physicsStep(FIXED_DT,input);accumulator-=FIXED_DT;}
 render();
 if(time-lastHudUpdate>90){updateHud();lastHudUpdate=time;}
 frameHandle=requestAnimationFrame(gameLoop);
}

function resetSimulation(reason='reinicio_manual'){
 const wasRunning=!!(sim&&sim.running);if(reason)archiveCurrentAttempt(reason);sim=createSimulation();accumulator=0;previousTime=0;
 byId('gameReward').classList.add('hidden');updateHud();render();
 if(!wasRunning&&!frameHandle)frameHandle=requestAnimationFrame(gameLoop);
}

function setScene(next,reason=`cambio_escena_${scene}_a_${next}`){
 archiveCurrentAttempt(reason);scene=next;labStation='A';
 byId('playGraybox').classList.toggle('active',scene==='graybox');byId('playLab').classList.toggle('active',scene==='lab');
 byId('labControls').classList.toggle('hidden',scene!=='lab');
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===labStation));
 resetSimulation(null);
}

function teleportStation(station){
 if(scene!=='lab')return;archiveCurrentAttempt(`cambio_estacion_${labStation}_a_${station}`);labStation=station;
 document.querySelectorAll('[data-station]').forEach(button=>button.classList.toggle('active',button.dataset.station===station));
 resetSimulation(null);logEvent('estacion',{station});
}

function setControllerMode(enabled){
 document.body.classList.toggle('controller-mode',enabled);byId('controllerStatus').classList.toggle('hidden',!enabled);
}

function startGame(){
 stopNarration();show('game');byId('appTitle').textContent='Eren y Scar · Graybox funcional';
 archiveCurrentAttempt('nuevo_inicio');cancelAnimationFrame(frameHandle);frameHandle=0;sim=createSimulation();previousTime=0;accumulator=0;lastHudUpdate=0;
 byId('gameReward').classList.add('hidden');setControllerMode(false);updateHud();frameHandle=requestAnimationFrame(gameLoop);
}

function openLandscapeGame(){
 if(!TEST_MODE&&!Number(localStorage.getItem('game-tokens')||0)&&!completedStories().size){byId('gameStatus').textContent='Primero completa un cuento nuevo';tone('wrong');return;}
 document.body.classList.add('game-mode');if(window.AndroidLayout)AndroidLayout.landscape();startGame();
}

function closeLandscapeGame(){
 archiveCurrentAttempt('salir_juego');if(sim)sim.running=false;cancelAnimationFrame(frameHandle);frameHandle=0;stopNarration();setControllerMode(false);document.body.classList.remove('game-mode');
 if(window.AndroidLayout)AndroidLayout.portrait();renderMenu();
}

function savePlaytestLog(){
 if(!sim)return'';
 const json=JSON.stringify(playtestBundle(),null,2);localStorage.setItem('graybox-last-playtest',json);byId('playtestLogText').value=json;return json;
}

function openPlaytestDialog(recordEvent=true){
 if(!sim)return;
 if(recordEvent)logEvent('ver_registro');
 savePlaytestLog();logDialogWasPaused=sim.paused;sim.paused=true;byId('playtestLogDialog').classList.remove('hidden');
}

function closePlaytestDialog(){
 byId('playtestLogDialog').classList.add('hidden');if(sim&&!sim.complete)sim.paused=logDialogWasPaused;
}

function sharePlaytest(){
 if(!sim)return;
 logEvent('compartir_registro');const json=savePlaytestLog();
 if(window.AndroidShare&&typeof window.AndroidShare.shareText==='function'){
  window.AndroidShare.shareText('Registro playtest · Eren y Scar',json);toast('Elige dónde enviar el registro.');
 }else{
  openPlaytestDialog(false);toast('Registro guardado. Puedes copiarlo.');
 }
}

async function copyPlaytest(){
 if(!sim)return;
 logEvent('copiar_registro');const json=savePlaytestLog(),area=byId('playtestLogText');let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Registro copiado.':'Mantén pulsado el texto para copiarlo.');
}

async function copyPlaytestSummary(){
 if(!sim)return;
 logEvent('copiar_resumen');const json=JSON.stringify(compactPlaytestBundle(),null,2),area=byId('playtestLogText');area.value=json;localStorage.setItem('graybox-last-playtest-summary',json);let copied=false;
 try{
  if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(json);copied=true;}
  else{area.focus?.();area.select?.();copied=!!document.execCommand?.('copy');}
 }catch(error){copied=false;}
 toast(copied?'Resumen copiado.':'Resumen mostrado: mantén pulsado para copiarlo.');
}

function bindPointerHold(element){
 const names=(element.dataset.controls||'').split(/\s+/).filter(Boolean);
 const release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,names);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

function bindPointerPress(id,name){
 const element=byId(id),release=event=>{event.preventDefault();pointerControls.delete(event.pointerId);element.classList.remove('pressed');};
 element.addEventListener('pointerdown',event=>{event.preventDefault();element.setPointerCapture?.(event.pointerId);pointerControls.set(event.pointerId,[name]);element.classList.add('pressed');});
 element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);element.addEventListener('lostpointercapture',release);
}

document.querySelectorAll('[data-controls]').forEach(bindPointerHold);
bindPointerPress('jump','jump');bindPointerPress('action','action');bindPointerPress('scarAction','scar');

window.addEventListener('keydown',event=>{
 if(!document.body.classList.contains('game-mode'))return;
 if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(event.code))event.preventDefault();
 keyControls.add(event.code);
});
window.addEventListener('keyup',event=>keyControls.delete(event.code));
window.addEventListener('blur',()=>{keyControls.clear();pointerControls.clear();Object.keys(nativeControls).forEach(key=>nativeControls[key]=false);});

window.androidGameKey=(control,pressed)=>{if(!sim||!sim.running)return;setControllerMode(true);if(control in nativeControls)nativeControls[control]=pressed;};
window.androidGameAxis=(x,y)=>{if(!sim||!sim.running)return;setControllerMode(true);nativeControls.left=x<-.35;nativeControls.right=x>.35;nativeControls.up=y<-.55;nativeControls.crouch=y>.55;};
window.addEventListener('gamepadconnected',()=>setControllerMode(true));window.addEventListener('gamepaddisconnected',()=>setControllerMode(false));
byId('gameViewport').addEventListener('pointerdown',event=>{if(!event.target.closest?.('button'))setControllerMode(false);});

byId('directGame').onclick=openLandscapeGame;byId('openGame').onclick=openLandscapeGame;byId('playReward').onclick=openLandscapeGame;byId('exitGame').onclick=closeLandscapeGame;
byId('gameRewardOk').onclick=closeLandscapeGame;byId('gameRewardAgain').onclick=()=>setScene('graybox','probar_otra_vez');
byId('playGraybox').onclick=()=>setScene('graybox','seleccion_graybox');byId('playLab').onclick=()=>setScene('lab','seleccion_laboratorio');
byId('resetGame').onclick=()=>resetSimulation('reinicio_manual');
byId('toggleDebug').onclick=()=>{debug=!debug;byId('toggleDebug').textContent=`Colliders: ${debug?'sí':'no'}`;render();};
byId('exportPlaytest').onclick=sharePlaytest;byId('showPlaytest').onclick=()=>openPlaytestDialog(true);
byId('copyPlaytest').onclick=copyPlaytest;byId('copyPlaytestSummary').onclick=copyPlaytestSummary;byId('sharePlaytest').onclick=sharePlaytest;byId('closePlaytest').onclick=closePlaytestDialog;
document.querySelectorAll('[data-station]').forEach(button=>button.onclick=()=>teleportStation(button.dataset.station));

function bindRange(id,key,output,suffix=''){
 const input=byId(id),target=byId(output);
 input.addEventListener('input',()=>{tuning[key]=Number(input.value);target.textContent=`${format(input.value)}${suffix}`;});
 input.addEventListener('change',()=>{logEvent('ajuste_metrica',{key,value:tuning[key]});if(key==='labHeight'||key==='labGap')resetSimulation(`ajuste_${key}`);});
}
bindRange('heightTuning','labHeight','heightOutput',' m');bindRange('gapTuning','labGap','gapOutput',' m');
bindRange('walkTuning','walk','walkOutput');bindRange('runTuning','run','runOutput');bindRange('jumpTuning','jump','jumpOutput');
byId('gravityTuning').addEventListener('input',event=>{tuning.gravityDown=Number(event.target.value);byId('gravityOutput').textContent=event.target.value;});
byId('gravityTuning').addEventListener('change',()=>logEvent('ajuste_metrica',{key:'gravityDown',value:tuning.gravityDown}));

})();
