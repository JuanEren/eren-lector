package com.juaneren.lector;

import android.app.Activity;
import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        webView.addJavascriptInterface(new LayoutBridge(), "AndroidLayout");
        setContentView(webView);
        tts = new TextToSpeech(this, this);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(new Locale("es", "ES"));
            tts.setSpeechRate(0.72f);
            ttsReady = true;
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { runJs("window.nativeSpeechStart&&window.nativeSpeechStart()"); }
                @Override public void onDone(String id) { runJs("window.nativeSpeechEnd&&window.nativeSpeechEnd()"); }
                @Override public void onError(String id) { runJs("window.nativeSpeechEnd&&window.nativeSpeechEnd()"); }
                @Override public void onRangeStart(String id, int start, int end, int frame) { runJs("window.nativeSpeechRange&&window.nativeSpeechRange(" + start + "," + end + ")"); }
            });
        }
    }

    private void runJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    private boolean sendGameKey(int keyCode, boolean pressed) {
        String control;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT: control = "left"; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: control = "right"; break;
            case KeyEvent.KEYCODE_DPAD_UP: control = "up"; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: control = "crouch"; break;
            case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_BUTTON_R2: control = "run"; break;
            case KeyEvent.KEYCODE_BUTTON_A: control = "jump"; break;
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_B: control = "action"; break;
            default: return false;
        }
        runJs("window.androidGameKey&&window.androidGameKey('" + control + "'," + pressed + ")");
        return true;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) { return sendGameKey(keyCode, true) || super.onKeyDown(keyCode, event); }
    @Override public boolean onKeyUp(int keyCode, KeyEvent event) { return sendGameKey(keyCode, false) || super.onKeyUp(keyCode, event); }
    @Override public boolean onGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && event.getAction() == MotionEvent.ACTION_MOVE) {
            float x = event.getAxisValue(MotionEvent.AXIS_X), y = event.getAxisValue(MotionEvent.AXIS_Y);
            runJs("window.androidGameAxis&&window.androidGameAxis(" + x + "," + y + ")");
            return true;
        }
        return super.onGenericMotionEvent(event);
    }

    public class VoiceBridge {
        @JavascriptInterface public void speak(String text) { if (ttsReady) { tts.stop(); tts.setSpeechRate(0.72f); tts.setPitch(1.0f); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reading"); } }
        @JavascriptInterface public void speakExpressive(String text) {
            if (ttsReady) {
                tts.stop();
                tts.setSpeechRate(0.76f);
                tts.setPitch(1.08f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "expressive-reading");
            }
        }
        @JavascriptInterface public void stop() { if (ttsReady) tts.stop(); }
    }

    public class LayoutBridge {
        @JavascriptInterface public void landscape() { runOnUiThread(() -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)); }
        @JavascriptInterface public void portrait() { runOnUiThread(() -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT)); }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } webView.destroy(); super.onDestroy(); }
}
