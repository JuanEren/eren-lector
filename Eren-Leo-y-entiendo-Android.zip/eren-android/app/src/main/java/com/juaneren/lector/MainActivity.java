package com.juaneren.lector;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        setContentView(webView);
        tts = new TextToSpeech(this, this);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(new Locale("es", "ES"));
            tts.setSpeechRate(0.72f);
            ttsReady = true;
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { runJs("window.nativeSpeechStart&&window.nativeSpeechStart()"); }
                @Override public void onDone(String id) { runJs("window.nativeSpeechEnd&&window.nativeSpeechEnd()"); }
                @Override public void onError(String id) { runJs("window.nativeSpeechEnd&&window.nativeSpeechEnd()"); }
                @Override public void onRangeStart(String id, int start, int end, int frame) { runJs("window.nativeSpeechRange&&window.nativeSpeechRange(" + start + "," + end + ")"); }
            });
        }
    }

    private void runJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    public class VoiceBridge {
        @JavascriptInterface public void speak(String text) { if (ttsReady) { tts.stop(); tts.setSpeechRate(0.72f); tts.setPitch(1.0f); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reading"); } }
        @JavascriptInterface public void speakExpressive(String text) {
            if (ttsReady) {
                tts.stop();
                tts.setSpeechRate(0.76f);
                tts.setPitch(1.08f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "expressive-reading");
            }
        }
        @JavascriptInterface public void stop() { if (ttsReady) tts.stop(); }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } webView.destroy(); super.onDestroy(); }
}
