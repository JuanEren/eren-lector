# Contrato funcional v0.1 · Eren, Scar y Graybox 01

**Proyecto:** Eren · lectura, comprensión y aventura 2D  
**Fecha de emisión:** 25 de agosto de 2026  
**Estado:** **EMITIDO PARA IMPLEMENTACIÓN Y MEDICIÓN**  
**Carácter de los valores:** hipótesis numéricas iniciales; solo se bloquearán tras superar las puertas de validación de este documento.

## 0. Decisión de diseño

El plano de 150 × 50 módulos se conserva como **macroplano aprobado de intención, rutas y contenido**. Sus distancias y alturas no se consideran todavía jugabilidad bloqueada: deberán contrastarse con el controlador real, la cámara real, Scar y el dispositivo táctil.

El primer ciclo tendrá dos escenas separadas:

1. `LAB_MOV_01`: laboratorio sin narrativa para medir movimiento, salto, cámara, colliders, Scar, daño y retorno.
2. `GB_M1_01_UMBRAL`: fragmento jugable de 36 × 12 módulos que reproduce, en pequeño, el patrón del macroplano: ruta principal, bucle superior opcional, orden básica de Scar, estrella, peligro, retorno y meta.

`GB_M1_01_UMBRAL` es una pieza de prueba, no una modificación automática del macroplano. Si funciona, sus proporciones se trasladarán al nivel completo; si no funciona, se cambia el *graybox* antes de tocar el arte aprobado.

## 1. Convenciones técnicas

| Convención | Valor contractual |
|---|---|
| Unidad de mundo | `1 módulo = 100 px` de autoría |
| Subdivisión de geometría | `0,5 módulo = 50 px` |
| Coordenadas | Origen abajo a la izquierda; `x` hacia la derecha, `y` hacia arriba |
| Rectángulos | `[x, y, ancho, alto]`, usando su esquina inferior izquierda |
| Geometría, colliders y triggers colocados | Múltiplos exactos de 0,5 módulo |
| Posición dinámica | Continua: Eren, Scar, objetos móviles y cámara **no** se redondean a la retícula durante el movimiento |
| Física | Paso fijo de `1/60 s`; el resultado no dependerá de los FPS de renderizado |
| Referencia visual | Paisaje `1920 × 1080`; cámara segura de `19,2 × 10,8 módulos` |
| Arte del prototipo | Bloques grises, siluetas simples y etiquetas de depuración; sin decoración final |

La retícula regula lo que se diseña y coloca. Redondear cada fotograma la posición de un cuerpo dinámico produciría tirones y queda expresamente prohibido.

## 2. Tabla de métricas de Eren · candidato v0.1

### 2.1 Cuerpo y locomoción

| Parámetro | Valor | Estado / uso |
|---|---:|---|
| Lienzo artístico | 3 × 2 módulos | Bloqueado por catálogo |
| Pivote | Centro inferior | Bloqueado por catálogo |
| Collider de pie | 1 × 1,5 módulos | Bloqueado por catálogo |
| Collider agachado/arrastre | 1,5 × 1 módulo | Bloqueado por catálogo |
| Collider aéreo | 1 × 1,5 módulos | Bloqueado por catálogo |
| Velocidad de caminar | 3,5 módulos/s | Candidato |
| Velocidad de correr | 6 módulos/s | Candidato |
| Aceleración caminando | 20 módulos/s² | Alcanza velocidad en ≈0,18 s |
| Aceleración corriendo | 24 módulos/s² | Alcanza velocidad en 0,25 s |
| Frenado sin dirección | 28 módulos/s² | Desde carrera: ≤0,75 módulo |
| Inversión de dirección | 36 módulos/s² | Evita un giro instantáneo, sin sensación pesada |
| Aceleración aérea | 14 módulos/s² | Conserva inercia; permite corregir sin girar en seco |
| Velocidad horizontal aérea máxima | 6 módulos/s | No hay impulso oculto por cambiar de animación |
| Escalón automático | 0,5 módulo | Solo con suelo y espacio libre sobre el personaje |
| Caída máxima | 16 módulos/s | Velocidad terminal |
| Daño por caída | Ninguno | El vacío/agua/lava dañan mediante trigger; caer desde altura por sí solo no |

### 2.2 Salto

| Parámetro | Valor candidato |
|---|---:|
| Impulso vertical inicial | 15,9 módulos/s |
| Gravedad en subida | 36 módulos/s² |
| Gravedad en bajada | 44 módulos/s² |
| Altura máxima, botón mantenido | 3,5 módulos |
| Altura mínima objetivo, pulsación breve | 1,5 ± 0,25 módulos |
| Tiempo hasta el ápice | ≈0,44 s |
| Tiempo total, misma altura de salida/llegada | ≈0,84 s |
| Sostenimiento mínimo del impulso | 0,08 s |
| Corte al soltar Salto | Multiplicar velocidad vertical ascendente por 0,35 |
| *Coyote time* | 0,12 s |
| Búfer de salto | 0,12 s |
| Bloqueo de aterrizaje | 0,08 s; no borra una dirección ni un salto almacenado |

Los tres saltos aprobados —vertical, hacia delante y corriendo— comparten la misma física vertical. Cambian la velocidad horizontal de entrada y la animación, no la gravedad ni el collider.

### 2.3 Envolvente de geometría para Eren

| Situación | Distancia/altura de diseño | Uso permitido |
|---|---:|---|
| Escalón sin saltar | 0,5 | Camino principal |
| Repisa vertical estándar | ≤2,5 | Camino principal |
| Repisa vertical deliberada | 3 | Camino principal, con preparación visible |
| Repisa vertical límite | 3,5 | Solo secreto opcional |
| Repisa imposible | ≥4 | Bloqueo inequívoco |
| Hueco estándar caminando | ≤2,5 | Camino principal |
| Hueco estándar corriendo | ≤4 | Camino principal tras enseñar Correr |
| Hueco de habilidad | 4,5 | Solo opcional, sin progreso obligatorio |
| Hueco imposible | ≥5 | No colocar recompensa alcanzable detrás |

Las cifras de 3,5 y 5 módulos son límites, no objetivos habituales. El camino crítico conserva margen respecto al máximo físico.

### 2.4 Daño y retorno de Eren

| Parámetro | Valor contractual |
|---|---:|
| Corazones | 3 |
| Coste de agua, vacío, pinchos o lava | 1 corazón por evento |
| Reacción sin control | 0,25 s |
| Tiempo máximo hasta recuperar el control | 1 s desde el impacto |
| Invulnerabilidad tras volver | 1,25 s |
| Al llegar a 0 corazones | Restaurar 3 en el ancla activa; no borrar la estrella ni progreso del fragmento |

El retorno usa anclas diseñadas y comprobadas. No guarda automáticamente cualquier posición en la que Eren haya tocado suelo, porque podría convertir una plataforma peligrosa o una esquina en un punto de reaparición.

## 3. Tabla de métricas de Scar · candidato v0.1

### 3.1 Cuerpo y locomoción

| Parámetro | Valor | Estado / uso |
|---|---:|---|
| Lienzo de trabajo | 2 × 1,5 módulos | Bloqueado para el lote mínimo |
| Pivote | Centro inferior `(100,150)` | Bloqueado para el lote mínimo |
| Collider de pie/carrera | 1,5 × 1 módulo | Bloqueado como valor inicial del laboratorio; ajustable solo tras medición |
| Collider aéreo | 1,5 × 1 módulo | Bloqueado como valor inicial |
| Collider bajo automático | 1,5 × 0,5 módulo | Candidato activo en GB01 para atravesar el paso bajo mediante enlace de navegación |
| Velocidad andando | 3 módulos/s | Seguimiento próximo |
| Velocidad corriendo | 5,5 módulos/s | Seguimiento normal |
| Velocidad de alcance | 6,5 módulos/s | Solo cuando queda atrás; no es una habilidad jugable |
| Aceleración en suelo | 22 módulos/s² | Candidato |
| Frenado | 28 módulos/s² | Candidato |
| Escalón automático | 0,5 módulo | Igual que Eren |
| Impulso vertical | 14,7 módulos/s | Candidato |
| Gravedad subida/bajada | 36 / 44 módulos/s² | Mismo lenguaje físico que Eren |
| Altura máxima | 3 módulos | Las alturas mayores requieren ruta propia o ayuda de Eren |
| Hueco obligatorio máximo | 3,5 módulos | Incluye margen de IA |
| Tiempo total de salto | ≈0,78 s | Salida y llegada a igual altura |

Scar no colisiona como cuerpo sólido contra Eren: no puede empujarlo, encerrarlo ni servirle de plataforma. La caricia y las órdenes usan proximidad, no una colisión física entre ambos.

### 3.2 Seguimiento, órdenes y recuperación

| Regla | Valor contractual |
|---|---|
| Posición preferida | Entre 1,5 y 3 módulos detrás de Eren |
| Distancia 0–1,5 | Espera o ajusta andando; no invade el collider de Eren |
| Distancia 1,5–5 | Anda hacia su posición preferida |
| Distancia 5–9 | Corre y usa enlaces de salto válidos |
| Distancia 9–14 | Modo alcance; recalcula ruta como máximo cada 0,1 s |
| Separación >14 o ruta imposible | Inicia recuperación de seguridad |
| Respuesta al botón Scar | Gesto/maullido en ≤0,25 s y comienzo de la acción si existe ruta |
| Punto «espera» | Radio de aceptación de 0,5 módulo |
| Pérdida de ruta | Espera 3 s y prueba la jerarquía de navegación antes de reunirse |
| Reunión de seguridad | Solo fuera de cámara; aparece en apoyo seguro y entra andando |
| Daño de Scar | No consume corazones; reacción breve y retorno a apoyo seguro |

Jerarquía obligatoria: ruta habilitada por Eren → túnel de Scar → escalera compartida → ruta alternativa → reunión de seguridad. Scar salta y aterriza mediante su propio cuerpo físico; nunca copia la coordenada vertical de Eren.

## 4. Cámara y escala real de juego

| Parámetro | Contrato v0.1 |
|---|---|
| Marco seguro de diseño | 19,2 × 10,8 módulos, equivalente a 1920 × 1080 a escala de autoría |
| Otras relaciones de aspecto | Nunca recortar el ancho seguro de 19,2; mostrar mundo adicional o usar barras según dispositivo |
| Tamaño aparente de Eren | 1,5/10,8 = 13,9 % de la altura segura |
| Zona muerta | 3 × 1,5 módulos |
| Anticipación horizontal | Hasta 3 módulos en la dirección de avance a velocidad de carrera |
| Transición de anticipación | 0,35 s |
| Suavizado horizontal | 0,18 s |
| Suavizado vertical | 0,25 s |
| Línea de pies en suelo estable | Aproximadamente al 65 % de la altura del marco desde arriba |
| Seguimiento vertical | No se mueve dentro de ±1,5 módulos; sigue al superar esa banda |
| Mirar abajo | Mantener Abajo 0,35 s desplaza hasta 3 módulos; vuelve al soltar |
| Límites | La cámara se limita al volumen del nivel y no revela vacío de producción |

Reglas de encuadre:

- Antes de un salto obligatorio, el apoyo de llegada completo debe estar visible con al menos 1 módulo de margen.
- La anticipación no puede ocultar el borde desde el que se salta.
- Personajes, aterrizajes, peligros, mecanismos, pistas y recompensas obligatorias no pueden quedar bajo las zonas táctiles de las esquinas inferiores.
- El temblor de cámara está desactivado en la versión base. Si se añade al daño, durará como máximo 0,12 s y tendrá opción de reducción.
- La cámara se desplaza de forma continua; no se ajusta a casillas de 0,5.

### 4.1 Interfaz táctil de referencia

Se conserva la disposición aprobada: cruceta a la izquierda; Acción arriba; Correr abajo a la izquierda; Saltar abajo a la derecha; botón de Scar, más pequeño, junto al grupo derecho.

| Elemento | Medida de referencia a 1920 × 1080 |
|---|---:|
| Cruceta completa | 300 × 300 px de zona activa |
| Acción, Correr y Saltar | 160 px visuales; 180 px de zona activa |
| Scar | 125 px visuales; 150 px de zona activa |
| Separación mínima entre zonas activas | 24 px |
| Toques simultáneos | Mínimo 3 |

La escala se adapta uniformemente a la zona segura física del dispositivo. Las diagonales no normalizan la componente horizontal: `Arriba+Dcha.` mantiene `x=1`, para que pulsar una diagonal no reduzca la velocidad. Arriba y Abajo solo añaden su acción contextual; no cancelan izquierda/derecha.

## 5. Contrato de colliders y capas

| Elemento | Forma / caja nominal | Colisiona con | Observaciones |
|---|---|---|---|
| Eren de pie/aéreo | Cápsula o rectángulo redondeado dentro de 1 × 1,5 | Mundo, peligros, objetos funcionales | Base exactamente en el pivote plantar |
| Eren agachado | Cápsula horizontal dentro de 1,5 × 1 | Mundo, peligros | Solo vuelve a pie si cabe la caja 1 × 1,5 |
| Scar de pie/aérea | Cápsula o caja redondeada dentro de 1,5 × 1 | Mundo, peligros de Scar | Valor inicial bloqueado para el laboratorio |
| Scar baja automática | Cápsula horizontal dentro de 1,5 × 0,5 | Mundo, peligros de Scar | Se activa por enlace de paso bajo; no requiere una orden manual de Eren |
| Eren ↔ Scar | Sin colisión sólida | Trigger de proximidad | Evita bloqueos y empujones |
| Terreno | Rectángulos estáticos | Eren, Scar, cajas | Arte y superficie coincidirán después |
| Peligro | Trigger | Eren y/o Scar según máscara | No modifica la forma del terreno |
| Marcador Scar | Trigger de 1,5 × 0,5 | Scar | Confirma acudir/esperar; no cambia geometría en GB01 |
| Punto seguro | Trigger | Eren | Guarda un ancla ya validada, nunca una posición arbitraria |

Se utilizarán detección continua o barrido para los personajes. Los márgenes internos del solucionador físico no son geometría de nivel y pueden usar la precisión técnica necesaria; no se usarán para alterar una distancia diseñada.

## 6. `LAB_MOV_01` · laboratorio de formas grises

### 6.1 Estructura

Escena de 96 × 14 módulos dividida en seis estaciones de 16 módulos. Un selector de depuración teletransporta al inicio de cada estación y reinicia sus contadores. Toda superficie es gris; los peligros, triggers, rutas de Scar y anclas solo reciben contornos de depuración.

| Estación | Franja X | Construcción | Qué decide |
|---|---:|---|---|
| A · Velocidad | 0–16 | Suelo `[0,0,16,2]`; líneas de tiempo en x=2, 7 y 12 | Caminar, correr, aceleración, frenado y giro |
| B · Altura | 16–32 | Salida `[16,0,7,2]`; hueco 2; llegada móvil desde x=25 con desniveles +1,5/+2,5/+3/+3,5/+4 | Salto corto, mantenido y límites verticales |
| C · Distancia | 32–48 | Salida `[32,0,7,2]`; llegada móvil con huecos 1/2,5/3/4/4,5/5 | Envolvente horizontal caminando/corriendo |
| D · Colliders | 48–64 | Suelo `[48,0,16,2]`; techos con luces de 1,5, 1 y 0,5 | Eren de pie/agachado; volumen bajo futuro de Scar |
| E · Scar | 64–80 | Plataformas `[64,0,5,2]`, `[70,0,4,2]`, `[76.5,2,3.5,2]` | Seguimiento, salto propio, orden, espera y ruta perdida |
| F · Daño | 80–96 | Plataformas `[80,0,6,2]` y `[89,0,7,2]`; agua x=86–89; pinchos x=92–93,5 | Corazones, invulnerabilidad, retorno y recuperación de Scar |

La estación D usa estos pasos:

- luz de 1,5: Eren de pie pasa sin engancharse;
- luz de 1: Eren solo pasa agachado y no puede levantarse debajo;
- luz de 0,5: ensayo reservado del collider bajo de Scar; no habilita todavía una mecánica de túnel;
- al salir, cada personaje recupera su postura únicamente si la caja correspondiente cabe.

### 6.2 Lecturas automáticas del laboratorio

La superposición de depuración registrará:

- velocidad X/Y y estado actual;
- tiempo desde pulsación hasta movimiento;
- punto de despegue, ápice y aterrizaje;
- altura y distancia reales del salto;
- collider activo y contactos de suelo/techo;
- posición y estado de Scar, enlace de navegación elegido y última ruta válida;
- ancla segura activa, corazón perdido y tiempo hasta recuperar el control;
- rectángulo de cámara, anticipación y elementos tapados por la UI.

## 7. `GB_M1_01_UMBRAL` · primer fragmento jugable

### 7.1 Objetivo de experiencia

En 2–3 minutos de primera partida, Eren debe sentir que controla bien al protagonista, descubre voluntariamente un pequeño desvío, recoge una estrella, comprueba que Scar responde a su orden sin bloquearlo, realiza un salto corriendo con aterrizaje visible, sufre como máximo un retorno corto y llega a una meta clara.

### 7.2 Relación con el macroplano

GB01 comprime sistemas ya presentes en el tramo inicial del macroplano para poder probarlos en dos pantallas. No afirma que sus coordenadas sustituyan todavía a las del plano de 150 × 50.

| Elemento de GB01 | Fuente en el macroplano |
|---|---|
| Zona segura inicial | Explanada x=0–20 |
| Desvío superior opcional | Inicio de la subida hacia la ruta superior, x≈20–42 |
| Orden básica de Scar | Primer nodo `S`, x≈46–56; en GB01 solo se prueba acudir/esperar |
| Agua y retorno | Primeros peligros localizados de la ruta inferior, x≈32–47 |
| Meta local | Fin de la prueba; no representa la meta `M` del nivel completo |

### 7.3 Geometría exacta

| ID | Rectángulo / punto | Función |
|---|---|---|
| `G0` | `[0,0,10,2]` | Inicio seguro |
| `G1` | `[11,0,7,2]` | Plataforma tras hueco tutorial de 1 módulo |
| `G2` | `[19.5,0,5,2]` | Plataforma tras segundo hueco corto y ancla R1 |
| `G3` | `[28,0,8,2]` | Aterrizaje, ancla R2, pinchos y meta |
| `TECHO_CAJA` | `[7.5,3.5,2,0.5]` | Impide saltar sobre la caja; obliga a probar Acción |
| `TECHO_BAJO` | `[12,3,2,0.5]` | Luz de 1 módulo; obliga a agacharse/arrastrarse |
| `U1` | `[14.5,4,4,0.5]` | Primer apoyo del bucle opcional |
| `U2` | `[19,6,4,0.5]` | Punto alto con estrella visible |
| `U3` | `[22.5,4.5,2,0.5]` | Retorno a G2 antes del salto corriendo |
| `CAJA_TEST` | `[8,2,1,1]` | Acción/golpe; se rompe sin alterar la geometría |
| `ESTRELLA_TEST` | trigger `[20.5,6.5,0.5,0.5]` | Coleccionable provisional del bucle superior |
| `MARCADOR_SCAR` | trigger `[15,2,1.5,0.5]` | Scar acude, confirma y espera; no abre puerta ni túnel |
| `AGUA` | `[24.5,-2,3.5,3.5]` | Hueco de carrera; daño al caer |
| `PINCHOS` | `[30.5,2,1.5,0.5]` | Prueba visible de daño y salto corto |
| `R0` | pies `(6.5,2)` | Inicio y primer retorno |
| `R1` | pies `(22,2)` | Se activa al aterrizar en G2 |
| `R2` | pies `(29,2)` | Se activa al aterrizar tras el agua |
| `META` | trigger `[34.5,2,1,2]` | Cierre claro del fragmento |

Spawns: Eren con los pies en `(6.5,2)` y Scar en `(5,2)`. Ambos quedan fuera de la zona de oclusión de la cruceta. Límites de cámara: x=0–36 y y=0–12.

### 7.4 Secuencia de *beats*

| Beat | Experiencia y sistema | Criterio local |
|---|---|---|
| 1 · Control | G0 ofrece 10 módulos seguros y espacio a la izquierda del spawn | El jugador prueba cruceta, carrera y cambio de dirección sin riesgo |
| 2 · Acción | La caja está bajo un techo y no puede saltarse | Se rompe sin mover la plataforma ni cambiar el collider de Eren |
| 3 · Salto | Hueco de 1 módulo entre G0 y G1 | No requiere Correr; aterrizaje visible |
| 4 · Agacharse | Techo con luz de 1 módulo sobre G1 | Eren entra bajo, avanza y solo se levanta al disponer de espacio |
| 5 · Scar | Una huella visible marca un punto de espera | Una orden hace acudir y confirmar; una segunda pulsación libera/llama a Scar |
| 6 · Lectura breve | «Scar, espera sobre la huella.» | El texto provoca una acción inmediata; no abre un cuestionario |
| 7 · Elección | U1→U2→U3 forma un bucle superior con una estrella | Recompensa visible desde abajo y retorno a G2 |
| 8 · Carrera | Hueco de agua de 3,5 módulos | Obliga a usar Correr + Salto; la llegada completa está encuadrada |
| 9 · Daño y retorno | Agua o pinchos restan un corazón | Retorno al ancla más próxima en ≤1 s; progreso y estrella se conservan |
| 10 · Cierre | Meta a 3 módulos de los pinchos | Celebración provisional y pantalla de resultados de depuración |

Ayuda graduada junto a la huella: texto inmediato; tras 3 s sin acción Scar mira el marcador y aparece `?`; tras 6 s se anima el icono de pata. Cuando Scar confirma, el icono cambia a «Llamar» para enseñar la segunda pulsación. No hay explicación oral del diseñador durante el test.

La confirmación de la huella exige simultáneamente radio horizontal de 0,5 módulo, altura de la ruta inferior y apoyo sobre `G1`. Una coincidencia solo horizontal desde `U1` no es válida. Si Scar recibe la orden desde `U1`, utiliza los descensos `U1 → TECHO_BAJO → G1`; si llega desde la izquierda, atraviesa el paso bajo con collider bajo automático.

### 7.5 Fuera de alcance de GB01

- arte final, paralaje, iluminación y fauna;
- enemigos, combate completo y sistema artístico completo de cajas rompibles; `CAJA_TEST` es un bloque gris;
- escaleras, plataformas móviles y puzles de letras/números;
- túneles y mecanismos avanzados de Scar distintos del paso bajo funcional ensayado en GB01;
- economía definitiva de estrellas de lectura;
- guardado entre sesiones y selección de libros;
- más de una instrucción lectora obligatoria.

## 8. Prueba de cruceta, correr, saltar, daño y retorno

| ID | Prueba | Procedimiento | Aprobación |
|---|---|---|---|
| `IN-01` | Cruceta | Izquierda/derecha, diagonales y cambios durante 50 pulsaciones | 50/50 reconocidas; ninguna dirección queda retenida al soltar |
| `IN-02` | Multitáctil | Dirección + Correr + Saltar; dirección + Scar, 20 veces cada combinación | 20/20 sin cancelar otro toque |
| `IN-03` | Acción | Golpear la caja diez veces desde ambos lados | 10/10; una pulsación no se duplica ni cancela dirección |
| `MV-01` | 5 módulos andando | Salir desde reposo en estación A | 1,50 s ±0,10 |
| `MV-02` | 5 módulos corriendo | Salir desde reposo manteniendo Correr | 0,96 s ±0,08 |
| `MV-03` | Frenado | Soltar dirección a 6 módulos/s | Detención en ≤0,75 módulo |
| `JP-01` | Salto corto | Diez pulsaciones breves | Ápice medio entre 1,25 y 1,75 |
| `JP-02` | Salto máximo | Diez pulsaciones mantenidas | Ápice 3,5 ±0,15 |
| `JP-03` | Hueco estándar | Diez intentos de 2,5 andando y 4 corriendo | ≥9/10 en cada caso |
| `JP-04` | Límite | Probar 4,5 y 5 módulos | 4,5 solo se clasifica opcional; 5 no puede ser necesario |
| `CO-01` | Colliders | Pasar las tres luces y tratar de levantarse bajo techo | Ningún enganche, penetración o cambio de escala |
| `CO-02` | Paso bajo GB01 | Entrar, avanzar, invertir dirección y salir bajo `TECHO_BAJO` | No permite saltar ni levantarse; devuelve el collider de pie al salir |
| `SC-01` | Seguimiento | Recorrer estación E y GB01 sin esperar a Scar | Scar completa ≥95 % de recorridos válidos sin reunión de seguridad |
| `SC-02` | Física propia | Saltar con Eren mientras Scar queda quieta o toma otra ruta | La Y de Scar nunca se copia; aterriza por contacto propio |
| `SC-03` | Orden | Enviar a Scar al marcador desde G1 y desde U1, liberarla y llamarla | Respuesta ≤0,25 s; llega a G1 dentro del radio de 0,5; no valida desde otra altura ni usa teletransporte visible |
| `SC-04` | Paso bajo | Enviar a Scar desde la izquierda del techo bajo hasta la huella | Activa collider 1,5 × 0,5, atraviesa sin saltar contra el techo y recupera su collider al salir |
| `RW-01` | Estrella | Verla desde la ruta, recogerla y sufrir daño después | Recogida inequívoca; no reaparece ni se pierde tras el retorno |
| `DM-01` | Daño | Tocar agua y pinchos una vez | Pierde exactamente 1 corazón por evento |
| `DM-02` | Retorno | Medir desde daño hasta control | ≤1 s; reaparece en ancla segura mirando hacia la ruta |
| `DM-03` | Invulnerabilidad | Mantenerse cerca del peligro tras volver | 1,25 s sin daño repetido; feedback visible |
| `CA-01` | Cámara | Ejecutar todos los saltos obligatorios a derecha e izquierda | Despegue y llegada visibles; sin salto de fe |
| `CA-02` | UI | Repetir en dispositivo con controles táctiles | Ningún apoyo, peligro o mecanismo obligatorio queda tapado |

Se repetirán `MV`, `JP`, `DM` y `CA` con render limitado a 30 y 60 FPS. Las trayectorias y los tiempos físicos no pueden variar más de un 5 %.

## 9. Protocolo de *playtest* del fragmento

1. Equipo: eliminar fallos técnicos sin evaluar todavía diversión.
2. Persona que desconoce el plano: observar sin explicar y verificar legibilidad.
3. Eren: sesión breve, sin convertirla en examen y sin corregirle durante el recorrido.
4. Repetición otro día: separar aprendizaje real de novedad inicial.

Registrar por intento: dispositivo, límite de FPS, tiempo total, primer movimiento, primera carrera, cada despegue/aterrizaje, ruta elegida, estrella, uso de Scar, ayudas mostradas, daño, ancla, tiempo de retorno, peticiones de ayuda, abandono y deseo espontáneo de continuar.

El fragmento pasa la prueba con Eren cuando:

- termina sin instrucciones orales del adulto después de las ayudas previstas;
- usa la combinación Correr + Saltar en el hueco de 3,5 sin más de tres fallos consecutivos;
- entiende o descubre el papel de Scar sin que el adulto pulse por él;
- ningún error elimina progreso ya obtenido;
- la segunda partida muestra igual o menor fricción que la primera;
- al terminar puede explicar, con sus palabras o señalando, qué orden dio a Scar y cómo respondió.

Que quiera continuar se registrará como señal motivacional importante, pero una única respuesta verbal no sustituye la observación de varias sesiones.

## 10. Emisión del contrato funcional

### Obligaciones de implementación

- `CF-01` Toda magnitud se expresará en módulos; no se ajustará una animación para cambiar una trayectoria.
- `CF-02` Las métricas estarán en un archivo de configuración y no dispersas en código.
- `CF-03` Eren y Scar conservarán collider, pivote y escala entre fotogramas de un mismo estado.
- `CF-04` La entrada táctil aceptará al menos tres toques simultáneos.
- `CF-05` Scar navegará mediante enlaces y física propia; la reunión será el último recurso y ocurrirá fuera de cámara.
- `CF-06` Todo salto obligatorio mostrará su aterrizaje antes del compromiso.
- `CF-07` Daño = un corazón + feedback + retorno corto + 1,25 s de invulnerabilidad.
- `CF-08` El *graybox* no incorporará arte final ni ampliará el catálogo.
- `CF-09` Ningún valor candidato se declarará bloqueado solo porque «se siente bien» para el equipo.
- `CF-10` Cada modificación cambiará una hipótesis identificada y se anotará con resultado de prueba.

### Entregables de la implementación

1. Build de `LAB_MOV_01`.
2. Build de `GB_M1_01_UMBRAL`.
3. Configuración versionada de métricas.
4. Registro exportable de las pruebas anteriores.
5. Capturas de 30 y 60 FPS con colliders, cámara y rutas de Scar visibles.
6. Acta `APROBADO`, `REVISAR` o `RECHAZADO` por cada puerta de validación.

### Entrega mínima a Arte/Animación

- Este contrato aporta a `EREN_E1_R1` la cámara real, la escala aparente, el pivote, los colliders y las velocidades que faltaban para probar los diez fotogramas candidatos.
- El alcance visual vigente no cambia: Eren, 11 secuencias/28 fotogramas objetivo; Scar, 9 secuencias/21 fotogramas objetivo.
- Los personajes pueden sustituirse por siluetas regladas mientras una secuencia siga en borrador. El arte candidato no bloquea el laboratorio.
- No se solicitan todavía caricia, túnel de Scar, escalera, cooperación avanzada, celebración final ni combate completo.
- Superar este contrato no promueve automáticamente ningún PNG a `GAME_READY`; la prueba en cámara es evidencia de entrada para el QA correspondiente.

### Puerta de salida

El contrato pasa de `v0.1 candidato` a `v1.0 bloqueado` únicamente cuando:

- todas las pruebas técnicas obligatorias están aprobadas;
- el fragmento es completado por una persona nueva sin explicación;
- Eren lo completa con las ayudas internas previstas;
- se ha realizado al menos una iteración posterior al primer test;
- las distancias del macroplano se han revisado contra la envolvente aprobada;
- cámara, controles y retorno han sido comprobados en el dispositivo móvil objetivo.

Hasta entonces, el estado correcto es: **macroplano aprobado; métricas, cámara y geometría jugable pendientes de validación**.

## 11. Decisiones que este contrato cierra

- Primera escala de cámara y tamaño aparente de personajes.
- Valores iniciales completos de caminar, correr, saltar y caer.
- Envolvente modular para repisas y huecos.
- Colliders propuestos de Scar y mantenimiento de los colliders bloqueados de Eren.
- Seguimiento, llamada y recuperación de Scar.
- Dos escenas concretas y su geometría.
- Una estrella provisional, un único texto diegético y una única orden básica de Scar en GB01.
- Daño amable con retorno corto y sin pérdida de progreso.
- Criterios verificables para decidir si se puede construir el Nivel 1.

## 12. Referencias internas

- `REGLAS_CONTROLES_EREN_SCAR.md`
- `REGLAS_OBLIGATORIAS.md`
- `ESTADO_PRODUCCION.md`
- `Plano_Nivel_1_150x50.png`
- `CATALOGO_MUNDO_1.md`
- `CATALOGO_SCAR.md`
- `CATALOGO_EREN.md`
- `ALCANCE_MINIMO_EREN_SCAR_GREYBOX.md`
- `ANEXO_GAME_LEVEL_DESIGN_GREYBOX_V1.md`
- `GUIA_MAESTRA_ESTADO_Y_RUTA.md`
- `DIAGNOSTICO_Y_METODOLOGIA_GAME_DESIGN_EREN.md`
