# Protocolo breve de playtest · GB01

## Objetivo

Decidir si movimiento, salto, cámara, colliders, Scar y retorno son suficientemente claros y agradables antes de montar el Nivel 1 completo o aplicar arte final.

## Preparación

- Probar en el dispositivo Android habitual y en horizontal.
- Hacer primero una pasada con controles táctiles y después otra con mando.
- Mantener los valores iniciales durante la primera pasada.
- No explicar la solución salvo bloqueo de más de 20 segundos.

## Pasada 1 · Graybox 01

1. Caminar, frenar y cambiar de sentido en la primera plataforma.
2. Intentar saltar la entrada y golpear su parte gris: `U0_VERTICAL` debe permanecer. Romper solo la caja marrón inferior con `ACCIÓN`, comprobar que de pie aún bloquea y atravesar la abertura agachado.
3. Probar salto corto y salto mantenido.
4. Pasar agachado bajo el techo de 1 módulo.
5. Leer «Scar, espera sobre la huella» y usar el botón `SCAR`.
   - Repetir una vez con Scar detrás del túnel y otra con Scar sobre la plataforma superior.
   - La orden solo es correcta si termina físicamente sobre la huella de la ruta inferior.
6. Probar por separado la ruta baja G1→G2 y la ruta alta U1→U2→U3; ambas deben ser fiables y la estrella sigue siendo opcional.
7. Cruzar el agua con `CORRER + SALTAR` y observar si Scar ejecuta su salto largo sin caer ni desaparecer.
8. Saltar las dos puntas andando y comprobar que existe margen visible. En otro intento, tocarlas deliberadamente una vez para comprobar daño y retorno.
9. Alcanzar la meta y comprobar que la celebración espera a que Scar llegue a G3.

Registrar especialmente:

- Si Eren se siente pesado, controlado o nervioso.
- Si el salto parece corto, correcto o flotante.
- Si la cámara anticipa bien sin marear.
- Si se entiende qué hace el botón de Scar.
- Si el rombo derecho se reconoce sin explicación: Scar azul arriba, Correr verde izquierda, Acción roja derecha y Saltar amarillo abajo.
- Si el retorno tras daño es inmediato y no frustrante.

## Pasada 2 · Laboratorio

- `A`: comparar andar/correr, frenada y giro.
- `B`: variar el desnivel entre 1,5 y 4 módulos.
- `C`: variar el hueco entre 1 y 5 módulos.
- `D`: comprobar caja, techo de pie y techo agachado.
- `E`: observar a Scar en superficies de distinta altura.
- `F`: repetir agua, pinchos y retorno.

Usar `Ajuste vivo de sensaciones` para modificar una sola variable cada vez. Tras cada cambio, reiniciar la estación y repetir exactamente la misma acción.

## Criterio de salida

No se aprueba el Nivel 1 completo hasta que:

- no haya enganches visibles de collider;
- el hueco obligatorio de 4 módulos falle andando y sea fiable corriendo;
- la caja inferior no pueda omitirse, `U0_VERTICAL` permanezca tras romperla, el paso exija agacharse y los dos pinchos puedan saltarse andando sin una salida o aterrizaje al límite;
- tanto G1→G2 como U1→U2→U3 sean rutas válidas y legibles;
- Scar complete la prueba sin copiar la altura de Eren;
- Scar atraviese el agua 10/10 veces con el enlace contextual y cero recuperaciones por agua;
- daño y retorno devuelvan control en menos de 1 segundo;
- cruceta, correr y saltar admitan pulsación simultánea;
- el jugador pueda terminar el tramo sin explicación externa.

El botón `Compartir registro` guarda la sesión en el dispositivo y abre el menú nativo de Android para enviarla. `Ver registro` permite copiar el JSON completo o un resumen compacto para ChatGPT. El registro conserva hasta diez intentos con actividad —excluye aperturas vacías del visor— e incluye ajustes, métricas, salto largo, recuperación, reunión en meta, estados finales y eventos temporales.
