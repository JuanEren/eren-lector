# Protocolo breve de playtest · GB01

## Objetivo

Decidir si movimiento, salto, cámara, colliders, Scar y retorno son suficientemente claros y agradables antes de montar el Nivel 1 completo o aplicar arte final.

## Preparación

- Probar en el dispositivo Android habitual y en horizontal.
- Hacer primero una pasada con controles táctiles y después otra con mando.
- Mantener los valores iniciales durante la primera pasada.
- No explicar la solución salvo bloqueo de más de 20 segundos.

## Pasada 1 · Graybox 01

1. Caminar, frenar y cambiar de sentido en la primera plataforma.
2. Romper la caja con `ACCIÓN`.
3. Probar salto corto y salto mantenido.
4. Pasar agachado bajo el techo de 1 módulo.
5. Leer «Scar, espera sobre la huella» y usar el botón `SCAR`.
   - Repetir una vez con Scar detrás del túnel y otra con Scar sobre la plataforma superior.
   - La orden solo es correcta si termina físicamente sobre la huella de la ruta inferior.
6. Elegir ruta baja o ruta alta; la estrella es opcional.
7. Cruzar el agua con `CORRER + SALTAR`.
8. Tocar una vez los pinchos para comprobar daño y retorno.
9. Alcanzar la meta.

Registrar especialmente:

- Si Eren se siente pesado, controlado o nervioso.
- Si el salto parece corto, correcto o flotante.
- Si la cámara anticipa bien sin marear.
- Si se entiende qué hace el botón de Scar.
- Si el retorno tras daño es inmediato y no frustrante.

## Pasada 2 · Laboratorio

- `A`: comparar andar/correr, frenada y giro.
- `B`: variar el desnivel entre 1,5 y 4 módulos.
- `C`: variar el hueco entre 1 y 5 módulos.
- `D`: comprobar caja, techo de pie y techo agachado.
- `E`: observar a Scar en superficies de distinta altura.
- `F`: repetir agua, pinchos y retorno.

Usar `Ajuste vivo de sensaciones` para modificar una sola variable cada vez. Tras cada cambio, reiniciar la estación y repetir exactamente la misma acción.

## Criterio de salida

No se aprueba el Nivel 1 completo hasta que:

- no haya enganches visibles de collider;
- el hueco obligatorio de 3,5 módulos sea fiable corriendo;
- Scar complete la prueba sin copiar la altura de Eren;
- daño y retorno devuelvan control en menos de 1 segundo;
- cruceta, correr y saltar admitan pulsación simultánea;
- el jugador pueda terminar el tramo sin explicación externa.

El botón `Compartir registro` guarda la sesión en el dispositivo y abre el menú nativo de Android para enviarla. `Ver registro` permite revisarla y copiarla manualmente. El JSON conserva hasta diez intentos, incluso después de reiniciar o cambiar de escena, e incluye el motivo de cierre, ajustes activos, métricas, estados de navegación de Scar, estado final y eventos temporales.
