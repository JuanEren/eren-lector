import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';

const key = process.env.AZURE_SPEECH_KEY;
const region = process.env.AZURE_SPEECH_REGION;
const voice = process.env.AZURE_SPEECH_VOICE || 'es-ES-ElviraNeural';
if (!key || !region) throw new Error('Faltan AZURE_SPEECH_KEY o AZURE_SPEECH_REGION.');

const root = process.cwd();
const appFile = path.join(root, 'app/src/main/assets/www/app.js');
const outputDir = path.join(root, 'app/src/main/assets/www/assets/audio');
const source = await fs.readFile(appFile, 'utf8');
const dataSection = source.slice(0, source.indexOf('let story='));
const sandbox = {};
vm.createContext(sandbox);
const catalogue = vm.runInContext(`${dataSection}\nJSON.stringify({stories,levelAdditions})`, sandbox);
const { stories, levelAdditions } = JSON.parse(catalogue);
await fs.mkdir(outputDir, { recursive: true });

const xml = value => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function narrationText(storyIndex, paragraphIndex, level) {
  const item = stories[storyIndex].items[paragraphIndex];
  const additions = item.extra || levelAdditions[storyIndex][paragraphIndex];
  return [item.text, ...additions.slice(0, Math.max(0, level - 1))].join(' ');
}

function ssml(text) {
  const sentences = text.match(/[^.!?]+[.!?]?/g)?.map(part => part.trim()).filter(Boolean) || [text];
  const spoken = sentences.map((sentence, index) => {
    const emphasis = index === sentences.length - 1 && sentences.length > 1 ? `<emphasis level="moderate">${xml(sentence)}</emphasis>` : xml(sentence);
    return `<s>${emphasis}</s>${index < sentences.length - 1 ? '<break time="330ms"/>' : ''}`;
  }).join('');
  return `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="es-ES"><voice name="${voice}"><prosody rate="-6%" pitch="+3%" volume="+4%">${spoken}</prosody></voice></speak>`;
}

async function synthesize(text, destination) {
  const endpoint = `https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`;
  for (let attempt = 1; attempt <= 4; attempt++) {
    const response = await fetch(endpoint, { method: 'POST', headers: { 'Ocp-Apim-Subscription-Key': key, 'Content-Type': 'application/ssml+xml', 'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3', 'User-Agent': 'eren-reading-app' }, body: ssml(text) });
    if (response.ok) { await fs.writeFile(destination, Buffer.from(await response.arrayBuffer())); return; }
    if (attempt === 4) throw new Error(`Azure TTS ${response.status}: ${await response.text()}`);
    await sleep(attempt * 1200);
  }
}

let created = 0, reused = 0;
for (let storyIndex = 0; storyIndex < stories.length; storyIndex++) {
  for (let paragraphIndex = 0; paragraphIndex < stories[storyIndex].items.length; paragraphIndex++) {
    for (let level = 1; level <= 4; level++) {
      const destination = path.join(outputDir, `story-${storyIndex}-paragraph-${paragraphIndex}-level-${level}.mp3`);
      try { const stat = await fs.stat(destination); if (stat.size > 1000) { reused++; continue; } } catch {}
      await synthesize(narrationText(storyIndex, paragraphIndex, level), destination);
      created++;
      process.stdout.write(`\rLocuciones creadas: ${created} · reutilizadas: ${reused}`);
    }
  }
}
console.log(`\nAudio listo. Voz: ${voice}. Nuevos: ${created}. Reutilizados: ${reused}.`);
