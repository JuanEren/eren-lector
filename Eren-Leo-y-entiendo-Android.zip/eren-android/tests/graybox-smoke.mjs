import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('game.css', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const gradle = await readFile(new URL('../../../../build.gradle.kts', root), 'utf8');
const source = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={getSim:()=>sim,reset:reason=>resetSimulation(reason),commandScar};
})();`);

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id;
    this.dataset = {};
    this.classList = new ClassList();
    this.listeners = new Map();
    this.style = {};
    this.textContent = '';
    this.value = '';
    this.offsetWidth = 10;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, pointerId: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  closest(selector) { return selector === 'button' ? this : null; }
}

const elements = new Map();
for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
const get = id => elements.get(id);
const controlMap = {
  moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
  moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
};
for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
for (const [id, value] of Object.entries({ heightTuning: '3', gapTuning: '4', walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;

const stations = [...'ABCDEF'].map(letter => { const element = new Element(); element.dataset.station = letter; return element; });
const body = new Element('body');
const documentListeners = new Map();
const document = {
  body,
  getElementById: id => get(id),
  querySelectorAll: selector => selector === '[data-controls]' ? [...elements.values()].filter(element => element.dataset.controls) : selector === '[data-station]' ? stations : [],
  createElement: () => new Element(),
  addEventListener(type, callback) {
    if (!documentListeners.has(type)) documentListeners.set(type, []);
    documentListeners.get(type).push(callback);
  },
};

const gradient = { addColorStop() {} };
const context2d = new Proxy({ createLinearGradient: () => gradient }, {
  get(target, key) { if (key in target) return target[key]; return () => {}; },
  set(target, key, value) { target[key] = value; return true; },
});
get('gameCanvas').getContext = () => context2d;
get('gameCanvas').getBoundingClientRect = () => ({ width: 960, height: 540 });

const storage = new Map();
const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
const windowListeners = new Map();
let nextFrame = null;
let frameId = 0;
let sharedText = '';
const window = {
  document,
  devicePixelRatio: 1,
  innerWidth: 960,
  innerHeight: 540,
  AndroidShare: { shareText(subject, text) { sharedText = `${subject}\n${text}`; } },
  addEventListener(type, callback) {
    if (!windowListeners.has(type)) windowListeners.set(type, []);
    windowListeners.get(type).push(callback);
  },
  dispatchEvent(event) { for (const callback of windowListeners.get(event.type) || []) callback(event); },
  requestAnimationFrame(callback) { nextFrame = callback; return ++frameId; },
  cancelAnimationFrame() { nextFrame = null; },
};

const sandbox = {
  window, document, navigator: { getGamepads: () => [] }, localStorage,
  requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
  Blob, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, setTimeout: callback => { callback(); return 1; }, clearTimeout() {},
  console,
  completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
  tone() {}, playAzureSequence() {}, renderMenu() {},
};
window.localStorage = localStorage;
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: 'graybox-game.js' });

if (!sourceText.includes("APP_VERSION='19.0.0-graybox-layout-scar-jump'") || !gradle.includes('versionCode = 19')) throw new Error('La versión Android y la versión del graybox no quedaron alineadas en v19.');
if (!css.includes('.scar-button{top:0;left:50%') || !css.includes('background:#1769d2')) throw new Error('Scar no quedó arriba y azul en el rombo derecho.');
if (!css.includes('.run-button{left:4%;top:50%') || !css.includes('background:#159a65')) throw new Error('Correr no quedó a la izquierda y verde.');
if (!css.includes('.action-button{right:4%;top:50%') || !css.includes('background:#e13d42')) throw new Error('Acción no quedó a la derecha y roja.');
if (!css.includes('.jump-button{left:50%;bottom:0') || !css.includes('background:#f2b516')) throw new Error('Saltar no quedó abajo y amarillo.');

get('directGame').click();
if (!body.classList.contains('game-mode')) throw new Error('El acceso directo no abrió el juego sin completar un cuento.');

const grayboxWorld = window.__grayboxTest.getSim().world;
const solid = id => grayboxWorld.solids.find(item => item.id === id);
const modular = value => Math.abs(value * 2 - Math.round(value * 2)) < 1e-9;
for (const item of [...grayboxWorld.solids, ...grayboxWorld.hazards, grayboxWorld.marker, grayboxWorld.goal]) {
  for (const key of ['x', 'y', 'w', 'h']) if (!modular(item[key])) throw new Error(`${item.id || 'trigger'}.${key}=${item[key]} no respeta la retícula de 0,5 módulo.`);
}
if (!modular(grayboxWorld.star.x) || !modular(grayboxWorld.star.y)) throw new Error('El anclaje de la estrella no respeta la retícula de 0,5 módulo.');
if (solid('TECHO_CAJA').x + solid('TECHO_CAJA').w !== 8 || solid('G0').x + solid('G0').w - (solid('TECHO_CAJA').x + solid('TECHO_CAJA').w) !== 2) throw new Error('El techo de la caja no dejó 2 módulos seguros antes del borde de G0.');
if (solid('U2').x - (solid('U1').x + solid('U1').w) !== 1.5) throw new Error('U1 y U2 no dejaron el canal horizontal de 1,5 módulos.');
if (solid('G2').x + solid('G2').w - (solid('U3').x + solid('U3').w) !== 2) throw new Error('U3 no dejó 2 módulos seguros antes del agua.');
const spikes = grayboxWorld.hazards.find(item => item.id === 'PINCHOS');
if (spikes.x - (grayboxWorld.checkpoints.find(item => item.id === 'R2').x + .5) !== 2.5) throw new Error('R2 no dejó 2,5 módulos libres antes de los pinchos.');

const tick = time => {
  const callback = nextFrame;
  if (!callback) throw new Error('No hay frame de juego pendiente.');
  nextFrame = null;
  callback(time);
};
tick(16.7);

window.dispatchEvent({ type: 'keydown', code: 'Space', preventDefault() {} });
for (let i = 2; i < 15; i++) tick(i * 16.7);
const state = get('metricState').textContent;
if (state !== 'AIRE') throw new Error(`El salto no produjo estado AIRE: ${state}`);
window.dispatchEvent({ type: 'keyup', code: 'Space', preventDefault() {} });
for (let i = 15; i < 61; i++) tick(i * 16.7);

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
for (let i = 61; i < 80; i++) tick(i * 16.7);
const speed = get('metricSpeed').textContent;
if (!speed || speed === '0,0 m/s') throw new Error('La física no respondió al movimiento horizontal.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });

window.dispatchEvent({ type: 'keydown', code: 'KeyX', preventDefault() {} });
tick(1350);
window.dispatchEvent({ type: 'keyup', code: 'KeyX', preventDefault() {} });
tick(1367);
get('exportPlaytest').click();
const grayboxLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const grayboxAttempt = grayboxLog.attempts.at(-1);
if (!grayboxAttempt.events.some(event => event.type === 'caja_rota')) throw new Error('La acción no rompió la caja dentro del rango funcional.');
if (!sharedText.includes('Registro playtest') || !sharedText.includes('caja_rota')) throw new Error('El puente de compartir no recibió el registro del playtest.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowDown', preventDefault() {} });
for (let i = 83; i < 91; i++) tick(i * 16.7);
if (get('metricState').textContent !== 'AGACHADO') throw new Error('El collider agachado no se activó.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowDown', preventDefault() {} });

const placeActorsForScarTest = (scarX, scarY) => {
  const live = window.__grayboxTest.getSim();
  Object.assign(live.eren, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
  Object.assign(live.scar, { x: scarX, y: scarY, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
  window.__grayboxTest.commandScar();
  return live;
};

let scenarioTime = 1520;
let lowerScar = placeActorsForScarTest(11.05, 2);
for (let i = 0; i < 420 && lowerScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (lowerScar.scar.mode !== 'wait' || Math.abs(lowerScar.scar.y - 2) > .1) throw new Error('Scar no llegó físicamente a la placa desde detrás del túnel.');
if (!lowerScar.events.some(event => event.type === 'scar_paso_bajo_inicio') || !lowerScar.events.some(event => event.type === 'scar_en_huella')) throw new Error('No se registró el paso bajo y la llegada de Scar.');

window.__grayboxTest.reset('prueba_scar_desde_abajo');
let upperScar = placeActorsForScarTest(15.75, 4.5);
for (let i = 0; i < 720 && upperScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (upperScar.scar.mode !== 'wait' || Math.abs(upperScar.scar.y - 2) > .1) throw new Error(`Scar validó mal o no bajó desde U1: ${upperScar.scar.x.toFixed(2)}, ${upperScar.scar.y.toFixed(2)}, ${upperScar.scar.navPhase}`);
if (!upperScar.events.some(event => event.type === 'scar_ruta' && event.phase === 'bajar_u1_a_techo') || !upperScar.events.some(event => event.type === 'scar_en_huella')) throw new Error('La ruta de descenso U1 → placa no quedó registrada.');

window.__grayboxTest.reset('prueba_salto_largo_scar');
const longJump = window.__grayboxTest.getSim();
Object.assign(longJump.eren, { x: 28.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(longJump.scar, { x: 22.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
for (let i = 0; i < 100 && !longJump.events.some(event => event.type === 'scar_salto_largo_exito'); i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (!longJump.events.some(event => event.type === 'scar_salto_largo_inicio') || !longJump.events.some(event => event.type === 'scar_salto_largo_exito')) throw new Error('Scar no completó físicamente el enlace contextual G2 → G3.');
if (longJump.events.some(event => event.type === 'scar_recuperacion' && event.reason === 'water')) throw new Error('Scar cayó al agua durante su enlace contextual.');
if (Math.abs(longJump.scar.y - 2) > .1 || longJump.scar.x < 27.25) throw new Error('Scar no aterrizó apoyada sobre G3 después del salto largo.');

Object.assign(longJump.eren, { x: 35.25, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
Object.assign(longJump.scar, { x: 30.5, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0, recoveryGrace: 0, traversal: null });
scenarioTime += 16.7; tick(scenarioTime);
if (!longJump.goalPending || longJump.complete) throw new Error('La meta no esperó a Scar antes de celebrar.');
for (let i = 0; i < 120 && !longJump.complete; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (!longJump.complete || !longJump.events.some(event => event.type === 'scar_salto_pinchos_exito') || !longJump.events.some(event => event.type === 'meta_reunion_scar')) throw new Error('Scar no evitó los pinchos o la reunión real no cerró la meta.');
if (longJump.events.some(event => event.type === 'scar_recuperacion' && event.reason === 'spikes')) throw new Error('Scar tocó los pinchos durante la reunión en meta.');

get('playLab').click();
stations.find(button => button.dataset.station === 'E').click();
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keydown', code: 'KeyC', preventDefault() {} });
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keyup', code: 'KeyC', preventDefault() {} });
for (let i = 0; i < 8; i++) { scenarioTime += 16.7;tick(scenarioTime); }
if (get('metricScar').textContent !== 'ESPERA') throw new Error('La orden independiente a Scar no cambió su estado.');

stations.find(button => button.dataset.station === 'F').click();
scenarioTime += 16.7;tick(scenarioTime);
const prompt = get('gamePrompt').textContent;
if (!prompt.includes('agua') && !prompt.includes('pinchos')) throw new Error('La estación F no mostró su objetivo de daño.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keydown', code: 'ShiftLeft', preventDefault() {} });
for (let i = 0; i < 111; i++) { scenarioTime += 16.7;tick(scenarioTime); }
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keyup', code: 'ShiftLeft', preventDefault() {} });

get('toggleDebug').click();
get('exportPlaytest').click();
if (!localStorage.getItem('graybox-last-playtest')) throw new Error('No se guardó el registro del playtest.');
const labLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const damageAttempt = labLog.attempts.find(attempt => attempt.events.some(event => event.type === 'daño'));
if (!damageAttempt) throw new Error('La estación F no registró daño y retorno.');
if (labLog.attemptCount < 4) throw new Error('El registro no conservó los intentos anteriores después de reiniciar y cambiar de escena.');
if (!labLog.attempts.some(attempt => attempt.events.some(event => event.type === 'scar_paso_bajo_inicio')) || !labLog.attempts.some(attempt => attempt.events.some(event => event.type === 'scar_en_huella'))) throw new Error('El registro persistente perdió las pruebas de Scar.');
if (labLog.attempts.some(attempt => attempt.tuning.run !== 6)) throw new Error('La velocidad de carrera dejó de estar fijada en 6,0.');
if (labLog.appVersion !== '19.0.0-graybox-layout-scar-jump' || labLog.version !== 'GB01-v4') throw new Error('El registro no identifica la compilación v19.');
if (!labLog.attempts.some(attempt => attempt.summary.scarLongJumpSuccesses === 1 && attempt.summary.goalReunions === 1)) throw new Error('El resumen no conserva el salto largo y la reunión de Scar.');

get('showPlaytest').click();
if (get('playtestLogDialog').classList.contains('hidden') || !get('playtestLogText').value.includes('daño')) throw new Error('El visor de registro no mostró los datos guardados.');
get('closePlaytest').click();
if (!get('playtestLogDialog').classList.contains('hidden')) throw new Error('El visor de registro no se cerró.');

get('showPlaytest').click();
get('copyPlaytestSummary').click();
const compactLog = JSON.parse(localStorage.getItem('graybox-last-playtest-summary'));
if (!compactLog || compactLog.attemptCount !== labLog.attemptCount || compactLog.attempts.some(attempt => attempt.keyEvents.some(event => event.type === 'control_inicio'))) throw new Error('El resumen compacto no filtró correctamente el registro.');
get('closePlaytest').click();

window.__grayboxTest.reset('prueba_intento_vacio');
scenarioTime += 16.7; tick(scenarioTime);
get('showPlaytest').click();
const emptyCountA = JSON.parse(localStorage.getItem('graybox-last-playtest')).attemptCount;
get('closePlaytest').click();
get('showPlaytest').click();
const emptyCountB = JSON.parse(localStorage.getItem('graybox-last-playtest')).attemptCount;
if (emptyCountB !== emptyCountA) throw new Error('Abrir el visor creó un intento vacío en el registro.');

console.log(JSON.stringify({ result: 'ok', speed, state, prompt, attempts: labLog.attemptCount, scarLowPass: true, scarUpperDescent: true, scarLongJump: true, scarSpikeJump: true, goalReunion: true, emptyAttemptsFiltered: true, labDamage: damageAttempt.summary.damageCount, runSpeed: damageAttempt.tuning.run }));
