import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const root = new URL('../app/src/main/assets/www/', import.meta.url);
const html = await readFile(new URL('index.html', root), 'utf8');
const sourceText = await readFile(new URL('graybox-game.js', root), 'utf8');
const source = sourceText.replace(/\n\}\)\(\);\s*$/, `
window.__grayboxTest={getSim:()=>sim,reset:reason=>resetSimulation(reason),commandScar};
})();`);

class ClassList {
  constructor() { this.values = new Set(); }
  add(...names) { names.forEach(name => this.values.add(name)); }
  remove(...names) { names.forEach(name => this.values.delete(name)); }
  contains(name) { return this.values.has(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : !!force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
}

class Element {
  constructor(id = '') {
    this.id = id;
    this.dataset = {};
    this.classList = new ClassList();
    this.listeners = new Map();
    this.style = {};
    this.textContent = '';
    this.value = '';
    this.offsetWidth = 10;
  }
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(callback);
  }
  dispatch(type, extras = {}) {
    const event = { type, target: this, currentTarget: this, preventDefault() {}, pointerId: 1, ...extras };
    for (const callback of this.listeners.get(type) || []) callback(event);
    if (type === 'click' && this.onclick) this.onclick(event);
  }
  click() { this.dispatch('click'); }
  focus() {}
  select() {}
  setPointerCapture() {}
  closest(selector) { return selector === 'button' ? this : null; }
}

const elements = new Map();
for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
const get = id => elements.get(id);
const controlMap = {
  moveUpLeft: 'left up', moveUp: 'up', moveUpRight: 'right up', moveLeft: 'left', moveRight: 'right',
  moveDownLeft: 'left crouch', crouch: 'crouch', moveDownRight: 'right crouch', run: 'run',
};
for (const [id, value] of Object.entries(controlMap)) get(id).dataset.controls = value;
for (const [id, value] of Object.entries({ heightTuning: '3', gapTuning: '4', walkTuning: '3.5', runTuning: '6', jumpTuning: '15.9', gravityTuning: '44' })) get(id).value = value;

const stations = [...'ABCDEF'].map(letter => { const element = new Element(); element.dataset.station = letter; return element; });
const body = new Element('body');
const documentListeners = new Map();
const document = {
  body,
  getElementById: id => get(id),
  querySelectorAll: selector => selector === '[data-controls]' ? [...elements.values()].filter(element => element.dataset.controls) : selector === '[data-station]' ? stations : [],
  createElement: () => new Element(),
  addEventListener(type, callback) {
    if (!documentListeners.has(type)) documentListeners.set(type, []);
    documentListeners.get(type).push(callback);
  },
};

const gradient = { addColorStop() {} };
const context2d = new Proxy({ createLinearGradient: () => gradient }, {
  get(target, key) { if (key in target) return target[key]; return () => {}; },
  set(target, key, value) { target[key] = value; return true; },
});
get('gameCanvas').getContext = () => context2d;
get('gameCanvas').getBoundingClientRect = () => ({ width: 960, height: 540 });

const storage = new Map();
const localStorage = { getItem: key => storage.has(key) ? storage.get(key) : null, setItem: (key, value) => storage.set(key, String(value)) };
const windowListeners = new Map();
let nextFrame = null;
let frameId = 0;
let sharedText = '';
const window = {
  document,
  devicePixelRatio: 1,
  innerWidth: 960,
  innerHeight: 540,
  AndroidShare: { shareText(subject, text) { sharedText = `${subject}\n${text}`; } },
  addEventListener(type, callback) {
    if (!windowListeners.has(type)) windowListeners.set(type, []);
    windowListeners.get(type).push(callback);
  },
  dispatchEvent(event) { for (const callback of windowListeners.get(event.type) || []) callback(event); },
  requestAnimationFrame(callback) { nextFrame = callback; return ++frameId; },
  cancelAnimationFrame() { nextFrame = null; },
};

const sandbox = {
  window, document, navigator: { getGamepads: () => [] }, localStorage,
  requestAnimationFrame: window.requestAnimationFrame.bind(window), cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
  Blob, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, setTimeout: callback => { callback(); return 1; }, clearTimeout() {},
  console,
  completedStories: () => new Set(), stopNarration() {}, show(id) { get(id).classList.remove('hidden'); },
  tone() {}, playAzureSequence() {}, renderMenu() {},
};
window.localStorage = localStorage;
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: 'graybox-game.js' });

get('directGame').click();
if (!body.classList.contains('game-mode')) throw new Error('El acceso directo no abrió el juego sin completar un cuento.');

const tick = time => {
  const callback = nextFrame;
  if (!callback) throw new Error('No hay frame de juego pendiente.');
  nextFrame = null;
  callback(time);
};
tick(16.7);

window.dispatchEvent({ type: 'keydown', code: 'Space', preventDefault() {} });
for (let i = 2; i < 15; i++) tick(i * 16.7);
const state = get('metricState').textContent;
if (state !== 'AIRE') throw new Error(`El salto no produjo estado AIRE: ${state}`);
window.dispatchEvent({ type: 'keyup', code: 'Space', preventDefault() {} });
for (let i = 15; i < 61; i++) tick(i * 16.7);

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
for (let i = 61; i < 80; i++) tick(i * 16.7);
const speed = get('metricSpeed').textContent;
if (!speed || speed === '0,0 m/s') throw new Error('La física no respondió al movimiento horizontal.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });

window.dispatchEvent({ type: 'keydown', code: 'KeyX', preventDefault() {} });
tick(1350);
window.dispatchEvent({ type: 'keyup', code: 'KeyX', preventDefault() {} });
tick(1367);
get('exportPlaytest').click();
const grayboxLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const grayboxAttempt = grayboxLog.attempts.at(-1);
if (!grayboxAttempt.events.some(event => event.type === 'caja_rota')) throw new Error('La acción no rompió la caja dentro del rango funcional.');
if (!sharedText.includes('Registro playtest') || !sharedText.includes('caja_rota')) throw new Error('El puente de compartir no recibió el registro del playtest.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowDown', preventDefault() {} });
for (let i = 83; i < 91; i++) tick(i * 16.7);
if (get('metricState').textContent !== 'AGACHADO') throw new Error('El collider agachado no se activó.');
window.dispatchEvent({ type: 'keyup', code: 'ArrowDown', preventDefault() {} });

const placeActorsForScarTest = (scarX, scarY) => {
  const live = window.__grayboxTest.getSim();
  Object.assign(live.eren, { x: 15.75, y: 2, vx: 0, vy: 0, onGround: true, crouched: false, w: 1, h: 1.5, facing: 1 });
  Object.assign(live.scar, { x: scarX, y: scarY, vx: 0, vy: 0, onGround: true, crouched: false, w: 1.5, h: 1, mode: 'follow', navPhase: 'follow', navTargetX: null, navTargetY: null, navStuck: 0, recoverTimer: 0 });
  window.__grayboxTest.commandScar();
  return live;
};

let scenarioTime = 1520;
let lowerScar = placeActorsForScarTest(11.05, 2);
for (let i = 0; i < 420 && lowerScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (lowerScar.scar.mode !== 'wait' || Math.abs(lowerScar.scar.y - 2) > .1) throw new Error('Scar no llegó físicamente a la placa desde detrás del túnel.');
if (!lowerScar.events.some(event => event.type === 'scar_paso_bajo_inicio') || !lowerScar.events.some(event => event.type === 'scar_en_huella')) throw new Error('No se registró el paso bajo y la llegada de Scar.');

window.__grayboxTest.reset('prueba_scar_desde_abajo');
let upperScar = placeActorsForScarTest(15.75, 4.5);
for (let i = 0; i < 720 && upperScar.scar.mode !== 'wait'; i++) { scenarioTime += 16.7; tick(scenarioTime); }
if (upperScar.scar.mode !== 'wait' || Math.abs(upperScar.scar.y - 2) > .1) throw new Error(`Scar validó mal o no bajó desde U1: ${upperScar.scar.x.toFixed(2)}, ${upperScar.scar.y.toFixed(2)}, ${upperScar.scar.navPhase}`);
if (!upperScar.events.some(event => event.type === 'scar_ruta' && event.phase === 'bajar_u1_a_techo') || !upperScar.events.some(event => event.type === 'scar_en_huella')) throw new Error('La ruta de descenso U1 → placa no quedó registrada.');

get('playLab').click();
stations.find(button => button.dataset.station === 'E').click();
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keydown', code: 'KeyC', preventDefault() {} });
scenarioTime += 16.7;tick(scenarioTime);
window.dispatchEvent({ type: 'keyup', code: 'KeyC', preventDefault() {} });
for (let i = 0; i < 8; i++) { scenarioTime += 16.7;tick(scenarioTime); }
if (get('metricScar').textContent !== 'ESPERA') throw new Error('La orden independiente a Scar no cambió su estado.');

stations.find(button => button.dataset.station === 'F').click();
scenarioTime += 16.7;tick(scenarioTime);
const prompt = get('gamePrompt').textContent;
if (!prompt.includes('agua') && !prompt.includes('pinchos')) throw new Error('La estación F no mostró su objetivo de daño.');

window.dispatchEvent({ type: 'keydown', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keydown', code: 'ShiftLeft', preventDefault() {} });
for (let i = 0; i < 111; i++) { scenarioTime += 16.7;tick(scenarioTime); }
window.dispatchEvent({ type: 'keyup', code: 'ArrowRight', preventDefault() {} });
window.dispatchEvent({ type: 'keyup', code: 'ShiftLeft', preventDefault() {} });

get('toggleDebug').click();
get('exportPlaytest').click();
if (!localStorage.getItem('graybox-last-playtest')) throw new Error('No se guardó el registro del playtest.');
const labLog = JSON.parse(localStorage.getItem('graybox-last-playtest'));
const damageAttempt = labLog.attempts.find(attempt => attempt.events.some(event => event.type === 'daño'));
if (!damageAttempt) throw new Error('La estación F no registró daño y retorno.');
if (labLog.attemptCount < 4) throw new Error('El registro no conservó los intentos anteriores después de reiniciar y cambiar de escena.');
if (!labLog.attempts.some(attempt => attempt.events.some(event => event.type === 'scar_paso_bajo_inicio')) || !labLog.attempts.some(attempt => attempt.events.some(event => event.type === 'scar_en_huella'))) throw new Error('El registro persistente perdió las pruebas de Scar.');
if (labLog.attempts.some(attempt => attempt.tuning.run !== 6)) throw new Error('La velocidad de carrera dejó de estar fijada en 6,0.');

get('showPlaytest').click();
if (get('playtestLogDialog').classList.contains('hidden') || !get('playtestLogText').value.includes('daño')) throw new Error('El visor de registro no mostró los datos guardados.');
get('closePlaytest').click();
if (!get('playtestLogDialog').classList.contains('hidden')) throw new Error('El visor de registro no se cerró.');

console.log(JSON.stringify({ result: 'ok', speed, state, prompt, attempts: labLog.attemptCount, scarLowPass: true, scarUpperDescent: true, labDamage: damageAttempt.summary.damageCount, runSpeed: damageAttempt.tuning.run }));
